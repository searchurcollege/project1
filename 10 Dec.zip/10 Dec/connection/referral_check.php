<?php
    include('dbconnect.php');
    $referral=$_REQUEST['referral'];
    $sql="SELECT partner_id, partner_referral_code FROM suc_partner_referral_code WHERE partner_referral_code='$referral'";
    $result=$conn->query($sql);
    $i=0;
    while($row=$result->fetch_assoc())
    {
        $partner_id=$row['partner_id'];
        $sql2="SELECT partner_no_of_users FROM suc_partners WHERE partner_id=$partner_id";
        $result2=$conn->query($sql2);
        while($row2=$result2->fetch_assoc())
        {
            $partner_no_of_users=$row2['partner_no_of_users'];
            $sql3="SELECT COUNT(partner_id) AS count FROM suc_partner_users WHERE partner_id=$partner_id";
            $result3=$conn->query($sql3);
            while($row3=$result3->fetch_assoc())
                $count=$row3['count'];
            $count=$partner_no_of_users-$count;
            if($count>=1)
            {
                session_start();
                $email=$_SESSION['email'];
                $sql4="INSERT INTO suc_partner_users (partner_id, user_id, user_status) VALUES ($partner_id, '$email', 1)";
                $result4=$conn->query($sql4);
            }
            else
                $i++;
        }
        $i++;
    }
    if($i==0)
        $data=0;
    else
    if($i==2)
        $data=2;
    else
    {
        session_start();
        $email=$_SESSION['email'];
        $sql="UPDATE users SET referral_code='$referral', amt_paid=199, balance_amt=0 WHERE email='$email'";
        $result=$conn->query($sql);
        $data=1;
    }
    echo $data;
?>