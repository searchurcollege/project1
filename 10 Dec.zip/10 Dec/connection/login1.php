<?php
    include('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">

    <title>Clean Modal Login Form - Bootsnipp.com</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    @import url(http://fonts.googleapis.com/css?family=Roboto);

/****** LOGIN MODAL ******/
.loginmodal-container {
  padding: 30px;
  max-width: 350px;
  width: 100% !important;
  background-color: #F7F7F7;
  margin: 0 auto;
  border-radius: 2px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  font-family: roboto;
}

.loginmodal-container h1 {
  text-align: center;
  font-size: 1.8em;
  font-family: roboto;
}

.loginmodal-container input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  position: relative;
}

.loginmodal-container input[type=text], input[type=password] {
  height: 44px;
  font-size: 16px;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  /* border-radius: 2px; */
  padding: 0 8px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.loginmodal-container input[type=text]:hover, input[type=password]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.loginmodal {
  text-align: center;
  font-size: 14px;
  font-family: 'Arial', sans-serif;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
/* border-radius: 3px; */
/* -webkit-user-select: none;
  user-select: none; */
}

.loginmodal-submit {
  /* border: 1px solid #3079ed; */
  border: 0px;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1); 
  background-color: #4d90fe;
  padding: 17px 0px;
  font-family: roboto;
  font-size: 14px;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
}

.loginmodal-submit:hover {
  /* border: 1px solid #2f5bb7; */
  border: 0px;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
}

.loginmodal-container a {
  text-decoration: none;
  color: #666;
  font-weight: 400;
  text-align: center;
  display: inline-block;
  opacity: 0.6;
  transition: opacity ease 0.5s;
} 

.login-help{
  font-size: 12px;
}    </style>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
</head>
<body>
   

<div  class="col-md-12">
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Login to Your Account</h1><br>
				  <form id="frmLogin" action="user_login.php">
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="text" class="form-control" name="email"id="email" placeholder="Email" required />
                    </div>
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="password" class="form-control" name="password" placeholder="Password" required />
                    </div>
                    <div class="col-md-12 text-right" style="margin-top: 10px;">
                        <button type="submit" class="btn btn-success pull-left">Login</button>
                        <button id="fp" class="btn btn-warning pull-left" style="margin-left: 10px;">Forgot Password</button>
                        <br /><br /><span class="pull-right" style="margin-top: 7px; font-weight: bold;">
                            New user ? <a href="https://www.searchurcollege.com/connection/register1.php"><span style="margin-right: 10px; cursor: pointer; color: #5D9BD0;">Register Here</span></a>
                        </span>
                        <div class="row"></div>
                        <span id="success" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Login Succeeded.</span>
                        <span id="success1" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Password send to Email.</span>
                        <span id="error" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Invalid Credentials</span>
                         <span id="error1" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Something Wrong, Please click on Forget Password</span>
                    </div>
                </form>
					
				  
				</div>
			</div>
		  </div>	<script type="text/javascript">
		</script>
    <script type="text/javascript">
        //Login User
        $('#frmLogin').submit(function(event) {
          //alert(window.location.pathname);
          $.post(
           'https://www.searchurcollege.com/connection/user_login.php',
            $(this).serialize(),
            function(data)
            {
                if(data=='1')
                {
                    $("#success").show();
                    eid=$('#eid').val();
                    setTimeout(function() { $("#success").hide(); }, 3000);
                    if(eid>0)
                        window.location.href = "https://www.searchurcollege.com/exam/start-exam/"+eid;
                    else
                    {
                        window.location.href = "https://www.searchurcollege.com";
                    }
                }
                else
                if(data=='2')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                if(data==0)
                {
                    $("#error").show();
                    setTimeout(function() { $("#error").hide(); }, 3000);
                }
                else
                {
                    window.location.href = "https://www.searchurcollege.com/connection/alert.php?email="+data;
                }
            }
          );
          //alert("11");
          return false; 
        }); 
</script>

<script type="text/javascript">
        //Login User
        $('#fp').click(function(event) {
            email=$('#email').val();
         // alert("window.location.pathname");
          $.post(
           'https://www.searchurcollege.com/connection/forget_pass.php?email='+email,
            
            function(data)
            {
                //alert(data);
                if(data=='1')
                {
                     
                    $("#success1").show();
                    setTimeout(function() { $("#success1").hide(); }, 3000);
                       
                    
                }
                
                else
                if(data=='0')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                {
                    $("#error1").show();
                    setTimeout(function() { $("#error1").hide(); }, 4000);
                }
            }
          );
          return false;   
        }); 
</script>


</body>
</html>
