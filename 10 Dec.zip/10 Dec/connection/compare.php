<style>
@media (min-width: 992px){
.col-md-9 {
    width: 73%!important;
}
}
</style>
<div class="container">
    <center><div class="row">
        <div class="col-md-9 my-4 mx-auto">
          
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsve">
                    <table class="table table-striped table-hover">
                      <thead class="thead-inverse">
                        <tr>
                            <th class="w-25"></th>
                            <th class="">Standard</th>
                            <th class="">Premium</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td class="w-25 option">Top Colleges & Universities</td>
                          <td><i class="fa fa-check"></i></td>
                          <td><i class="fa fa-check"></i></td>
                        </tr>
                        <tr>
                          <td class="option">Eligibility & Admission</td>
                          <td><i class="fa fa-check"></i></td>
                          <td><i class="fa fa-check"></i></td>
                        </tr>
                        <tr>
                          <td class="option">College Rankings</td>
                          <td><i class="fa fa-check"></i></td>
                          <td><i class="fa fa-check"></i></td>
                        </tr>
                        <tr>
                          <td class="option">College Brochures</td>
                          <td><i class="fa fa-check"></i></td>
                          <td><i class="fa fa-check"></i></td>
                        </tr>
                        <tr>
                        <?php
                            for($i=0;$i<sizeof($a);$i++)
                             {
                              echo '<td class="option">'.$a[$i].'</td>';
                             }
                              echo '<td class="option">Covering '.$c.' and many more...</td>';
                        ?>
                          <td>-</td>
                          <td><i class="fa fa-check"></i></td>
                        </tr>
                        <tr>
                          <td class="option">10 Years Questions Bank</td>
                          <td>-</td>
                          <td><i class="fa fa-check"></i></td>
                        </tr>
                        <tr>
                          <td class="option">Tests History & Progress Tracking</td>
                          <td>-</td>
                          <td><i class="fa fa-check"></i></td>
                        </tr>
                        <tr>
                          <td class="option">Important Dates - Mobile Alerts</td>
                          <td>-</td>
                          <td><i class="fa fa-check"></i></td>
                          
                        </tr>
                       
                      </tbody>
                      
                    </table>
                </div>
                </div>
            </div>
        </div>
    </div></center>
</div>

<table class="table stable-striped">
                            <tr style="background: gray; color: white;"><td width="45%" style="background: #F2F2F2; color: black; border: 0px; text-align: left;"><b>Checkout the benifits</b></td><td><b>Standard</b></td><td style="background: green"><b>Premium</b></td></tr>
                            <tr><td class="first">Top Colleges & Universities</td><td class="second"><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">Eligibility & Admission</td><td class="second"><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">College Rankings</td><td class="second"><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">College Brochures</td><td class="second"><img src="../img/tick.png" height="20" /><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                            <?php
                                for($i=0;$i<sizeof($a);$i++)
                                {
                                    echo '<tr><td class="first">'.$a[$i].'</td><td class="second"></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>';
                                }
                                //echo '<tr><td colspan="2" class="first">Covering '.$c.' and many more...</td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>';
                                echo '<tr><td class="first">Covering '.$c.' and many more...</td><td class="second"></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>';
                            ?>
                            <tr><td class="first">10 Years Questions Bank</td><td class="second"></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">Tests History & Progress Tracking</td><td class="second"></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">Important Dates - Mobile Alerts</td><td class="second"></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                            <!--<tr><td class="first">365 Days Support</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>
                            <tr><td class="first">Career Guidance</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>-->
                    </table>