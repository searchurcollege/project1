<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'/>
<?php
    include('dbconnect.php');
    //session_start();
    $eid=$_SESSION['eid'];
    echo '<input type="hidden" id="eid" value="'.$eid.'" />';
    $name=$_REQUEST['na'];
    $city=$_REQUEST['ct'];
    $email=$_REQUEST['em'];
    $phone=$_REQUEST['ph'];
    $pm=199;
    $ap=199;
    $ba=$pm-$ap;
    $order_id=$_REQUEST['order_id'];
    $tracking_id=$_REQUEST['tracking_id'];
    $order_status=$_REQUEST['order_status'];
    $payment_mode=$_REQUEST['payment_mode'];
    $sql="UPDATE users SET premium_amt='$pm', amt_paid='$ap', balance_amt='$ba', order_id='$order_id', order_date='$order_date', tracking_id=$tracking_id, order_status='$order_status', 'payment_mode='$payment_mode' WHERE contact='$phone'";
    $result=$conn->query($sql);
    echo '<br /><br /><br /><center>';
    echo '<span id="msg1"><h3>Please do not refresh Page. We are into payment process <img class="img-responsive" src="../img/loading.gif" height="20" /><h3></span>';
    echo '<span id="msg2" style="display: none;"><h3>Payment of &nbsp;<i class="fa fa-inr fa-sm"><b> 199-/</b></i> is made successfully<br /> Redirecting now... <img class="img-responsive" src="../img/loading.gif" height="20" /></span>';
    $msg='Received a sum of Rs.'.$pm.'/- agst. Premium Membership with www.searchurcollege.com';
    $url='http://nimbusit.co.in/api/swsendSingle.asp?username=t1searchurcollege&password=ranjay786&sender=SEARCH&sendto='.$phone.'&message='.$msg;
    $url=str_replace(" ", '%20', $url);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    //$response = curl_exec($ch);
    curl_close($ch);
?>

<script>
    $(document).on("ready", function () {
        eid=$('#eid').val();
        url='https://www.searchurcollege.com/exam/start-exam/'+eid;
        setTimeout(function() {
            $(location).attr('href', url)
        }, 5000);
    });
</script>