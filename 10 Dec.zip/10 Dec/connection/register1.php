<?php
    include('header3.php');
    error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">

    <title>SearchUrCollege - Register</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    @import url(http://fonts.googleapis.com/css?family=Roboto);

/****** LOGIN MODAL ******/
.loginmodal-container {
  padding: 30px;
  max-width: 350px;
  width: 100% !important;
  background-color: #F7F7F7;
  margin: 0 auto;
  border-radius: 2px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  font-family: roboto;
}

.loginmodal-container h1 {
  text-align: center;
  font-size: 1.8em;
  font-family: roboto;
}

.loginmodal-container input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  position: relative;
}

.loginmodal-container input[type=text], input[type=password] {
  height: 44px;
  font-size: 16px;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  /* border-radius: 2px; */
  padding: 0 8px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.loginmodal-container input[type=text]:hover, input[type=password]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.loginmodal {
  text-align: center;
  font-size: 14px;
  font-family: 'Arial', sans-serif;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
/* border-radius: 3px; */
/* -webkit-user-select: none;
  user-select: none; */
}

.loginmodal-submit {
  /* border: 1px solid #3079ed; */
  border: 0px;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1); 
  background-color: #4d90fe;
  padding: 17px 0px;
  font-family: roboto;
  font-size: 14px;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
}

.loginmodal-submit:hover {
  /* border: 1px solid #2f5bb7; */
  border: 0px;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
}

.loginmodal-container a {
  text-decoration: none;
  color: #666;
  font-weight: 400;
  text-align: center;
  display: inline-block;
  opacity: 0.6;
  transition: opacity ease 0.5s;
} 

.login-help{
  font-size: 12px;
}    </style>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
</head>
<body>
   

<div class="col-md-12">
          <div class="modal-dialog">
                <div class="loginmodal-container">
                    <h1>Register</h1><br>
                  <form id="frmRegister" action="user_register.php">
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <select id="L1" name="last_qualification" class="form-control" rrequired>
                                <option disabled selected>Last Qualification</option>
                                <?php
                                    include_once('functions.php');
                                    include_once('dbconnect.php');
                                    $result=selectCourse();
                                    while($row=$result->fetch_assoc())
                                    {
                                        $id=$row['id'];
                                        echo '<option value="'.$id.'">'.$row["course_master_name"].'</option>';
                                    }
                                ?>
                            </select>
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <select id="course_interested" name="course_interested" class="form-control" style="width: 100%; text-align :center; ackground: red;" rrequired>
                            <option disabled selected>Course Looking for</option>
                            
                            
                            </select>
                        </span>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control iinput-md" id="first_name" name="first_name" placeholder="First Name" rrequired />
                          <span class="input-group-btn" style="width: 0px;"></span>
                          <input type="text" class="form-control input-md" id="last_name" name="last_name" placeholder="Last Name" rrequired />
                        </div>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input id="email2" type="email" class="form-control" name="email" placeholder="Email" rrequired />
                        </span>
                        <span class="input-group">
                            <span class="input-group"><span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" name="password1" placeholder="Password" rrequired />
                        </span>
                        <span class="input-group">
                            <span class="input-group"><span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" name="password2" placeholder="Confirm Password" rrequired />
                        </span>
                        <span class="input-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="Contact No." rrequired />
                            </div>
                        </span>
                        <span class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                            
                            <select id="cl" name="current_location" class="form-control" style="width: 100%!important;" rrequired>
                                <option disabled selected>Current Location</option>
                                <?php
                                   include('dbconnect.php');
                                   $sql="SELECT * FROM location";
                                   $result=$conn->query($sql);
                                   while($row=$result->fetch_assoc())
                                   {
                                        $id=$row['id'];
                                        echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
                                   }
                                ?> 
                            </select>
                            </span>
                        </span>
                        <span class="input-group" style="margin-top: 10px;">
                            <span class="input-group-addon"><i class="fa fa-flag-checkered"></i></span>
                            <select id="c2" name="preferred_location" class="form-control" style="width: 100%!important;" rrequired>
                            <!-- <input list="preferred_location" id="c2" name="preferred_location" class="form-control" placeholder="Preferred Location" required /> -->
                            <option disabled selected>Preferred Location</option>
                                <?php
                                   $sql="SELECT * FROM location";
                                   $result=$conn->query($sql);
                                   while($row=$result->fetch_assoc())
                                   {
                                        $id=$row['id'];
                                        echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
                                   }
                                ?> 
                            </select>
                        </span>
                        <span class="input-group" style="margin-top: 10px;">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <select name="reference" id="r1" class="form-control">
                                <option selected disabled>Select Reference</option>
                                <option value="Facebook">Facebook</option>
                                <option value="Whatsapp">Whatsapp</option>
                                <option value="SMS">SMS</option>
                                <option value="Email">Email</option>
                                <option value="Internet">Internet</option>
                                <option value="Friend">Friend</option>
                                <option value="Coaching/Tuition">Coaching/Tuition</option>
                                <option value="School/College">School/College</option>
                                <option value="Others">Others</option>
                            </select>
                            <input type="text" class="col-md-6 form-control" id="reference_name" name="reference_name" placeholder="Name Source" style="display: none;" />
                            </span>
                        </span>
                        <center><div style="ppadding: 0px;" class="g-recaptcha pull-right" data-sitekey="6LdkqGsUAAAAAHaGJsKsrkrvewL8eWH2U_xGOttR"></div></center>
                        <div class="col-md-12" style="padding: 0px;"><br />
                        <div class="col-md-5">
                            Already Registered ?</b>
                            <br /><a href="https://www.searchurcollege.com/connection/login1.php" style="color: #5D9BD0;"><b>Login Here</b></a>
                        </div>
                        <div class="col-md-7">
                            <div id="msg">
                                <span id="rsuccess" class="pull-right" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> <span id="m1"></span></span>
                                <span id="rerror" class="pull-right" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <span id="m2"></span></span>
                            </div>
                            <button id="sub" type="submit" class="btn btn-primary pull-right">Register</button>
                        </div>
                        <div id="regButton" class="col-md-4" style="display: none; background: #DE4313;">
                        </div>
                        </div>
                        <br /><br />
                    </form>
                    
                  
                </div>
            </div>
          </div>    
      <div id="otp" style="display: none; z-index: 10000; color: black;">
    <center>
    <form id="frmOTP">
        <h4>Enter OTP sent to your mobile</h4>
        <br />
        <div class="input-group">
            <input type="text" class="form-control" id="otp_box" name="otp" placeholder="OTP" sstyle="width: 150px;" required />
            <span class="input-group-btn">
                <button type="submit" class="btn btn-success">Go</button>
            </span>
        </div>
        <div id="v5" style="display: block;">Not received? <a class="resendOTP" href="">Resend OTP</a></div>
        <div id="v4" style="display: none;"><span style="font-weight: bold;">OTP sent</span><i class="fa fa-send" style="margin-left: 5px; margin-top: 20px;"></i></div>
        <div id="v1" style="display: none;"><span style="font-size: 20px; font-weight: bold;">Verifying</span><i class="fa fa-circle-o-notch fa-spin" style="font-size: 24px; margin-left: 5px; margin-top: 20px;"></i></div>
        <div id="v2" style="display: none;"><span style="color: green; font-weight: bold;">Number Verified</span><i class="fa fa-check" style="font-size: 24px; margin-left: 5px; margin-top: 20px; color: green;"></i></div>
        <div id="v3" style="display: none;"><span style="color: red; font-weight: bold;">Incorrect OTP</span><!--<i class="fa fa-close" style="margin-left: 5px; margin-top: 20px; color: red; margin-right: 10px; font-weight: bold;"></i><a class="resendOTP" href="">Resend OTP?</a></div>-->
    </form>
    </center>
</div>
<script type="text/javascript">
        </script>
    <sscript src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    $('#why_head').click(function(){
        $(this).find('i').toggleClass('fa-plus fa-minus')
        $('#msg1').toggle().fade();
    });
</script>

<script type="text/javascript">
    $(document).ready(function(){

        $('#L1').change(function(event) {
          $('#L2').val('');
          id=$('#L1').val();
          $.post(
           'https://www.searchurcollege.com/connection/info.php?id='+id,
            $(this).serialize(),
            function(data){
              $("#course_interested").html(data);
            }
          );
          return false;
        });   

        //Register User
        $('#frmRegister').submit(function(event) {
          $.post(
           'https://www.searchurcollege.com/connection/user_register.php',
            $(this).serialize(),
            function(data){
                //$('#v3').fadeIn().delay(2000).fadeOut();
                if(data==1 || data.substring(0,3)=="Log")
                {
                    $('#m1').text(data);
                    $("#frmRegister input").prop("disabled", true);
                    $("#frmRegister select").prop("disabled", true);
                    $('#sub').prop('disabled', true);
                    $('#rsuccess').css('display','block');
                    $('#rsuccess').fadeIn().delay(2000).fadeOut();
                    $('#otp').css('display', 'block');
                    $('#otp_box').focus();
                }
                else
                {
                    $('#m2').text(data);
                    $('#rerror').css('display','block');
                    $('#rerror').fadeIn().delay(2000).fadeOut();
                }
          });
          return false;   
        });

        //Verify OTP
        $('#frmOTP').submit(function(event) {
          phone=$('#phone').val();
          $('#v1').show();
          $.post(
           'https://www.searchurcollege.com/connection/verify_otp.php?phone='+phone,
            $(this).serialize(),
            function(data){
              $('#v1').hide();
                if(data=='found' || data.substring(0,3)=="Log")
              {
                $('#v2').show();
                $('#v3').hide();
                $('#v4').hide();
                $('#v5').hide();
                $('#na').val($('#first_name').val()+' '+$('#last_name').val());
                $('#ct').val($('#city').val());
                $('#ph').val($('#phone').val());
                $('#em').val($('#email2').val());
                //$('#register .close').click();
                setTimeout(function() {
                    $('#otp').hide();
                    //$('#col3').css('display','block');
                    //location.reload();
                    $("#d").removeClass("modal-lg"); 
                    $("#register").removeClass("modal-lg");
                    //alert("11");
                    $('#col1').css('display','none');
                    $('#col2').css('display','none');
                }, 2000);
                window.location.href = "https://www.searchurcollege.com";
              }
              else
              {
                $('#v2').hide();
                $('#v3').show();
                $('#v4').hide();
              }
            }
          );
          return false;   
        });   

        //Resend OTP
        $('.resendOTP').click(function(event) {
          $('#v1').hide();
          $('#v2').hide();
          $('#v3').hide();
          $('#v4').fadeIn().delay(2000).fadeOut();
          $('#v5').fadeOut().delay(2000).fadeIn();
          phone=$('#phone').val();
          $.post(
           'https://www.searchurcollege.com/connection/resend_otp.php?phone='+phone,
            $(this).serialize(),
            function(data){

            }
          );
          return false;   
        });   
    });
    $('#pclose').on('click', function () {
        location.reload();
    });
    $("#r1").on('input', function () {
        var val = this.value;
        if(val=='Others' || val=='Coaching/Tuition' || val=='School/College')
        {
            $("#r1").removeClass("col-md-12");
            $("#r1").addClass("col-md-6");
            $('#reference_name').show();
            $('#reference_name').focus();
        }
        else
        {
            $("#r1").removeClass("col-md-6");
            $("#r1").addClass("col-md-12");
            $('#reference_name').hide();
        }
    });
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.css">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    //select2 
  // $("#course_interested").select2();
  // $("#cl").select2();
  // $("#c2").select2();

});
</script>

</body>
</html>
