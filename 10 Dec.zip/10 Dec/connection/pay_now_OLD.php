<?php
    include('header.php');
    $ph=$_SESSION['contact'];
    $stream=$_SESSION['stream'];
    include('dbconnect.php');

    $sql1="SELECT super_cat_id FROM `tbl_course_category` WHERE category='$stream'";
        $result1=$conn->query($sql1);
        foreach ($result1 as $var1)
            $master_id=$var1['super_cat_id'];
?>
    <style type="text/css">
        li{
            font-size: 15px;
        }

    </style>

    <div class="container" style="margin-top: 40px;">
        <div class="col-md-3"></div>
        <div class="col-md-6">
    		<div class=".why" style="ddisplay: none; background: #DAEBFA; padding: 10px; text-align: left; color: black!important;">
                <h3 style="color: #5D9BD0;"><i class="fas fa-info-circle fa-lg"></i>
                <b>Premium Membership Offer</h3>
                <span style="position: absolute; top: 10px; right: 30px;" onclick="location.href = 'https://www.searchurcollege.com/exam/home/?id=1'"><button class="btn btn-default btn-sm pull-left"><i class="fa fa-times"  aria-hidden="true"></i></button></span> </b>
                <br /><h4>Get the <b style="color: green;">Premium</b> benifits <strong>only @ <i class="fa fa-inr"></i> 199/- </strong></h4>
                <br />
                
                    
                    <span><!--<i class="pull-right fa fa-info"></i>-->
                    <span id="msg1" class="div-no-mobile"><br />
                        <lh><h4><strong> What will you get: </strong></h4></lh></br>
                    <ul>
                        <?php 
                            $sql="SELECT exam_exercise_name from cat03_exam_exercise where super_cat_id='$master_id' order by sort_order LIMIT 5" ;
                            $result=$conn->query($sql);
                            if($result->num_rows>0){
                                foreach ($result as $var) {
                                    $exams_name=$var['exam_exercise_name'];  
                                   
                                    ?> 
                                  <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Last 10 years question banks for <strong> <?php echo $exams_name ?>.</strong></li> <?php
                                }
                              //  echo $master_id
                            }
                        ?>
                        
                       
                        
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp There will be more 40,000 questions</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Minimum 10 sets of chapter wise practice test for each subject in MBA syllabus</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Unlimited full length practice test & Colleges</li>
                    </br>
                   
                        <lh><h4><strong> Information About:</strong></h4></lh></br>
                    <ul>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp   Exams </li>
                       
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp  Courses</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspTop Colleges & Universities</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspEligibility Criteria For Admission</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspRanking of Universities & Colleges</li>
                       
                    </ul>
                </br>
                   </span>
             <!--   <table class="table stable-striped" border=1>
                    <tr style="background: gray; color: white;"><td width="45%"><b>Benifits</b></td><td><b>Standard</b></td><td style="background: green"><b>Premium</b></td></tr>
                    <tr><td class="first">10 Years Questions Bank</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Tests History & Progress Tracking</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Important Dates - Mobile Alerts</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>

                    
                    <?php
                        $c='Relevant Subjects';
                        for($i=0;$i<sizeof($a);$i++)
                        {
                            //  echo '<tr><td class="first">'.$a[$i].'</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>';
                        }
                       // echo '<tr><td colspan="2" class="first">Covering '.$c.' and many more...</td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>';
                    ?>

                    <tr><td class="first">Top Colleges & Universities</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Eligibility & Admission</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">College Rankings</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">College Brochures</td><td><img src="../img/tick.png" height="20" /><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    
                   <tr><td class="first">365 Days Support</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>
                    <tr><td class="first">Career Guidance</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>
                </table> -->
                <center>
                	   <form method="POST" name="customerData" action="https://www.searchurcollege.com/cca/ccavRequestHandler.php">
                            <!--<input type="hhidden" id="na" name="na" />
                            <input type="hhidden" id="ct" name="ct" />
                            <input type="hhidden" id="ph" name="ph" />
                            <input type="hhidden" id="em" name="em" />-->
                            <?php
                                $dateTimeObject = new DateTime('now');
                                $tn=$dateTimeObject->format('Ymdhis');
                                $uid=$_SESSION['uid'];
                                $oid=$uid.'-'.$dateTimeObject->format('Ymdhis');
                            ?>
                            <input type="hidden" name="tid" id="tid" value="<?php echo $tn;?>" rreadonly />
                            <input type="hidden" name="merchant_id" value="188437"/>
                            <input type="hidden" name="order_id" value="<?php echo $oid;?>"/>
                            <input type="hidden" name="amount" value="199"/>
                            <input type="hidden" name="currency" value="INR"/>
                            <input type="hidden" name="redirect_url" value="https://www.searchurcollege.com/cca/success.php" />
                            <input type="hidden" name="cancel_url" value="https://www.searchurcollege.com/cca/failure.php" />
                            <input type="hidden" name="language" value="EN"/>
                            <input type="hidden" id="na" name="billing_name" value="<?php echo $_SESSION['user_name']?>" />
                            <input type="hidden" id="ct" name="billing_city" />
                            <input type="hidden" id="ph" name="billing_tel" value="<?php echo $_SESSION['contact']?>" />
        		        	<input type="hidden" id="em" name="billing_email" value="<?php echo $_SESSION['email']?>" />
                        <button type="submit" class="btn btn-primary">Complete your Payment</button>
                    </form>
                </center>
    		</div>
		</div>
    </div>        
