    <link href="https://fonts.googleapis.com/css?family=Noto+Serif+KR" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="https://www.searchurcollege.com/img/favicon.ico">
    <llink rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/style.css">
    <style>
        @import url("https://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css");
    </style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.1.1/css/bootstrap.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<?php
if(!isset($_SESSION)) 
 session_start();
 
?>
<!DOCTYPE html>
<html>

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=0">
    
    <link rel="stylesheet" href="https://www.searchurcollege.com/demo.css" />
    <script src="https://www.searchurcollege.com/hc-offcanvas-nav.js"></script> 
 
<!-- google file verification-->
<meta name="google-site-verification" content="6EfYIRGsOHzIp52jxpan0ecb5yZdo5KjoPnFuG0GjSI" />
<!--end-->

 
 <!--Bing site tag-->
<meta name="msvalidate.01" content="F04770FCC8B31FAD4D0BACE0D2DBECE2" />
<!--Bing End-->
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-118318912-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-118318912-1');
</script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '438116786600943');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=438116786600943&ev=PageView&noscript=1"
></noscript>
<!-- End Facebook Pixel Code -->






  
  
  </head>
<style>
@media screen and (min-width: 486px) and (max-width: 786px){
.logo{
        width: 50%!important;
        height: 70px!important;
        margin-top: -26px!important;
        padding-top: 10px!important;
        padding-bottom: 10px!important;
        margin-left: 175px!important;
    }
}
@media screen and (min-width: 200px) and (max-width: 486px){
    .logo{
        width: 50%!important;
        height: 70px!important;
        margin-top: -26px!important;
        padding-top: 10px!important;
        padding-bottom: 10px!important;
        margin-left: 75px!important;
    }
    .list {height: 38px;
    margin-bottom: 2px;
    }
    #id, .carousel-indicators {display: none;}
    #onestop {padding-bottom: 10px;}

 .hc-offcanvas-nav h2 {
    background: lightgray!important;
}
.blink_me {
    animation: blinker 1s linear infinite;
}
@keyframes blinker{

    0%{     color: #000;    }
    49%{    color: blue; }
    50%{    color: #ff9934; }
    99%{    color: yellowgreen;  }
    100%{   color: red;    }

}


 
   
}
</style>






  <body>



<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P9BJF7F"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->



<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" sstyle="margin-top: 60px;">
  <div class="col-md-12" style="background: #FF9934!important; height: 50px;">
  <div >
            <a class="toggle" style="margin-top: -10px; margin-left: 10px;">
                <span></span> 
            </a>
            <a class="navbar-brand" href="https://www.searchurcollege.com"><center><img src="https://www.searchurcollege.com/img/header-logo.png" class="logo" /></center></a>
            <!--<a href="https://www.searchurcollege.com/"><img src="https://www.searchurcollege.com/img/user.png"  style="margin-left: 350px; margin-top: -40px;" /></a>-->
            
    </div>        
    </div> 
    
    
           
    <div id="container" style="display: none; background: white; z-index: 1000!important;">

      <header style="z-index: 1000!important;">
            
        <div class="wrapper cf" style="background: white; z-index: 1000!important;">
         
          <nav id="main-nav" >
            <ul style="background: #ff9934; height: 160px;">
                <li>
                <?php
                 if(isset($_SESSION['photo']))
                 
                    echo'<center><img src="https://www.searchurcollege.com/exam/profile/profileImage/'.$_SESSION['photo'].'" id="user" style="margin-top: 0px!important; height: 80px;" /><br />';
                  else
                    echo'<center><img src="https://www.searchurcollege.com/img/user1.png" id="user" style="margin-top: 0px!important; height: 80px;" /><br />';
                  ?>
                
                <!--<center><img src="https://www.searchurcollege.com/img/user1.png" id="user" style="margin-top: 0px!important; height: 80px;" /><br />-->
                <h3 style="margin-top: 2px!important;">
                <?php       
                    if(isset($_SESSION['email']))
                    {
                        if($_SESSION['ba']==0)
                            echo 'Welcome '.$_SESSION['user_name'].' <i class="fa fa-star ffa-spin" title="Premium Member" style="color: #F2FB05; margin-top: -15px;"></i>';
                        else
                            echo 'Welcome '.$_SESSION['user_name'];
                    }else
                    echo 'Welcome User';
                ?>
                
                
                </h3></center>
                </li>
            </ul>
            <ul class="first-nav" style="background: white!important;">
              <li>
                 <a style="color: black!important;" href="https://www.searchurcollege.com/"><b>HOME</b></a>
                 <?php
                           // if(session_status()==PHP_SESSION_NONE)
                            // if(!isset($_SESSION))
                            //session_start();
                            if(isset($_SESSION['email']))
                            {
                                
                                echo '<a href="https://www.searchurcollege.com/exam/home/?id=1"><b>Dashboard</b></a>';
                                echo '<a href="https://www.searchurcollege.com/connection/logout.php"><b>Logout</b></a>';
                            }
                            else
                            {
                                echo '<a href="https://www.searchurcollege.com/connection/login1.php"><b>Login</b></a>';
                                echo '<a href="#" id="log2" data-toggle="modal" data-target="#login2" style="display: none;"><b>Login</b></a>';
                                echo '<a href="https://www.searchurcollege.com/connection/register1.php"><b>Register</b></a>';
                            }
                        ?>
              </li>
              <!--<li  style="background: white!important;">
               
                <a class="bblink_me" style="color: black!important;"><b>PRACTICE TEST &nbsp;&nbsp;<i class="fa fa-pencil blink_me" style="font-size:24px"></i></b></a> 
                <ul>-->
                <?php
                 // if(!isset($_SESSION['email']))
                {
				    echo'<li  style="background: white!important;">
                    <a class="bblink_me" style="color: black!important;"><b>TEST SERIES &nbsp;&nbsp;<i class="fa fa-pencil blink_me" style="font-size:24px"></i></b></a>  
                <ul>';
                	include_once('functions.php');
                    $result=selectStream();
                    while($row=$result->fetch_assoc())
                    {
                        $id=$row['super_cat_id'];
                        if($id<6){
                        //echo '<li><a href="https://www.searchurcollege.com/test/test.php?id='.$id.'">'.$row["super_cat_name"].'</a></li>';
                    
                        echo '<li style="background: white!important;"><a style="color: black!important;" href="https://www.searchurcollege.com/test/test.php?id='.$id.'"><b>'.$row["super_cat_name"].'</b></a></li>';
                    }}
                  echo'</ul>
              </li>';  
                }
               ?>
                
            </ul>

            <ul class="second-nav" style="background: white; color: black!important;">
              <li cclass="devices">
                <a style="color: black!important;"><b>MBA</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a href="#" style="color: black!important;"><b>Courses</b></a>
                    <ul>
                      <li><a style="color: black!important;" href="https://www.searchurcollege.com/colleges/mba-college-list-1"><b>MBA/PGDM</b></a>
                          <a style="color: black!important;" href="https://www.searchurcollege.com/colleges/distance-mba/college-list-1"><b>Distance MBA</b></a>
                          <!--<a href="#">Executive MBA/PGDM</a>
                          <a href="#">Online MBA</a>
                          <a href="#">Part Time MBA</a>-->
                      </li>
                    </ul>
                  </li>
                  <li cclass="television">
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/mba-exams.php" ><b>MBA Exam Details</b></a>
                    <!--<a href="#" >Location of college</a>
                    <a href="#" >Reviews of college</a>
                    <a href="#" >Colleges excepting Scores Exam</a>-->
                  </li>
                  <li cclass="camera">
                    <a style="color: black!important;" href="#"><b>Ranking of College</b></a>
                    
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/ranking/management-2018"><b>2018</b></a>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/ranking/management-2017"><b>2017</b></a>
                        <a style="color: black!important;" href="https://www.topuniversities.com/university-rankings/rankings-by-location/india/2019" target="_blank"><b>QS Ranking</b></a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>
              
              
              <li cclass="devices">
                <a style="color: black!important;"><b>Engineering</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a style="color: black!important;" href="#"><b>Courses</b></a>
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/colleges/engineering-college-list-1"><b>B.E./B.Tech.</b></a>
                        <a style="color: black!important;" href="#"><b>M.E./M.Tech.</b></a>
                        <a style="color: black!important;" href="#"><b>Diploma Courses</b></a>
                        <!--<a href="#">Distance Diploma Courses</a>
                        <a href="#">Distance B.Tech</a>-->
                      </li>
                    </ul>
                  </li>
                  <li cclass="television">
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/engineering-exams.php" ><b>Engineering Exam Details</b></a>
                    <!--<a href="#" >Location of college</a>
                    <a href="#" >Reviews of college</a>
                    <a href="#" >Colleges excepting Scores Exam</a>-->
                  </li>
                  <li cclass="camera">
                    <a style="color: black!important;" href="#"><b>Ranking of College</b></a>
                    
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/ranking/engineering-2018"><b>2018</b></a>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/ranking/engineering-2017"><b>2017</b></a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>
              
              <li cclass="devices">
                <a style="color: black!important;"><b>LAW</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a style="color: black!important;" href="#"><b>Courses<b></a>
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/colleges/law-college-list-1"><b>BA LLB</b></a>
                        <!--<a href="#">BBA LLB</a>
                        <a href="#">LLB</a>
                        <a href="#">LLM</a>-->
                      </li>
                    </ul>
                  </li>
                  <li cclass="television">
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/law-exams.php" ><b>LAW Exam Details</b></a>
                    <!--<a href="#" >Location of college</a>
                    <a href="#" >Reviews of college</a>
                    <a href="#" >Colleges excepting Scores Exam</a>-->
                  </li>
                  <li cclass="camera">
                    <a style="color: black!important;" href="#"><b>Ranking of College</b></a>
                    
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/ranking/law-2018"><b>2018</b></a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>
              
              <li cclass="devices">
                <a style="color: black!important;"><b>DESIGN</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a style="color: black!important;" href="#"><b>Courses</b></a>
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="#"><b>Communication Design</b></a>
                        <a style="color: black!important;" href="#"><b>Fashion Design</b></a>
                        <a style="color: black!important;" href="#"><b>Industrial/Product Design</b></a>
                        <a style="color: black!important;" href="#"><b>Interior Design</b></a>
                      </li>
                    </ul>
                  </li>
                  <li cclass="television">
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/design-exams.php" ><b>Design Exam Details</b></a>
                    <!--<a href="#" >Location of college</a>
                    <a href="#" >Reviews of college</a>
                    <a href="#" >Colleges excepting Scores Exam</a>
                  </li>
                  <li cclass="camera">
                    <a href="#">Ranking of College</a>
                    
                    <ul>
                      <li>
                        <a href="https://www.searchurcollege.com/ranking/law-2018">2018</a>
                      </li>
                    </ul>
                  </li>-->
                </ul>
              </li>
              
              <li cclass="devices">
                <a style="color: black!important;"><b>MEDICAL</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a style="color: black!important;" href="#"><b>Courses</b></a>
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/colleges/medical-college-list-1"><b>MBBS</b></a>
                        <a style="color: black!important;" href="#"><b>Pharmacy</b></a>
                        <a style="color: black!important;" href="#"><b>Nursing</b></a>
                        <a style="color: black!important;" href="#"><b>Dental Science</b></a>
                      </li>
                    </ul>
                  </li>
                  <li cclass="television">
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/medical-exams.php" ><b>Medical Exam Details</b></a>
                    <!--<a href="#" >Location of college</a>
                    <a href="#" >Reviews of college</a>
                    <a href="#" >Colleges excepting Scores Exam</a>-->
                  </li>
                  <li cclass="camera">
                    <a style="color: black!important;" href="#"><b>Ranking of College</b></a>
                    
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="https://www.searchurcollege.com/ranking/medical-2018"><b>2018</b></a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>
              
              <li cclass="devices">
                <a style="color: black!important;"><b>MORE</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a style="color: black!important;" href="#"><b>Courses</b></a>
                    <ul style="background: white; color: black!important;">
                      <li>
                        <a style="color: black!important;" href="#"><b>BCA</b></a>
                        <a style="color: black!important;" href="#"><b>MCA</b></a>
                        <a style="color: black!important;" href="#"><b>BSc. IT</b></a>
                        <a style="color: black!important;" href="#"><b>MSc. IT</b></a>
                        <a style="color: black!important;" href="#"><b>BBA</b></a>
                        <a style="color: black!important;" href="#"><b>BBM</b></a>
                        <a style="color: black!important;" href="#"><b>Hotal Management</b></a>
                        <a style="color: black!important;" href="#"><b>Media & Journalism</b></a>
                        <a style="color: black!important;" href="#"><b>Engineerng Diploma (Polytechnic)</b></a>
                        <a style="color: black!important;" href="#"><b>Animation</b></a>
                        <a style="color: black!important;" href="#"><b>Finance & Accounts<b></a>
                        <a style="color: black!important;" href="#"><b>Degree Courses (Arts, Commerce & Science)</b></a>
                        <a style="color: black!important;" href="#"><b>Others (Diploma etc.)</b></a>
                      </li>
                    </ul>
                  </li>
                  <li cclass="television">
                    <a style="color: black!important;" href="#"><b>Other Exam Details</b></a>
                    <!--<a href="#" >Location of college</a>
                    <a href="#" >Reviews of college</a>
                    <a href="#" >Colleges excepting Scores Exam</a>
                  </li>
                  <li cclass="camera">
                    <a href="#">Ranking of College</a>
                    
                    <ul>
                      <li>
                        <a href="https://www.searchurcollege.com/ranking/medical-2018">2018</a>
                      </li>
                    </ul>
                  </li>-->
                </ul>
              </li>
              
              <li cclass="devices">
                <a style="color: black!important;"><b>SCHOLARSHIP</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a style="color: black!important;" ><b>Central Govt.</b></a>
                    <a style="color: black!important;" ><b>State Govt.</b></a>
                	<a style="color: black!important;" ><b>CSR Funding</b></a>
               		<a style="color: black!important;" ><b>Minority</b></a>
                    <a style="color: black!important;" ><b>Loan</b></a>
                  </li>
                 </ul>
              </li>
              
              <li cclass="devices">
                <a style="color: black!important;"><b>EXAMS</b></a>
                <ul style="background: white; color: black!important;">
                  <li cclass="mobile">
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/mba-exams.php"><b>MBA</b></a>
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/engineering-exams.php"><b>Engineering</b></a>
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/medical-exams.php" ><b>Medical</b></a>
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/law-exams.php" ><b>LAW</b></a>
                    <a style="color: black!important;" href="https://www.searchurcollege.com/exams/design-exams.php" ><b>Design</b></a>
                    <!--<a href="#" >Others Exam </a>-->
                  </li>
                 </ul>
              </li>
              
              
            </ul>

          </nav>
        <div></div>

          

        </div>

      </header>

 

<!----------------------------------End----------------------------------------->
      

      <script>
        (function($) {
          var $nav = $('#main-nav');
          var $toggle = $('.toggle');
          var data = {};
          var defaultData = {
            maxWidth: false,
            customToggle: $toggle,
            navTitle: '',
            levelTitles: true,
            pushContent: '#container'
          };

          // calling like this only for demo purposes

          const initNav = function(conf) {
            var $old = $('.hc-offcanvas-nav');

            setTimeout(function() {
              if ($old.length) {
                // clear previous instance
                $old.remove();
              }
            }, $toggle.hasClass('toggle-open') ? 420 : 0);

            if ($toggle.hasClass('toggle-open')) {
              $toggle.click();
            }

            // remove old toggle click event
            $toggle.off('click');

            // remember data
            $.extend(data, conf)

            // call the plugin
            $nav.clone().hcOffcanvasNav($.extend({}, defaultData, data));
          }

          // run first demo
          initNav({});

          $('.actions').find('a').on('click', function(e) {
            e.preventDefault();

            var $this = $(this).addClass('active');
            var $siblings = $this.parent().siblings().children('a').removeClass('active');

            initNav(eval('(' + $this.data('demo') + ')'));
          });

          $('.actions').find('input').on('change', function() {
            var $this = $(this);
            var data = eval('(' + $this.data('demo') + ')');

            if ($this.is(':checked')) {
              initNav(data);
            }
            else {
              var removeData = {};
              $.each(data, function(index, value) {
                removeData[index] = false;
              });
              initNav(removeData);
            }
          });
        })(jQuery);
      </script>

    </div>

  </body>
</html>