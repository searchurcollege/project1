	<?php
include("../../../connection/dbconnect.php");
$k="";
$v="";
$date = date('Y-m-d H:i:s');
foreach ($_POST as $key => $value) {
	if($key=="password2")
	{

	}

	else
	{
		if($key=="term")
		{

		}
		else
		{
			$k.=$key.", ";
		$v.="'".$value."', ";
		}
		
	}

  
  
}
  $k=rtrim($k,', ');
  $v=rtrim($v,', ');

$k1 = explode(", ",$k);
unset($k1[12]);
unset($k1[13]);
$k1 = implode(", ",$k1);
// echo $k1;
$k2 = explode(", ",$k);
foreach($k2 as $i =>$key) {

    if($i!=2 && $i!=3 && $i!=12 && $i!=13)
    {
      unset($k2[$i]);
    }

}
$k2 = implode(", ",$k2);
$k2.=', referral_code_status_dt';


$v1 = explode(", ",$v);
unset($v1[12]);
unset($v1[13]);
$v1 = implode(", ",$v1);
//echo $v1;

$v2 = explode(", ",$v);
foreach($v2 as $i =>$key) {

    if($i!=2 && $i!=3 && $i!=12 && $i!=13)
    {
      unset($v2[$i]);
    }
}
$v2 = implode(", ",$v2);
$v2.=", '".$date."'";

 $_FILES['partner_banner']['name'];
 $_FILES['partner_logo']['name'];

$s="";


 $tbl_name=$_REQUEST["table_name"];
 $sql ="INSERT INTO $tbl_name(".$k1.") VALUES (".$v1.")" ;
if ($conn->query($sql) == TRUE) {
	 $last_id = $conn->insert_id;
    $s=1;
    echo 1;
    //echo "Record Updated </br>";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
   $k2.=", partner_ID";
   $v2.=" ,'".$last_id."'";
 $sql1 ="INSERT INTO suc_partner_referral_code (".$k2.") VALUES (".$v2.")" ;
 if($s==1)
 {
 if ($conn->query($sql1) == TRUE) {
 
    echo 1;
    //echo "Record Updated2 </br>";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
 echo 0;
}
}
if(!empty($_FILES['partner_logo']['name']) && $s==1)
{
	//echo "string";

   
            
             $allowedExts = array("gif", "jpeg", "jpg", "png");
            //chdir('images');
             $currentDir = getcwd();
            $uploadDirectory = "/images/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['partner_logo']['name'];
            $fileSize = $_FILES['partner_logo']['size'];
            $fileTmpName  = $_FILES['partner_logo']['tmp_name'];
            $fileType = $_FILES['partner_logo']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="logo_".$last_id.'.'.$fileExtension;
             $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                          $sql1="UPDATE $tbl_name SET partner_logo='$fn' WHERE partner_id='$last_id'";
                          $result=$conn->query($sql1);
                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
         
         echo 1;                
       //echo 'Logo Uploaded </br>';
}
if(!empty($_FILES['partner_banner']['name']) && $s==1)
{
	//echo "string";
	 
            
             $allowedExts = array("gif", "jpeg", "jpg", "png");
            //chdir('images');
             $currentDir = getcwd();
            $uploadDirectory = "/images/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['partner_banner']['name'];
            $fileSize = $_FILES['partner_banner']['size'];
            $fileTmpName  = $_FILES['partner_banner']['tmp_name'];
            $fileType = $_FILES['partner_banner']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="banner_".$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET partner_banner='$fn' WHERE partner_id='$last_id'";
                          $result=$conn->query($sql1);
                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
       
       echo 1;                  
     // echo "banner uploaded";  
}
?>