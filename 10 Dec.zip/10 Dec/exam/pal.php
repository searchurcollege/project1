<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/exam/assets/css/start_exam.css">	
<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/exam/assets/css/do_exam.css">
<style>
li
{
    display: inline;
}
</style>
						<?php
                            include_once '../includes/global.php';
                        	$examID = $_GET['eid'];
							$quesIdStm="SELECT question_id FROM questions where exam_id=?";
                            $quesID = $myconn->prepare($quesIdStm);
							$quesID->bind_param('i', $examID);
							$quesID->execute();
							$quesID->store_result();
							$quesID->bind_result($question_id);
							$NofQues=1;
							while($quesID->fetch()>0)
                            {
                                $color='';
                                $answer='';
                                $quesIdStm2="SELECT answer FROM user_answer
                                    WHERE exam_id=$examID AND user_id='$userID' AND question_id=$question_id";
                                $quesID2 = $myconn->prepare($quesIdStm2);
                            	$quesID2->execute();
                            	$quesID2->store_result();
        						$quesID2->bind_result($answer);
        						while($quesID2->fetch()>0)
                                {
                                    $answer=$answer;
                                    if($answer!='')
                                        $color='#6FAE45';
                                }
                                //echo '<br>A='.$answer;
                                if($color=='')
     							     echo '<li class="'.$NofQues.'"><a data-toggle="tab" index="<?php echo $NofQues;?>" oonclick="refreshIframe('.$examID.','.$question_id.','.$NofQues.');" id="tabID" class="not_visited" target="_parent" href="https://searchurcollege.com/exam/do-exam/'.$examID.'" title="'.$NofQues.'">'.$NofQues.'</a></li>';
                                else
     							     echo '<li class="'.$NofQues.'"><a style="color: white; background: '.$color.'" data-toggle="tab" index="<?php echo $NofQues;?>" onclick="refreshIframe('.$examID.','.$question_id.','.$NofQues.');" id="tabID" class="not_visited" target="_parent" href="https://searchurcollege.com/exam/do-exam/'.$examID.'">'.$NofQues.'</a></li>';
							     $NofQues++;
							}
						?>
					</ul>

<script>
    function refreshIframe(eid,qno,num)
    {
        //if(num>=1)
            //num=num-1;
        //else
        var ifr = parent.document.getElementsByName('qFrame')[0];
        //var curl= document.getElementById("qFrame").contentWindow.location.href;
        
        var url="https://searchurcollege.com/exam/exam/fetch_question.php?eid="+eid+"&sno2="+qno+"&num="+num;
        alert(url);
        parent.document.getElementById(ifr).src = parent.document.getElementById(ifr).src;
        
        //$('#qFrame').attr("src", url);
        //ifr.src = ifr.src;
    }
</script>

