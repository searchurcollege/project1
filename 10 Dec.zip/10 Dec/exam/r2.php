	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header1.php'); 
	?>
		<style>
			#border-bottom{
				border-bottom:1px solid #ff6300;
				margin-bottom:10px;
			}		
		</style>

		<div class="row row-eq-height">
			
			<div class="col-md-2 col-xs-12 left-sidebar"> 
		
				<?php require_once(__ROOT__.'/includes/sidebar.php'); ?>
				
			</div>
			
		
			<div class="col-md-10 col-xs-12  div-content"> 
			
				<!-- Content Header (Page header) -->
				<div id="contentHeader">
				
					<h4><i class="fa fa-file"></i> <a style="color: white;" href="r1.php">My Result</a>
                    <?php
                     $n1=$_REQUEST['n1'];
                     $scid=$_REQUEST['scid'];
                     echo '&nbsp;&nbsp;<i class="fa fa-caret-right"></i>&nbsp;&nbsp;<a style="color: white;" hhref="r1.php?scid=".$scid"><b style="color: skyblue;">'.$n1.'</b></a>';
                    ?>
                    </h4>
				</div>					
                <style>
                    .box2
                    {
                        padding: 10px!important;
                        margin: 10px!important;
                    }
                </style>
				<div class="col-md-12 col-xs-12">
                    <?php
                        //echo '<h4><b>'.$n1.'</b></h4>';
                    	$stm2="SELECT main_cat_id, main_cat_name, main_cat_description FROM cat01_main_category WHERE main_cat_status=1 AND super_cat_id=$scid ORDER by main_cat_id asc limit 100";
                        if($stm2 = $myconn->prepare($stm2))
                    	{
                    		$stm2->execute();
                    		$stm2->store_result();
                    		$stm2->bind_result($main_cat_id, $main_cat_name, $main_cat_description);
                    		while($stm2->fetch()>0)
                            {
                                echo '<a href="'.BASE_URL.'exam/r3.php?mcid='.$main_cat_id.'&scid='.$scid.'&n1='.$n1.'&n2='.$main_cat_name.'" style="color: white;"><button class="btn btn-primary btn-md box2">'.$main_cat_name.'</button></a>';
                            }
                        }
                        echo '</ul></li>';
                    ?>
				</div>
			</div>

		</div>

		<?php require_once(__ROOT__.'/includes/footer.php');?>