	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header.php'); 
       
	?>
		<link rel="stylesheet" type="text/css" href="assets/css/exam.css">
		<style>
			.container{display:none;}
			.navbar {display:none;}
			.navbar-fixed-bottom{display:none;}
			#main-content {overflow-x: hidden;overflow-y: hidden; width:100%;height:100%;margin-bottom:-78px!important;margin:auto;padding:0;}
			.panel{overflow-x: hidden;overflow-y: hidden;width:100%;height:100%; margin-left:1px;}
			#exam_instruction{font-size:16px;}
			ul>li{list-style: none;}
			.redioBtn{margin-right:10px!important;}

			@media screen and (min-width: 200px) and (max-width: 499px){

				#message{
					height: 200px!important;
					width: 300px!important;
				}
			}
            
            .panel-danger>.panel-heading {
                 color: #ffffff;
                 background-color: #ff9935;
                 border-color: #ff9935;
            }
		</style>
        <?php
        //session_start();
            $uid=$_SESSION['regUsrId'];
            $eid=$_SESSION['examID'];
            echo '<input type="hidden" id="uid" value="'.$uid.'" />';
            echo '<input type="hidden" id="eid" value="'.$eid.'" />';
        ?>
		<div class="row">
			<div class="col-md-12" id="main-content" style="padding-bottom: 0!important;">
			<!-- Main content -->
				<div class="panel panel-danger">
					<div class="panel-heading text-center">
						<h4 class="panel-title">Searchurcollege Online Test Series</h4>
					</div>
					<div class="panel-body">
						<div class="col-md-6 col-md-offset-3 col-xs-12 text-center">
							<h3>Thank you for appearing this exam. Please give your value feedback</h3>
                            <textarea   id="message" name="message" required style="width: 500px;
                            height: 300px"></textarea>
							<p>Submit and check you score card...</p>
							<a style="padding: 16px 32px;"type="button" id="btnEndExam" name="btnEndExam" class="btn btn-primary" href="">Send</a>
						</div>						
					</div>
				</div>							
			</div>
		</div>
		<?php require_once(__ROOT__.'/includes/footer.php');?>
		<script>
			$('#btnEndExam').click(function(){

            var uid=$('#uid').val();
            var eid=$('#eid').val();
            var message=$('#message').val();
            var data="uid="+uid+"&eid="+eid+"&message="+message;
           // alert(data);
			$.ajax({
			type: "POST",
			url: "<?php echo BASE_URL;?>exam/submit_exam2.php?"+data,
			success: function(e){
				alert(e);	
				
				// window.close(this);
         	 window.location="https://www.searchurcollege.com/exam/exam/r1.php";
				}
			});
			return false;
		  });
		</script>	