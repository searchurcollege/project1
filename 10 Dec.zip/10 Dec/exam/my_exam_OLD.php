	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header.php');		
	?>
	<style>
		#border-bottom{
			border-bottom:1px solid #f56954 ;
			margin-bottom:10px;
		}
		.searchTerm {
		  float: left;
		  width: 100%;
		  border: 3px solid #f56954 ;
		  padding: 5px;
		  border-radius: 5px;
		  outline: none;
		  color: #9DBFAF;
		}

		.searchTerm:focus{
		  color: #ff6300;
		}
		.panel{
			border:1px solid #f56954 ;
			color:#fff;
		}
		.panel-heading{
			background:#f56954 ;
		}
		.inner-panel{
          border:1px solid #000 ;
          margin-top:2px;
		}
	</style>
		<div class="row row-eq-height">
			
			<div class="col-md-2 col-xs-12 left-sidebar"> 
		
				<?php require_once(__ROOT__.'/includes/sidebar.php'); ?>
				
			</div>
			
		
			<div class="col-md-10 col-xs-12 div-content">
			
			<!-- Content Header (Page header) -->
				<div id="contentHeader">
				
					<h4> <i class="fa fa-dashboard"></i> <strong>Dashboard </strong><i class="fa fa-chevron-right"></i>  Exam List</h4>
					
				</div>

				<div class="control-group" style="margin-top:10px;">
					<div class="col-md-10 col-md-offset-1">
						<form id="live-search" action="" class="styled searchTerm" method="post">
							<input type="text" class="form-control" id="filter" placeholder="Type to seach exam" />
							<span id="filter-count"></span>
						</form> 					
					</div>
				</div>
				
				<div class="col-md-12 col-xs-12" style="margin-top:10px;">
				
					<!-- Main content -->

					<div class="panel">
					
						<div class="panel-heading"> RECENTLY ADDED EXAM </div>
						
						<div class="panel-body">
	<?php
		$exam_cat_status=1;
		$stm1="SELECT exam_cat_id,exam_cat_name, exam_cat_description	FROM  cat02_exam_category WHERE exam_cat_status=? ORDER by exam_cat_id asc limit 100";
		if ($stm1 = $myconn->prepare($stm1)) 
		{
			$stm1->bind_param('i', $exam_cat_status);
			$stm1->execute();
			$stm1->store_result();
			$stm1->bind_result($exam_cat_id,$exam_cat_name,$exam_cat_description);
			$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
			$flag=0;
			while($stm1->fetch()>0){
				
		?>				

			<div class="col-md-12">

				<!-- Blue tile -->

				<div class="box box-solid" style="background:#bbbaba">

					<div class="box-header">
						<span class="box-title" style="margin-bottom:0;"><?php echo $exam_cat_name; ?></span>
					</div>

					<div class="box-body">
					
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
							<!--**********************************************************************************************
							// 		#1: Geet Exam Exercise Name 
							  --********************************************************************************************** -->
								<?php
									$stm2="SELECT exam_exercise_id,exam_exercise_name FROM cat03_exam_exercise  WHERE exam_cat_id=? AND exam_exercise_status=1 ORDER by exam_exercise_id desc limit 5";
									if ($stm2 = $myconn->prepare($stm2)) 
									{
										$stm2->bind_param('i', $exam_cat_id);
										$stm2->execute();
										$stm2->store_result();
										$stm2->bind_result($exam_exercise_id,$exam_exercise_name);
										while($stm2->fetch()>0){
								?>

										<div class="panel panel-default inner-panel">
										
											<div class="panel-heading" role="tab" id="heading<?php echo $exam_exercise_id;?>" style="border:1px solid #ddd;">
												<h4 class="panel-title">
													<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $exam_exercise_id;?>" aria-expanded="true" aria-controls="collapse<?php echo $exam_exercise_id;?>">
														<i class="more-less glyphicon glyphicon-plus pull-right"></i>
														<?php echo $exam_exercise_name;?>
													</a>
												</h4>
											</div>
											
											<div id="collapse<?php echo $exam_exercise_id;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo $exam_exercise_id;?>">
												<div class="panel-body">
													<?php
														$stm3="SELECT exam_id, no_of_question,type,price,available_from,available_to,exam_name, exam_duration FROM exam WHERE exam_exercise_id=? AND status=1 ORDER by exam_id desc limit 5";
														if ($stm3 = $myconn->prepare($stm3)) 
														{
															$stm3->bind_param('i', $exam_exercise_id);
															$stm3->execute();
															$stm3->store_result();
															$stm3->bind_result($exam_id,$no_of_question,$type,$price,$available_from,$available_to,$exam_name, $exam_duration);
															while($stm3->fetch()>0){
														?>
                                                        <div class="promoDiv">
                    										<label class="labelHeading">
                    											<?php echo $exam_name;?>
                    										</label>	
                    											<em  class="text-danger"><b>No Of Question</b> : <?php echo $no_of_question;?> | 
                    											<b>Start From </b>:<?php echo $available_from;?> <b> To </b>: <?php echo $available_to;?> | 
                    											<?php if(empty($price)){echo "<em class='text-success'>FREE</em>";}else{echo $price;}?></em>
                    											<a href="<?php echo BASE_URL;?>start-exam/<?php echo $exam_id?>" onclick="return startExam(this,<?php echo $_SESSION['profile-percent'];?>)">
                                                                    <?php
                                                                        $user=$_SESSION['regUsrId'];
                                                                		$exmName="SELECT time_left FROM user_answer where user_id='$user' AND exam_id=$exam_id";
                                                                        $exmName = $myconn->prepare($exmName);
                                                                		//$exmName->bind_param('i', $exam_id);
                                                                		$exmName->execute();
                                                                		$exmName->store_result();
                                                                		$exmName->bind_result($ed);
                                                                		$exmName->fetch();
                                                                        //echo 'E='.$ed.' X='.$exam_duration;
                                                                        if(strlen($ed)>10 || $ed=='')
                                                                            ;//echo '<span class="btn-with-zomm">Start Exam ('.$exam_duration.' mins)</span>';
                                                                        else
                                                                            ;//echo '<span class="btn-with-zomm">Start Exam ('.substr($ed,3,7).' mins)</span>';
                                                                        $ed=$exam_duration='';
                                                                        echo '<span class="btn-with-zomm">Start Exam</span>';
                                                                    ?>
                    											</a>
                    									</div>
														<?php
															}
														}
													?>
												</div>
											</div>
											
										</div>	
								<?php
										}
									}
									?>
						</div><!-- panel-group -->	
					
					</div><!-- /.box-body -->

				</div><!-- /.box -->

			</div>
			
	<?php
			$flag++;
			}
		}

	?>
							
						</div>
					</div>				
				</div>
				
			</div>				
				
		</div>
		
		
	</div>

	<?php require_once(__ROOT__.'/includes/footer.php');?>
	
	<!-- *************************** Redirect page to Start-Exam in new tab  ****************************-->
	<script>
		localStorage.clear();
		function startExam(hrefLink,profPerc){
		    var sendLink = hrefLink;
		    var prfValue = profPerc;
			if(prfValue < 100){
				window.open(sendLink,'Start-exam');
				return false;				
			}
			else{
				$('#divErrorProfile').show();
				$('#ErrorMessage').html('Your Profile is less than 100%, firstly complete your profile then you can take exam...');
				return false;
			}
		}
	</script>
	
	<!-- *************************** Search Exam On keypress ********************************************-->
	<script type="text/javascript">
		$(document).ready(function(){
			$("#filter").keyup(function(){
		 
				// Retrieve the input field text and reset the count to zero
				var filter = $(this).val(), count = 0;
		 
				// Loop through the comment list
				$(".panel-body div").each(function(){
		 
					// If the list item does not contain the text phrase fade it out
					if ($(this).text().search(new RegExp(filter, "i")) < 0) {
						$(this).fadeOut();
		 
					// Show the list item if the phrase matches and increase the count by 1
					} else {
						$(this).show();
						count++;
					}
				});
		 
				// Update the count
				var numberItems = count;
				//$("#filter-count").text("Number of Comments = "+count);
			});
		});
	</script>	