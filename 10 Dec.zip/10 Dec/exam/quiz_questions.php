<?php
 define("HOST", "localhost");            // IP Address of Database Server
    define("USER", "searchurcollege");             // Database User Name 
    define("PASSWORD", "Newme7503415202");          // Database User Password 
    define("DATABASE", "searchurcollege_main");      // Database Name 
    define("CAN_REGISTER", "any");
    define("DEFAULT_ROLE", "member");
    define("SECURE", FALSE);                // For HTTPS it is TRUE and for HTTTP it is FALSE


    ini_set('display_errors',1);
    ini_set('display_startup_errors',1);
    error_reporting(E_ALL);
    error_reporting(E_ERROR | E_PARSE);

    function getConnected($host, $user, $pass, $db) {

    $mysqli = new mysqli($host, $user, $pass, $db);

        if ($mysqli->connect_error)
            die('Could Not Connect To DataBase');

        return $mysqli;
    }

    $myconn = getConnected(HOST, USER, PASSWORD, DATABASE);
	
    ?>
	<body>
		<div class="container question">
			<div class="col-xs-12 col-sm-8 col-md-8 col-xs-offset-4 col-sm-offset-3 col-md-offset-3">
				<form class="form-horizontal" role="form" id='login' method="post" action="result.php">
					<?php 
                        $examID=28;
    					$quesIdStm="SELECT question_id, question FROM questions where exam_id=? ORDER BY RAND() LIMIT 3";
    					$quesID = $myconn->prepare($quesIdStm);
    					$quesID->bind_param('i', $examID);
    					$quesID->execute();
    					$quesID->store_result();
    					$quesID->bind_result($question_id, $question);
    					$i=1;
    					while($quesID->fetch()>0){
                        if($i==1){?>
                    <div id='question<?php echo $i;?>' class='cont'>
                    <p class='questions' id="qname<?php echo $i;?>"> <?php echo $i?>.<?php $question;?></p>
                    <input type="radio" value="1" id='radio1_<?php echo $question_id;?>' name='<?php echo $question_id;?>'/><?php //echo ;?>
                   <br/>
                    <input type="radio" value="2" id='radio1_<?php echo $question_id;?>' name='<?php echo $question_id?>'/><?php //echo $result['answer2'];?>
                    <br/>
                    <input type="radio" value="3" id='radio1_<?php echo $question_id;?>' name='<?php echo $question_id;?>'/><?php //echo $result['answer3'];?>
                    <br/>
                    <input type="radio" value="4" id='radio1_<?php echo $question_id;?>' name='<?php echo $question_id;?>'/><?php //echo $result['answer4'];?>
                    <br/>
                    <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $result['question_id'];?>'/>                                                                      
                    <br/>
                    <button id='<?php echo $i;?>' class='next btn btn-success' type='button'>Next</button>
                    </div>     
                      
                     <?php }elseif($i<1 || $i<$rows){?>
                     
                       <div id='question<?php echo $i;?>' class='cont'>
                    <p class='questions' id="qname<?php echo $i;?>"><?php echo $i?>.<?php echo $result['question'];?></p>
                    <input type="radio" value="1" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $question_id;?>'/><?php //echo $result['answer1'];?>
                    <br/>
                    <input type="radio" value="2" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $question_id;?>'/><?php //echo $result['answer2'];?>
                    <br/>
                    <input type="radio" value="3" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $question_id;?>'/><?php //echo $result['answer3'];?>
                    <br/>
                    <input type="radio" value="4" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $question_id;?>'/><?php //echo $result['answer4'];?>
                    <br/>
                    <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $result['question_id'];?>'/>                                                                      
                    <br/>
                    <button id='<?php echo $i;?>' class='previous btn btn-success' type='button'>Previous</button>                    
                    <button id='<?php echo $i;?>' class='next btn btn-success' type='button' >Next</button>
                    </div>
                       
                       
                       
                        
                        
                   <?php }elseif($i==$rows){?>
                    <div id='question<?php echo $i;?>' class='cont'>
                    <p class='questions' id="qname<?php echo $i;?>"><?php echo $i?>.<?php echo $result['question'];?></p>
                    <input type="radio" value="1" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $result['question_id'];?>'/><?php echo $result['answer1'];?>
                    <br/>
                    <input type="radio" value="2" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $result['question_id'];?>'/><?php echo $result['answer2'];?>
                    <br/>
                    <input type="radio" value="3" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $result['question_id'];?>'/><?php echo $result['answer3'];?>
                    <br/>
                    <input type="radio" value="4" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $result['question_id'];?>'/><?php echo $result['answer4'];?>
                    <br/>
                    <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['question_id'];?>' name='<?php echo $result['question_id'];?>'/>                                                                      
                    <br/>
                    
                    <button id='<?php echo $i;?>' class='previous btn btn-success' type='button'>Previous</button>                    
                    <button id='<?php echo $i;?>' class='next btn btn-success' type='submit'>Finish</button>
                    </div>
					<?php } $i++;} ?>
					
				</form>
			</div>
		</div>


<?php

if(isset($_POST[1])){ 
   $keys=array_keys($_POST);
   $order=join(",",$keys);
   
   //$query="select * from questions id IN($order) ORDER BY FIELD(id,$order)";
  // echo $query;exit;
   
   $response = mysqli_query($con, "select id,answer from questions where id IN($order) ORDER BY FIELD(id,$order)")   or die(mysqli_error( $con ));
   $right_answer = 0;
   $wrong_answer = 0;
   $unanswered = 0;
   while( $result = mysqli_fetch_assoc( $response ) ){
       if( $result['answer']==$_POST[$result['question_id']] ){
           $right_answer++;
	   } else if($_POST[$result['question_id']]==5){
		   $unanswered++;
	   } else{
		   $wrong_answer++;
	   }
       
   }
   
   
   echo "right_answer : ". $right_answer."<br>";
   echo "wrong_answer : ". $wrong_answer."<br>";
   echo "unanswered : ". $unanswered."<br>";
?>
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.10.2.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.validate.min.js"></script>
		
		<script>
		$('.cont').addClass('hide');
		count=$('.questions').length;
		 $('#question'+1).removeClass('hide');
		 
		 $(document).on('click','.next',function(){
		     last=parseInt($(this).attr('id'));     
		     nex=last+1;
		     $('#question'+last).addClass('hide');
		     
		     $('#question'+nex).removeClass('hide');
		 });
		 
		 $(document).on('click','.previous',function(){
             last=parseInt($(this).attr('id'));     
             pre=last-1;
             $('#question'+last).addClass('hide');
             
             $('#question'+pre).removeClass('hide');
         });
         
         
         
		</script>
	</body>
</html>
<?php }else{
    
 header( 'Location: '.BASE_PATH ) ;
      
}
?>