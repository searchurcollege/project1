	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header.php'); 
		error_reporting(0);
		$userID=$_SESSION['regUsrId'];
	?>
	<style>
	.panel{
		border:2px solid #f56954 ;
		color:#fff;
	}
	.panel-heading{
		background:#f56954 ;
	}
	#resultTable {
        font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }
    
    #resultTable td, #resultTable th {
        border: 1px solid #ddd;
        padding: 8px;
    }
    
    #resultTable tr:nth-child(even){background-color: #f2f2f2;}
    
    #resultTable tr:hover {background-color: #ddd;}
    
    #resultTable th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #f56954 ;
        color: white;
    }
</style>
	</style>
        <script src="<?php echo BASE_URL;?>assets/js/chart-loader.js" type="text/javascript"></script>
		<div class="row row-eq-height">
			
			<div class="col-md-2 col-xs-12 left-sidebar"> 
		
				<?php require_once(__ROOT__.'/includes/sidebar.php'); ?>
				
			</div>
			
		
			<div class="col-md-10 col-xs-12 div-content"> 
			
				<!-- Content Header (Page header) -->
				<div id="contentHeader">
				
					<h4> <i class="fa fa-dashboard"></i> <strong>Dashboard </strong><i class="fa fa-chevron-right"></i>  Result</h4>
					
				</div>

				<div class="col-md-12 col-xs-12" style="margin-top:10px;">
				
					<!-- Main content -->

					<div class="panel">
					
						<div class="panel-heading">My Result</div>
						

	<style>
	.panel{
		border:2px solid #f56954 ;
		color:#fff;
	}
	.panel-heading{
		background:#f56954 ;
	}
	#resultTable {
        font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }
    
    #resultTable td, #resultTable th {
        border: 1px solid #ddd;
        padding: 8px;
    }
    
    #resultTable tr:nth-child(even){background-color: #f2f2f2;}
    
    #resultTable tr:hover {background-color: #ddd;}
    
    #resultTable th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #f56954 ;
        color: white;
    }
</style>

<?php
    $a=1;
    $b=1;
    $c=1;
    $d=1;
    $e=1;
	$super_cat_status=1;
	$stm1="SELECT super_cat_id, super_cat_name, super_cat_description FROM cat00_super_category WHERE super_cat_status=? ORDER by super_cat_id asc limit 100";
	if ($stm1 = $myconn->prepare($stm1)) 
	{
		$stm1->bind_param('i', $super_cat_status);
		$stm1->execute();
		$stm1->store_result();
		$stm1->bind_result($super_cat_id, $super_cat_name, $super_cat_description);
		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
		while($stm1->fetch()>0){
        ?>
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingTwo">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#One<?php echo $super_cat_id.$a;?>" aria-expanded="false" aria-controls="collapseTwo">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        <?php echo $super_cat_name;?>
                    </a>
                </h4>
            </div>
            <div id="One<?php echo $super_cat_id.$a;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                <div class="panel-body">
                    <?php
                    	$main_cat_status=1;
                    	$stm2="SELECT main_cat_id, main_cat_name, main_cat_description FROM cat01_main_category WHERE main_cat_status=? AND super_cat_id=? ORDER by main_cat_id asc limit 100";
                    	if ($stm2 = $myconn->prepare($stm2)) 
                    	{
                    		$stm2->bind_param('ii', $main_cat_status, $super_cat_id);
                    		$stm2->execute();
                    		$stm2->store_result();
                    		$stm2->bind_result($main_cat_id, $main_cat_name, $main_cat_description);
                    		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                    		while($stm2->fetch()>0){
                    		  echo '$main_cat='.$main_cat_id;
                            ?>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingTwo">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#Two<?php echo $main_cat_id.$b;?>" aria-expanded="false" aria-controls="collapseTwo">
                                            <i class="more-less glyphicon glyphicon-plus"></i>
                                            <?php echo $main_cat_name;?>
                                        </a>
                                    </h4>
                                </div>
                                <div id="Two<?php echo $main_cat_id.$b;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                    <div class="panel-body">
                                        <?php
                                        	$exam_cat_status=1;
                                        	$stm3="SELECT exam_cat_id, exam_cat_name, exam_cat_description FROM cat02_exam_category WHERE exam_cat_status=? AND main_cat_id=? ORDER by exam_cat_id asc limit 100";
                                        	if ($stm3 = $myconn->prepare($stm3)) 
                                        	{
                                        		$stm3->bind_param('ii', $exam_cat_status, $main_cat_id);
                                        		$stm3->execute();
                                        		$stm3->store_result();
                                        		$stm3->bind_result($exam_cat_id, $exam_cat_name, $exam_cat_description);
                                        		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                                        		while($stm3->fetch()>0){
                                        		  echo '$exam_cat='.$exam_cat_id;
                                                ?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading" role="tab" id="headingTwo">
                                                        <h4 class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#Three<?php echo $exam_cat_id.$c;?>" aria-expanded="false" aria-controls="collapseTwo">
                                                                <i class="more-less glyphicon glyphicon-plus"></i>
                                                                <?php echo $exam_cat_name;?>
                                                            </a>
                                                        </h4>
                                                    </div>
                                                    <div id="Three<?php echo $exam_cat_id.$c;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                        <div class="panel-body">
                                                            <?php
                                                            	$exam_exercise_status=1;
                                                            	$stm4="SELECT exam_exercise_id, exam_exercise_name, exam_exercise_description FROM cat03_exam_exercise WHERE exam_exercise_status=? AND exam_cat_id=? ORDER by exam_exercise_id asc limit 100";
                                                            	if ($stm4 = $myconn->prepare($stm4)) 
                                                            	{
                                                            		$stm4->bind_param('ii', $exam_exercise_status, $exam_cat_id);
                                                            		$stm4->execute();
                                                            		$stm4->store_result();
                                                            		$stm4->bind_result($exam_exercise_id, $exam_exercise_name, $exam_exercise_description);
                                                            		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                                                            		while($stm4->fetch()>0){
                                                            		  echo '$exam_exercise='.$exam_exercise_id;
                                                                    ?>
                                                                    <div class="panel panel-default">
                                                                        <div class="panel-heading" role="tab" id="headingTwo">
                                                                            <h4 class="panel-title">
                                                                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#Four<?php echo $exam_exercise_id.$d;?>" aria-expanded="false" aria-controls="collapseTwo">
                                                                                    <i class="more-less glyphicon glyphicon-plus"></i>
                                                                                    <?php echo $exam_exercise_name;?>
                                                                                </a>
                                                                            </h4>
                                                                        </div>
                                                                        <div id="Four<?php echo $exam_exercise_id.$d;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                                            <div class="panel-body">
                                                                                <?php
                                                                                	$exam_status=1;
                                                                                	$stm5="SELECT exam_id, exam_name, description FROM exam WHERE status=? AND exam_exercise_id=? ORDER by exam_id asc limit 100";
                                                                                	if ($stm5 = $myconn->prepare($stm5)) 
                                                                                	{
                                                                                		$stm5->bind_param('ii', $exam_status, $exam_exercise_id);
                                                                                		$stm5->execute();
                                                                                		$stm5->store_result();
                                                                                		$stm5->bind_result($exam_id, $exam_name, $description);
                                                                                		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                                                                                		while($stm5->fetch()>0){
                                                                                		  echo '$exam_exercise='.$exam_id;
                                                                                        ?>
                                                                                        <div class="panel panel-default">
                                                                                            <div class="panel-heading" role="tab" id="headingTwo">
                                                                                                <h4 class="panel-title">
                                                                                                        <i class="more-less glyphicon glyphicon-file"></i>
                                                                                                        <?php echo $exam_name;?>


							<div class="col-md-12 col-xs-12" style="margin-top: 20px;">
							
								<table class="table table-bordered table-striped table-hover">
									<thead class="bg-red">
										<th></th>										
										<th>Exam Name</th>										
										<th>Dated</th>										
										<th>Total Questions</th>
										<th>Time</th>
										<th>Total Marks</th>
										<th>Passing Marks</th>
										<!--<th>Attempts</th>-->
										<th>Correct</th>
										<th>Wrong</th>
										<th>Marks</th>
										<th>Result</th>
									</thead>
									<tbody>
								<?php
									//*********************************************************************************************
									// 	#: Get Recent Exam Status
									//*********************************************************************************************
										$userExamSt=1;
										$user_id = $_SESSION['regUsrId'] ;
										/*$userExm="SELECT ue.user_exam_id, ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,
													ue.total_attempt,ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,
													e.exam_name FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id=? AND  ue.status=?";*/
										$userExm="SELECT ue.id, ue.created_at, ue.user_exam_id, ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,
													ue.total_attempt,ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,
													e.exam_name FROM user_exam ue, exam e WHERE ue.user_id=? AND exam_id= ? AND ue.status=?  ORDER BY ue.created_at DESC";
										if ($userExm = $myconn->prepare($userExm)) 
										{
											$userExm->bind_param('sii', $user_id,$exam_id,$userExamSt);
											$userExm->execute();
											$userExm->store_result();
											$userExm->bind_result($id, $created_at, $user_exam_id,$total_no_of_ques,$time_duration,$total_marks,$pass_marks,
																	$total_attempt,$correct_answer, $wrong_answer, $user_get_marks, $result_status,$exam_name);
											while($userExm->fetch()){
											    $created_at=date('d-M-Y h:i a',strtotime($created_at)); 
												if(empty($exam_name)){
												echo '<tr>
														<td colspan="10">	
															<div class="callout callout-info">
																<h4>No exams have been taken at the moment !</h4>
															</div>
														</td>
													</tr>';
												}
												else{
												
								?>
													<tr>
														<td><?php echo $id;?></td>
														<td><?php echo $exam_name;?></td>
														<td><?php echo $created_at;?></td>
														<td><?php echo $total_no_of_ques;?></td>
														<td><?php echo $time_duration.' <em>min</em>';?></td>
														<td><?php echo $total_marks;?></td>
														<td><?php echo $pass_marks;?></td>
														<!--<td><?php echo $total_attempt;?></td>-->
														<td><?php echo $correct_answer;?></td>
														<td><?php echo $wrong_answer;?></td>
														<td><?php echo $user_get_marks;?></td>
														<td>
															<label class="label label-<?php if($result_status=='PASS'){ echo 'success';}else{ echo 'danger';}?>"> <?php echo $result_status;?> </label>
															&nbsp;&nbsp;<a href="<?php echo BASE_URL;?>exmID/<?php echo $id;?>" title="View Questions"><i class="fa fa-eye fa-2x"></i></a>
														</td>
														
													</tr>
								<?php
												}
											}
										}
								?>
									</tbody>
									
								</table>
									
							</div>

                                                                                                    </a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <?php
                                                                                            $e++;
                                                                                        }
                                                                                    }
                                                                                ?>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                        $d++;
                                                                    }
                                                                }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                                    $c++;
                                                }
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                                $b++;
                            }
                        }
                    ?>
                </div>
            </div>
        </div>
        <?php
            $a++;
        }
    }
?>

						</div>
					</div>	
					
				</div>
				
			</div>				
				
		</div>

	<?php require_once(__ROOT__.'/includes/footer.php');?>
	