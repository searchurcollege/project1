<?php
    session_start();
    $code=$_SESSION['code'];
	//************************** Include Requied File ***************************
	define('__ROOT__', dirname(dirname(__FILE__))); 
	require_once(__ROOT__.'/includes/global.php'); 
	require_once(__ROOT__.'/includes/authentication.php');
	
	//error_reporting(0);

	$exam_id=$_REQUEST['hfExamId'];
	$totalNoQues=$_REQUEST['hfTotalNoQues']; // Total No of Questions
    $timeDuration=$_REQUEST['hfTimeDuration'];
	$totalMarks=$_REQUEST['hfTotalMarks'];
	$passMarks=$_REQUEST['hfPassMarks'];
	$user_id = $_REQUEST['hfUserId'];


		//**************** Get Total Correct Answer *************************
	 $servername="localhost";
    $username="searchurcollege";
    $password="Newme7503415202";
    $dbname="searchurcollege_main";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error)
        die("Connection failed: " . $conn->connect_error);
		$correctAnswer = array();
		 $chk="SELECT q.question_id_OLD FROM questions q JOIN answer a ON a.exam_id = q.exam_id AND a.question_id = q.question_id_OLD AND q.exam_id=$exam_id LEFT JOIN user_answer u ON u.exam_id = q.exam_id AND u.question_id = q.question_id AND u.user_id = ? AND u.code=? ORDER BY q.question_id";

		  $chk = $myconn->prepare($chk);
		$chk->bind_param('is', $exam_id,$user_id );
		$chk->execute();
		$chk->store_result();
		$chk->bind_result($question_id_OLD);
		$chk->fetch();
		$n=$question_id_OLD;
                          // $chk="SELECT question_id_OLD from questions";
                           // $rslt=$conn->query($chk);
                           // while($row11=$rslt->fetch_assoc())
                           //  {
                           //      $n=$row11["question_id_OLD"];
                           //  }
                            if($n>0){
														$stm1="SELECT COUNT(u.answer)
                                    FROM questions q JOIN answer a ON a.exam_id = q.exam_id 
                                    AND a.question_id = q.question_id_OLD AND q.exam_id=? 
                                    LEFT JOIN user_answer u ON u.exam_id = q.exam_id 
                                    AND u.question_id = q.question_id AND u.answer=a.correct_answer AND u.user_id = ? AND u.code='$code'" ;
                                  }
                              else {
                                $stm1="SELECT COUNT(u.answer)
                                    FROM questions q JOIN answer a ON a.exam_id = q.exam_id 
                                    AND a.question_id = q.question_id AND q.exam_id=? 
                                    LEFT JOIN user_answer u ON u.exam_id = q.exam_id 
                                    AND u.question_id = q.question_id AND u.answer=a.correct_answer AND u.user_id = ? AND u.code='$code'" ;
                              }



		// $stm1="SELECT  COUNT(a.correct_answer) as total_Correct 
		// 		FROM answer a, user_answer u WHERE a.question_id=u.question_id 
		// 		AND a.correct_answer=u.answer AND u.exam_id=? AND u.user_id=? AND u.code='$code'";
        $stms1 = $myconn->prepare($stm1);
		$stms1->bind_param('is', $exam_id,$user_id );
		$stms1->execute();
		$stms1->store_result();
		$stms1->bind_result($total_Correct);
		$stms1->fetch();
			$correctAnswer=$total_Correct;

		//**************** Get Total Attempt *************************
		//$stm2="SELECT count(answer) as total_attempt FROM user_answer WHERE exam_id=? AND user_id=? AND mark=0 AND answer!=0 order by question_id asc";
		$stm2="SELECT count(user_id) as total_attempt FROM user_exam WHERE user_exam_id=? AND user_id=?";// AND mark=0 AND answer!=0 order by question_id asc";
		$stms2 = $myconn->prepare($stm2);
		$stms2->bind_param('is', $exam_id, $user_id);
		$stms2->execute();
		$stms2->store_result();
		$stms2->bind_result($total_attempt);
		$stms2->fetch();
		
		// Count total no of attempts
		$userAttempts=$total_attempt;

		//**************** User Wrong Answer *************************
		$userWrongAnswer=$userAttempts - $correctAnswer;
		
		//**************** User Not Attempte *************************
		$userNotAttmpt=$totalNoQues - $userAttempts;

		//**************** User Total Get Marks **********************
		$userGetMarks=($correctAnswer*4)-($userWrongAnswer);	

		//**************** User Exam Status **********************
		if($userGetMarks > $passMarks){
			$userExamStatus='PASS';
		}
		else{
			$userExamStatus='FAILED';
		}

		// Chech Exam attempted or Not
		$stm="SELECT user_exam_id FROM user_exam where user_id=? AND user_exam_id=?";
		$stms = $myconn->prepare($stm);
		$stms->bind_param('si', $user_id,$exam_id);
		$stms->execute();
		$stms->store_result();
		$stms->bind_result($userExamID);
		$stms->fetch();
		/*if(!empty($userExamID)){
			// Update if question is already answered 
			$stmUpdt="UPDATE user_exam SET user_exam_id='$exam_id', total_no_of_ques='$totalNoQues', time_duration='$timeDuration', 
					total_marks='$totalMarks', pass_marks='$passMarks',total_attempt='$userAttempts', 
					correct_answer='$correctAnswer', wrong_answer='$userWrongAnswer',user_get_marks='$userGetMarks',
					result_status='$userExamStatus' WHERE user_id=? AND user_exam_id=?";
			$stmsUdt = $myconn->prepare($stmUpdt);
			$stmsUdt->bind_param('si', $user_id,$exam_id);
			$stmsUdt->execute();
			echo 'submited';
		}
		else*/{
			$stmIns="INSERT INTO user_exam (code,user_exam_id,user_id,total_no_of_ques,time_duration,total_marks,pass_marks,
						total_attempt,correct_answer, wrong_answer,user_get_marks,result_status, created_at )VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $date = date('Y-m-d H:i:s', time());
			$stmsIns = $myconn->prepare($stmIns);
			$stmsIns->bind_param('sisiiiiiiiiss',$code,$exam_id,$user_id,$totalNoQues,$timeDuration,$totalMarks,$passMarks,$userAttempts,$correctAnswer,$userWrongAnswer,$userGetMarks,$userExamStatus,$date);
			$stmsIns->execute();

            //Remove from Answer table
			$stmIns="UPDATE user_answer SET status='submited' WHERE exam_id=? AND user_id=?";
			$stmsIns = $myconn->prepare($stmIns);
			$stmsIns->bind_param('is',$exam_id,$user_id);
			$stmsIns->execute();

			echo 'submited';
		}

   
?>