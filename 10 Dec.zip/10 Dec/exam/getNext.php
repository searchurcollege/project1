<?php
    include('../../connection/dbconnect.php');
    if ($conn->connect_error)
        die("Connection failed: " . $conn->connect_error);
    $btn=$_REQUEST['btn'];
    $eid=$_REQUEST['eid'];
    $currentQuestion=$_REQUEST['qid'];
    $sql="SELECT 
          (
            SELECT question_id
            FROM questions WHERE question_id < $currentQuestion AND exam_id=$eid ORDER BY question_id DESC LIMIT 1
          ) AS pid,
          (
            SELECT question_id
            FROM questions WHERE question_id > $currentQuestion AND exam_id=$eid ORDER BY question_id ASC LIMIT 1
          ) AS nid";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        foreach($result as $var)
        {
            if($btn=='next')
            {
                $user_id='project1973@gmail.com';
                $answer=$_REQUEST['answer'];
                $color=$_REQUEST['color'];
                $time_left=$_REQUEST['time_left'];
                $qid=$var['nid'];

                //Check for Existing Answer          
                $sql2="SELECT answer FROM user_answer2 WHERE question_id = $currentQuestion AND exam_id=$eid AND user_id='$user_id' LIMIT 1";
                $result2=$conn->query($sql2);
                $ans=0;
                if($result2->num_rows>0)
                {
                    foreach($result2 as $var2)
                        $ans=$var2['answer'];
                }
                                
                $sql2="SELECT question, question_type, option_count FROM questions WHERE question_id > $currentQuestion AND exam_id=$eid ORDER BY question_id ASC LIMIT 1";
                $result2=$conn->query($sql2);
                foreach($result2 as $var2)
                {
                    $qt=$var2['question_type'];
                    $oc=$var2['option_count'];
                    $cq='-A-'.$ans.'-QT-'.$qt.'-OC-'.$oc.'-Q-'.$var2['question'];
                }
                $sql2="INSERT INTO user_answer2 (user_id, question_id, exam_id, answer, color, time_left) VALUES ('$user_id', $currentQuestion, $eid, $ans, '$color', '$time_left')";
                $result2=$conn->query($sql2);
            }
            else
            if($btn=='prev')
            {
                $qid=$var['pid'];
                $sql2="SELECT question, question_type, option_count FROM questions WHERE question_id < $currentQuestion AND exam_id=$eid ORDER BY question_id DESC LIMIT 1";
                $result2=$conn->query($sql2);
                foreach($result2 as $var2)
                {
                    $qt=$var2['question_type'];
                    $oc=$var2['option_count'];
                    $cq='-QT-'.$qt.'-OC-'.$oc.'-Q-'.$var2['question'];
                }
            }
            else
            if($btn=='pallet')
            {
                $sql2="SELECT question, question_type, option_count FROM questions WHERE question_id = $currentQuestion AND exam_id=$eid ORDER BY question_id ASC LIMIT 1";
                $result2=$conn->query($sql2);
                foreach($result2 as $var2)
                {
                    $qt=$var2['question_type'];
                    $oc=$var2['option_count'];
                    $cq='-QT-'.$qt.'-OC-'.$oc.'-Q-'.$var2['question'];
                }
            }
        }
            echo $qid.'-X-'.$cq;
    }
    else
        echo '0';
?>
