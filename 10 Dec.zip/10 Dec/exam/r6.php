	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header.php'); 
	?>
		<style>
			#border-bottom{
				border-bottom:1px solid #ff6300;
				margin-bottom:10px;
			}		
		</style>

		<div class="row row-eq-height">
			
			<div class="col-md-2 col-xs-12 left-sidebar"> 
		
				<?php require_once(__ROOT__.'/includes/sidebar.php'); ?>
				
			</div>
			
		
			<div class="col-md-10 col-xs-12  div-content"> 
			
				<!-- Content Header (Page header) -->
				<div id="contentHeader">
				
					<h4><i class="fa fa-file"></i> <a style="color: white;" href="r1.php">My Result</a>
                    </h4>
				</div>					
                <style>
                    .box2
                    {
                        padding: 10px!important;
                        margin: 10px!important;
                    }
                </style>
				<div class="col-md-12 col-xs-12">
                    <?php
                        //echo '<h4><b>'.$n4.'</b></h4>';
                        $eid=$_REQUEST['eid'];

?>
						<!--<div class="row">
							<div class="col-md-12">
								<br>
								<div class="col-md-12" id="border-bottom">
									<h4><b>TEST PERFORMANCE</b></h4>
								</div>
							</div>-->
							<div class="col-md-12 col-xs-12">
<style>
th
{
    padding: 5px;
    text-align: center;
}
</style>							
							
                                <table class="ttable table-bordered table-striped table-hover" style="width:100%">
									<thead class="bg-red">
										<th width="20%">Dated</th>										
										<th width="20%">Exam Name</th>										
										<th>Questions</th>
										<th>Total Time</th>
										<th>Total Marks</th>
										<th>Passing Marks</th>
										<th>Attempted</th>
										<th>Correct</th>
										<th>Wrong</th>
										<th>Marks</th>
										<th>Result</th>
									</thead>
									<tbody>
								<?php
									//*********************************************************************************************
									// 	#: Get Recent Exam Status
									//*********************************************************************************************
										$user_id = $_SESSION['regUsrId'] ;
										$userExm="SELECT ue.id, ue.user_exam_id, ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,
													ue.total_attempt,ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,
													e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id='$user_id' AND ue.user_exam_id=$eid ORDER BY ue.created_at DESC";
                                        if ($userExm = $myconn->prepare($userExm)) 
										{
											$userExm->execute();
											$userExm->store_result();
											$userExm->bind_result($id,$user_exam_id,$total_no_of_ques,$time_duration,$total_marks,$pass_marks,
											$total_attempt,$correct_answer, $wrong_answer, $user_get_marks, $result_status, $exam_name, $exam_id, $date, $code);
											while($userExm->fetch()){
        										$userExm2="SELECT COUNT(answer_id) AS tot_attempts FROM user_answer WHERE code='$code'";
                                                $userExm2=$myconn->prepare($userExm2); 
    											$userExm2->execute();
    											$userExm2->store_result();
    											$userExm2->bind_result($tot_attempts);
    											while($userExm2->fetch())
                                                    $tot_attempts=$tot_attempts;
                                                $date=date('d-M-Y H:i',strtotime($date));
												if(empty($exam_name)){
												echo '<tr>
														<td colspan="10">	
															<div class="callout callout-info">
																<h4>No exams have been taken at the moment !</h4>
															</div>
														</td>
													</tr>';
												}
												else{
												   $total_attempt=$tot_attempts;
                                                   $wrong_answer=$total_attempt-$correct_answer;
            									   if($wrong_answer<0)
                                                        $wrong_answer=0-$wrong_answer;
    												$mpq=$total_marks/$total_no_of_ques;
                                                    $user_get_marks=round($correct_answer*$mpq);
                                                    $a=$total_marks/$total_no_of_ques;
                                                    if($user_get_marks>=$pass_marks)
                                                        $result_status='PASS';
                                                    else
                                                        $result_status='FAILED';
								?>
													<tr>
														<td align="center"><?php echo $date;?></td>
														<td align="center"><?php echo $exam_name;?></td>
														<td align="center"><?php echo $total_no_of_ques;?></td>
														<td align="center"><?php echo $time_duration.' <em>min</em>';?></td>
														<td align="center"><?php echo $total_marks;?></td>
														<td align="center"><?php echo $pass_marks;?></td>
														<td align="center"><?php echo $total_attempt;?></td>
														<td align="center"><?php echo $correct_answer;?></td>
														<td align="center"><?php echo $wrong_answer;?></td>
														<td align="center"><?php echo $user_get_marks;?></td>
														<td align="center" valign="middle">
															<a href="<?php echo BASE_URL;?>exmID/<?php echo $code;?>" title="View Questions">
                                                             <label style="mmargin-top: 15px; padding: 2px;" class="btn btn-block btn-xs label-<?php if($result_status=='PASS'){ echo 'success';}else{ echo 'danger';}?>"> <?php echo '<font color="white">'.$result_status.'</font>';?><i class="fa fa-eye fa-1x" style="color: white; margin-left: 5px; margin-top: 5px;"></i> </label>
															</a>
														</td>
														
													</tr>
								<?php
												}
											}
										}
								?>
									</tbody>
									
								</table>
									
							</div>
							
						</div>
<?php
////////////////////////////////////////////////////


                    ?>
				</div>
			</div>				

		</div>

		<?php require_once(__ROOT__.'/includes/footer.php');?>