<?php
    session_start();
    $code=$_SESSION['code'];
	//************************** Include Requied File ***************************
	define('__ROOT__', dirname(dirname(__FILE__))); 
	require_once(__ROOT__.'/includes/global.php'); 
	require_once(__ROOT__.'/includes/authentication.php');
	
	//error_reporting(0);

//FEEDBACK
    $subject= 'Feedback Received';
    $uid=$_REQUEST['uid'];
    $eid=$_REQUEST['eid'];
    $message=$_REQUEST['message'];
    //include('connection/dbconnect.php');
//include('../../connection/dbconnect.php');
 $servername="localhost";
    $username="searchurcollege";
    $password="Newme7503415202";
    $dbname="searchurcollege_main";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error)
        die("Connection failed: " . $conn->connect_error);
    if(strlen($message)>0)
    {
    	$stmIns="INSERT INTO feedback (user_id, exam_id, message) VALUES(?,?,?)";
    	$stmsIns = $conn->prepare($stmIns);
    	$stmsIns->bind_param('sis',$uid,$eid,$message);
    	$stmsIns->execute();
    	echo "feedback submited";

        //Settings
        $from_name='SearchUrSchool';
        $from="amitv92@gmail.com";  
        $signature='Regards<br />Administrator<br /><br />
        <b><img src="https://www.searchurcollege.com/frontassets/images/logo.png" width="150px"></b><br />
        Noida<br />';
    
        $mail_message='Dear Sir,<br /><br />A Feedback is received. Details below:<br /><br />';
        $mail_message.='<table width="50%">';
        $mail_message.='<tr><td>User</td><td>'.$uid.'</td></tr>';
        $mail_message.='<tr><td>Exam ID</td><td>'.$eid.'</td></tr>';
        $mail_message.='<tr><td>Message</td><td>'.$message.'</td></tr>';
        $mail_message.='<br /><br />'.$signature.'<br />';
        $headers = "From: $from_name <$from> \r\n"; 
        $headers .= "Reply-To: $from \r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        $headers .= "BCC: kapil.catalyst@gmail.com\r\n";
       
        //mail($from, $subject, $mail_message, $headers);
    }
?>