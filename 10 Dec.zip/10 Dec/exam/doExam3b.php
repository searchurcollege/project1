
<meta http-equiv="cache-control" content="private, max-age=0, no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
    include_once '../includes/global.php';
    include_once '../includes/authentication.php';
	define('__ROOT__', dirname(dirname(__FILE__))); 
	$examID = $_REQUEST['examid'];
    $userID = $_SESSION['regUsrId'];
    $sql="SELECT user_name FROM users WHERE user_id=?";
    $sql = $myconn->prepare($sql);
	$sql->bind_param('s', $userID);
	$sql->execute();
	$sql->store_result();
	$sql->bind_result($user_name);
	$sql->fetch();
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/start_exam.css">	
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/start_exam.css">	
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/do_exam.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<style>
.radioBtn
{
    padding-right: 20px!important;
    display: inline-block!important;
}
.scrollbar
{
	mmargin-left: 30px;
	float: left;
	height: 380px;
	width: 100%;
	background: #F5F5F5;
	overflow-y: scroll;
	margin-bottom: 25px;
}

.force-overflow
{
	min-height: 450px;
}

.style-4::-webkit-scrollbar-track
{
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar
{
	width: 10px;
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar-thumb
{
	background-color: #000000;
	border: 2px solid #555555;
}
</style>
<body style="overflow: hidden;">
    <?php
        if(isset($_POST['submit'])){
            header('Location: '.$_SERVER['REQUEST_URI']);
        }
        if(isset($_REQUEST['fq']))
            unset($_SESSION['timeLeft']);

        $exmName="SELECT exam_name, exam_duration, no_of_question, total_mark, pass_marks FROM exam where exam_id=? LIMIT 1";
        $exmName = $myconn->prepare($exmName);
    	$exmName->bind_param('i', $examID);
    	$exmName->execute();
    	$exmName->store_result();
    	$exmName->bind_result($exam_name,$exam_duration,$no_of_question,$total_mark,$pass_marks);
    	$exmName->fetch();
    	$_SESSION['no_of_question']=$no_of_question;
    
        //Fetch exam in Answer table
    	$tquestn="SELECT sno, question_id, time_left FROM user_answer WHERE user_id=? AND exam_id=? ORDER BY time_left";
        $tquestn = $myconn->prepare($tquestn);
        $tquestn->bind_param('si',$userID,$examID);
    	$tquestn->execute();
    	$tquestn->store_result();
    	$tquestn->bind_result($sno,$qid,$timeLeft);
    	$tquestn->fetch();

        if(isset($_SESSION['timeLeft']))
            ;
        else
        {
        	if(empty($timeLeft))
                $timeLeft=convertToHoursMins($exam_duration, '%02d:%02d:00');
            $_SESSION['timeLeft']=$timeLeft;
        }

    ?>
    <div class="row" style="background: #FF9934; margin: 0px;">
        <div class="col-md-9 text-center">
    		<h4 style="color: white;">SearchUrCollege Test Series (<?php echo $exam_name;?>) </h4>
        </div>
        <div class="col-md-3 pull-right" style="margin-top: 10px;">
    		<a href="https://www.searchurcollege.com/exam" style="margin-right: 10px; color: black;"><i class="fa fa-home"></i> HOME</a>
    		<a href="#DemoModal1" data-toggle="modal" style="margin-right: 10px; color: black;"><i class="fa fa-book"></i> Questions</a>
    		<a href="#DemoModal2" data-toggle="modal" style="margin-right: 10px; color: black;"><i class="fa fa-info-circle"></i> Instruction</a>
        </div>
    </div>
    <div class="row btn-primary" style="padding: 0px 15px 0px 15px;">
        <div class="col-md-3" style="margin-top: 8px;">
            <?php
                        $quesIdStm="SELECT question_id FROM questions WHERE exam_id=$examID";
                        $quesID = $myconn->prepare($quesIdStm);
                    	$quesID->execute();
                    	$quesID->store_result();
            			$quesID->bind_result($question_id);
                        $i=1;
                        $sno=array();
                        $qno=array();
            			while($quesID->fetch()>0)
                        {
                            $sno[$i-1]=$i;
                            $qno[$i-1]=$question_id;
                            $i++;
                        }
                        $one=$qno[0];
                        if($one=='')
                        {
                            echo 'Questions are not uploaded yet';
                            exit;
                        }
                        if(isset($_REQUEST['sn']))
                        {
                            if(isset($_REQUEST['prev']))
                            {
                                $sn=$_REQUEST['sn']-2;
                                if($sn<=1)
                                    $sn=0;
                            }
                            else
                            {
                                $sn=$_REQUEST['sn'];
                                if($sn==$_REQUEST['noq'])
                                    $sn=$sn-1;
                            }
                            $nqno=$qno[$sn];
                        }
                        else
                        {
                            $sn=1;
                            $nqno=$qno[0];
                        }
            ?>
            <b style="font-size: 15px;">Question : 
            <?php
                if(isset($_REQUEST['fq']))
                    echo $sn;
                else
                    echo $sn+1;
            ?>
            </b>
        </div>
        <div class="col-md-6" style="margin-top: 8px; text-align: right;">
            Language: 
            <select class="text-right" disabled="disabled" style="color: black;">
                <option>English</option>
                <option>Hindi</option>
            </select>
        </div>
        <div cclass="col-md-3">
            <div class="btn-group pull-right">
                <button type="button" class="btn btn-primary"><b style="font-size: 15px;">Time Left: </b></button>
                <input type="hidden" name="start_value" id="start_value" style="color: black;" value="<?php echo $_SESSION['timeLeft'];?>" />
                <input type="hidden" name="pause_value" id="pause_value" value="2" />
                <input type="hidden" name="timeLeft" style="color: black;" id="timeLeft" />
                <input type="hidden" name="loadData" id="loadData" />

                <button type="button" class="btn btn-primary" id="clock"><b style="font-size: 15px;"><span class="divCounter" id="divCounter"></span></b></button>
                <button type="button" class="btn btn-danger" id="pause"><i class="fa fa-pause"></i> Pause Test</button>
            </div>
        </div>
    </div>
    <div id="question_body1" class="row" style="background: white;">
        <div class="col-md-9" style="padding: 15px;">
            <div class="scrollbar style-4" style="padding: 15px; height: 70%; background: white;">
                <form action="doExam3.php" method="GET">
                    <?php
                        if(isset($_REQUEST['fq']))
                            echo '<input type="hidden" id="sn" name="sn" value="'.($sn).'" />';
                        else
                            echo '<input type="hidden" id="sn" name="sn" value="'.($sn+1).'" />';
                        $quesIdStm="SELECT question, question_type FROM questions WHERE question_id=$nqno";
                        $quesID = $myconn->prepare($quesIdStm);
                    	$quesID->execute();
                    	$quesID->store_result();
                    	$quesID->bind_result($question, $question_type);
            			while($quesID->fetch()>0)
                        {
                            $question=$question;
                            $question_type=$question_type;
                        }
                        echo $question;

                    ?>
                    <input type="hidden" id="sno" value="<?php echo $sn+1;?>" />
                    <input type="hidden" id="uid" value="<?php echo $userID;?>" />
                    <input type="hidden" id="qno" value="<?php echo $nqno;?>" />
                    <input type="hidden" id="eid" name="examid" value="<?php echo $examID;?>" />
                    <input type="hidden" id="noq" name="noq" value="<?php echo $no_of_question;?>" />
            </div>
        </div>
        <div class="col-md-3" style="padding: 15px; padding-right: 30px;">
            <table width="100%">
                <tr>
                    <td>
        				<img style="border: 0px;" src="<?php echo 'https://www.searchurcollege.com/exam/profile/profileImage/'.$_SESSION['photo'];?>" width="100px">
                    </td>
                    <td align="center"><?php echo strtoupper($user_name);?></td>
                </tr>
            </table>
			<div class="panel panel-danger" style="max-height: 60%;">
				<div class="panel-heading text-center">
					<h4 class="panel-title">Question Palette</h4>
				</div>
				<div class="panel-body" style="background: white; padding-right: 0px;">
					<ul id="quetionList1" class="nav nav-tabs scrollbar style-4 text-center" style="min-height: 150px; max-height: 150px; overflow-y: auto; background: white;">
						<?php
							$quesIdStm="SELECT question_id FROM questions where exam_id=?";
							$quesID = $myconn->prepare($quesIdStm);
							$quesID->bind_param('i', $examID);
							$quesID->execute();
							$quesID->store_result();
							$quesID->bind_result($question_id);
							$i=1;
							while($quesID->fetch()>0)
                            {
                                $color='';
                                //$answer='';
                                $quesIdStm2="SELECT answer, color FROM user_answer
                                    WHERE exam_id=$examID AND user_id='$userID' AND question_id=$question_id AND status!='submited'";
                                $quesID2 = $myconn->prepare($quesIdStm2);
                            	$quesID2->execute();
                            	$quesID2->store_result();
        						$quesID2->bind_result($answer,$color);
        						while($quesID2->fetch()>0)
                                {
                                    $answer=$answer;
                                    $color=$color;
                                    if($color=='#6FAE45')
                                        $c='white';
                                    else
                                        $c='black';
                                }
                                echo '<li class="q'.$i.'"><a style="color: '.$c.'; background: '.$color.'" data-toggle="tab" index="'.$i.'" onclick="refreshIframe('.$examID.','.$question_id.','.$i.');" id="tabID" class="not_visited" href="'.$i.'" title="'.$i.'">'.$i.'</a></li>';
                                $i++;
							}
						?>			
					</ul>
                </div>
				<div class="col-md-12" style="margin-top: -20px;">
					<table class="instruction_area">  
						<tbody>  
							<tr>  
								<td><span class="not_visited" title="Not Visited">1</span></td>  
								<td>Not Visited</td>  
							</tr>  
							<tr>  
								<td><span class="not_answered" title="Not Answered">2</span></td>  
								<td>Not Answered</td>  
							</tr>  
							<tr>  
								<td><span class="answered" title="Answered">3</span></td>  
								<td>Answered</td>  
							</tr>  
							<tr>  
								<td><span class="review" title="Not Answered &amp; Mark for Review">4</span></td>  
								<td>Marked for Review </td>  
							</tr>   
						</tbody>  
					</table> 
				</div>
			</div>
		</div>
        <!-- BUTTONS -->
        <div class="col-md-12" style="background: white; padding: 15px; bottom: 10px; position: fixed;">
            <div class="col-md-9 text-center">
                	<input type="hidden" id="correctAns" name="correctAns" value="<?php echo $answer;?>"/>
                    <b>Select Answer: </b>
                    <?php
                        if($question_type=='Single')
                        {
                        ?>
            				<label for="rd1" style="margin-left: 20px; cursor: pointer;"><input name="ans" class="radioBtn" <?php if($answer==1){echo 'checked=checked';}?>  type="radio" nname="correctAns" onclick="collectRadio(1);" id="rd1" value="1"/> 1 </label>
            				<label for="rd2" style="margin-left: 20px; cursor: pointer;"><input name="ans" class="radioBtn" type="radio" <?php if($answer==2){echo 'checked=checked';}?>  nname="correctAns" onclick="collectRadio(2);" id="rd2" value="2"/> 2 </label>
            				<label for="rd3" style="margin-left: 20px; cursor: pointer;"><input name="ans" class="radioBtn" type="radio" <?php if($answer==3){echo 'checked=checked';}?>  nname="correctAns" onclick="collectRadio(3);" id="rd3" value="3"/> 3 </label>
            				<label for="rd4" style="margin-left: 20px; cursor: pointer;"><input name="ans" class="radioBtn" type="radio" <?php if($answer==4){echo 'checked=checked';}?>  nname="correctAns" onclick="collectRadio(4);" id="rd4" value="4"/> 4 </label>										
                        <?php
                        }
                        else
                        {
                        ?>
            				<label for="rd1" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" <?php if(strpos($answer, '1') !== false){echo 'checked=checked';}?> type="checkbox" onchange="collect(1,'rd1');" id="rd1" value="1"/> 1 </label>
               				<label for="rd2" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="checkbox" <?php if(strpos($answer, '2') !== false){echo 'checked=checked';}?> onchange="collect(2,'rd2');" id="rd2" value="2"/> 2 </label>
            				<label for="rd3" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="checkbox" <?php if(strpos($answer, '3') !== false){echo 'checked=checked';}?> onchange="collect(3,'rd3');" id="rd3" value="3"/> 3 </label>
            				<label for="rd4" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="checkbox" <?php if(strpos($answer, '4') !== false){echo 'checked=checked';}?> onchange="collect(4,'rd4');" id="rd4" value="4"/> 4 </label>
                        <?php
                		}
                    ?>
                <br /><br />
            	<button id="clearResponse" class="btn btn-info"><b>CLEAR RESPONSE</b></button>
            	<button id="review" type="submit" name="review" value="review" class="btn btn-warning"><b>REVIEW</b></button>
            	<button id="prev" name="prev" type="submit" class="btn btn-primary"><b><i class="fa fa-chevron-left"></i> PREV</b></button>
            	<button id="next" name="next" type="submit" class="btn btn-primary"><b>Save & NEXT <i class="fa fa-chevron-right"></i></b></button>
            </div>
            <div class="col-md-3 text-center">
    			<form id="formSubmitExam" name="formSubmitExam">
    				<input type="hidden" name="btn" id="btn">
    				<input type="hidden" nname="hfUserId" id="hfUserId" value="<?php echo $_SESSION['regUsrId'];?>">
    				<input type="hidden" nname="hfExamId" id="hfExamId" value="<?php echo $examID;?>">
    				<input type="hidden" nname="hfTotalNoQues" id="hfTotalNoQues" value="<?php echo $no_of_question;?>">
    				<input type="hidden" nname="hfTimeDuration" id="hfTimeDuration" value="<?php echo $exam_duration;?>">
    				<input type="hidden" nname="hfTotalMarks" id="hfTotalMarks" value="<?php echo $total_mark;?>">
    				<input type="hidden" nname="hfPassMarks" id="hfPassMarks" value="<?php echo $pass_marks;?>">
					<a href="<?php echo BASE_URL;?>end-exam" type="button" id="btnSubmitExam" name="btnSubmitExam" class="btn btn-danger">SUBMIT YOUR EXAM</a>
    			</form>
            </div>
    </div>
    </form>
    </div>
</body>


	<!--***********************************************************************************
	//	#: Instruction Modal 
	***************************************************************************************-->
	<div class="DemoModal2">
		<!-- Modal Contents -->
		<div id="DemoModal2" class="modal fade"> <!-- class modal and fade -->
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header"> <!-- modal header -->
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
						<h4 class="modal-title"><p> <b><u>Instruction : </u></b></p></h4>
					</div>
					<div class="modal-body" style="min-height:550px; max-height:550px; overflow-y: scroll"> <!-- modal body -->
							<ol style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
								<li>Total duration of examination is <span class="text-danger"><b><?php echo $exam_duration; ?> minutes. </b></span></li>  
								<li>The clock will be set at the server. The countdown timer in the top right corner of screen will display the remaining time available for you to complete the examination. When the timer reaches zero, the examination will end by itself. You will not be required to end or submit your examination.</li>  
								<li>The Question Palette displayed on the right side of screen will show the status of each question using one of the following symbols:<br>  
									<table class="instruction_area" style="FONT-SIZE: 100%">  
										<tbody>  
											<tr>  
												<td><span class="not_visited" title="Not Visited">A</span></td>  
												<td>You have not visited the question yet.</td>  
											</tr>  
											<tr>  
												<td><span class="not_answered" title="Not Answered">B</span></td>  
												<td>You have not answered the question.</td>  
											</tr>  
											<tr>  
												<td><span class="answered" title="Answered">C</span></td>  
												<td>You have answered the question.</td>  
											</tr>  
											<tr>  
												<td><span class="review" title="Not Answered &amp; Mark for Review">D</span></td>  
												<td>You have NOT answered the question, but have marked the question for review.</td>  
											</tr>  
											<tr>  
												<td><span class="review_answered" title="Answered &amp; Mark for Review" style="background-position: -6px -82px; line-height: 34px;">E</span></td>  
												<td>You have answered the question, but marked it for review.</td>  
											</tr>  
										</tbody>  
									</table>  
								</li> 
								<li style="LIST-STYLE-TYPE: none">The Marked for Review status for a question simply indicates that you would like to look at that question again. 
									<font color="red">
										<i>If a question is answered and Marked for Review, your answer for that question will be considered in the evaluation. </i>
									</font>
								</li> 
							</ol>
							<br>
							<p> <b><u>Navigating to a Question : </u></b></p>
							<br>
							<ol start="4" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
								<li>To answer a question, do the following:  
									<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a"> 
										<li>Click on the question number in the Question Palette to go to that numbered question directly.</li>  
										<li>Click on <strong>Save &amp;Next</strong> to save your answer for the current question and then go to the next question.</li>  
										<li>Click on <strong>Mark for Review &amp; Next</strong> to save your answer for the current question, mark it for review, and then go to the next question.<br>  
											<span style="color:#ff0000;">Caution: Note that your answer for the current question will not be saved, if you navigate to another question directly by clicking on its question number.</span>
										</li> 
									</ol> 
								</li><br> 
								<li>You can view all the questions by clicking on the Question Paper button. Note that the options for multiple choice type questions will not be shown.</li> 
							</ol><br>	
						<p> <b><u>Answering a Question : </u></b></p>
						<br>						
						<ol start="6" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
							<li>Procedure for answering a multiple choice type question:  
								<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a">  
									<li>To select your answer, click on the button of one of the options.</li> 
									<li>To deselect your chosen answer, click on the button of the chosen option again or click on the <b>Clear Response</b> button.</li>  
									<li>To change your chosen answer, click on the button of another option.</li>  
									<li>To save your answer, you MUST click on the <b>Save &amp; Next</b> button.</li>  
									<li>To mark the question for review, click on the <b>Mark for Review &amp; Next</b> button.<br>  
										<em><span style="color:#ff0000;">If an answer is selected for a question that is 'Marked for Review', that answer will be considered in the evaluation even if it is not marked as 'Save &amp; Next', at the time of final submission</span>.</em>
									</li>  
								</ol>  
							</li>  
							<li>To change your answer to a question that has already been answered, first select that question for answering and then follow the procedure for answering that type of question.</li> 
							<li>Note that questions for which option has been chosen and answers are saved or marked for review will be considered for evaluation.</li> 
							<li><em><span style="color:#ff0000;">� (one fourth) marks i.e. one mark will be deducted for indicating incorrect response of each question. No deduction from the total score will be made if no response is indicated for a question</span></em>.</li> 
						</ol><br>
						<div class="cusInstText1" style="height: 91%; width: 100%; overflow: auto; display: block;">
							<p style="text-align: center;">
								<u><strong>Exam specific Instructions</strong></u>
							</p> <br> <br> 
							<ol> 
								<li>This is a Mock test. The Question paper displayed is for practice purposes only. Under no circumstances should this be presumed as a sample paper.</li> 
								<li>Each question is allocated 4 (four) marks for each correct.</li> 
								<li>One fourth marks will be deducted for incorrect response of each question. No deduction from the total score will be made if no answer is given.</li> 
								<li>There is only one correct answer for each question.</li> 
							</ol> <br> <br> 
						</div>														
					</div>
				</div> <!-- / .modal-content -->
			</div> <!-- / .modal-dialog -->
		</div><!-- / .modal -->
	</div>
	<!--***********************************************************************************
	//	#: Instruction Modal 
	***************************************************************************************-->
	<div class="DemoModal1">
		<!-- Modal Contents -->
		<div id="DemoModal1" class="modal fade"> <!-- class modal and fade -->
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header"> <!-- modal header -->
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
						<h4 class="modal-title text-primary"><p> <b>All Questions :</b></p></h4>
					</div>
					<div class="modal-body" style="min-height:550px; max-height:550px; overflow-y: scroll"> <!-- modal body -->
						<?php             
							$QuesList="SELECT question FROM questions where exam_id=?";
							$QuesList = $myconn->prepare($QuesList);
							$QuesList->bind_param('i', $examID);
							$QuesList->execute();
							$QuesList->store_result();
							$QuesList->bind_result($ViewQuestion);
                            $QNo=1;
							while($QuesList->fetch()>0){
						?>	
						<div class="well well-sm text-center">
						    <span class="text-danger pull-left"><?php echo 'Question '.$QNo;?></span>
						    <hr style="border-top: 1px solid #0a540d;">
							<?php echo $ViewQuestion;?>
						</div>						
						<?php
					    	$QNo++;
							}
						?>
					</div>
				</div> <!-- / .modal-content -->
			</div> <!-- / .modal-dialog -->
		</div><!-- / .modal -->
	</div>

	<input type="hidden" id="option1" />
	<input type="hidden" id="option2" />
	<input type="hidden" id="option3" />
	<input type="hidden" id="option4" />

<?php
function convertToHoursMins($time, $format = '%02d:%02d')
{
    if ($time < 1)
        return;
    $hours = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}
?>

<script>
	$('#pause').click(function(){
		//$('#pause').hide();
        v=parseInt($('#pause_value').val())+1;
        $('#pause_value').val(v);
        if($('#pause').html()=='<i class="fa fa-play"></i> Start Test')
            $('#pause').html('<i class="fa fa-pause"></i> Pause Test');
        else
            $('#pause').html('<i class="fa fa-play"></i> Start Test');
        $('#question_body1').hide();
        $('#question_body2').show();
        $('#quetionList1').hide();
        $('#quetionList2').show();
    });

	$('#clearResponse').click(function(e){
		$('.radioBtn').removeAttr('checked');
		$('.radioBtn').removeAttr('checked');
        $('#correctAns').val('');
        e.preventDefault();
        return false;
 	});

	$('#prev').click(function(e){
        var sno=$('#sno').val();
        $('#sno').val(sno-1);
	});

	$('#next').click(function(e){
        //myVar = $(".panel").find('.1').val();
        //alert(1);
        //$('.q1').css({'border-width':'9px', 'border-style':'solid', 'border-color':'red'});

        var sno=$('#sno').val();
        var uid=$('#uid').val();
        var qno=$('#qno').val();
        var eid=$('#eid').val();
        var noq=$('#noq').val();
        var tl=$('#timeLeft').val();
        var btn=$('#btn').val('Y');
        $('#next').val('Y');
        var correctAns=$('#correctAns').val();
        var param='?btn='+btn+'&sno='+sno+'&uid='+uid+'&qno='+qno+'&eid='+eid+'&correctAns='+correctAns+"&tl="+tl;
		$.ajax({
		type: "POST",
		url: 'save_answer.php'+param,
		data: param,
		success: function(data){
        	if(UsrAns>0){
				$('.'+QuesNo).find('a').addClass('answered').removeClass("not_answered not_visited review");
			}
			if(!$.trim(data)){
				alert('You have reached last question');
				return false;
			}					
			$("#questionID").html(data);
			var QuesNoNew=$('#hfQuesNo').val();
			if(isNaN(QuesNoNew))
                QuesNoNew=1;
			$('#Qno').text('Question '+QuesNoNew);
			$('.'+QuesNoNew).find('a').addClass('not_answered').removeClass("not_visited answered review");
			}
		});
		});
        
        function collectRadio(x)
        {
            $('#correctAns').val(x);
        }
        function collect(x,y)
        {
            if($("#"+y).is(':checked'))
            {
                if(y=='rd1')
                    $('#option1').val(1);
                if(y=='rd2')
                    $('#option2').val(2);
                if(y=='rd3')
                    $('#option3').val(3);
                if(y=='rd4')
                    $('#option4').val(4);
                a=$('#option1').val();
                b=$('#option2').val();
                c=$('#option3').val();
                d=$('#option4').val();
                if(a.length>0)
                    a=a+', ';
                if(b.length>0)
                    b=b+', ';
                if(c.length>0)
                    c=c+', ';
                if(d.length>0)
                    d=d+', ';
                e=a+b+c+d;
                e=e.slice(0,-2);
                $('#correctAns').val(e);
            }
            else
            {
                if(y=='rd1')
                    $('#option1').val('');
                if(y=='rd2')
                    $('#option2').val('');
                if(y=='rd3')
                    $('#option3').val('');
                if(y=='rd4')
                    $('#option4').val(''); 
                a=$('#option1').val();
                b=$('#option2').val();
                c=$('#option3').val();
                d=$('#option4').val();
                if(a.length>0)
                    a=a+', ';
                if(b.length>0)
                    b=b+', ';
                if(c.length>0)
                    c=c+', ';
                if(d.length>0)
                    d=d+', ';
                e=a+b+c+d;
                e=e.slice(0,-2);
                $('#correctAns').val(e);
            }
        }
    </script>


<script>
	var hoursleft = 0;
    var minutesleft = 0;
    var secondsleft = 0;
	var hoursleft = parseInt($('#start_value').val().substring(0,2)); //give minutes you wish
	var minutesleft = parseInt($('#start_value').val().substring(3,5)); //give minutes you wish
    var secondsleft = parseInt($('#start_value').val().substring(6,8)); // give seconds you wish

	var sec = secondsleft;
	var mins = minutesleft;
	var hours = hoursleft;
	var finishedtext = "Time Up!";
	var end1;
	//if(localStorage.getItem("end1")) {
	//	end1 = new Date(localStorage.getItem("end1"));
	//}  else
     {
		end1 = new Date();
		end1.setHours(end1.getHours()+hoursleft);
		end1.setMinutes(end1.getMinutes()+minutesleft);
		end1.setSeconds(end1.getSeconds()+secondsleft);
	}
	    var counter = function () {
		var now = new Date();
	    var diff = end1 - now;

		diff = new Date(diff);

		var milliseconds = parseInt((diff%1000)/100)
		var sec = parseInt((diff/1000)%60)
		var mins = parseInt((diff/(1000*60))%60)
		var hours = parseInt((diff/(1000*60*60))%24);
		if (hours < 10) {
			hours = "0" + hours;
		}
		if (mins < 10) {
			mins = "0" + mins;
		}
		if (sec < 10) { 
			sec = "0" + sec;
		}
		if(now >= end1) {
			clearTimeout(interval);
		   // localStorage.setItem("end", null);
			localStorage.removeItem("end1");
			localStorage.clear();
			document.getElementById('divCounter').innerHTML = finishedtext;
			$('#btn').attr("disabled", true);
			$('#btnNext').attr("disabled", true);
            var $examID=$('#$examID').val();
			// Submit Exam 
			$.ajax({
				type: "POST",
				url: "<?php echo BASE_URL;?>exam/submit_exam.php?examID="+$examID,
				data: $('#formSubmitExam').serialize(this),
				success: function(response) {
					if(response=="submited"){
						wihe = 'width='+screen.availWidth+',height='+screen.availHeight;
						window.open( '<?php echo BASE_URL;?>exam/end_exam.php','EndExam',"screenX=1,screenY=1,left=1,top=1," + wihe),
						window.close('DoExam')
						return false;
					}
				}
			});
		} else {
            if(($('#pause_value').val()%2)==0)
            {
				var value =hours + ":" + mins + ":" + sec;
                $('#pause').val('Pause Test');
                $('#timeLeft').val(value);
                
                //document.write('<a href="another_page.php?xt='+value+'">aa</a>';);
                
                $('#question_body1').show();
                $('#question_body2').hide();
                $('#quetionList1').show();
                $('#quetionList2').hide();
				localStorage.setItem("end1", end1);
				document.getElementById('divCounter').innerHTML = value;
            }
            else
            {
                $('#start_value').val($('#timeLeft').val());
    			hoursleft = parseInt($('#start_value').val().substring(0,2)); //give minutes you wish
    			minutesleft = parseInt($('#start_value').val().substring(3,5)); //give minutes you wish
                secondsleft = parseInt($('#start_value').val().substring(6,8)); // give seconds you wish

				end1 = new Date();
				end1.setHours(end1.getHours()+hoursleft);
				end1.setMinutes(end1.getMinutes()+minutesleft);
				end1.setSeconds(end1.getSeconds()+secondsleft);
			    counter = function () {
				now = new Date();
			    diff = end1 - now;
   				diff = new Date(diff);
				milliseconds = parseInt((diff%1000)/100)
				sec = parseInt((diff/1000)%60)
				mins = parseInt((diff/(1000*60))%60)
				hours = parseInt((diff/(1000*60*60))%24);
				if (hours < 10)
					hours = "0" + hours;
				if (mins < 10)
					mins = "0" + mins;
				if (sec < 10)
					sec = "0" + sec;
                }
            }
		}
	}
	var interval = setInterval(counter, 0);
</script>

<script>
	//*********************** Submit Exam ****************************	
	$('#btnSubmitExam').click(function(){
	 if (confirm('Are you sure you want to Submit?'))
     {
        alert(3);
		$.ajax({
			type: "POST",
			url: "<?php echo BASE_URL;?>exam/submit_exam.php",
			data: $('#formSubmitExam').serialize(this),
			success: function(response) {
				if(response=="submited"){
					window.open( this.href,'DoExam',"location=no,status=no,menubar=no,toolbar=no,resizable=no,scrollbars=no," + wihe),
					window.close(this)
					return false;
				}
			}
			 alert(2);
		});
    }
    else
		return false;
	});		
</script>

</body>
