<!DOCTYPE html>
  <link rel="stylesheet" type="text/css" href="css/slick.css">
  <link rel="stylesheet" type="text/css" href="css/slick-theme.css">
  <title>Search ur College-Model Question Paper</title>
  <meta name="description" content="Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test">
  <meta name="keywords" content="MAT,CAT,XAT,CMAT, Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css'>

 


<?php
define( "BASE_URL", "https://www.searchurcollege.com/exam/");
?>
<style class="cp-pen-styles">

*, *:before, *:after {
  box-sizing: border-box;
}

.load-more-container {
  background: transparent;
  width: 100%!important;
  min-height: 500px;
  margin: 20px auto;
  position: relative;
}
.load-more-container ul {
  list-style-type: none;
  padding: 0;
}
.load-more-container ul:after {
  content: "";
  display: table;
  clear: both;
}
.load-more-container ul li {
  width: calc(20% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 5px;
}
.load-more-container ul li:nth-child(1n + 7) {
  max-height: 0;
  opacity: 0;
  transition: 0.1s ease-in;
}
.load-more-container .load-more-btn {
  width: 150px;
  line-height: 40px;
  border-radius: 2px;
  margin: 0 auto;
  display: block;
  background: #219150;
  color: #fff;
  cursor: pointer;
  text-align: center;
}
.load-more-container .load-more-btn:hover {
  background: green;
}
.load-more-container .load-more-btn .loaded {
  display: none;
}
.load-more-container #load-more {
  display: none;
}
.load-more-container #load-more:checked ~ ul li:nth-child(1n + 5) {
  max-height: 999px;
  opacity: 1;
  transition: 0.2s ease-in;
}
.load-more-container #load-more:checked ~ .load-more-btn .loaded {
  display: block; 
}
.load-more-container #load-more:checked ~ .load-more-btn .unloaded {
  display: none;
  
}

@media (max-width: 500px) {
 .load-more-container ul li {
  width: calc(100% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 2px;
}

}

@media screen and (min-width: 200px) and (max-width: 499px){
    #dv{display: none;}
    #mv{display: inline;}
}
section.study-section .nav-tabs {
    border-bottom: 2px solid transparent!important;
}


.scrollbar
{
mmargin-left: 30px;
float: le0t;
height: 400px;
width: 100%;
background: #ffffff;
overflow-y: scroll;
margin-bottom: 25px;
}
.force-overflow
{
min-height: 450px;
}
.style-4::-webkit-scrollbar-track
{
-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
background-color: #596f7c;
}
.style-4::-webkit-scrollbar
{
width: 10px;
background-color: #F5F5F5;
}
.style-4::-webkit-scrollbar-thumb
{
background-color: #000000;
border: 2px solid #555555;
}

</style>
  
  
  <style type="text/css">
    .blocks
    {
        background: white;
        display: inline-flexbox!important;
        padding: 5px;
        border-radius: 5px;
        text-align: center;
        width: 100px;
        min-width: 70px!important;
        margin-right: 15px!important;
    }
    .bB1
    {
        margin-left: -10px;
        margin-top: 28px;
    }
    .B2
    {
        margin-left: -30px;
        mmargin-top: -40px;
    }
    .nav-pills>li.active>a, .nav-pills>li.active>a:hover, .nav-pills>li.active>a:focus
    {
        background: #596f7c!important;
    }
    .slick-prev:before, .slick-next:before
    {
        color: white!important;   
    }
    * {
      box-sizing: border-box;
    }

    .slider {
        width: 100%;
        margin-top: 10px;
    }

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 100%;
    }

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }
    .slick-prev
    {
          margin-left: 15px;
    }
    .slick-next
    {
          margin-right: 15px;
    }


    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: 1;
    }
    
    .slick-active {
      opacity: 1;
    }

    .slick-current {
      opacity: 1;
    }


.tabs-content {
       @include clearfix;
       margin-bottom: $tabs-content-margin-bottom;
       width: 100%;
       > .content {

          // Replacement for display: none;, a fix for carousel in tabs
         overflow-y: hidden;
         height: 0;

         float: $default-float;
         padding: $tabs-content-padding 0;
         width: 100%;
         &.active { display: block; float: none;  height: auto;}  // height: auto; added. Also part of the display: none; replacement, a fix for carousel in tabs
         &.contained { padding: $tabs-content-padding; }
       }
       &.vertical {
         display: block;
         > .content { padding: 0 $tabs-content-padding; }
      }
        
        section.study-section .tab-content {
        margin-top: 40px!important;
}
    }
    
   body{
    background: white!important;
   }
   
.exam-tab .nav>li>a {
    position: relative;
    display: block;
    padding: 0px 60px;
    padding-bottom: 3px;
    font-size: 22px!important;
    border-radius: 0px;
    color: #596F7C;
    margin-left: 17px;
}   
@media screen and (min-width: 200px) and (max-width: 499px){
    
 .exam-tab .nav>li>a {
    position: relative;
    display: block;
    padding: 0px 30px;
    padding-bottom: 3px;
    font-size: 16px!important;
    border-radius: 0px;
    color: #596F7C;
    margin-left: 15px;
}   
 .btn-group-lg>.btn, .btn-lg {
    padding: 05px 16px!important;
    font-size: 15px!important;
    line-height: 1.3333333;
    border-radius: 6px;
} 
#title{
    
    font-size:20px!important;
}  
} 
.btn-group-lg>.btn, .btn-lg {
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.3333333;
    border-radius: 6px;
} 
  
      </style>
<?php

include('../../connection/header.php');



$id=$_REQUEST['id'];

$name=selectStreamc2($id);

?>
<div class="col-md-12" style="background: url('https://www.searchurcollege.com/frontassets/images/slide_new_d.jpg');height: 150px;"></div>

        <div class="text-center free-text" style="margin-top: 2px; margin-bottom: 10px;">
         <span style="font-size: 30px;"><b><?php echo strtoupper($name);?> TEST</b></span><br />
        </div>
        
        <div class="col-md-2" style="background: ; margin-right: -15px;"> 
		<?php include('left.php'); ?>
        </div>
        
        <div class="col-md-10" style="padding: 0px;">
        <div class="exam-tab" style="margin-top: -10px; padding: 0px;">
          <ul class="nav nav-pills" style="border: 0px;">
            <?php
                $n=0;            
                $z2=1;            
                $z3=$w=0;            
                $main_cat_id=array();
                $exam_cat_id=array();
                $result=level2();
                foreach($result as $var)
                    $main_cat_id[]=$var['main_cat_id'];
                for($i=0;$i<sizeof($main_cat_id);$i++)
                {
                    $v=$main_cat_id[$i];
                    $result=level3($v);
                    $x=0;
                    foreach($result as $var)
                    {
                        $exam_cat_id[]=$var['exam_cat_id'];
                        $x++;
                    }
                    if($x>0)
                    {
                        $result=level2b($v);
                        foreach($result as $var)
                            $title=$var['main_cat_name'];
                            
                        if($i==0)
                            echo '<li class="active"><a data-toggle="pill" href="#exam-one'.$i.'" style="border-radius: 10px;"><b>'.$title.'</b></a></li>';
                        else
                        if($i==1)
                            echo '<li onclick=setHeight();><a data-toggle="pill" href="#exam-one'.$i.'" style="border-radius: 10px;"><b>'.$title.'</b></a></li>';
                        else
                            echo '<li><a data-toggle="pill" href="#exam-one'.$i.'" style="border-radius: 10px;"><b>'.$title.'</b></a></li>';
                    }
                }
        echo '</ul>
        <div class="row"></div>
        <div class="col-md-12 tab-content" style="bbackground: red; margin-top: 20px!important; padding: 0px!important;">';
        $x=0;
        $p=0;
        $q=0;
        for($j=0;$j<$i;$j++)
        {
            if($j==0)
                echo '<div id="exam-one'.$j.'" class="tab-pane fade in active" style="bbackground: green; paddin-bottom: 0px!important;">';
            else
                echo '<div id="exam-one'.$j.'" class="tab-pane fade in">';
            echo '<div style="padding: 15px!important;">';

            echo '<section class="study-section" style="background: white; padding: 0px;"><div class="#">';
            $v=$main_cat_id[$j];

            $result=level3($v);     //Level 3
            echo'<div style="bbackground: green; margin-top: -22px; margin-bottom: 10px;">';
            $e=$f=0;
            $s=1; 
            $clr=array();
            $clr[0]='#ffffff;';
            $clr[1]='#ffffff;';
            $clr[2]='#ffffff;';
            $clr[3]='#ffffff;';
            $clr[4]='#ffffff;';
            foreach($result as $var)
            {
                $exam_cat_name=$var['exam_cat_name'];
                if($exam_cat_name!='Others')
                {                
                 if($e==0)
                  echo '<a class="varc" data-toggle="pill" href="#home'.$p.'" style="color: white; margin-right: 20px; min-width: 0px;"><button id="btn'.$p.'" class="btn btn-lg" style="min-width: 100px; background: #596F7C; min-width: 0px;" onclick="show('.$p.');">'.$exam_cat_name.'</button></a>';
                 else                     
                  echo '<a data-toggle="pill" href="#home'.$p.'" style="color: black; margin-right: 20px;"><button id="btn'.$p.'" class="btn btn-lg" style="min-width: 100px;  min-width: 0px; background: '.$clr[$f].'" onclick="show('.$p.');">'.$exam_cat_name.'</button></a>';                    
                 $n++;                    
                }
                $e++;
                $f++;
                $p++;
                if($f==5)
                    $f=0;
            }
            echo '</div>';
            $result=level3($v);     //Level 3

//VARC TABS
//echo '<br>N='.$e.'<br>';
if($e>=0 && $e<=1)
    echo '<div class="tab-content scrollbar style-4" style="background: #596f7c!important; padding: 20px; padding-bottom: 45px; margin-top: -25px; min-height: 550px;">';
else
    echo '<div class="tab-content scrollbar style-4" style="background: #596f7c!important; padding: 20px; padding-bottom: 45px; margin-top: 0px; min-height: 550px;">';
            $e=1;
            foreach($result as $var)
            {
                $exam_cat_id=$var['exam_cat_id'];
                $exam_cat_name=$var['exam_cat_name'];
                
                if($e==1)
                    echo '<div id="home'.$q.'" class="tab-pane fade in active" style="margin-lefT: 30px;">';
                else
                    echo '<div id="home'.$q.'" class="tab-pane fade in">';
                $result=level4($exam_cat_id);     //Level 4
                foreach($result as $var)
                {
                    $exam_exercise_id=$var['exam_exercise_id'];
                    $title=$var['exam_exercise_name'];
                    echo '<div class="clearfix"></div>';
                    if($title!='Others')
                    {
                        //echo '<ul class="nav nav-tabs">';
        		        //echo '<li class="active"><a data-toggle="tab" href="#" style="background:#fe9837; padding: 0px 20px!important; margin-top: -5px!important; position: relative!important;"><font size="4"><b style="padding-bottom: 15px!important;">'.$title.'</b></font></a></li>';
                        //echo '</ul>';
                        if($z2==1)
                            echo '<button class="btn btn-default" style="background: orange; color: white; font-size: 18px; border: 0px; margin-top: 0px;"><i class="fa fa-folder"></i> <b style="margin-left: 5px; letter-spacing: 2px;">'.$title.'</b></button>';
                        else
                            echo '<button class="btn btn-default" style="background: orange; color: white; font-size: 18px; border: 0px; margin-top: 15px;"><i class="fa fa-folder"></i> <b style="margin-left: 5px; letter-spacing: 2px;">'.$title.'</b></button>';
                    }
                    $z2++;
                    ///level5 code///
                    echo'<div class="col-md-12" style="bbackground: red; margin-top: -28px!important; margin-left: -35px!important; margin-bottom: -28px!important;">
                    
                    
                        <div class="load-more-container col-md-12">
                        <input type="checkbox" id="load-more'.$z3.'"/>
                        
                    <ul>';
                   
echo'<style> 
 .load-more-container #load-more'.$z3.' {
  display: none;
}
.load-more-container #load-more'.$z3.':checked ~ ul li:nth-child(1n + 7) {
  max-height: 999px;
  opacity: 1;
  transition: 0.2s ease-in;
}
.load-more-container #load-more'.$z3.':checked ~ .load-more-btn .loaded {
  display: block;
 
}
.load-more-container #load-more'.$z3.':checked ~ .load-more-btn .unloaded{
  display: none;
  
}
 </style>';
                        $result2=level5($exam_exercise_id);
                        $z=1;
                        $z4=1;
                        foreach($result2 as $var2)
                        {
                            $mci=$var2['main_cat_id'];
                            $exam_id=$var2['exam_id'];
                            $title2=$var2['exam_name'];
       
                            
                            
                            echo'<li>
                            
                            <center><span style="font-size: 20px; color: #fe9837; padding-top: 10px; letter-spacing: 1px;"><b>'.$title2.'</b></span>
                            <br><span style="cursor: pointer;" onclick=chk("'.$exam_id.'");><button class="btn btn-success btn-sm" sstyle="bbackground: '.$bgcolor.'; color: white;">Start Test</button></span></center>
                            
                            </li>';
                            $z4++;
                        }         
 
  echo'</ul>';
  if($z4>=6)
      echo '<label class="load-more-btn" for="load-more'.$z3.'">
        <span class="unloaded pull-right"><i class="fa fa-angle-double-down fa-lg" style="color: white; position: absolute; right: -14px; margin-top: -35px"></i></span>
        <span class="loaded pull-right"><i class="fa  fa-angle-double-up fa-lg" style="color: white; position: absolute; right: -14px; margin-top: -35px"></i></span>
      </label>';
echo '</div>';
$z3++;
                        
                        
                        
                    echo'</div>';
                    
                   ////level5 code end///// 
                    
                }
                echo '</div>';
            $q++;
            }
echo '<div style="height: 200px;"></div>';
            
        echo '<div></div>';
        echo '</div>';
        //END VARC
 

                    $k++;

            echo '</div></section></div></div>';
        }
        echo '<input type="hidden" id="elementc" value="'.$n.'"/>';
        ?>


       </div>
      
</div>

			   
              <!-- end exam circle -->
           
            
  </div></div>      

<section>
<?php
    include('../../footer.php');
?>

</section>




    <!-- ...........End js include here.............. -->

<script type="text/javascript">
	$(document).ready(function(){
$('.carousel[data-type="multi"] .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
  for (var i=0;i<4;i++) {
    next=next.next();
    if (!next.length) {
        next = $(this).siblings(':first');
  	}
    
    next.children(':first-child').clone().appendTo($(this));
  }
});
});	</script>
    <sscript src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <sscript src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

  <sscript src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  <sscript src="js/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $(".regular").slick({
        dots: false,
        infinite: true,
        slidesToShow: 6,
        slidesToScroll: 6
      });
    });

    $(document).ready(function () {
         var screen = $(window).width();  
         if (screen > 768)
         {
              $(".regular").slick({
                dots: false,
                infinite: true,
                slidesToShow: 6,
                slidesToScroll: 6
              });
         }
         else
         {
              $(".regular").slick({
                dots: false,
                infinite: true,
                slidesToShow: 3,
                slidesToScroll: 3
              });
         }
     });
     </script>
<script>
$('.nav-tabs').load(
    function()
    {
        $('.exam-tab .nav').removeClass('.nav');
    }
);
    function show2(x)
    {
        x='.'+x;
        $(x).css('display','inline');
    }
</script>

<script>
$('.nav-pills li').on('click', function (e) {
       $('.slick-arrow').trigger('click');

});

function show(x)
{
    
     var s='#btn'+x;
     var n=$('#elementc').val();
     for(i=1;i<=n;i++)
     {          
        s2='#btn'+i;
        $(s2).css("background-color","white");
        $(s2).css("color","black");
     }
     $(s).css("background-color","#596F7C");
     $(s).css("color","White");

}
</script>

<script>
    function show3(x)       //View More
    {
        var obj='#A'+(x);
        var b1='#B'+(x);
        var b2='#C'+(x);
        $(obj).css("display","block");
        $(b1).css("display","none");
        $(b2).css("display","block");
    }
    function show4(x)       //View Less
    {
        var obj='#A'+(x);
        var b1='#B'+(x);
        var b2='#C'+(x);
        $(obj).css("display","none");
        $(b1).css("display","block");
        $(b2).css("display","none");
    }
    function chk(exam_id)
    {
        u='https://www.searchurcollege.com/connection/chk_url.php?eid='+exam_id;
        $.ajax({
            type: "POST",
            url: u,
            success: function(data)
            {
                if(data==0)
                {
                    $('#log2').click();
                    $("#login2 #eid").val(exam_id);
                }
                else
                //if(data==1)
                    $(location).attr('href', 'https://www.searchurcollege.com/exam/start-exam/'+exam_id);
                /*else
                if(data==2)
                    $(location).attr('href', 'https://www.searchurcollege.com/connection/pay_now.php');*/
            }
         });
    }
    function mv(){
         $("#mv").hide();
    }
</script>

<script type="text/javascript"> 
    var mobile = (/iphone|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()));  
    if(mobile)
    { 
        $('#mv').css('display', 'e');
    }
</script>


<div id="login2" class="modal fade" role="dialog" style="margin-top: 100px;">
  <div class="modal-dialog">
    <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="col-md-12" style="background: white; padding: 10px; padding-bottom: 45px!important;">
                <h4 class="modal-title"><b><i class="fa fa-user-o"></i> User Login</b><br /><br /></h4>
                <input type="hidden" id="eid" value="<?php //echo $_REQUEST['eid'];?>" />
                <form id="frmLogin2" action="user_login.php">
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="text" class="form-control" name="email" placeholder="Email" required />
                    </div>
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="password" class="form-control" name="password" placeholder="Password" required />
                    </div>
                    <div class="col-md-12 text-right">
                        <button type="submit" class="btn btn-success pull-left">Login</button>
                        <button type="button" class="btn btn-default pull-right"class="close" data-dismiss="modal">Close</button>
                        <span id="success2" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Login Succeeded.</span>
                        <span id="error2" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Invalid Credentials</span>
                    </div>
                    <div class="col-md-12">
                        <!--<a href="" class="pull-right" style="margin-right: 5px;"><img src="../img/google.png" height="30" /></a>
                        <a href="" class="pull-right" style="margin-right: 5px;"><img src="../img/fb.png" height="30" /></a>-->
                        <span class="pull-right" style="margin-top: 7px; font-weight: bold;">
                            New user ? <a><span data-toggle="modal" data-target="#register" data-dismiss="modal" style="margin-right: 10px; cursor: pointer; color: #5D9BD0;">Register Here</span></a>
                            <!--|
                            <a href="" style="margin-left: 10px; margin-right: 10px;">Forget Password</a>-->
                        </span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
        //Login User 2
        $('#frmLogin2').submit(function(event) {
          $.post(
           'https://www.searchurcollege.com/connection/user_login.php',
            $(this).serialize(),
            function(data)
            {
                if(data=='1')
                {
                    $("#success2").show();
                    eid=$('#eid').val();
                    setTimeout(function() { $("#success2").hide(); }, 3000);
                    if(eid>0)
                        window.location.href = "https://www.searchurcollege.com/exam/start-exam/"+eid;
                    else
                        $("#login2").modal().show();
                }
                else
                if(data=='2')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                {
                    $("#error2").show();
                    setTimeout(function() { $("#error2").hide(); }, 3000);
                }
            }
          );
          return false;   
        }); 
</script>

<script>
    function setHeight()
    {
        $('.varc').click();
        $("#dv").height("10em");
    }
</script>

