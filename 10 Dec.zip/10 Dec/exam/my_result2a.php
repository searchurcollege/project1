	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header.php'); 
		error_reporting(0);
		$userID=$_SESSION['regUsrId'];
	?>
	<style>
    body {
        font-size : 16px;
    }
	.panel{
		border:2px solid #f56954 ;
		color:#fff;
	}
	.panel-heading{
		background:#f56954 ;
	}
	#resultTable {
        font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }
    
    #resultTable td, #resultTable th {
        border: 1px solid #ddd;
        padding: 8px;
    }
    
    #resultTable tr:nth-child(even){background-color: #f2f2f2;}
    
    #resultTable tr:hover {background-color: #ddd;}
    
    #resultTable th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #f56954 ;
        color: white;
    }
</style>
	</style>
        <script src="<?php echo BASE_URL;?>assets/js/chart-loader.js" type="text/javascript"></script>
		<div class="row row-eq-height">
			
			<div class="col-md-2 col-xs-12 left-sidebar"> 
		
				<?php require_once(__ROOT__.'/includes/sidebar.php'); ?>
				
			</div>
			
		
			<div class="col-md-10 col-xs-12 div-content"> 
			
				<!-- Content Header (Page header) -->
				<div id="contentHeader">
				
					<h4> <i class="fa fa-dashboard"></i> <strong>Dashboard </strong><i class="fa fa-chevron-right"></i>  Result</h4>
					
				</div>

				<div class="col-md-12 col-xs-12" style="margin-top:10px;">
				
					<!-- Main content -->

					<div class="panel">
					   <?php
                                $alpha=array('A','B','C','D','E');
								$userResulID=$_REQUEST['exmID'];
                            	$tquestn="SELECT user_exam_id FROM user_exam WHERE code='$userResulID'";
                                $tquestn = $myconn->prepare($tquestn);
                            	$tquestn->execute();
                            	$tquestn->store_result();
                            	$tquestn->bind_result($user_exam_id);
                            	$tquestn->fetch();

                            	$tquestn="SELECT exam_name FROM exam WHERE exam_id=$user_exam_id";
                                $tquestn = $myconn->prepare($tquestn);
                            	$tquestn->execute();
                            	$tquestn->store_result();
                            	$tquestn->bind_result($exam_name);
                            	$tquestn->fetch();
                        ?>
						<div class="panel-heading">My Result - <b><?php echo $exam_name; ?></b></div>
						
						<div class="panel-body">
    <?php
								//$stm3="SELECT ue.id, ue.user_exam_id,ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,ue.total_attempt,
								//		ue.correct_answer,ue.wrong_answer,ue.user_get_marks,ue.result_status,e.exam_name
								//		FROM user_exam ue, exam e WHERE ue.user_exam_id = e.exam_id AND ue.code = '$userResulID'";


										$stm3="SELECT ue.id, ue.user_exam_id, ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,
													ue.total_attempt,ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,
													e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.code = '$userResulID'";


                                ?>
							<?php
								/*$stm3="SELECT ue.user_exam_id,ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,ue.total_attempt,
										ue.correct_answer,ue.wrong_answer,ue.user_get_marks,ue.result_status,e.exam_name
										FROM user_exam ue, exam e WHERE ue.user_exam_id = e.exam_id AND ue.user_id=? ORDER by ue.user_exam_id desc";*/
       
								if ($stm3 = $myconn->prepare($stm3))
								{
								    //$stm3->bind_param('s',$userID);
									$stm3->execute();
									$stm3->store_result();
									$stm3->bind_result($id,$user_exam_id,$total_no_of_ques,$time_duration,$total_marks,$pass_marks,
									$total_attempt,$correct_answer, $wrong_answer, $user_get_marks, $result_status, $exam_name, $exam_id, $date, $code);
                            ?>
                            <?php
									while($stm3->fetch()>0){
										$userExm2="SELECT COUNT(answer_id) AS tot_attempts FROM user_answer WHERE code='$code'";
                                        $userExm2=$myconn->prepare($userExm2); 
										$userExm2->execute();
										$userExm2->store_result();
										$userExm2->bind_result($tot_attempts);
										while($userExm2->fetch())
                                            $total_attempt=$tot_attempts;
                                        $wrong_answer=$tot_attempts-$correct_answer;
								?>
												<div class="col-md-12">
												<div class="col-md-6 col-md-offset-3 col-xs-12" style="margin-left: -20px;">
                                                    <!--<h4><?php echo "<font color=black>".$exam_name;?></font></h4>-->
													<script type="text/javascript">
														google.charts.load("current", {packages:["corechart"]});
														google.charts.setOnLoadCallback(drawChart);
															function drawChart() {
																var data = google.visualization.arrayToDataTable([
																  ['Task', 'Question Details'],
																  ['Total Questions', <?php echo $total_no_of_ques;?>],
																  ['Wrong', <?php echo $wrong_answer;?>],
																  ['Total Attempt', <?php echo $total_attempt;?>],
																  ['Correct',  <?php echo $correct_answer;?>],																  
																]);

																var options = {
																  title: 'QUESTION DETAILS',
																  
																  pieHole :0.4,
																};

																var chart = new google.visualization.PieChart(document.getElementById('piechart_3d<?php echo $exam_id;?>'));
																chart.draw(data, options);
															}
													</script>
													<br>
													 <div id="piechart_3d<?php echo $exam_id;?>" style="margin-bottom:5px;"></div>
												</div>

												<div class="col-md-6   " style="mmargin-bottom: -25px; mmargin-top: 0px; mmargin-left: 0px;">
                                                    
                                                   
                                                             <script type="text/javascript">
                                                                google.charts.load("current", {packages:['corechart']});
                                                                google.charts.setOnLoadCallback(drawChart);
                                                                function drawChart() {
                                                                  var data = google.visualization.arrayToDataTable([
                                                                   ['Task', 'Question Details',{ role: "style" }],
                                                                   ['Wrong', <?php echo $wrong_answer;?>,"#CD5C5C"],
                                                                   ['Correct',  <?php echo $correct_answer;?>,"#228B22"],
                                                                   ['Total Attempt', <?php echo $total_attempt;?>,"#FF8C00"],
									                             //  ['Total Quesion', <?php echo $total_no_of_ques;?>,"#0000CD"],
                                                                   ]);
                                                            
                                                                   var view = new google.visualization.DataView(data);
                                                                  
                                                                            
                                                                                 var options = {
                                                                                    title: "Total Quesion",
                                                                                    width: 600,
                                                                                    height: 400,
                                                                                    bar: {groupWidth: "95%"},
                                                                                    legend: { position: "none" },
                                                                                  };
                                                                                  var chart = new google.visualization.ColumnChart(document.getElementById('barchart_3d<?php echo $exam_id;?>'));
                                                                                  chart.draw(view, options);
                                                                              }
                                                                              </script>
                                                                              


                                                    <div id="barchart_3d<?php echo $exam_id;?>" class="graph2" style="margin-bottom:0px; "></div> 
													 <!-- <div id="piechart_3d<?php echo $exam_id;?>" style="margin-bottom:5px; background: red;"></div>-->
												</div>
												</div>
												
												<div class="col-md-12" style="color:#000; height:400px; overflow-y: scroll">
													<?php
														$stm1="SELECT q.question_id, q.question, a.correct_answer,a.solution, u.code, u.answer 
														        FROM questions q JOIN answer a ON a.exam_id = q.exam_id 
														        AND a.question_id = q.question_id_OLD AND q.exam_id=$exam_id 
														        LEFT JOIN user_answer u ON u.exam_id = q.exam_id 
														        AND u.question_id = q.question_id AND u.user_id = '$userID' AND u.code='$userResulID' ORDER BY q.question_id";
														$stms1 = $myconn->prepare($stm1);
														//$stms1->bind_param('is', $exam_id,$userID);
														$stms1->execute();
														$stms1->store_result();
														$stms1->bind_result($question_id,$question,$correct_answer,$solution,$code,$urAnswer);
														$sn=1;
														while($stms1->fetch()>0)
                                                        {
                                                        ?>
                                                            <div class="well well-sm" style="color:#000;">
                                                                <p>
                                                                    <h4 title="<?php echo $question_id;?>" class="text-danger pull-left"> <?php echo '<b>Question:</b> '.$sn;?></h4> 
                                                                    <br />  
                                                                    <hr style="border-top: 1px solid #0a540d;"><?php echo $question;?>
                                                                </p>
                                                                <p class="text-left"><b>Your Answer: <?php echo $alpha[$urAnswer-1];?>
                                                                    <?php 
                                                                    $urAnswer=str_replace(' ', '', $urAnswer);
                                                                    if($correct_answer==$urAnswer)
                                                                        echo '<i class="fa fa-check text-success"></i>';
                                                                    else
                                                                    {
                                                                        if(!empty($urAnswer))
                                                                            echo '<i class="fa fa-times text-danger" aria-hidden="true"></i>';
                                                                        else
                                                                            echo 'Not Attempted';
                                                                    }
                                                                    ?></b>
                                                                </p>
                                                                <p class="text-left"><b>Correct Answer: <?php echo $alpha[$correct_answer-1];?> <i class="fa fa-check text-success"></i></b></p>
                                                                <h4 cclass="text-success" ddata-toggle="collapse" ddata-target="#solution<?php echo $sn;?>"><b>Solution:</b> <i class="fa fa-arrow-down" aria-hidden="true"></i> </h4>
                                                                
                                                                <div style="background: lightgrey; margin-left: 0px;" id="solution<?php echo $sn;?>" cclass="collapse">
                                                                    <div class="well well-sm" style="background: #EAEDED  ">
                                                                        <?php //echo strip_tags($solution); ?>
                                                                        <?php 
                                                                            echo $solution;
                                                                         ?>
                                                                    </div>
                                                                </div>
                                                            <?php
                                                                $sn++;
                                                            echo '</div>';
                                                        }
                                                        ?>
												
											</div>
										</div>
										
									</div>
									
							<?php
                                }
                                }
								?>
								
							</div><!-- panel-group -->

						<?php
                        ?>
						</div>
					</div>	
					
				</div>
				
			</div>				
				
		</div>

	<?php require_once(__ROOT__.'/includes/footer.php');?>
	