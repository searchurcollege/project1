<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
$k=rtrim($k,', ');
$v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];
$college_id= $_REQUEST["college_id"].'_';

$sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
if ($conn->query($sql) == TRUE)
{
  $last_id = $conn->insert_id;
}
else
{
 echo "error";
}


 
if(!empty(array_filter($_FILES['facility_image_path']['name']))){
    //echo "1";
        foreach($_FILES['facility_image_path']['name'] as $key=>$val){
            
             $allowedExts = array("gif", "jpeg", "jpg", "png");
           // $extension = end(explode(".", $_FILES["facility_image_path"]["name"]));

            // $currentDir = '../'.getcwd().'/gallery/college/facility';
            chdir('../gallery/college/facility');
            $currentDir = getcwd();
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['facility_image_path']['name'][$key];
            $fileSize = $_FILES['facility_image_path']['size'][$key];
            $fileTmpName  = $_FILES['facility_image_path']['tmp_name'][$key];
            $fileType = $_FILES['facility_image_path']['type'][$key];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="facility_".$college_id.$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET facility_image_path='$fn' WHERE facility_id='$last_id'";
                          $result=$conn->query($sql1);
                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
        }
        echo 1;
         
    }
    
?>
