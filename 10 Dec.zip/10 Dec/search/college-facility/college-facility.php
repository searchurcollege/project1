 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Add College Facility
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college-facility/college_facility_Action.php?table_name=suc_college_facilities" method="POST"  >
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden" />
                                        <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>" />
                                        <div class="form-group col-xs-4">
											<label for="catName">College Name</label>
											<select class="form-control" id="college_id" name="college_id" required>
												<option>Select College</option>
                                                 <?php 
                                                    include("../../../../connection/dbconnect.php");
                                                    $sql="SELECT college_id,college_name from suc_college order by college_name";
                                  $result=$conn->query($sql);
                                      while($row=$result->fetch_assoc())
                                        {
                                            $college_id=$row["college_id"];
                                           $college_name=$row["college_name"];
                                         //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                          echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                        }
                                                     ?>								
											</select>
										</div>

                    <div class="form-group col-xs-4">
                      <label for="catName">Facilities</label>
                      <select class="form-control" id="facility_code" name="facility_code" required>
                        <option disabled selected>Select Facility</option>
                         <?php 
                          $sql="SELECT facility_code,facility_name from suc_facilities_master order by facility_name";
                          $result=$conn->query($sql);
                              while($row=$result->fetch_assoc())
                                {
                                  $facility_code=$row["facility_code"];
                                  $facility_name=$row["facility_name"];
                                  echo ' <option  value="'.$facility_code.'">'.$facility_name.'</option> ';
                                }
                                             ?>               
                      </select>
                    </div>

                                        <div class="form-group col-xs-4">
											<label for="catName">Facility Image</label>
											<input type="file" oonchange="ProfImage(this)" class="form-control" name="facility_image_path[]" multiple id="facility_image_path"   />
										</div>
                    
										
                                        <div class="form-group col-xs-4">
											<label for="catName">Facility Start Date</label>
											<input type="text" placeholder="YYYY/MM/DD" class="form-control " name="facility_start_dt" id="datepicker" value=""  />
										</div>
                                        
                                        <div class="form-group col-xs-4">
											<label for="catName">Facility End Date</label>
											<input type="text" placeholder="YYYY/MM/DD" class="form-control " name="facility_end_dt" id="datepicker1" value=""  />
					                    </div>
                                        
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Facility Notes</label>
											<textarea class="form-control summernote" placeholder="Facility Notes" id="facility_notes" name="facility_notes"></textarea>
										</div>
                                        <div class="col-md-3 inputGroupContainer">
                                            <label class="col-md-8 text-right">Status</label>
                                            <div class="col-md-2">
                                           <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="facility_status" name="facility_status" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                      
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
                    <center> <img id ="loadingImage" style="max-height: 140px; margin-left: -70px; position: absolute; ffloat:left; display: none;" cclass="pull-right" src="https://searchurcollege.com/exam/admin/search/loading.gif"></center>
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
            <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--New RECORD INSERTED--</h4></center></div>
					</div>	
				</div>
			</section>
		</aside>

    
	</div>
  <script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo BASE_URL;?>assets/js/AdminLTE/app.js" type="text/javascript"></script>

	<!-- <div style="background: red ; height: 30px;"></div> -->
<?php //include_once '../../includes/footer.php';?>



 <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
  <link rel="stylesheet" href="css/select2-bootstrap.css">


<script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.full.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#college_id").select2();
    $("#facility_code").select2();
  

});
</script>
<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  $( function() {
    $( "#datepicker1" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
	//CKEDITOR.replace( 'facility_notes' );
    
  </script>

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
         $("#loadingImage").show();
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      } 
      // var file_data = $("#facility_image_path").prop("files")[0];   // Getting the properties of file from file field
      // var form_data = new FormData();                  // Creating object of FormData class
      // form_data.append("file", file_data)        
      $.ajax({
        url:"college_facility_Action.php?table_name=suc_college_facilities",
        method:"POST",
        //data: $('#frmSubmi').serialize(),
          data: new FormData(this),
          contentType: false,       // The content type used when sending data to the server.
          cache: false,             // To unable request pages to be cached
          processData:false, 
        success:function(data)
        {
          alert(data);
          if(data==1){
            $('#loadingImage').hide();
            $('#success').fadeIn().delay(1000).fadeOut();
            setTimeout("location.href = 'college-facility.php'",2000);
        }
        
        }
      });
      
      
    });
  });
</script>