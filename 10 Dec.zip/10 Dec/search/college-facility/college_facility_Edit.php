 <?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$id=$_REQUEST['id'];
$tbl="suc_college_facilities";
$actionId="facility_id";
 $ssql="SELECT * from $tbl where $actionId='$id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
              $c_id=$rw["college_id"];
              $c_code=$rw["facility_code"];
              $c_facility_name=$rw["facility_name"];
              $c_facility_notes=$rw["facility_notes"];
              $c_facility_start_dt=$rw["facility_start_dt"];
              $c_facility_end_dt=$rw["facility_end_dt"];
              $c_facility_status=$rw["facility_status"];
             
            }
          
?>

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <!-- <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script> -->
<?php
 session_start ();
   $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
    <?php include_once '../../includes/left_sidebar.php';?>
    <!-- left column -->
    <aside class="right-side">  
      <section class="content-header">              
        <h4>Add College Facility
          <span class="label label-danger" id="validateError"></span> 
          <a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
        </h4>         
      </section>
      <section class="content">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college-facility/college_facility_Action.php?table_name=suc_college_facilities" method="POST"  >
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-12">
                   
                                       
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Name</label>
                      <select class="form-control" id="college_id" name="college_id" required>
                        <option>Select College</option>
                                                 <?php 
                                                    include("../../../../connection/dbconnect.php");
                                                    $sql="SELECT college_id,college_name from suc_college";
                                  $result=$conn->query($sql);
                                      while($row=$result->fetch_assoc())
                                        {
                                            $college_id=$row["college_id"];
                                           $college_name=$row["college_name"];
                                         //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                        if($c_id==$college_id)
                                          echo ' <option selected value="'.$college_id.'">'.$college_name.'</option> ';
                                        else
                                          echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';

                                        }
                                                     ?>               
                      </select>
                    </div>

                    <div class="form-group col-xs-4">
                      <label for="catName">Facilities</label>
                      <select class="form-control" id="facility_code" name="facility_code" required>
                        <option disabled >Select Facility</option>
                         <?php 
                          $sql="SELECT facility_code,facility_name from suc_facilities_master order by facility_name";
                          $result=$conn->query($sql);
                              while($row=$result->fetch_assoc())
                                {
                                  $facility_code=$row["facility_code"];
                                  $facility_name=$row["facility_name"];
                                  if($c_code==$facility_code)
                                    echo ' <option selected  value="'.$facility_code.'">'.$facility_name.'</option> ';
                                  else
                                    echo ' <option  value="'.$facility_code.'">'.$facility_name.'</option> ';
                                }
                                             ?>               
                      </select>
                    </div>
                                        <div class="form-group col-xs-6">
                      <label for="catName">Facility Start Date</label>
                      <input type="text" placeholder="YYYY/MM/DD" class="form-control " name="facility_start_dt" id="datepicker" value="<?php echo $c_facility_start_dt;?>" required />
                    </div>
                                        
                                        <div class="form-group col-xs-6">
                      <label for="catName">Facility End Date</label>
                      <input type="text" placeholder="YYYY/MM/DD" class="form-control " name="facility_end_dt" id="datepicker1" value="<?php echo $c_facility_end_dt;?>" required />
                              </div>
                                        
                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">Facility Notes</label>
                      <textarea class="form-control summernote" placeholder="college_desc" id="facility_notes" name="facility_notes"><?php echo $c_facility_notes;?></textarea>
                    </div>
                                        <div class="col-md-3 inputGroupContainer">
                                            <label class="col-md-8 text-right">Status</label>
                                            <div class="col-md-2">
                                          <?php
                                          if($c_facility_status==1)
                                            echo '<div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="facility_status" name="facility_status" type="checkbox" value="1"></div>';
                                          else
                                            echo '<div class="input-group"><input  data-toggle="toggle" data-onstyle="warning" id="facility_status" name="facility_status" type="checkbox" value="1"></div>';
                                          ?>
                                           
                                        </div>
                                        </div>
                                      
                                      
                  </div>
                 </div>
              </div>
              <div class="box-footer clearfix"> 
                <div class="col-xs-12"> 
                  <div class="col-xs-12 pull-right">
                    <center> <img id ="loadingImage" style="max-height: 140px; margin-left: -70px; position: absolute; ffloat:left; display: none;" cclass="pull-right" src="https://searchurcollege.com/exam/admin/search/loading.gif"></center>
                    <button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
                  </div>
                </div>
              </div>
            </form>
          </div>  
        </div>
      </section>
    </aside>

    
  </div>
  <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--Record Updated--</h4></center></div>
  <!-- <div style="background: red ; height: 30px;"></div> -->
<?php //include_once '../../includes/footer.php';?>
 <script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo BASE_URL;?>assets/js/AdminLTE/app.js" type="text/javascript"></script>


 <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
  <link rel="stylesheet" href="css/select2-bootstrap.css">


<script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.full.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#college_id").select2();
    $("#facility_code").select2();
  

});
</script>
<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  $( function() {
    $( "#datepicker1" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
 

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
        //alert("ajax");
       e.preventDefault();

      $.ajax({
        url:"college_facility_Update.php?table_name=<?php echo $tbl;?>&course_id=<?php echo $id ?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
         // alert(data);
          if(data==1){
            $('#success').show();
            setTimeout("location.href = 'college_facility_View.php'",2000);
        }
        }
      });
      
      
    });
  });
</script>