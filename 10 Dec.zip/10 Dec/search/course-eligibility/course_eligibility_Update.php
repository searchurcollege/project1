<?php 
$date = date('Y-m-d H:i:s');
 $college_status=$_REQUEST["cc_eligibility_status"];
$tbl_name=$_REQUEST["table_name"];
$suc_id=$_REQUEST["course_id"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", cc_eligibility_status='0' "; 
}

include("../../../../connection/dbconnect.php");
 $sql="update ".$tbl_name." set ".$k." where cc_eligibility_id=".$suc_id;
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>