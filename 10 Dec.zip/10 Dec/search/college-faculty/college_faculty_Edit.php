<?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$id=$_REQUEST['id'];

$tbl="suc_college_faculty";
 $ssql="SELECT * from $tbl where college_id='$id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
              $c_id=$rw["college_id"];

              $c_fac_strength=$rw["college_faculty_strength"];
              $c_fac_phd=$rw["college_faculty_phd"];
              $c_fac_full_time=$rw["college_faculty_full_time"];
              $c_fac_visiting=$rw["college_faculty_visiting"];
              $c_fac_profile=$rw["college_faculty_profile"]; 
            }
          
?>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
   $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
    <?php include_once '../../includes/left_sidebar1.php';?>
    <!-- left column -->
    <aside class="right-side">  
      <section class="content-header">              
        <h4>Edit College Faculty
          <span class="label label-danger" id="validateError"></span> 
          <a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
        </h4>         
      </section>
      <section class="content">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-12">
                                    <input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                    <div class="form-group col-xs-6">
                      <label for="catName">College Name</label>
                      <select class="form-control" id="college_id" name="college_id" required>
                        <option>Select College</option>
                                                         <?php 
                                                            // include("../../../../connection/dbconnect.php");
                                                            $sql="SELECT college_id,college_name from suc_college";
                                          $result=$conn->query($sql);
                                              while($row=$result->fetch_assoc())
                                                {
                                                    $college_id=$row["college_id"];
                                                   $college_name=$row["college_name"];
                                                 //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                                  if($c_id==$college_id)
                                                    echo ' <option selected value="'.$college_id.'">'.$college_name.'</option> ';
                                                  else
                                                    echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                                }
                                                             ?>               
                      </select>
                    </div>
  

                    <div class="form-group col-xs-4">
                      <label for="catName">Total Faculty</label>
                      <input type="text" placeholder="eg 30" class="form-control" name="college_faculty_strength" id="college_faculty_strength" value="<?php echo $c_fac_strength ?>" required />
                    </div>

                       <div class="form-group col-xs-4">
                      <label for="catName">Full Time Faculty</label>
                      <input type="text" placeholder="eg 20" class="form-control" id="college_faculty_full_time" name="college_faculty_full_time" value="<?php echo $c_fac_full_time ?>" />
                    </div>  
                                         <div class="form-group col-xs-4">
                      <label for="catName">College Faculty PHD</label>
                      <input type="text" placeholder="College Faculty PHD" class="form-control" name="college_faculty_phd" id="college_faculty_phd" value="<?php echo $c_fac_phd;?>" required />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">Visiting Faculty</label>
                      <input type="text" placeholder="Visiting Faculty" class="form-control" name="college_faculty_visiting" id="college_faculty_visiting" value="<?php echo $c_fac_visiting;?>" required />
                    </div>
                                        
                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">College Faculty Profile</label>
                      <textarea class="form-control summernote" id="college_faculty_profile" name="college_faculty_profile"><?php echo $c_fac_profile;?></textarea>
                    </div>
                                     </div>
                 </div>
              </div>
              <div class="box-footer clearfix"> 
                <div class="col-xs-12"> 
                  <div class="col-xs-12 pull-right">
                    <button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
                  </div>
                </div>
              </div>
            </form>
          </div>  

        </div>
      </section>
      <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--Record Updated--</h4></center></div>
    </aside>

    
  </div>
  
  <!-- <div style="background: red ; height: 30px;"></div> -->
<?php //include_once '../../includes/footer.php';?>
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo BASE_URL;?>assets/js/AdminLTE/app.js" type="text/javascript"></script>

<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
  //CKEDITOR.replace( 'college_faculty_profile' );

  </script>
  
<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_faculty_Update.php?table_name=<?php echo $tbl; ?>&course_id=<?php  echo $id;?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          //alert(data);
          if(data==1){
            $('#success').show();
            setTimeout("location.href = 'college_faculty_View.php'",2000);
        }
        
        }
      });
      
      
    });
  });
</script>