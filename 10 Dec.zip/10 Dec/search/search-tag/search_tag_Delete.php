<?php
  $a=$_REQUEST['tagRecord'];
 include("../../../../connection/dbconnect.php");
   $sql="DELETE FROM suc_search_tag WHERE id='$a' ";
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>