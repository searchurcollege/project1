	<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
 $k=rtrim($k,', ');
 $v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];

  $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
 if ($conn->query($sql) == TRUE) {
	echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
//echo 1;//"success";
}
?>