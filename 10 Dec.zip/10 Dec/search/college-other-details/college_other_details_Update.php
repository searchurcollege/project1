<?php 
$date = date('Y-m-d H:i:s');

$tbl_name=$_REQUEST["table_name"];
$suc_id=$_REQUEST["Contact_id"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');

include("../../../../connection/dbconnect.php");
  $sql="update ".$tbl_name." set ".$k." where id=".$suc_id;
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>