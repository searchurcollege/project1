<?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$id=$_REQUEST['id'];
 $ssql="SELECT * from suc_college_other_details where id='$id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
              $c_id=$rw["college_id"];
                $c_place_details=$rw["college_placement_details"];
                $c_place_high=$rw["college_highest_placementmet"];
               $c_place_avg=$rw["college_average_placement"];
               $c_place_low=$rw["college_lowest_placement"];
               $c_place_top=$rw["college_top_recruiters"];
               $c_place_top_logo=$rw["college_top_recruiters_logo_path"];
                $c_place_awards=$rw["college_awards"];
                $c_place_alumina=$rw["college_alumina"];
                $c_place_collaboration=$rw["college_collaboration"];
                
            }
        $sql="SELECT college_id,college_name from suc_college where college_id=$c_id;";
      $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
            {
                $c_college_id=$row["college_id"];
                $c_college_name=$row["college_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
?>

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
   $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
    <?php include_once '../../includes/left_sidebar1.php';?>
    <!-- left column -->
    <aside class="right-side">  
      <section class="content-header">              
        <h4>Edit College Contact
          <span class="label label-danger" id="validateError"></span> 
          <a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
        </h4>         
      </section>
      <section class="content">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-12">
                                   
                        
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Placement Details</label>
                      <input type="text" placeholder="College Placement Details" class="form-control" name="college_placement_details" id="college_placement_details" value="<?php echo $c_place_details; ?>" required />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Highest Placementmet</label>
                      <input type="text" placeholder="College Highest Placementmet" class="form-control" name="college_highest_placementmet" id="college_highest_placementmet" value="<?php echo $c_place_high; ?>" required />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Average Placement</label>
                      <input type="text" placeholder="College Average Placement" class="form-control" name="college_average_placement" id="college_average_placement" value="<?php echo $c_place_avg; ?>" required />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Lowest Placement</label>
                      <input type="text" placeholder="College Lowest Placement" class="form-control" name="college_lowest_placement" id="college_lowest_placement" value="<?php echo $c_place_low; ?>" required />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Top Recruiters</label>
                      <input type="text" placeholder="College Lowest Placement" class="form-control" name="college_top_recruiters" id="college_top_recruiters" value="<?php echo $c_place_top; ?>" required />
                    </div>
                                        
                                        <div class="form-group col-xs-4">
                      <img src="../gallery/college/placements/<?php echo $c_place_top_logo;?>" style="height: 90px;">
                    </div>
                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">College Awards</label>
                      <textarea class="form-control summernote" placeholder="College Awards" id="college_awards" name="college_awards"><?php echo $c_place_awards; ?></textarea>
                    </div>
                                          
                    <div class="form-group col-xs-12"> 
                      <label for="cat_Description">College Alumina</label>
                      <textarea class="form-control summernote" placeholder="College Alumina" id="college_alumina" name="college_alumina"><?php echo $c_place_alumina; ?></textarea>
                    </div>
                                        <div class="form-group col-xs-12"> 
                      <label for="cat_Description">College Collaboration</label>
                      <textarea class="form-control summernote" placeholder="College Collaboration" id="college_collaboration" name="college_collaboration"><?php echo $c_place_collaboration; ?></textarea>
                    </div>
                                      
                  </div>
                 </div>
              </div>
              <div class="box-footer clearfix"> 
                <div class="col-xs-12"> 
                  <div class="col-xs-12 pull-right">
                    <button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
                  </div>
                </div>
              </div>
            </form>
            <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Updated</h4></center></div>  
          </div>
          
        </div>
      </section>
    </aside>

    
  </div>
  
  <!-- <div style="background: red ; height: 30px;"></div> -->
<?php //include_once '../includes/footer.php';?>


<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_other_details_Update.php?table_name=suc_college_other_details&Contact_id=<?php echo $id; ?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          alert(data);
          if(data==1){
            $('#success').fadeIn().delay(1000).fadeOut();
            setTimeout("location.href = '../college-dashboard-view.php'",2000);

            
        }
        }
      });
      
      
    });
  });
</script>