
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
     
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmit" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										<div class="form-group col-xs-6">
											<label for="catName">College Name</label>
											<input type="text" placeholder="College Name" class="form-control" name="college_name" id="college_name" value="" required />
										</div>
										      <input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                        <div class="form-group col-xs-6">
											<label for="catName">University</label>
											<select class="form-control sselect2" id="uni_id" name="uni_id" rrequired>
												<option selected  value="0">none</option>
                                                 <?php 
                                                include("../../../connection/dbconnect.php");
                                                $sql="SELECT uni_id,uni_name from suc_university";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $uni_id=$row["uni_id"];
            						               $uni_name=$row["uni_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
            						              echo ' <option  value="'.$uni_id.'">'.$uni_name.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>
                                        

                                        <div class="form-group col-xs-4">
                                          <label for="catName">Location</label>
                                          <select class="form-control" id="college_location_id" name="college_location_id" required>
                                            <option>Select Location</option>
                                             <?php 
                                            include("../../../connection/dbconnect.php");
                                            $sql="SELECT id,location_name from location";
                          $result=$conn->query($sql);
                              while($row=$result->fetch_assoc())
                                {
                                    $lid=$row["id"];
                                   $lname=$row["location_name"];
                                 //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                  echo ' <option  value="'.$lid.'">'.$lname.'</option> ';
                                }
                                             ?>               
                                          </select>
                                        </div>
                                        <div class="form-group col-xs-4">
											<label for="catName">College Image</label>
											<input type="file" placeholder="College Name" class="form-control" name="college_image_path[]" multiple id="college_image_path" value="" rrequired />
										</div>
                    <div class="form-group col-xs-4">
                      <label for="catName">College Tag</label>
                      <input type="text" placeholder="college Tag" class="form-control" name="search_tag_value" id="search_tag_value" value="" required />
                    </div>
                    <input type="hidden" name="search_tag_type" value="2" />
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Description</label>
											<textarea class="form-control summernote" placeholder="College Description" id="college_desc" name="college_desc"></textarea>
										</div>
                                        	
										<div class="form-group col-xs-4">
											<label for="catName">Establishment Date</label>
											<input type="text" placeholder="YYYY/MM/DD" class="form-control " name="college_establishment_dt" id="datepicker" value="" rrequired />
										</div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Type</label>
											<select class="selectpicker form-control" id="college_type" name="college_type">
												<option>Select Type</option>
                                                <option  value="1">Goverment</option>
                                                <option  value="2">Private</option>
                                            </select> 
										</div>
                                        <!-- <div class="form-group col-xs-4">
											<label for="catName">No. of Course</label>
											<input type="text" placeholder="No. of Course" class="form-control " name="college_no_of_courses" id="college_no_of_courses" value="" rrequired />
										</div> -->
                                        <div class="form-group col-xs-4">
											<label for="catName">College Code Flag</label>
											<input type="text" placeholder="College Code Flag" class="form-control " name="college_code_flag" id="college_code_flag" value="" rrequired />
										</div>
                                        <!-- <div class="form-group col-xs-4">
											<label for="catName">College Management</label>
											<input type="text" placeholder="College Management" class="form-control " name="college_management_style" id="college_management_style" value="" rrequired />
										</div> -->
                                        <div class="form-group col-xs-4">
											<label for="catName">Minority Type</label>
											<input type="text" placeholder="Minority Type" class="form-control " name="college_minority_type" id="college_minority_type" value="" rrequired />
										</div>
                                        
                          
                    <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">              			
										 <div class="form-group col-xs-12"> 
											<label for="cat_Description">Admission Notes</label>
											<textarea class="form-control summernote" placeholder="Admission Notes" id="college_admission_notes" name="college_admission_notes"></textarea>
										</div>
                                        <div class="form-group col-xs-3"> 
											<label for="cat_Description">AICTE Approved</label>
											<input checked data-toggle="toggle" data-onstyle="warning" id="college_aicte_approved" name="college_aicte_approved" type="checkbox" value="1" />
										</div>
                                        <div class="form-group col-xs-3"> 
											<label for="cat_Description">Admission Notes</label>
											<input checked data-toggle="toggle" data-onstyle="warning" id="college_status" name="college_status" type="checkbox" value="1" />
										</div>
                                        
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit"  nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right"> Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>	
				</div>
			</section>
		</div>
  <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--New RECORD INSERTED--</h4></center></div>
	<!-- <div style="background: red ; height: 30px;"></div> -->
<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
	//CKEDITOR.replace( 'college_desc' );
    //CKEDITOR.replace( 'college_admission_notes' );
  </script>

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmit").submit(function(e){
      //  alert("sss");
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college/colAction.php?table_name=suc_college",
        method:"POST",
       // data: $('#frmSubmit').serialize(),
        data: new FormData(this),
        contentType: false,       // The content type used when sending data to the server.
        cache: false,             // To unable request pages to be cached
        processData:false, 
        success:function(data)
        {
          alert(data);
          if(data==0){
            alert("Record not INSERTED")
            //$('#success').show();

            //setTimeout("location.href = 'college.php'",2000);
        }
        else
        {
          $('html, body').animate({ scrollTop: 0 }, 0);
          $('#success').fadeIn().delay(2000).fadeOut();
          $('#id02').val(data);
          $('#id03').val(data);
          $('#id04').val(data);
        }
        
        }
      });
      
      
    });
  });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.min.js"></script>
 <!-- <script src="../js/select2.full.min.js"></script> -->
<script>
$( ".select2" ).select2( {
theme: "bootstrap",
placeholder: "Select a State",
maximumSelectionSize: 6,
containerCssClass: ':all:'
} );

</script>