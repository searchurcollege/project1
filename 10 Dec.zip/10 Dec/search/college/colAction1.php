
<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
    if($key=="create_uni"){

    }
   else
   {
   	$k.=$key.", ";
    $v.="'".$value."', ";
   }
  
}
$k=rtrim($k,', ');
$v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];
$college_name=$_REQUEST["college_name"];
//$sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
// $sql1 ='INSERT INTO suc_search_tag(search_tag_id,search_tag_value,search_tag_type) VALUES ("'.$college_name.'","'.$college_name.'","2")' ;
if(!empty(array_filter($_FILES['college_image_path']['name']))){
    //echo "1";
        foreach($_FILES['college_image_path']['name'] as $key=>$val){
           $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ; ;
            if ($conn->query($sql) == TRUE) {
                 $last_id = $conn->insert_id;
                  
                    

              // echo "success";
            } else {
                 // "Error: " . $sql . "<br>" . $conn->error;
                echo "error";
            }
             $allowedExts = array("gif", "jpeg", "jpg", "png");
           // $extension = end(explode(".", $_FILES["college_image_path"]["name"]));

            // $currentDir = '../'.getcwd().'/gallery/college/facility';
            chdir('../gallery/college');
            $currentDir = getcwd();
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['college_image_path']['name'][$key];
            $fileSize = $_FILES['college_image_path']['size'][$key];
            $fileTmpName  = $_FILES['college_image_path']['tmp_name'][$key];
            $fileType = $_FILES['college_image_path']['type'][$key];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="col_".$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET college_image_path='$fn' WHERE college_id='$last_id'";
                          $result=$conn->query($sql1);

                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
        }
        if($last_id>=1)
        {
           $sql1 ='INSERT INTO suc_search_tag(search_tag_id,search_tag_value,search_tag_type) VALUES ("'.$college_name.'","'.$college_name.'","2")' ;
                  $conn->query($sql1);
        }

        if($_REQUEST["create_uni"] && $_REQUEST["uni_id"]==0)
{
  $uni_name=$_REQUEST["college_name"];
  $uni_location=$_REQUEST["college_location_id"];
  $uni_type=$_REQUEST["college_type"];
  $uni_create=$_REQUEST["created_by"];
   $uniQuery="INSERT Into suc_university (uni_name,uni_location_id,uni_type,created_by,uni_status) VALUES ('".$uni_name."','".$uni_location."','".$uni_type."','".$uni_create."','1')";
  $conn->query($uniQuery);

  $UniSelect="SELECT uni_id from suc_university where uni_name='".$uni_name."' and created_by='".$uni_create."'";
  $Uniresult=$conn->query($UniSelect);
  while($rw=$Uniresult->fetch_assoc())
    $uni_id=$rw["uni_id"];
  $update="UPDATE $tbl_name SET uni_id='".$uni_id."' WHERE college_id=".$last_id;
  $conn->query($update);

  
}
        echo $last_id;
         
    }
    
    if(!empty($_FILES['college_brochure_path']['name'])){
    //echo "1";
    	$last_id="1";
             $allowedExts = array("pdf","doc");
            $currentDir = getcwd()."/documents";
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here
            $college_id=$_REQUEST["college_id"]."_";
            $fileExtensions = ['jpeg','jpg','png','pdf','doc']; // Get all the file extensions
             $fileName = $_FILES['college_brochure_path']['name'];
            $fileSize = $_FILES['college_brochure_path']['size'];
            $fileTmpName  = $_FILES['college_brochure_path']['tmp_name'];
            $fileType = $_FILES['college_brochure_path']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="Doc_".$college_id.$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (!in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                         $sql2="UPDATE $tbl_name SET college_brochure_path='$fn' WHERE college_id='$last_id'";
                         $conn->query($sql2);

                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
         
    }
?>
