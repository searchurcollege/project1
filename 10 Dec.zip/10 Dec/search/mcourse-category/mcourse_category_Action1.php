	<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
 $k=rtrim($k,', ');
 $v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];

 $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
 
if ($conn->query($sql) == TRUE) {
	$sql1="INSERT INTO suc_search_tag(search_tag_value,search_tag_id,search_tag_type,created_dt,created_by) VALUES ('".$_REQUEST['course_cat_name']."','".$_REQUEST['course_cat_name']."','1','".$_REQUEST['created_dt']."','".$_REQUEST['created_by']."')" ;
	if($conn->query($sql1) == TRUE)
	{	
		echo 1;
	}
    //echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
//echo 1;//"success";
?>