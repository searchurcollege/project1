<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
$k=rtrim($k,', ');
$v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];
$college_id= $_REQUEST["college_id"].'_';
 


// $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
// if ($conn->query($sql) == TRUE) {
// 	 $last_id = $conn->insert_id;
//    echo "success";
// } else {
//      // "Error: " . $sql . "<br>" . $conn->error;
// 	echo "error";
// }



// if( $_FILES['college_gallery_pic']['name']!=NULL) {
//             $allowedExts = array("gif", "jpeg", "jpg", "png");
//     $extension = end(explode(".", $_FILES["file"]["name"]));
//      $currentDir = getcwd().'/images';
//     $uploadDirectory = "/";
//     $errors = []; // Store all foreseen and unforseen errors here

//     $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
//   	 $fileName = $_FILES['college_gallery_pic']['name'];
//     $fileSize = $_FILES['college_gallery_pic']['size'];
//     $fileTmpName  = $_FILES['college_gallery_pic']['tmp_name'];
//     $fileType = $_FILES['college_gallery_pic']['type'];
//     $fileExtension = strtolower(end(explode('.',$fileName)));
//     $fn=$college_id.$last_id.'.'.$fileExtension;
//     $uploadPath =$currentDir. $uploadDirectory . $fn;

//     if (! in_array($fileExtension,$fileExtensions)) {
//             $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
//         }

//         if ($fileSize > 2000000) {
//             $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
//         }

//         if (empty($errors)) {
//             $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
           
//             if ($didUpload) {
//                 //echo "The file " . basename($fileName) . " has been uploaded";
                 
//                  //include('../../../connection/dbconnect.php');
//                  $sql1="UPDATE suc_college_gallery SET college_gallery_pic='$fn' WHERE college_gallery_id='$last_id'";
//                   $result=$conn->query($sql1);
//                 echo 1;
//             } else {
//                 echo "An error occurred somewhere. Try again or contact the admin";
//             }
//         } else {
//             foreach ($errors as $error) {
//                 echo $error . "These are the errors" . "\n";
//             }
//         }
   
// }
//------------------------------------------------------------------
//echo $_FILES['college_gallery_content_path']['name'];
if(!empty(array_filter($_FILES['college_gallery_content_path']['name']))){
	//echo "1";
        foreach($_FILES['college_gallery_content_path']['name'] as $key=>$val){
        	 $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
			if ($conn->query($sql) == TRUE) {
				 $last_id = $conn->insert_id;
			  // echo "success";
			} else {
			     // "Error: " . $sql . "<br>" . $conn->error;
				echo "error";
			}
			 $allowedExts = array("gif", "jpeg", "jpg", "png");
		    $extension = end(explode(".", $_FILES["file"]["name"]));
		    chdir('../gallery');
		     $currentDir = getcwd();
		    $uploadDirectory = "/";
		    $errors = []; // Store all foreseen and unforseen errors here

		    $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
		  	 $fileName = $_FILES['college_gallery_content_path']['name'][$key];
		    $fileSize = $_FILES['college_gallery_content_path']['size'][$key];
		    $fileTmpName  = $_FILES['college_gallery_content_path']['tmp_name'][$key];
		    $fileType = $_FILES['college_gallery_content_path']['type'][$key];
		    $fileExtension = strtolower(end(explode('.',$fileName)));
		    $fn="gallery_".$college_id.$last_id.'.'.$fileExtension;
		    $uploadPath =$currentDir. $uploadDirectory . $fn;

		    if (! in_array($fileExtension,$fileExtensions)) {
		            $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
		        }

		        if ($fileSize > 2000000) {
		            $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
		        }

		        if (empty($errors)) {
		            $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
		           
		            if ($didUpload) {
		                //echo "The file " . basename($fileName) . " has been uploaded";
		                 
		                 //include('../../../connection/dbconnect.php');
		                 $sql1="UPDATE suc_college_gallery SET college_gallery_content_path='$fn' WHERE college_gallery_id='$last_id'";
		                  $result=$conn->query($sql1);
		                //echo 1;
		            } else {
		                echo "An error occurred somewhere. Try again or contact the admin";
		            }
		        } else {
		            foreach ($errors as $error) {
		                echo $error . "These are the errors" . "\n";
		            }
		        }
			             
		}
		echo 1;
         
    }
    
?>
<?php 

 // $fileName = basename($_FILES['college_gallery_pic']['name'][$key]);
 //            $targetFilePath = $currentDir . $fileName;
 //            if(in_array($fileType, $allowTypes)){
 //                // Upload file to server
 //                if(move_uploaded_file($_FILES["college_gallery_pic"]["tmp_name"][$key], $targetFilePath)){
 //                    // Image db insert sql
 //                    $insertValuesSQL .= "('".$fileName."', NOW()),";
 //                }else{
 //                    $errorUpload .= $_FILES['college_gallery_pic']['name'][$key].', ';
 //                }
 //            }else{
 //              echo  $errorUploadType .= $_FILES['college_gallery_pic']['name'][$key].', ';
 //            }
?>