<?php 
$date = date('Y-m-d H:i:s');
 $college_status=$_REQUEST["college_rating_status"];
$tbl_name=$_REQUEST["table_name"];
$suc_id=$_REQUEST["Contact_id"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", college_rating_status='0' "; 
}


include("../../../../connection/dbconnect.php");

  $sql="update ".$tbl_name." set ".$k." where college_rating_id=".$suc_id;
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>