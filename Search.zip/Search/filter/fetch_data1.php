<?php 
echo '<div class="checkbox " id ="11"style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="20">MCA</label>
      </p></div>';
?>

