<?php

//fetch_data.php

include("../connection/dbconnect.php");


 // if(isset($_POST["brand"]))
 // {
 //  $brand_filter = implode("','", $_POST["brand"]);
 //  $query .= "
 //   AND product_brand IN('".$brand_filter."')
 //  ";
 // }
 if(isset($_POST["c_id"]))
 {
   $c_id_f= $_POST["c_id"];
  $c_id_f=rtrim($c_id_f,', ');

   
 }
 if(isset($_REQUEST["loc_name"]))
{
 $loc=$_REQUEST["loc_name"];

}
 if(isset($_POST["brand"]))
 {
  $brand_filter = implode("','", $_POST["brand"]);
   $query="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_location_id IN( '".$brand_filter."') AND college_id IN( ".$c_id_f.") ";
 }

 if(isset($_POST["fee"]))
 {
  $storage_filter = implode(", ", $_POST["fee"]);
   $storage_filter;
  $k1 = explode(", ",$storage_filter);
   $min=$k1[0];
   $max=$k1[1];

   $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_college_course_fee_structure c
            ON b.college_course_fee_id = c.cc_fee_id
WHERE   a.college_id IN( ".$c_id_f.") and c.cc_total_fee BETWEEN '$min' and '$max'";

 }

if(isset($_POST["course"]))
 {
  $course_filter = implode("','", $_POST["course"]);
    $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_master_course c
            ON b.master_course_id = c.course_id
WHERE   c.course_cat_id IN ('$course_filter') AND a.college_id IN( ".$c_id_f.")";
 }
 if(isset($_POST["course"]) && isset($_POST["brand"]))
 {
 // $course_filter = implode("','", $_POST["course"]);
  //$brand_filter = implode("','", $_POST["brand"]);
    $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_master_course c
            ON b.master_course_id = c.course_id
WHERE   c.course_cat_id IN ('$course_filter') and a.college_location_id IN('".$brand_filter."') and  a.college_id IN( ".$c_id_f.")";
 }
 if(isset($_POST["fee"]) && isset($_POST["brand"]))
 {
  //$course_filter = implode("','", $_POST["course"]);
  //$brand_filter = implode("','", $_POST["brand"]);
   $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_college_course_fee_structure c
            ON b.college_course_fee_id = c.cc_fee_id
        
WHERE      a.college_id IN( ".$c_id_f.") AND a.college_location_id IN( '".$brand_filter."') and c.cc_total_fee BETWEEN $min and $max ";
 }

 if(isset($_POST["fee"]) && isset($_POST["course"]))
 {
  //$course_filter = implode("','", $_POST["course"]);
  //$brand_filter = implode("','", $_POST["brand"]);
    $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_college_course_fee_structure c
            ON b.college_course_fee_id = c.cc_fee_id
        INNER JOIN suc_master_course d
            ON b.master_course_id = d.course_id
WHERE   d.course_cat_id IN ('$course_filter') AND a.college_id IN( ".$c_id_f.") and c.cc_total_fee BETWEEN $min and $max ";
 }
 if(!isset($_POST["fee"]) && !isset($_POST["course"]) && !isset($_POST["brand"]))
 {

  if(isset($_REQUEST["college_like"]))
  {
     $s=$_REQUEST["college_like"];
     $query="select search_tag_type from suc_search_tag where search_tag_value like '%$s%'";
 $result=$conn->query($query);
  while($row=$result->fetch_assoc())
        {
          $name=$row["search_tag_type"];
        }
     if($name==1 && isset($_REQUEST["loc_name"]))
        {
         $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_master_course c
            ON b.master_course_id = c.course_id
        INNER JOIN suc_master_course_category d
            ON d.course_cat_id = c.course_cat_id
WHERE   course_cat_name like'%".$s."%' and a.college_location_id IN (".$loc.")";
        }
        elseif ($name==1 && !isset($_REQUEST["loc_name"])) {
           $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_master_course c
            ON b.master_course_id = c.course_id
        INNER JOIN suc_master_course_category d
            ON d.course_cat_id = c.course_cat_id
WHERE   course_cat_name like'%".$s."%' ";
         } 
        else
        {
          if(isset($_REQUEST["loc_name"]))
          {
            $query="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_name like '%$s%' and college_location_id IN (".$loc.")" ;
          }
          else
            $query="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_name like '%$s%' " ;
        }
}
elseif(isset($_REQUEST["loc_name"]))
{
  $query="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_location_id IN (".$loc.")";
}
else
{
  $query="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college";
}
  }
  
 
 if(isset($_POST["fee"]) && isset($_POST["course"]) && isset($_POST["brand"]))
 {
  $course_filter = implode("','", $_POST["course"]);
  $brand_filter = implode("','", $_POST["brand"]);
    $query="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_college_course_fee_structure c
            ON b.college_course_fee_id = c.cc_fee_id
        INNER JOIN suc_master_course d
            ON b.master_course_id = d.course_id
WHERE    a.college_location_id IN( '".$brand_filter."') AND a.college_id IN( ".$c_id_f.") and d.course_cat_id IN ('$course_filter') and c.cc_total_fee BETWEEN $min and $max ";
 }
 

 $result = $conn->query($query);
  
 
 $output = '';
 if($result->num_rows>0)
 {
  foreach($result as $row)
  {
    $uni_id=$row['uni_id'];
            $unisql="SELECT uni_name from suc_university where uni_id=$uni_id";
            $result1=$conn->query($unisql);
          while($row1=$result1->fetch_assoc())
            $uni_name=$row1["uni_name"];
           // $d=strip_tags($des);
           $c_name=$row["college_name"];
            $c_id=$row['college_id'];
            $c_desc=$row['college_desc'];
            $c_type=$row['college_type'];
            $c_location=$row['college_location_id'];
            $c_e_dt=$row['college_establishment_dt'];
            $c_e_dt=substr($c_e_dt, 0,4);
            if(substr($c_e_dt, 0,1)!="0")
            {
              $c_e_dt='|  &nbsp Established &nbsp'.$c_e_dt;
            }
            else
              $c_e_dt=""; 
            $c_aicte=$row['college_aicte_approved'];
            $c_no_courses=$row['college_no_of_courses'];
            $c_img=$row['college_image_path'];
            $sql2="SELECT college_rating from suc_college_rating where college_id=$c_id";
            $result2=$conn->query($sql2);
          while($row2=$result2->fetch_assoc())
             $rating=$row2["college_rating"];
          $sqlLocation="SELECT location_name,state from location where id=$c_location";
          $resultLocation=$conn->query($sqlLocation);
          while($rowLocation=$resultLocation->fetch_assoc()){
            $l_name=$rowLocation["location_name"];
            $l_state=$rowLocation["state"];
          }
          if($c_type=="1")
            $type="Government";
          else
            $type="Private";
          if($c_aicte=="1")
             $aprroval='|  &nbsp AICTE Approved  <i class="fa fa-info-circle" aria-hidden="true"></i>';
           else
             $aprroval='';
   // $output .= '
   // <div class="col-sm-4 col-lg-3 col-md-3">
   //  <div style="border:1px solid #ccc; border-radius:5px; padding:16px; margin-bottom:16px; height:450px;">
   //   <img src="image/'. $row['product_image'] .'" alt="" class="img-responsive" >
   //   <p align="center"><strong><a href="#">'. $row['product_name'] .'</a></strong></p>
   //   <h4 style="text-align:center;" class="text-danger" >'. $row['product_price'] .'</h4>
   //   <p>Camera : '. $row['product_camera'].' MP<br />
   //   Brand : '. $row['college_name'] .' <br />
   //   RAM : '. $row['product_ram'] .' GB<br />
   //   Storage : '. $row['product_storage'] .' GB </p>
   //  </div>

   // </div>
   // ';
           $output.= '<div class="wwell col-md-12 " style="background: white;height: 22%; margin-bottom: 20px; padding: 10px padding-left: 15px;  border:1px solid #D3D3D3; ">
              <form target="_blank" action="college_info.php" method="post"> 
              
                  <input type="hidden" name="resultCol" value="'.$c_id.'" />
                  <input type="hidden" name="resultColName" value="'.$c_name.'" />
                  <div class="mmedia col-md-2" style="bbackground: red;">
                    <button type="submit" style="background: transparent; border: 0px;"><img class="img-thumbnail"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/'.$c_img.'" sstyle="margin-left: -20px; ppadding-right: 10px; min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px; border:1px solid #D3D3D3;" style="position:absolute; top:10px; left: -5px; height:125px; width: 150px;"/></button>
                  </div>
                <div class="mmedia-body col-md-10" style="bbackground: yellow; mmargin-left:-20px; margin-top: 10px;">
                 <h4 class="memdia-heading" style="color:black; font-family: system-ui; "> <button class="bsubmit" type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left">'.$c_name.'</button>';
                 $output .='<span class="pull-right"><small>';
                    if($rating>=1)
                    {
                        $output.= "Rating";
                        for($i=0;$i<$rating;$i++)
                            $output.=' <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i>';
                    }
                    $output.='</small></span>';
                 $output.='</h4><p style="font-size :14px; color:#696969;"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp '.$l_name.','.$l_state.'
                   &nbsp| &nbsp&nbsp<i class="fa fa-university" aria-hidden="true"></i>&nbsp '.$uni_name.'
                   
                    &nbsp| &nbsp&nbsp Courses: '. $c_no_courses  ;
                 if($rating>=1){
                  //$output.= "&nbsp &nbsp| &nbsp Rating";
                 for($i=0;$i<$rating;$i++)
                 {
                  //$output.= ' <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i>';
                 }}
                 $rating="";
                 $output.=' </p><p style="color:#696969; font-size:14px;"> &nbsp Ownership :&nbsp'.$type;
                 $output.= '  &nbsp'.$c_e_dt.'&nbsp'.$aprroval.'</p>';
                 $sqlfacilities="SELECT facility_name, facility_image_path from suc_college_facilities where college_id=$c_id";
                 $resultfacilities=$conn->query($sqlfacilities);
                 while($rowfacilities=$resultfacilities->fetch_assoc()){
                   $facility_name=$rowfacilities["facility_name"];
                  $facility_image_path=$rowfacilities["facility_image_path"];
                  $output.= '<img cclass="img-thumbnail" style ="width: 25px; margin-left:5px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/'.$facility_image_path.'" title="'.$facility_name.'"> &nbsp';
                  }
                 $output.=' 
            </div>
            </form>
          </div>';
  }
 }
 else
 {
  //$output = '<h3>No Data Found</h3>';
 }
 echo $output;


?>