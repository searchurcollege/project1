
<head>
    <title>SearchurCollege - Results</title>  
    <META NAME="Description" CONTENT="View all Article on Searchurcollege."/>
    <META NAME="Keywords" CONTENT="Searchurcollege, Article, Ranking, Course, Exam, College, Scholarship"/>
    <!-- <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script> -->
</head>
<style >
  .lbl:hover
  {
    color: #00b3b3;
  }
  

</style>
      <link href="https://fonts.googleapis.com/css?family=Noto+Serif+KR" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
      <link rel="shortcut icon" type="image/x-icon" href="https://www.searchurcollege.com/img/favicon.ico">
      <llink rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/style.css">
      <sscript type="text/javascript" src="https://www.searchurcollege.com/js/jquery.min.js"></script>
      <sscript type="text/javascript" src="https://www.searchurcollege.com/js/bootstrap.min.js"></script>
      <sscript src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.1.1/css/bootstrap.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<style>
    .sub
    {
        background: transparent; border: 0px;
    }
    .sub:hover
    {
        background: black; color: white; border: 0px;
    }
</style>

 
<!---------Microdata Schema----------->
<script type=�application/ld+json�>
{
"@context": "http://www.schema.org",
"@type": "Online Test Portal",
"url": "https://www.searchurcollege.com",
"name": "SearchurCollege",
"image": "https://www.searchurcollege.com/img/header-logo.png",
"description": "Searchurcollege is online educational information classified and  practice test portal. This platform will empower students with making  the most important decision of their life."
}
</script>
<!------------------------------------->  

  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-118318912-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-118318912-1');
</script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '438116786600943');
  fbq('track', 'PageView');
</script>
<noscript><img alt="searchurcollege facebook" height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=438116786600943&ev=PageView&noscript=1"
></noscript>
<!-- End Facebook Pixel Code -->
   <style> 

    .glow {
          background-color: yellow;
          -webkit-border-radius: 10px;
          bborder-radius: 10px;
          border: none;
          color: yellow;
          cursor: pointer;
          display: inline-block;
          font-family: Arial;
          font-size: 20px;
          ppadding: 5px 10px;
          text-align: left;
          text-decoration: none;
      -webkit-animation: glowing 1500ms infinite;
      -moz-animation: glowing 1500ms infinite;
      -o-animation: glowing 1500ms infinite;
      animation: glowing 1500ms infinite;
    }
    @-webkit-keyframes glowing {
      0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
      50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
      100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
    }
    
    @-moz-keyframes glowing {
      0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
      50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
      100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
    }
    
    @-o-keyframes glowing {
      0% { background-color: orange; box-shadow: 0 0 3px #B20000; }
      50% { background-color: orange; box-shadow: 0 0 40px #FF0000; }
      100% { background-color: orange; box-shadow: 0 0 3px #B20000; }
    }
    
    @keyframes glowing {
      0% { background-color: orange; box-shadow: 0 0 3px red; }
      50% { background-color: orange; box-shadow: 0 0 40px red; }
      100% { background-color: orange; box-shadow: 0 0 3px red; }
    }
    .box {
       width:200px;height:300px;
       position:relative;
       border:1px solid #BBB;
       background:#eee;
       float:left;
       margin:20px
    }
    .ribbon {
       position: absolute;
       right: -5px; top: -5px;
       z-index: 1;
       overflow: hidden;
       width: 75px; height: 75px; 
       text-align: right;
    }
    .ribbon span {
       font-size: 10px;
       color: #fff; 
       text-transform: uppercase; 
       text-align: center;
       font-weight: bold; line-height: 20px;
       transform: rotate(45deg);
       width: 100px; display: block;
       background: #79A70A;
       background: linear-gradient(#9BC90D 0%, #79A70A 100%);
       box-shadow: 0 3px 10px -5px rgba(0, 0, 0, 1);
       position: absolute;
       top: 19px; right: -21px;
    }
    .ribbon span::before {
       content: '';
       position: absolute; 
       left: 0px; top: 100%;
       z-index: -1;
       border-left: 3px solid #79A70A;
       border-right: 3px solid transparent;
       border-bottom: 3px solid transparent;
       border-top: 3px solid #79A70A;
    }
    .ribbon span::after {
       content: '';
       position: absolute; 
       right: 0%; top: 100%;
       z-index: -1;
       border-right: 3px solid #79A70A;
       border-left: 3px solid transparent;
       border-bottom: 3px solid transparent;
       border-top: 3px solid #79A70A;
    }
    .red span {background: linear-gradient(#F70505 0%, #8F0808 100%);}
    .red span::before {border-left-color: #8F0808; border-top-color: #8F0808;}
    .red span::after {border-right-color: #8F0808; border-top-color: #8F0808;}
    
    .blue span {background: linear-gradient(#2989d8 0%, #1e5799 100%);}
    .blue span::before {border-left-color: #1e5799; border-top-color: #1e5799;}
    .blue span::after {border-right-color: #1e5799; border-top-color: #1e5799;}
    
    .nav li {font-weight: bold;}
</style>

<style type="text/css">
    .dropdown-submenu {
    position: relative;
}

#dropsec{

}
.dropdown-submenu>.dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -6px;
    margin-left: -1px;
    -webkit-border-radius: 0 6px 6px 6px;
    -moz-border-radius: 0 6px 6px;
    border-radius: 0 6px 6px 6px;
}
.dropdown-menu li a:hover {
    background: black!important;
    color: white!important;
}
.dropdown-submenu:hover>.dropdown-menu {
    display: block;
    color: white!important;
}
.dropdown-submenu li a:hover{
    background: black!important;
    color: white!important;
}
.dropdown-submenu>a:after {
    display: block;
    content: " ";
    float: right;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
    border-width: 5px 0 5px 5px;
    border-left-color: #ccc;
    margin-top: 5px;
    margin-right: -10px;
}
.dropdown-submenu:hover>a:after {
    border-left-color: #fff;
}
.dropdown-submenu.pull-left {
    float: none;
}
.dropdown-submenu.pull-left>.dropdown-menu {
    left: -100%;
    margin-left: 10px;
    -webkit-border-radius: 6px 0 6px 6px;
    -moz-border-radius: 6px 0 6px 6px;
    border-radius: 6px 0 6px 6px;
}    
.navbar-inverse .navbar-nav>.open>a, .navbar-inverse .navbar-nav>.open>a:focus, .navbar-inverse .navbar-nav>.open>a:hover {
    color: #000000!important;
    background-color: #fffdfd!important;
}
.dropdown-menu {
    background-color: #ffffff!important;
}
.dropdown-menu>li>a {
    color: #000000!important;
  }
 
section .main-section { height: 20px; }
.input1{
    text-align: left!important;
    font-family: Arial;
    font-size: 14px;
    padding: 8px 0px 0px 15px;
    display: block;
    clear: both;
    font-weight: normal;
    line-height: 1.42857143;
    color: #333;
    white-space: nowrap
    
}
.input1:hover {
    background: black!important;
    color: white!important;
    width:100%!important;
}
</style>
  </head>
    <section class="main-section"><section class="nav-section">
    <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container-fluid" style="height: 5px;">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
              </button>
              <a class="navbar-brand" href="https://www.searchurcollege.com#disqus_thread"><img alt="searchuecollege.com" src="https://www.searchurcollege.com/img/header-logo.png"></a>
            </div>
            <div class="nav-rt">
              <ul class="nav navbar-nav navbar-right right-nav">
                <li>
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img alt="searchurcollege_user" src="https://www.searchurcollege.com/img/user.png"></a>                  <ul id="dropsec" class="dropdown-menu multi-level">
                        <li><a href="#" id="log" data-toggle="modal" data-target="#login">Login</a></li><li style="display: none;"><a href="#" id="log2" data-toggle="modal" data-target="#login2">Login</a></li><li><a href="#" data-toggle="modal" data-target="#register">Register</a></li>                    </ul>
                </li>
              </ul>
            </div>
            <!-- end nav rt -->
            <div class="collapse navbar-collapse" id="myNavbar" style="margin-left: -10px!important;">
               <ul class="nav navbar-nav" >
               <li style="background: #ff9934;" cclass="glow"><a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: white; font-size: 18px; font-weight: bold;">TEST SERIES <div style="font-size: 12px; background: yellow; color: green; padding: 8px 5px 8px 5px; position: absolute; right: 10px; margin-top: -35px;" class="blink"><b>NEW</b></div><span class="caret" style="color: gray;"></span></a>
                        <ul class="dropdown-menu multi-level"><li><a href="https://www.searchurcollege.com/test/test.php?id=1">MBA</a></li><li><a href="https://www.searchurcollege.com/test/test.php?id=3">Engineering</a></li><li><a href="https://www.searchurcollege.com/test/test.php?id=4">Medical</a></li><li><a href="https://www.searchurcollege.com/test/test.php?id=5">Law</a></li></ul></li>              <!--
 <li style="background: #ff9934;" cclass="glow"><a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: white; font-size: 18px; font-weight: bold;">TEST SERIES<div style="font-size: 12px; background: yellow; color: green; padding: 8px 5px 8px 5px; position: absolute; right: 10px; margin-top: -35px;" class="blink"><b>NEW</b></div><span class="caret" style="color: gray;"></span></a>
                        <ul class="dropdown-menu multi-level"><li><form method="POST" action="https://www.searchurcollege.com/test/test.php"><input type="hidden" name="id" value="1"><input type="submit" class="sub input1" value="MBA"  /></form></li><li><form method="POST" action="https://www.searchurcollege.com/test/test.php"><input type="hidden" name="id" value="3"><input type="submit" class="sub input1" value="Engineering"  /></form></li><li><form method="POST" action="https://www.searchurcollege.com/test/test.php"><input type="hidden" name="id" value="4"><input type="submit" class="sub input1" value="Medical"  /></form></li><li><form method="POST" action="https://www.searchurcollege.com/test/test.php"><input type="hidden" name="id" value="5"><input type="submit" class="sub input1" value="Law"  /></form></li><li><form method="POST" action="https://www.searchurcollege.com/test/test.php"><input type="hidden" name="id" value="6"><input type="submit" class="sub input1" value="Design"  /></form></li></ul></li>-->
               
               <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">MBA <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu ">
                                <li>
                                    <a href="https://www.searchurcollege.com/colleges/mba-college-list-1.php">MBA/PGDM</a>
                                    <a href="https://www.searchurcollege.com/colleges/distance-mba/college-list-1.php">Distance MBA</a>
                                <!--<a href="#">Executive MBA/PGDM</a>
                                    <a href="#">Online MBA</a>
                                    <a href="#">Part Time MBA</a>-->
                                </li>
                            </ul>
                        </li>
                        <li><a href="https://www.searchurcollege.com/exams/mba-exams.php" >MBA Exam Details</a></li>
                    <!--<li><a href="#" >Location of college</a></li>
                        <li><a href="#" >Reviews of college</a></li>
                        <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/management-2018.php">2018</a>
                                    <a href="https://www.searchurcollege.com/ranking/management-2017.php">2017</a>
                                    <a href="https://www.topuniversities.com/university-rankings/rankings-by-location/india/2019" target="_blank">QS Ranking</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">ENGINEERING <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/colleges/engineering-college-list-1.php">B.E./B.Tech.</a>
                                    <a href="#">M.E./M.Tech.</a>
                                    <a href="#">Diploma Courses</a>
                                <!--<a href="#">Distance Diploma Courses</a>
                                    <a href="#">Distance B.Tech</a>-->
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/engineering-exams.php" >Engineering Exam Details</a></li>
                    <!--<li><a href="#" >Location of college</a></li>
                        <li><a href="#" >Reviews of college</a></li>
                        <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/engineering-2018.php">2018</a>
                                    <a href="https://www.searchurcollege.com/ranking/engineering-2017.php">2017</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">LAW <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/colleges/law-college-list-1.php">BA LLB</a>
                                    <a href="#">BBA LLB</a>
                                    <a href="#">LLB</a>
                                    <a href="#">LLM</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/law-exams.php" >LAW Exam Details</a></li>
                     <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                         <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/law-2018.php">2018</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->       
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">DESIGN <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#">Communication Design</a>
                                    <a href="#">Fashion Design</a>
                                    <a href="#">Industrial/Product Design</a>
                                    <a href="#">Interior Design</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/design-exams.php" >Design Exam Details</a></li>
                        <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <!--<li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#" >2018</a>
                                    <a href="#" >2017</a>
                                </li>
                            </ul>
                        </li>-->
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">MEDICAL <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/colleges/medical-college-list-1.php">MBBS</a>
                                    <a href="#">Pharmacy</a>
                                    <a href="#">Nursing</a>
                                    <a href="#">Dental Science</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/medical-exams.php" >Medical Exam Details</a></li>
                     <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/medical-2018.php">2018</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">MORE<b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#">BCA</a>
                                    <a href="#">MCA</a>
                                    <a href="#">BSc. IT</a>
                                    <a href="#">MSc. IT</a>
                                    <a href="#">BBA</a>
                                    <a href="#">BBM</a>
                                    <a href="#">Hotal Management</a>
                                    <a href="#">Media & Journalism</a>
                                    <a href="#">Engineerng Diploma (Polytechnic)</a>
                                    <a href="#">Animation</a>
                                    <a href="#">Finance & Accounts</a>
                                    <a href="#">Degree Courses (Arts, Commerce & Science)</a>
                                    <a href="#">Others (Diploma etc.)</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="#">Other Exam Details</a></li>
                     <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <!--<li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#" >2018</a>
                                    <a href="#" >2017</a>
                                </li>
                            </ul>
                        </li>-->
                    </ul>
                </li>
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">SCHOLARSHIP <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a >Central Govt.</a></li>
                        <li><a >State Govt.</a></li>
                    	<li><a >CSR Funding</a></li>
                   		<li><a >Minorty</a></li>
                        <li><a >Loan</a></li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">EXAMS <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">MBA</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/engineering-exams.php">Engineering</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/medical-exams.php" >Medical</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/law-exams.php" >LAW</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/design-exams.php" >Design</a></li>
                   <!--<li><a href="#" >Others Exam </a></li>-->
                    </ul>
                </li>
                <!--  -->
            </ul>
            </div>
          </div>
        </nav>
      </section>
      <!-- end nav bar section -->
    </section>
    <div class="clearfix"></div>
 
<style>
@-webkit-keyframes blink {  
  from { opacity: 1.0; }
  to { opacity: 0.0; }
}

.blink {
  -webkit-animation-name: blink;  
  -webkit-animation-iteration-count: infinite;  
  -webkit-animation-timing-function: cubic-bezier(1.0,0,0,1.0);
  -webkit-animation-duration: 1s; 
}
</style>
    
<style>
.input-group
{
    margin-bottom: 10px;
}
.mydiv {
    position:fixed;
    top: 50%;
    lleft: 50%;
    width: 100%;
    margin-top: -9em; /*set to a negative number 1/2 of your height*/
    mmargin-left: -15em; /*set to a negative number 1/2 of your width*/
    border: 1px solid #ccc;
    background-color: #f3f3f3;
}
 @media screen and (min-width: 200px) and (max-width: 999px){
   .modal-content{
   padding-bottom: 45px!important; }
    
}

</style>

<div id="login" class="modal fade" role="dialog" style="margin-top: 100px;">
  <div class="modal-dialog">
    <div class="modal-content">
            <div class="col-md-12 col-xs-12" style="background: white; padding: 10px;">
                <button type="button" style="position: absolute; right: 20px; color: black;" class="close" data-dismiss="modal" title="Close">&times;</button>
                <h4 class="modal-title"><b><i class="fa fa-user-o"></i> User Login</b><br /><br /></h4>
                <form id="frmLogin" action="user_login.php">
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="text" class="form-control" name="email"id="email" placeholder="Email" required />
                    </div>
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="password" class="form-control" name="password" placeholder="Password" required />
                    </div>
                    <div class="col-md-12 text-right" style="margin-top: 10px;">
                        <button type="submit" class="btn btn-success pull-left">Login</button>
                        <button id="fp" class="btn btn-warning pull-left" style="margin-left: 10px;">Forgot Password</button>
                        <span class="pull-right" style="margin-top: 7px; font-weight: bold;">
                            New user ? <a><span data-toggle="modal" data-target="#register" data-dismiss="modal" style="margin-right: 10px; cursor: pointer; color: #5D9BD0;">Register Here</span></a>
                        </span>
                        <div class="row"></div>
                        <span id="success" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Login Succeeded.</span>
                        <span id="success1" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Password send to Email.</span>
                        <span id="error" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Invalid Credentials</span>
                         <span id="error1" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Something Wrong, Please click on Forget Password</span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
        //Login User
        $('#frmLogin').submit(function(event) {
          $.post('https://www.searchurcollege.com/connection/user_login.php',
            $(this).serialize(),
            function(data)
            {
                if(data=='1')
                {
                    $("#success").show();
                    eid=$('#eid').val();
                    setTimeout(function() { $("#success").hide(); }, 3000);
                    if(eid>0)
                        window.location.href = "https://www.searchurcollege.com/exam/start-exam/"+eid;
                    else
                    {
                        location.reload();
                    }
                }
                else
                if(data=='2')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                if(data==0)
                {
                    $("#error").show();
                    setTimeout(function() { $("#error").hide(); }, 3000);
                }
                else
                {
                    window.location.href = "https://www.searchurcollege.com/connection/alert.php?email="+data;
                }
            }
          );
          //alert("11");
          return false; 

        }); 
</script>

<script type="text/javascript">
        //Login User
        $('#fp').click(function(event) {
            email=$('#email').val();
         // alert("window.location.pathname");
          $.post(
           'https://www.searchurcollege.com/connection/forget_pass.php?email='+email,
            
            function(data)
            {
                console.log(data);
                if(data=='1')
                {
                    $("#success1").show();
                    setTimeout(function() { $("#success1").hide(); }, 3000);
                }
                else
                if(data=='2')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                if(data=='3') 
                {
                    window.location.href = "https://www.searchurcollege.com/connection/alert.php";
                }
                else
                {
                    $("#error1").show();
                    setTimeout(function() { $("#error1").hide(); }, 4000);
                }
            }
          );

          return false;   
        }); 
</script>

<style>
    #otp
    { 
        position:fixed;
        top: 50%;
        left: 52%;
        width: 300px;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: -15em; /*set to a negative number 1/2 of your width*/
        border: 5px double #5d9bd0;
        background-color: #f3f3f3;
        padding: 30px;
    }
    ul, span { list-style-type: none;  color: black;}
    .div-mobile {
        display: none;
    }
    .div-no-mobile {
        display: block;
    }
    @media screen and (min-width: 200px) and (max-width: 999px)
    {
        .div-no-mobile
        {
            display:none
        }
        .div-mobile
        {
            display: block;
        }
        .modal-body
        {
            padding: 20px!important;
        }
        #col1
        {
            margin-top: -20px;
            padding-bottom: 0px;
        }
        #col2
        {
            margin-top: 0px;
            padding-top: 1px!important;
        }
        #regButton
        {
            margin-top: -80px;
        }
    }
    #col1, #col2
    {
        padding-top: 20px!important;
    }
    .modal-body
    {
        background: #DAEBFA;
        padding: 0px;
    }
    .input-group
    {
        margin-bottom: 10px;
        width: 100%;
    }
    input[type=text]
    {
        border: 1px solid lightgrey!important;
        color: black!important;
    }
    #msg
    {
        margin-top: -10px;
        position: relative;
    }
    #msg2
    {
        position:fixed!important;
        top: 50%;
        left: 50%;
        max-width: 200px;
        hheight:18em;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: 0%; /*set to a negative number 1/2 of your width*/
        border: 1px solid #ccc;
        background-color: #f3f3f3;
        z-index: 1000;
    }
    /**
 * th,td {text-align: center; vertical-align: middle; padding: 2px;}
 *     .first{text-align: left;}
 *     .second{background: #DAD8D8;}
 *     .third{background: #B2F068; border: 0px!important;}
 */
</style>
<style>
    * {
      box-sizing: border-box;
    }
    
    .autocomplete {
      /*the container must be positioned relative:*/
      position: relative;
      display: inline-block;
    }
    
    .autocomplete-items {
      position: absolute;
      border: 1px solid #d4d4d4;
      border-bottom: none;
      border-top: none;
      z-index: 99;
      /*position the autocomplete items to be the same width as the container:*/
      top: 100%;
      left: 0;
      right: 0;
    }
    
    .autocomplete-items div {
      padding: 10px;
      cursor: pointer;
      background-color: #fff; 
      border-bottom: 1px solid #d4d4d4; 
    }
    
    .autocomplete-items div:hover {
      /*when hovering an item:*/
      background-color: #e9e9e9; 
    }
    
    .autocomplete-active {
      /*when navigating through the items using the arrow keys:*/
      background-color: DodgerBlue !important; 
      color: #ffffff; 
    }
</style>

	<!--<link href="css/style.css" rel='stylesheet' type='text/css'/>-->
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
			<script>$(document).ready(function(c) {
			$('.alert-close').on('click', function(c){
				$('.main-agile').fadeOut('slow', function(c){
					$('.main-agile').remove();
				});
			});	  
		});
		</script>

<!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#register">Open Modal</button>-->

<div id="register" class="modal fade" role="dialog">
  <div id="d" class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-body">
            <div class="row row-eq-height">
        		<div id="col1" class="col-md-6" style=" padding: 0px 40px 20px 40px;">
                    <h3 class="div-no-mobile" style="color: #ff9934;"><b>Why Register ?</b></h3>
                    <h3 id="why_head" class="div-mobile" style="color: #5D9BD0; cursor: pointer;"><b>Why Register ? <small style="position: absolute; margin-top: 5px; right: 15px;"><i class="fa fa-plus pull-right"></i></small></b></h3> </br>
                    <span><!--<i class="pull-right fa fa-info"></i>-->
                    <span id="msg1" class="div-no-mobile"><b><h3>General Benifits</h3></b><br />
                        <lh><strong> Information About:</strong></lh>
                    <ul>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp   Exams </li>
                       
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp  Courses</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspTop Colleges & Universities</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspEligibility Criteria For Admission</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspRanking of Universities & Colleges</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspEducation Loans</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspScholarship</li>
                    </ul>
                    <lh><strong>Additionals</strong></lh>
                    <ul>
                        
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbspAsk Your Doubt</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspGet Advice From Experience Experts</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspAlumni Review</li>
                       <!-- <li>Top Colleges & Universities</li>
                        <li>Popular Courses</li>
                        <li>Eligibility & Admission</li>
                        <li>College Rankings</li>
                        <li>Previous Year Question Papers</li>
                        <li>Subject Library</li>
                        <li>Online Tests & Exam Prepration</li>
                        <li>Tests History</li>
                        <li>Progress Tracking</li>
                        <li>News & Updates</li>
                        <li>Important Dates Alerts</li>
                        <li>365 Days Support</li>
                        <li>Career Guidance</li> -->
                    </ul></span>
                </div>
                
        		<div id="col2" class="col-md-6" style="background: white; padding: 0px 40px 20px 40px;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 style="color: #ff9934; text-align: left;"><i class="fa fa-user fa-sm"></i> <b>Register</b></h3>
                    <b style="color: black;">Tell us something about youself to offer better assistance  .</b><br /><br />
                    <form id="frmRegister" action="user_register.php">
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <select id="L1" name="last_qualification" class="form-control" rrequired>
                                <option disabled selected>Last Qualification</option>
                                <option value="1">Intermediate (10 + 2)</option><option value="3">Graduation</option>                            </select>
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <select id="course_interested" name="course_interested" class="form-control" rrequired>
                            <option disabled selected>Course Looking for</option>
                            
                            
                            </select>
                        </span>
                        <!-- <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <input list="course_interested" id="L2" name="course_interested" class="form-control" placeholder="Course Looking for" rrequired />
                            <datalist id="course_interested">
                            </datalist>
                        </span> -->
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control iinput-md" id="first_name" name="first_name" placeholder="First Name" rrequired />
                          <span class="input-group-btn" style="width: 0px;"></span>
                          <input type="text" class="form-control input-md" id="last_name" name="last_name" placeholder="Last Name" rrequired />
                        </div>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input id="email2" type="email" class="form-control" name="email" placeholder="Email" rrequired />
                        </span>
                        <span class="input-group">
                            <span class="input-group"><span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" name="password1" placeholder="Password" rrequired />
                        </span>
                        <span class="input-group">
                            <span class="input-group"><span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" name="password2" placeholder="Confirm Password" rrequired />
                        </span>
                        <span class="input-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="Contact No." rrequired />
                            </div>
                        </span>
                        <span class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                            <select id="cl" name="current_location" class="form-control" rrequired>
                                <option disabled selected>Current Location</option>
                                <option value="Abohar">Abohar</option><option value="Achalpur">Achalpur</option><option value="Adilabad">Adilabad</option><option value="Adityapur">Adityapur</option><option value="Adoni">Adoni</option><option value="Agartala">Agartala</option><option value="Agra">Agra</option><option value="Ahmadabad">Ahmadabad</option><option value="Ahmadnagar">Ahmadnagar</option><option value="Aizawl">Aizawl</option><option value="Ajmer">Ajmer</option><option value="Akola">Akola</option><option value="Akot">Akot</option><option value="Alandur">Alandur</option><option value="Alappuzha">Alappuzha</option><option value="Aligarh">Aligarh</option><option value="Alipur Duar">Alipur Duar</option><option value="Allahabad">Allahabad</option><option value="Alwal">Alwal</option><option value="Alwar">Alwar</option><option value="Amalner">Amalner</option><option value="Ambajogai">Ambajogai</option><option value="Ambala">Ambala</option><option value="Ambala Cantonment">Ambala Cantonment</option><option value="Ambala Sadar">Ambala Sadar</option><option value="Ambattur">Ambattur</option><option value="Ambikapur">Ambikapur</option><option value="Ambur">Ambur</option><option value="Amravati">Amravati</option><option value="Amreli">Amreli</option><option value="Amritsar">Amritsar</option><option value="Amroha">Amroha</option><option value="Anakapalle">Anakapalle</option><option value="Anand">Anand</option><option value="Anantapur">Anantapur</option><option value="Anantnag">Anantnag</option><option value="Anjangaon">Anjangaon</option><option value="Anjar">Anjar</option><option value="Aonla">Aonla</option><option value="Arakonam">Arakonam</option><option value="Arambagh">Arambagh</option><option value="Arani">Arani</option><option value="Araria">Araria</option><option value="Arrah">Arrah</option><option value="Aruppukkottai">Aruppukkottai</option><option value="Asansol">Asansol</option><option value="Ashoknagar">Ashoknagar</option><option value="Ashoknagar Kalyangarh">Ashoknagar Kalyangarh</option><option value="Attur">Attur</option><option value="Auraiya">Auraiya</option><option value="Aurangabad">Aurangabad</option><option value="Aurangabad">Aurangabad</option><option value="Avadi">Avadi</option><option value="Avaniapuram">Avaniapuram</option><option value="Ayodhya">Ayodhya</option><option value="Azamgarh">Azamgarh</option><option value="Badharghat">Badharghat</option><option value="Badlapur">Badlapur</option><option value="Bagaha">Bagaha</option><option value="Bagalkot">Bagalkot</option><option value="Bagbahra">Bagbahra</option><option value="Bahadurgarh">Bahadurgarh</option><option value="Baharampur">Baharampur</option><option value="Baheri">Baheri</option><option value="Bahraich">Bahraich</option><option value="Baidyabati">Baidyabati</option><option value="Baj Baj">Baj Baj</option><option value="Balaghat">Balaghat</option><option value="Balangir">Balangir</option><option value="Baleshwar">Baleshwar</option><option value="Ballarpur">Ballarpur</option><option value="Ballia">Ballia</option><option value="Bally">Bally</option><option value="Bally Cantonment">Bally Cantonment</option><option value="Balotra">Balotra</option><option value="Balrampur">Balrampur</option><option value="Balurghat">Balurghat</option><option value="Banda">Banda</option><option value="Bangalore">Bangalore</option><option value="Bangaon">Bangaon</option><option value="Bankra">Bankra</option><option value="Bankura">Bankura</option><option value="Bansbaria">Bansbaria</option><option value="Banswara">Banswara</option><option value="Bapatla">Bapatla</option><option value="Baramati">Baramati</option><option value="Baramula">Baramula</option><option value="Baran">Baran</option><option value="Baranagar">Baranagar</option><option value="Baraut">Baraut</option><option value="Barbil">Barbil</option><option value="Barddhaman">Barddhaman</option><option value="Bardoli">Bardoli</option><option value="Bareli">Bareli</option><option value="Bargarh">Bargarh</option><option value="Bari">Bari</option><option value="Bari Brahmana">Bari Brahmana</option><option value="Baripada">Baripada</option><option value="Barmer">Barmer</option><option value="Barnala">Barnala</option><option value="Barpeta">Barpeta</option><option value="Barsi">Barsi</option><option value="Basavakalyan">Basavakalyan</option><option value="Basirhat">Basirhat</option><option value="Basmat">Basmat</option><option value="Basoda">Basoda</option><option value="Basti">Basti</option><option value="Batala">Batala</option><option value="Bathinda">Bathinda</option><option value="Beawar">Beawar</option><option value="Begusarai">Begusarai</option><option value="Behta Hajipur">Behta Hajipur</option><option value="Bela">Bela</option><option value="Belampalli">Belampalli</option><option value="Belgaum">Belgaum</option><option value="Bellary">Bellary</option><option value="Bettiah">Bettiah</option><option value="Betul">Betul</option><option value="Beypur">Beypur</option><option value="Bhabua">Bhabua</option><option value="Bhadohi">Bhadohi</option><option value="Bhadrak">Bhadrak</option><option value="Bhadravati">Bhadravati</option><option value="Bhadravati">Bhadravati</option><option value="Bhadreswar">Bhadreswar</option><option value="Bhagalpur">Bhagalpur</option><option value="Bhalswa Jahangirpur">Bhalswa Jahangirpur</option><option value="Bhandara">Bhandara</option><option value="Bharatpur">Bharatpur</option><option value="Bharuch">Bharuch</option><option value="Bhatpara">Bhatpara</option><option value="Bhavnagar">Bhavnagar</option><option value="Bhawanipatna">Bhawanipatna</option><option value="Bhilai">Bhilai</option><option value="Bhilwara">Bhilwara</option><option value="Bhimavaram">Bhimavaram</option><option value="Bhind">Bhind</option><option value="Bhiwadi">Bhiwadi</option><option value="Bhiwandi">Bhiwandi</option><option value="Bhiwani">Bhiwani</option><option value="Bhongir">Bhongir</option><option value="Bhopal">Bhopal</option><option value="Bhubaneswar">Bhubaneswar</option><option value="Bhuj">Bhuj</option><option value="Bhuli">Bhuli</option><option value="Bhusawal">Bhusawal</option><option value="Bid">Bid</option><option value="Bidar">Bidar</option><option value="Bidhannagar">Bidhannagar</option><option value="Bihar">Bihar</option><option value="Bijapur">Bijapur</option><option value="Bijnor">Bijnor</option><option value="Bikaner">Bikaner</option><option value="Bilaspur">Bilaspur</option><option value="BinaEtawa">BinaEtawa</option><option value="Binnaguri">Binnaguri</option><option value="Bisalpur">Bisalpur</option><option value="Bishnupur">Bishnupur</option><option value="Biswan">Biswan</option><option value="Bobbili">Bobbili</option><option value="Bodhan">Bodhan</option><option value="Bodinayakkanur">Bodinayakkanur</option><option value="Bokaro">Bokaro</option><option value="Bolpur">Bolpur</option><option value="Bommanahalli">Bommanahalli</option><option value="Bongaigaon">Bongaigaon</option><option value="Borsad">Borsad</option><option value="Botad">Botad</option><option value="Brahmapur">Brahmapur</option><option value="Brajrajnagar">Brajrajnagar</option><option value="Budaun">Budaun</option><option value="Bulandshahr">Bulandshahr</option><option value="Buldana">Buldana</option><option value="Bundi">Bundi</option><option value="Burari">Burari</option><option value="Burhanpur">Burhanpur</option><option value="Buxar">Buxar</option><option value="Byatarayanapura">Byatarayanapura</option><option value="Calcutta">Calcutta</option><option value="Chaibasa">Chaibasa</option><option value="Chakdaha">Chakdaha</option><option value="Chalisgaon">Chalisgaon</option><option value="Challakere">Challakere</option><option value="Champdani">Champdani</option><option value="Chamrajnagar">Chamrajnagar</option><option value="Chandannagar">Chandannagar</option><option value="Chandausi">Chandausi</option><option value="Chandigarh">Chandigarh</option><option value="Chandkheda">Chandkheda</option><option value="Chandlodiya">Chandlodiya</option><option value="Chandpur">Chandpur</option><option value="Chandrapur">Chandrapur</option><option value="Channapatna">Channapatna</option><option value="Charkhi Dadri">Charkhi Dadri</option><option value="Charoda">Charoda</option><option value="Chas">Chas</option><option value="Chengalpattu">Chengalpattu</option><option value="Cheruvannur">Cheruvannur</option><option value="Chhapra">Chhapra</option><option value="Chhatarpur">Chhatarpur</option><option value="Chhibramau">Chhibramau</option><option value="Chhindwara">Chhindwara</option><option value="Chik Ballapur">Chik Ballapur</option><option value="Chikhli">Chikhli</option><option value="Chikmagalur">Chikmagalur</option><option value="Chilakalurupet">Chilakalurupet</option><option value="Chilla Saroda Bangar">Chilla Saroda Bangar</option><option value="Chinna Chawk">Chinna Chawk</option><option value="Chintamani">Chintamani</option><option value="Chiplun">Chiplun</option><option value="Chirala">Chirala</option><option value="Chirmiri">Chirmiri</option><option value="Chitradurga">Chitradurga</option><option value="Chitrakut Dham">Chitrakut Dham</option><option value="Chittaurgarh">Chittaurgarh</option><option value="Chittur">Chittur</option><option value="Chomun">Chomun</option><option value="Chopda">Chopda</option><option value="Churu">Churu</option><option value="Contai">Contai</option><option value="Cuddapah">Cuddapah</option><option value="Dabgram">Dabgram</option><option value="Dabhoi">Dabhoi</option><option value="Dabra">Dabra</option><option value="Dabwali">Dabwali</option><option value="Dadri">Dadri</option><option value="Dahanu">Dahanu</option><option value="Dahod">Dahod</option><option value="Dallo Pura">Dallo Pura</option><option value="Daltenganj">Daltenganj</option><option value="Damoh">Damoh</option><option value="Daosa">Daosa</option><option value="Darbhanga">Darbhanga</option><option value="Darjiling">Darjiling</option><option value="Dasarahalli">Dasarahalli</option><option value="Datia">Datia</option><option value="Davanagere">Davanagere</option><option value="Dehra Dun">Dehra Dun</option><option value="Dehra Dun Cantonment">Dehra Dun Cantonment</option><option value="Dehri">Dehri</option><option value="Delhi">Delhi</option><option value="Deoband">Deoband</option><option value="Deolali">Deolali</option><option value="Deoli">Deoli</option><option value="Deoria">Deoria</option><option value="Devghar">Devghar</option><option value="Dewas">Dewas</option><option value="Dhamtari">Dhamtari</option><option value="Dhanbad">Dhanbad</option><option value="Dhar">Dhar</option><option value="Dharapuram">Dharapuram</option><option value="Dharmapuri">Dharmapuri</option><option value="Dharmavaram">Dharmavaram</option><option value="Dhaulpur">Dhaulpur</option><option value="Dhenkanal">Dhenkanal</option><option value="Dholka">Dholka</option><option value="Dhone">Dhone</option><option value="Dhoraji">Dhoraji</option><option value="Dhrangadhra">Dhrangadhra</option><option value="Dhuburi">Dhuburi</option><option value="Dhule">Dhule</option><option value="Dhulian">Dhulian</option><option value="Dhuri">Dhuri</option><option value="Dibrugarh">Dibrugarh</option><option value="Didwana">Didwana</option><option value="Digdoh">Digdoh</option><option value="DighaMainpura">DighaMainpura</option><option value="Diglur">Diglur</option><option value="Dilli Cantonment">Dilli Cantonment</option><option value="Dimapur">Dimapur</option><option value="Dinapur">Dinapur</option><option value="Dindigul">Dindigul</option><option value="Dinhata">Dinhata</option><option value="Diphu">Diphu</option><option value="Disa">Disa</option><option value="Dod Ballapur">Dod Ballapur</option><option value="Dum Dum">Dum Dum</option><option value="Dumraon">Dumraon</option><option value="Durg">Durg</option><option value="Durgapur">Durgapur</option><option value="Edakkara">Edakkara</option><option value="Edathala">Edathala</option><option value="Eluru">Eluru</option><option value="Erode">Erode</option><option value="Etah">Etah</option><option value="Etawah">Etawah</option><option value="Faizabad">Faizabad</option><option value="Faridabad">Faridabad</option><option value="Faridkot">Faridkot</option><option value="Faridpur">Faridpur</option><option value="Farrukhabad">Farrukhabad</option><option value="Fatehpur">Fatehpur</option><option value="Fatehpur">Fatehpur</option><option value="Fazilka">Fazilka</option><option value="Firozabad">Firozabad</option><option value="Firozpur">Firozpur</option><option value="Firozpur Cantonment">Firozpur Cantonment</option><option value="Gadag">Gadag</option><option value="Gadchiroli">Gadchiroli</option><option value="Gaddiannaram">Gaddiannaram</option><option value="Gadwal">Gadwal</option><option value="Gajraula">Gajraula</option><option value="Gajuwaka">Gajuwaka</option><option value="Gandhidham">Gandhidham</option><option value="Gandhinagar">Gandhinagar</option><option value="Ganga Ghat">Ganga Ghat</option><option value="Ganganagar">Ganganagar</option><option value="Gangapur">Gangapur</option><option value="Gangarampur">Gangarampur</option><option value="Gangawati">Gangawati</option><option value="Gangoh">Gangoh</option><option value="Garulia">Garulia</option><option value="Gaya">Gaya</option><option value="Gayespur">Gayespur</option><option value="Gharoli">Gharoli</option><option value="Ghatal">Ghatal</option><option value="Ghatlodiya">Ghatlodiya</option><option value="Ghaziabad">Ghaziabad</option><option value="Ghazipur">Ghazipur</option><option value="Gobindgarh">Gobindgarh</option><option value="Godhra">Godhra</option><option value="Gohad">Gohad</option><option value="Gohana">Gohana</option><option value="Gokak">Gokak</option><option value="Gokalpur">Gokalpur</option><option value="Gola Gokarannath">Gola Gokarannath</option><option value="Gola Range">Gola Range</option><option value="Gonda">Gonda</option><option value="Gondal">Gondal</option><option value="Gondiya">Gondiya</option><option value="Gopalganj">Gopalganj</option><option value="Gopalpur">Gopalpur</option><option value="Gopichettipalaiyam">Gopichettipalaiyam</option><option value="Gorakhpur">Gorakhpur</option><option value="Goura">Goura</option><option value="Gudalur">Gudalur</option><option value="Gudivada">Gudivada</option><option value="Gudiyattam">Gudiyattam</option><option value="Gudur">Gudur</option><option value="Gulbarga">Gulbarga</option><option value="Guna">Guna</option><option value="Guntakal">Guntakal</option><option value="Guntur">Guntur</option><option value="Gurdaspur">Gurdaspur</option><option value="Guwahati">Guwahati</option><option value="Gwalior">Gwalior</option><option value="Habra">Habra</option><option value="Hajipur">Hajipur</option><option value="Haldwani">Haldwani</option><option value="Halisahar">Halisahar</option><option value="Hanumangarh">Hanumangarh</option><option value="Haora">Haora</option><option value="Hapur">Hapur</option><option value="Harda">Harda</option><option value="Hardoi">Hardoi</option><option value="Haridwar">Haridwar</option><option value="Harihar">Harihar</option><option value="Hasanpur">Hasanpur</option><option value="Hassan">Hassan</option><option value="Hastsal">Hastsal</option><option value="Hathras">Hathras</option><option value="Haveri">Haveri</option><option value="Hazaribag">Hazaribag</option><option value="Himatnagar">Himatnagar</option><option value="Hindaun">Hindaun</option><option value="Hindupur">Hindupur</option><option value="Hinganghat">Hinganghat</option><option value="Hingoli">Hingoli</option><option value="Hiriyur">Hiriyur</option><option value="Hisar">Hisar</option><option value="Hosakote">Hosakote</option><option value="Hoshangabad">Hoshangabad</option><option value="Hoshiarpur">Hoshiarpur</option><option value="Hospet">Hospet</option><option value="Hosur">Hosur</option><option value="Hubli">Hubli</option><option value="HugliChunchura">HugliChunchura</option><option value="Hyderabad">Hyderabad</option><option value="Ichalkaranji">Ichalkaranji</option><option value="Idappadi">Idappadi</option><option value="Ilkal">Ilkal</option><option value="Imphal">Imphal</option><option value="Indore">Indore</option><option value="Ingraj Bazar">Ingraj Bazar</option><option value="Islampur">Islampur</option><option value="Itanagar">Itanagar</option><option value="Itarsi">Itarsi</option><option value="Jabalpur">Jabalpur</option><option value="Jabalpur Cantonment">Jabalpur Cantonment</option><option value="Jaffrabad">Jaffrabad</option><option value="Jagadhri">Jagadhri</option><option value="Jagdalpur">Jagdalpur</option><option value="Jagraon">Jagraon</option><option value="Jagtial">Jagtial</option><option value="Jahanabad">Jahanabad</option><option value="Jahangirabad">Jahangirabad</option><option value="Jaipur">Jaipur</option><option value="Jaisalmer">Jaisalmer</option><option value="Jalandhar">Jalandhar</option><option value="Jalaun">Jalaun</option><option value="Jalgaon">Jalgaon</option><option value="Jalna">Jalna</option><option value="Jalor">Jalor</option><option value="Jalpaiguri">Jalpaiguri</option><option value="Jamalpur">Jamalpur</option><option value="Jamkhandi">Jamkhandi</option><option value="Jammu">Jammu</option><option value="Jamnagar">Jamnagar</option><option value="Jamnagar">Jamnagar</option><option value="Jamshedpur">Jamshedpur</option><option value="Jamui">Jamui</option><option value="Jamuria">Jamuria</option><option value="Jangipur">Jangipur</option><option value="Jaora">Jaora</option><option value="Jaunpur">Jaunpur</option><option value="Jaypur">Jaypur</option><option value="Jetpur">Jetpur</option><option value="Jhalawar">Jhalawar</option><option value="Jhansi">Jhansi</option><option value="Jhargram">Jhargram</option><option value="Jharia">Jharia</option><option value="Jharsuguda">Jharsuguda</option><option value="Jhumri Tilaiya">Jhumri Tilaiya</option><option value="Jhunjhunun">Jhunjhunun</option><option value="Jind">Jind</option><option value="Jodhpur">Jodhpur</option><option value="Jorapokhar">Jorapokhar</option><option value="Jorhat">Jorhat</option><option value="Junagadh">Junagadh</option><option value="Kadayanallur">Kadayanallur</option><option value="Kadi">Kadi</option><option value="Kadiri">Kadiri</option><option value="Kagaznagar">Kagaznagar</option><option value="Kairana">Kairana</option><option value="Kaithal">Kaithal</option><option value="Kakinada">Kakinada</option><option value="Kalamassery">Kalamassery</option><option value="Kaliyaganj">Kaliyaganj</option><option value="Kallur">Kallur</option><option value="Kalna">Kalna</option><option value="Kalol">Kalol</option><option value="Kalyan">Kalyan</option><option value="Kalyani">Kalyani</option><option value="Kamareddi">Kamareddi</option><option value="Kamarhati">Kamarhati</option><option value="Kambam">Kambam</option><option value="Kamthi">Kamthi</option><option value="Kanakapura">Kanakapura</option><option value="Kanchipuram">Kanchipuram</option><option value="Kanchrapara">Kanchrapara</option><option value="Kandi">Kandi</option><option value="Kannan Devan Hills">Kannan Devan Hills</option><option value="Kannangad">Kannangad</option><option value="Kannauj">Kannauj</option><option value="Kannur">Kannur</option><option value="Kanpur">Kanpur</option><option value="Kanpur Cantonment">Kanpur Cantonment</option><option value="Kapra">Kapra</option><option value="Kapurthala">Kapurthala</option><option value="Karaikal">Karaikal</option><option value="Karanja">Karanja</option><option value="Karauli">Karauli</option><option value="Karawal Nagar">Karawal Nagar</option><option value="Karimganj">Karimganj</option><option value="Karimnagar">Karimnagar</option><option value="Karnal">Karnal</option><option value="Karnul">Karnul</option><option value="Karsiyang">Karsiyang</option><option value="Karur">Karur</option><option value="Karwar">Karwar</option><option value="Kasganj">Kasganj</option><option value="Kashipur">Kashipur</option><option value="Kataka">Kataka</option><option value="Kathua">Kathua</option><option value="Katihar">Katihar</option><option value="Katras">Katras</option><option value="Katwa">Katwa</option><option value="Kavali">Kavali</option><option value="Kavundampalaiyam">Kavundampalaiyam</option><option value="Kayankulam">Kayankulam</option><option value="Kendujhar">Kendujhar</option><option value="Keshod">Keshod</option><option value="Khadki">Khadki</option><option value="Khagaria">Khagaria</option><option value="Khagaul">Khagaul</option><option value="Khajuri Khas">Khajuri Khas</option><option value="Khambhat">Khambhat</option><option value="Khamgaon">Khamgaon</option><option value="Khammam">Khammam</option><option value="Khandwa">Khandwa</option><option value="Khanna">Khanna</option><option value="Kharagpur">Kharagpur</option><option value="Kharagpur Railway Settlement">Kharagpur Railway Settlement</option><option value="Khardaha">Khardaha</option><option value="Khargone">Khargone</option><option value="Kharia">Kharia</option><option value="Khatauli">Khatauli</option><option value="Khopoli">Khopoli</option><option value="Khora">Khora</option><option value="Khurja">Khurja</option><option value="Kirari Suleman Nagar">Kirari Suleman Nagar</option><option value="Kiratpur">Kiratpur</option><option value="Kishanganj">Kishanganj</option><option value="Kishangarh">Kishangarh</option><option value="Koch Bihar">Koch Bihar</option><option value="Kochi">Kochi</option><option value="Kodar">Kodar</option><option value="Kohima">Kohima</option><option value="Kolar">Kolar</option><option value="Kolhapur">Kolhapur</option><option value="Kollam">Kollam</option><option value="Kollegal">Kollegal</option><option value="Kondukur">Kondukur</option><option value="Konnagar">Konnagar</option><option value="Kopargaon">Kopargaon</option><option value="Koppal">Koppal</option><option value="Koratla">Koratla</option><option value="Korba">Korba</option><option value="Kosi Kalan">Kosi Kalan</option><option value="Kot Kapura">Kot Kapura</option><option value="Kota">Kota</option><option value="Kottagudem">Kottagudem</option><option value="Kottayam">Kottayam</option><option value="Kovilpatti">Kovilpatti</option><option value="Koyampattur">Koyampattur</option><option value="Koyilandi">Koyilandi</option><option value="Kozhikkod">Kozhikkod</option><option value="Krishnagiri">Krishnagiri</option><option value="Krishnanagar">Krishnanagar</option><option value="Krishnarajapura">Krishnarajapura</option><option value="Kuchaman">Kuchaman</option><option value="Kukatpalle">Kukatpalle</option><option value="Kulti">Kulti</option><option value="Kumarapalaiyam">Kumarapalaiyam</option><option value="Kumbakonam">Kumbakonam</option><option value="Kundla">Kundla</option><option value="Kuniyamuthur">Kuniyamuthur</option><option value="Kunnamkulam">Kunnamkulam</option><option value="Kurichi">Kurichi</option><option value="Ladnun">Ladnun</option><option value="Laharpur">Laharpur</option><option value="Lakhimpur">Lakhimpur</option><option value="Lakhimpur">Lakhimpur</option><option value="Lakhisarai">Lakhisarai</option><option value="Lakhnau">Lakhnau</option><option value="Lakhnau Cantonment">Lakhnau Cantonment</option><option value="Lalbahadur Nagar">Lalbahadur Nagar</option><option value="Lalitpur">Lalitpur</option><option value="Lanka">Lanka</option><option value="Latur">Latur</option><option value="Lohardaga">Lohardaga</option><option value="Lonavale">Lonavale</option><option value="Loni">Loni</option><option value="Ludhiana">Ludhiana</option><option value="Lunglei">Lunglei</option><option value="Machilipatnam">Machilipatnam</option><option value="Madgaon">Madgaon</option><option value="Madhavaram">Madhavaram</option><option value="Madhipura">Madhipura</option><option value="Madhubani">Madhubani</option><option value="Madhyamgram">Madhyamgram</option><option value="Madras">Madras</option><option value="Madurai">Madurai</option><option value="Maduravoyal">Maduravoyal</option><option value="Mahadevapura">Mahadevapura</option><option value="Mahbubnagar">Mahbubnagar</option><option value="Maheshtala">Maheshtala</option><option value="Mahoba">Mahoba</option><option value="Mahuva">Mahuva</option><option value="Mainpuri">Mainpuri</option><option value="Maisuru">Maisuru</option><option value="Makrana">Makrana</option><option value="Malappuram">Malappuram</option><option value="Malaut">Malaut</option><option value="Malegaon">Malegaon</option><option value="Maler Kotla">Maler Kotla</option><option value="Malkajgiri">Malkajgiri</option><option value="Malkapur">Malkapur</option><option value="Mancheral">Mancheral</option><option value="Mandamarri">Mandamarri</option><option value="Mandidip">Mandidip</option><option value="Mandoli">Mandoli</option><option value="Mandsaur">Mandsaur</option><option value="Mandya">Mandya</option><option value="Mangalagiri">Mangalagiri</option><option value="Mangaluru">Mangaluru</option><option value="Mango">Mango</option><option value="Mangrol">Mangrol</option><option value="Manjeri">Manjeri</option><option value="Manmad">Manmad</option><option value="Mannargudi">Mannargudi</option><option value="Mansa">Mansa</option><option value="Markapur">Markapur</option><option value="Masaurhi">Masaurhi</option><option value="Mathura">Mathura</option><option value="Mau">Mau</option><option value="Mau">Mau</option><option value="Mauranipur">Mauranipur</option><option value="Mawana">Mawana</option><option value="Mayiladuthurai">Mayiladuthurai</option><option value="Memari">Memari</option><option value="Mettupalayam">Mettupalayam</option><option value="Mettur">Mettur</option><option value="Midnapur">Midnapur</option><option value="Mira Bhayandar">Mira Bhayandar</option><option value="Mirat">Mirat</option><option value="Mirat Cantonment">Mirat Cantonment</option><option value="Miryalaguda">Miryalaguda</option><option value="Mirzapur">Mirzapur</option><option value="Mithe Pur">Mithe Pur</option><option value="Modasa">Modasa</option><option value="Modinagar">Modinagar</option><option value="Moga">Moga</option><option value="Mohali">Mohali</option><option value="Mokama">Mokama</option><option value="Molarband">Molarband</option><option value="Moradabad">Moradabad</option><option value="Morena">Morena</option><option value="Mormugao">Mormugao</option><option value="Morvi">Morvi</option><option value="Motihari">Motihari</option><option value="Mubarakpur">Mubarakpur</option><option value="Mughal Sarai">Mughal Sarai</option><option value="Mumbai">Mumbai</option><option value="Mundka">Mundka</option><option value="Munger">Munger</option><option value="Muradnagar">Muradnagar</option><option value="Murwara">Murwara</option><option value="Mustafabad">Mustafabad</option><option value="Muzaffarnagar">Muzaffarnagar</option><option value="Muzaffarpur">Muzaffarpur</option><option value="Nadiad">Nadiad</option><option value="Nagaon">Nagaon</option><option value="Nagapattinam">Nagapattinam</option><option value="Nagaur">Nagaur</option><option value="Nagda">Nagda</option><option value="Nagercoil">Nagercoil</option><option value="Nagina">Nagina</option><option value="Nagpur">Nagpur</option><option value="Naihati">Naihati</option><option value="Najibabad">Najibabad</option><option value="Nalasopara">Nalasopara</option><option value="Nalgonda">Nalgonda</option><option value="Namakkal">Namakkal</option><option value="Nanded">Nanded</option><option value="Nandurbar">Nandurbar</option><option value="Nandyal">Nandyal</option><option value="Nangloi Jat">Nangloi Jat</option><option value="Narasapur">Narasapur</option><option value="Narasaraopet">Narasaraopet</option><option value="Narnaul">Narnaul</option><option value="Narwana">Narwana</option><option value="Nashik">Nashik</option><option value="Navadwip">Navadwip</option><option value="Navagam Ghed">Navagam Ghed</option><option value="Navghar">Navghar</option><option value="Navi Mumbai">Navi Mumbai</option><option value="Navi Mumbai">Navi Mumbai</option><option value="Navsari">Navsari</option><option value="Nawabganj">Nawabganj</option><option value="Nawada">Nawada</option><option value="Nawalgarh">Nawalgarh</option><option value="Nedumangad">Nedumangad</option><option value="Nellur">Nellur</option><option value="Nerkunram">Nerkunram</option><option value="Neyveli">Neyveli</option><option value="Neyyattinkara">Neyyattinkara</option><option value="Ni Barakpur">Ni Barakpur</option><option value="Ni Dilli">Ni Dilli</option><option value="Nimach">Nimach</option><option value="Nimbahera">Nimbahera</option><option value="Nipani">Nipani</option><option value="Nirmal">Nirmal</option><option value="Nizamabad">Nizamabad</option><option value="Noida">Noida</option><option value="Nokha">Nokha</option><option value="North Barakpur">North Barakpur</option><option value="North Dum Dum">North Dum Dum</option><option value="Nuzvid">Nuzvid</option><option value="Obra">Obra</option><option value="Old Maldah">Old Maldah</option><option value="Ongole">Ongole</option><option value="Orai">Orai</option><option value="Osmanabad">Osmanabad</option><option value="Ozhukarai">Ozhukarai</option><option value="Palakkad">Palakkad</option><option value="Palakollu">Palakollu</option><option value="Palasa">Palasa</option><option value="Palghar">Palghar</option><option value="Pali">Pali</option><option value="Palitana">Palitana</option><option value="Pallavaram">Pallavaram</option><option value="Pallichal">Pallichal</option><option value="Palwal">Palwal</option><option value="Palwancha">Palwancha</option><option value="Pammal">Pammal</option><option value="Panaji">Panaji</option><option value="Panchkula">Panchkula</option><option value="Pandharpur">Pandharpur</option><option value="Panihati">Panihati</option><option value="Panipat">Panipat</option><option value="Pannuratti">Pannuratti</option><option value="Paradwip">Paradwip</option><option value="Paramakkudi">Paramakkudi</option><option value="Parbhani">Parbhani</option><option value="Patan">Patan</option><option value="Patancheru">Patancheru</option><option value="Pathankot">Pathankot</option><option value="Patiala">Patiala</option><option value="Patna">Patna</option><option value="Pattanagere">Pattanagere</option><option value="Pattukkottai">Pattukkottai</option><option value="Payyannur">Payyannur</option><option value="Phagwara">Phagwara</option><option value="Phaltan">Phaltan</option><option value="Phulia">Phulia</option><option value="Phulwari">Phulwari</option><option value="Phusro">Phusro</option><option value="Piduguralla">Piduguralla</option><option value="Pilibhit">Pilibhit</option><option value="Pilkhuwa">Pilkhuwa</option><option value="Pimpri">Pimpri</option><option value="Pithampur">Pithampur</option><option value="Pithoragarh">Pithoragarh</option><option value="Pollachi">Pollachi</option><option value="Pondicherry">Pondicherry</option><option value="Ponnani">Ponnani</option><option value="Ponnur">Ponnur</option><option value="Porbandar">Porbandar</option><option value="Port Blair">Port Blair</option><option value="Proddatur">Proddatur</option><option value="Pudukkottai">Pudukkottai</option><option value="Pujali">Pujali</option><option value="Pul Pehlad">Pul Pehlad</option><option value="Puliyankudi">Puliyankudi</option><option value="Puna">Puna</option><option value="Punamalli">Punamalli</option><option value="Pune">Pune</option><option value="Pune Cantonment">Pune Cantonment</option><option value="Puri">Puri</option><option value="Purnia">Purnia</option><option value="Puruliya">Puruliya</option><option value="Pusad">Pusad</option><option value="Puth Kalan">Puth Kalan</option><option value="Puttur">Puttur</option><option value="Qutubullapur">Qutubullapur</option><option value="Rabkavi">Rabkavi</option><option value="Rae Bareli">Rae Bareli</option><option value="Raghogarh">Raghogarh</option><option value="Raichur">Raichur</option><option value="Raiganj">Raiganj</option><option value="Raigarh">Raigarh</option><option value="Raipur">Raipur</option><option value="Rajamahendri">Rajamahendri</option><option value="Rajampet">Rajampet</option><option value="Rajapalaiyam">Rajapalaiyam</option><option value="Rajendranagar">Rajendranagar</option><option value="Rajkot">Rajkot</option><option value="Rajnandgaon">Rajnandgaon</option><option value="Rajpur">Rajpur</option><option value="Rajpura">Rajpura</option><option value="Rajsamand">Rajsamand</option><option value="Ramachandrapuram">Ramachandrapuram</option><option value="Ramagundam">Ramagundam</option><option value="Ramanagaram">Ramanagaram</option><option value="Ramanathapuram">Ramanathapuram</option><option value="Ramgarh">Ramgarh</option><option value="Ramgarh Nagla Kothi">Ramgarh Nagla Kothi</option><option value="Ramod">Ramod</option><option value="Rampur">Rampur</option><option value="Rampur Hat">Rampur Hat</option><option value="Ranaghat">Ranaghat</option><option value="Ranchi">Ranchi</option><option value="Ranibennur">Ranibennur</option><option value="Raniganj">Raniganj</option><option value="Ranip">Ranip</option><option value="Ratangarh">Ratangarh</option><option value="Rath">Rath</option><option value="Ratlam">Ratlam</option><option value="Ratnagiri">Ratnagiri</option><option value="Raurkela">Raurkela</option><option value="Raurkela Industrial Township">Raurkela Industrial Township</option><option value="Raxaul">Raxaul</option><option value="Rayachoti">Rayachoti</option><option value="Rayadrug">Rayadrug</option><option value="Rayagada">Rayagada</option><option value="Renukut">Renukut</option><option value="Rewa">Rewa</option><option value="Rewari">Rewari</option><option value="Rishikesh">Rishikesh</option><option value="Rishra">Rishra</option><option value="Robertsonpet">Robertsonpet</option><option value="Rohtak">Rohtak</option><option value="Roshan Pura">Roshan Pura</option><option value="Rudrapur">Rudrapur</option><option value="Rupnagar">Rupnagar</option><option value="Rurki">Rurki</option><option value="Sadat Pur Gujran">Sadat Pur Gujran</option><option value="Sagar">Sagar</option><option value="Sagar">Sagar</option><option value="Saharanpur">Saharanpur</option><option value="Saharsa">Saharsa</option><option value="Sahaswan">Sahaswan</option><option value="Sahibganj">Sahibganj</option><option value="Salem">Salem</option><option value="Samalkot">Samalkot</option><option value="Samana">Samana</option><option value="Samastipur">Samastipur</option><option value="Sambalpur">Sambalpur</option><option value="Sambhal">Sambhal</option><option value="Sandila">Sandila</option><option value="Sangareddi">Sangareddi</option><option value="SangliMiraj">SangliMiraj</option><option value="Sangrur">Sangrur</option><option value="Sankarankoil">Sankarankoil</option><option value="Sardarshahr">Sardarshahr</option><option value="Sarni">Sarni</option><option value="Sasaram">Sasaram</option><option value="Satara">Satara</option><option value="Satna">Satna</option><option value="Sattenapalle">Sattenapalle</option><option value="Saunda">Saunda</option><option value="Sawai Madhopur">Sawai Madhopur</option><option value="Sehore">Sehore</option><option value="Sendhwa">Sendhwa</option><option value="Seoni">Seoni</option><option value="Serilungampalle">Serilungampalle</option><option value="Shahabad">Shahabad</option><option value="Shahabad">Shahabad</option><option value="Shahada">Shahada</option><option value="Shahdol">Shahdol</option><option value="Shahjahanpur">Shahjahanpur</option><option value="Shahpur">Shahpur</option><option value="Shajapur">Shajapur</option><option value="Shamli">Shamli</option><option value="Shantipur">Shantipur</option><option value="Shegaon">Shegaon</option><option value="Sheopur">Sheopur</option><option value="Sherkot">Sherkot</option><option value="Shikohabad">Shikohabad</option><option value="Shiliguri">Shiliguri</option><option value="Shillong">Shillong</option><option value="Shimla">Shimla</option><option value="Shimoga">Shimoga</option><option value="Shirpur">Shirpur</option><option value="Shivapuri">Shivapuri</option><option value="Sholapur">Sholapur</option><option value="Shorapur">Shorapur</option><option value="Shrirampur">Shrirampur</option><option value="Shrirampur">Shrirampur</option><option value="Sibsagar">Sibsagar</option><option value="Siddhapur">Siddhapur</option><option value="Siddipet">Siddipet</option><option value="Sidhi">Sidhi</option><option value="Sidlaghatta">Sidlaghatta</option><option value="Sihor">Sihor</option><option value="Sikandarabad">Sikandarabad</option><option value="Sikandarabad">Sikandarabad</option><option value="Sikar">Sikar</option><option value="Silchar">Silchar</option><option value="Sillod">Sillod</option><option value="Sindari">Sindari</option><option value="Singrauli">Singrauli</option><option value="Sira">Sira</option><option value="Sirhind">Sirhind</option><option value="Sirsa">Sirsa</option><option value="Sirsi">Sirsi</option><option value="Sirsilla">Sirsilla</option><option value="Sitamarhi">Sitamarhi</option><option value="Sitapur">Sitapur</option><option value="Siuri">Siuri</option><option value="Sivakasi">Sivakasi</option><option value="Siwan">Siwan</option><option value="Sonipat">Sonipat</option><option value="Sopur">Sopur</option><option value="South Dum Dum">South Dum Dum</option><option value="Srikakulam">Srikakulam</option><option value="Srikalahasti">Srikalahasti</option><option value="Srinagar">Srinagar</option><option value="Srivilliputtur">Srivilliputtur</option><option value="Sujangarh">Sujangarh</option><option value="Sukhmalpur Nizamabad">Sukhmalpur Nizamabad</option><option value="Sultanpur">Sultanpur</option><option value="Sultanpur Majra">Sultanpur Majra</option><option value="Sunabeda">Sunabeda</option><option value="Sunam">Sunam</option><option value="Supaul">Supaul</option><option value="Surat">Surat</option><option value="Suratgarh">Suratgarh</option><option value="Surendranagar">Surendranagar</option><option value="Suriapet">Suriapet</option><option value="Tadepalle">Tadepalle</option><option value="Tadepallegudem">Tadepallegudem</option><option value="Tadpatri">Tadpatri</option><option value="Tajpul">Tajpul</option><option value="Talipparamba">Talipparamba</option><option value="Tambaram">Tambaram</option><option value="Tanda">Tanda</option><option value="Tandur">Tandur</option><option value="Tanuku">Tanuku</option><option value="Tarn Taran">Tarn Taran</option><option value="Tenali">Tenali</option><option value="Tenkasi">Tenkasi</option><option value="Tezpur">Tezpur</option><option value="Thalassery">Thalassery</option><option value="Thaltej">Thaltej</option><option value="Thana">Thana</option><option value="Thanesar">Thanesar</option><option value="Thanjavur">Thanjavur</option><option value="Theni Allinagaram">Theni Allinagaram</option><option value="Thiruthangal">Thiruthangal</option><option value="Thiruvananthapuram">Thiruvananthapuram</option><option value="Thiruvarur">Thiruvarur</option><option value="Thrippunithura">Thrippunithura</option><option value="Thrissur">Thrissur</option><option value="Thuthukkudi">Thuthukkudi</option><option value="Tigri">Tigri</option><option value="Tikamgarh">Tikamgarh</option><option value="Tilhar">Tilhar</option><option value="Tindivanam">Tindivanam</option><option value="Tinsukia">Tinsukia</option><option value="Tiptur">Tiptur</option><option value="Tiruchchirappalli">Tiruchchirappalli</option><option value="Tiruchengode">Tiruchengode</option><option value="Tirunelveli">Tirunelveli</option><option value="Tirupathur">Tirupathur</option><option value="Tirupati">Tirupati</option><option value="Tiruppur">Tiruppur</option><option value="Tirur">Tirur</option><option value="Tiruvalla">Tiruvalla</option><option value="Tiruvannamalai">Tiruvannamalai</option><option value="Tiruvottiyur">Tiruvottiyur</option><option value="Titagarh">Titagarh</option><option value="Tohana">Tohana</option><option value="Tonk">Tonk</option><option value="Tumkur">Tumkur</option><option value="Tundla">Tundla</option><option value="Tuni">Tuni</option><option value="Tura">Tura</option><option value="Udagamandalam">Udagamandalam</option><option value="Udaipur">Udaipur</option><option value="Udgir">Udgir</option><option value="Udhampur">Udhampur</option><option value="Udumalaipettai">Udumalaipettai</option><option value="Udupi">Udupi</option><option value="Ujhani">Ujhani</option><option value="Ujjain">Ujjain</option><option value="Ulhasnagar">Ulhasnagar</option><option value="Ullal">Ullal</option><option value="Ulubaria">Ulubaria</option><option value="Una">Una</option><option value="Unjha">Unjha</option><option value="Unnao">Unnao</option><option value="Upleta">Upleta</option><option value="Uppal Kalan">Uppal Kalan</option><option value="Uran Islampur">Uran Islampur</option><option value="UttarparaKotrung">UttarparaKotrung</option><option value="Vadakara">Vadakara</option><option value="Vadodara">Vadodara</option><option value="Valparai">Valparai</option><option value="Valsad">Valsad</option><option value="Vaniyambadi">Vaniyambadi</option><option value="Vapi">Vapi</option><option value="Varanasi">Varanasi</option><option value="Vasai">Vasai</option><option value="Vastral">Vastral</option><option value="Vejalpur">Vejalpur</option><option value="Velampalaiyam">Velampalaiyam</option><option value="Velluru">Velluru</option><option value="Veraval">Veraval</option><option value="Vidisha">Vidisha</option><option value="Vijalpor">Vijalpor</option><option value="Vijayawada">Vijayawada</option><option value="Viluppuram">Viluppuram</option><option value="Vinukonda">Vinukonda</option><option value="Virappanchatram">Virappanchatram</option><option value="Virar">Virar</option><option value="Virudhachalam">Virudhachalam</option><option value="Virudunagar">Virudunagar</option><option value="Visakhapatnam">Visakhapatnam</option><option value="Visnagar">Visnagar</option><option value="Vizianagaram">Vizianagaram</option><option value="Vrindavan">Vrindavan</option><option value="Vuyyuru">Vuyyuru</option><option value="Wadhwan">Wadhwan</option><option value="Wadi">Wadi</option><option value="Wani">Wani</option><option value="Wanparti">Wanparti</option><option value="Warangal">Warangal</option><option value="Wardha">Wardha</option><option value="Warud">Warud</option><option value="Washim">Washim</option><option value="Wokha">Wokha</option><option value="Yadgir">Yadgir</option><option value="Yamunanagar">Yamunanagar</option><option value="Yavatmal">Yavatmal</option><option value="Yelahanka">Yelahanka</option><option value="Yemmiganur">Yemmiganur</option><option value="Ziauddin Pur">Ziauddin Pur</option> 
                            </select>
                            <!-- <input list="current_location" id="cl" name="current_location" class="form-control" placeholder="Current Location" required /> -->
                           <!--  <datalist id="current_location">
                                
                            </datalist> -->
                            </span>
                        </span>

                        <span class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                            <select id="c2" name="preferred_location" class="form-control" rrequired>
                            <!-- <input list="preferred_location" id="c2" name="preferred_location" class="form-control" placeholder="Preferred Location" required /> -->
                            <option disabled selected>Preferred Location</option>
                                <option value="Abohar">Abohar</option><option value="Achalpur">Achalpur</option><option value="Adilabad">Adilabad</option><option value="Adityapur">Adityapur</option><option value="Adoni">Adoni</option><option value="Agartala">Agartala</option><option value="Agra">Agra</option><option value="Ahmadabad">Ahmadabad</option><option value="Ahmadnagar">Ahmadnagar</option><option value="Aizawl">Aizawl</option><option value="Ajmer">Ajmer</option><option value="Akola">Akola</option><option value="Akot">Akot</option><option value="Alandur">Alandur</option><option value="Alappuzha">Alappuzha</option><option value="Aligarh">Aligarh</option><option value="Alipur Duar">Alipur Duar</option><option value="Allahabad">Allahabad</option><option value="Alwal">Alwal</option><option value="Alwar">Alwar</option><option value="Amalner">Amalner</option><option value="Ambajogai">Ambajogai</option><option value="Ambala">Ambala</option><option value="Ambala Cantonment">Ambala Cantonment</option><option value="Ambala Sadar">Ambala Sadar</option><option value="Ambattur">Ambattur</option><option value="Ambikapur">Ambikapur</option><option value="Ambur">Ambur</option><option value="Amravati">Amravati</option><option value="Amreli">Amreli</option><option value="Amritsar">Amritsar</option><option value="Amroha">Amroha</option><option value="Anakapalle">Anakapalle</option><option value="Anand">Anand</option><option value="Anantapur">Anantapur</option><option value="Anantnag">Anantnag</option><option value="Anjangaon">Anjangaon</option><option value="Anjar">Anjar</option><option value="Aonla">Aonla</option><option value="Arakonam">Arakonam</option><option value="Arambagh">Arambagh</option><option value="Arani">Arani</option><option value="Araria">Araria</option><option value="Arrah">Arrah</option><option value="Aruppukkottai">Aruppukkottai</option><option value="Asansol">Asansol</option><option value="Ashoknagar">Ashoknagar</option><option value="Ashoknagar Kalyangarh">Ashoknagar Kalyangarh</option><option value="Attur">Attur</option><option value="Auraiya">Auraiya</option><option value="Aurangabad">Aurangabad</option><option value="Aurangabad">Aurangabad</option><option value="Avadi">Avadi</option><option value="Avaniapuram">Avaniapuram</option><option value="Ayodhya">Ayodhya</option><option value="Azamgarh">Azamgarh</option><option value="Badharghat">Badharghat</option><option value="Badlapur">Badlapur</option><option value="Bagaha">Bagaha</option><option value="Bagalkot">Bagalkot</option><option value="Bagbahra">Bagbahra</option><option value="Bahadurgarh">Bahadurgarh</option><option value="Baharampur">Baharampur</option><option value="Baheri">Baheri</option><option value="Bahraich">Bahraich</option><option value="Baidyabati">Baidyabati</option><option value="Baj Baj">Baj Baj</option><option value="Balaghat">Balaghat</option><option value="Balangir">Balangir</option><option value="Baleshwar">Baleshwar</option><option value="Ballarpur">Ballarpur</option><option value="Ballia">Ballia</option><option value="Bally">Bally</option><option value="Bally Cantonment">Bally Cantonment</option><option value="Balotra">Balotra</option><option value="Balrampur">Balrampur</option><option value="Balurghat">Balurghat</option><option value="Banda">Banda</option><option value="Bangalore">Bangalore</option><option value="Bangaon">Bangaon</option><option value="Bankra">Bankra</option><option value="Bankura">Bankura</option><option value="Bansbaria">Bansbaria</option><option value="Banswara">Banswara</option><option value="Bapatla">Bapatla</option><option value="Baramati">Baramati</option><option value="Baramula">Baramula</option><option value="Baran">Baran</option><option value="Baranagar">Baranagar</option><option value="Baraut">Baraut</option><option value="Barbil">Barbil</option><option value="Barddhaman">Barddhaman</option><option value="Bardoli">Bardoli</option><option value="Bareli">Bareli</option><option value="Bargarh">Bargarh</option><option value="Bari">Bari</option><option value="Bari Brahmana">Bari Brahmana</option><option value="Baripada">Baripada</option><option value="Barmer">Barmer</option><option value="Barnala">Barnala</option><option value="Barpeta">Barpeta</option><option value="Barsi">Barsi</option><option value="Basavakalyan">Basavakalyan</option><option value="Basirhat">Basirhat</option><option value="Basmat">Basmat</option><option value="Basoda">Basoda</option><option value="Basti">Basti</option><option value="Batala">Batala</option><option value="Bathinda">Bathinda</option><option value="Beawar">Beawar</option><option value="Begusarai">Begusarai</option><option value="Behta Hajipur">Behta Hajipur</option><option value="Bela">Bela</option><option value="Belampalli">Belampalli</option><option value="Belgaum">Belgaum</option><option value="Bellary">Bellary</option><option value="Bettiah">Bettiah</option><option value="Betul">Betul</option><option value="Beypur">Beypur</option><option value="Bhabua">Bhabua</option><option value="Bhadohi">Bhadohi</option><option value="Bhadrak">Bhadrak</option><option value="Bhadravati">Bhadravati</option><option value="Bhadravati">Bhadravati</option><option value="Bhadreswar">Bhadreswar</option><option value="Bhagalpur">Bhagalpur</option><option value="Bhalswa Jahangirpur">Bhalswa Jahangirpur</option><option value="Bhandara">Bhandara</option><option value="Bharatpur">Bharatpur</option><option value="Bharuch">Bharuch</option><option value="Bhatpara">Bhatpara</option><option value="Bhavnagar">Bhavnagar</option><option value="Bhawanipatna">Bhawanipatna</option><option value="Bhilai">Bhilai</option><option value="Bhilwara">Bhilwara</option><option value="Bhimavaram">Bhimavaram</option><option value="Bhind">Bhind</option><option value="Bhiwadi">Bhiwadi</option><option value="Bhiwandi">Bhiwandi</option><option value="Bhiwani">Bhiwani</option><option value="Bhongir">Bhongir</option><option value="Bhopal">Bhopal</option><option value="Bhubaneswar">Bhubaneswar</option><option value="Bhuj">Bhuj</option><option value="Bhuli">Bhuli</option><option value="Bhusawal">Bhusawal</option><option value="Bid">Bid</option><option value="Bidar">Bidar</option><option value="Bidhannagar">Bidhannagar</option><option value="Bihar">Bihar</option><option value="Bijapur">Bijapur</option><option value="Bijnor">Bijnor</option><option value="Bikaner">Bikaner</option><option value="Bilaspur">Bilaspur</option><option value="BinaEtawa">BinaEtawa</option><option value="Binnaguri">Binnaguri</option><option value="Bisalpur">Bisalpur</option><option value="Bishnupur">Bishnupur</option><option value="Biswan">Biswan</option><option value="Bobbili">Bobbili</option><option value="Bodhan">Bodhan</option><option value="Bodinayakkanur">Bodinayakkanur</option><option value="Bokaro">Bokaro</option><option value="Bolpur">Bolpur</option><option value="Bommanahalli">Bommanahalli</option><option value="Bongaigaon">Bongaigaon</option><option value="Borsad">Borsad</option><option value="Botad">Botad</option><option value="Brahmapur">Brahmapur</option><option value="Brajrajnagar">Brajrajnagar</option><option value="Budaun">Budaun</option><option value="Bulandshahr">Bulandshahr</option><option value="Buldana">Buldana</option><option value="Bundi">Bundi</option><option value="Burari">Burari</option><option value="Burhanpur">Burhanpur</option><option value="Buxar">Buxar</option><option value="Byatarayanapura">Byatarayanapura</option><option value="Calcutta">Calcutta</option><option value="Chaibasa">Chaibasa</option><option value="Chakdaha">Chakdaha</option><option value="Chalisgaon">Chalisgaon</option><option value="Challakere">Challakere</option><option value="Champdani">Champdani</option><option value="Chamrajnagar">Chamrajnagar</option><option value="Chandannagar">Chandannagar</option><option value="Chandausi">Chandausi</option><option value="Chandigarh">Chandigarh</option><option value="Chandkheda">Chandkheda</option><option value="Chandlodiya">Chandlodiya</option><option value="Chandpur">Chandpur</option><option value="Chandrapur">Chandrapur</option><option value="Channapatna">Channapatna</option><option value="Charkhi Dadri">Charkhi Dadri</option><option value="Charoda">Charoda</option><option value="Chas">Chas</option><option value="Chengalpattu">Chengalpattu</option><option value="Cheruvannur">Cheruvannur</option><option value="Chhapra">Chhapra</option><option value="Chhatarpur">Chhatarpur</option><option value="Chhibramau">Chhibramau</option><option value="Chhindwara">Chhindwara</option><option value="Chik Ballapur">Chik Ballapur</option><option value="Chikhli">Chikhli</option><option value="Chikmagalur">Chikmagalur</option><option value="Chilakalurupet">Chilakalurupet</option><option value="Chilla Saroda Bangar">Chilla Saroda Bangar</option><option value="Chinna Chawk">Chinna Chawk</option><option value="Chintamani">Chintamani</option><option value="Chiplun">Chiplun</option><option value="Chirala">Chirala</option><option value="Chirmiri">Chirmiri</option><option value="Chitradurga">Chitradurga</option><option value="Chitrakut Dham">Chitrakut Dham</option><option value="Chittaurgarh">Chittaurgarh</option><option value="Chittur">Chittur</option><option value="Chomun">Chomun</option><option value="Chopda">Chopda</option><option value="Churu">Churu</option><option value="Contai">Contai</option><option value="Cuddapah">Cuddapah</option><option value="Dabgram">Dabgram</option><option value="Dabhoi">Dabhoi</option><option value="Dabra">Dabra</option><option value="Dabwali">Dabwali</option><option value="Dadri">Dadri</option><option value="Dahanu">Dahanu</option><option value="Dahod">Dahod</option><option value="Dallo Pura">Dallo Pura</option><option value="Daltenganj">Daltenganj</option><option value="Damoh">Damoh</option><option value="Daosa">Daosa</option><option value="Darbhanga">Darbhanga</option><option value="Darjiling">Darjiling</option><option value="Dasarahalli">Dasarahalli</option><option value="Datia">Datia</option><option value="Davanagere">Davanagere</option><option value="Dehra Dun">Dehra Dun</option><option value="Dehra Dun Cantonment">Dehra Dun Cantonment</option><option value="Dehri">Dehri</option><option value="Delhi">Delhi</option><option value="Deoband">Deoband</option><option value="Deolali">Deolali</option><option value="Deoli">Deoli</option><option value="Deoria">Deoria</option><option value="Devghar">Devghar</option><option value="Dewas">Dewas</option><option value="Dhamtari">Dhamtari</option><option value="Dhanbad">Dhanbad</option><option value="Dhar">Dhar</option><option value="Dharapuram">Dharapuram</option><option value="Dharmapuri">Dharmapuri</option><option value="Dharmavaram">Dharmavaram</option><option value="Dhaulpur">Dhaulpur</option><option value="Dhenkanal">Dhenkanal</option><option value="Dholka">Dholka</option><option value="Dhone">Dhone</option><option value="Dhoraji">Dhoraji</option><option value="Dhrangadhra">Dhrangadhra</option><option value="Dhuburi">Dhuburi</option><option value="Dhule">Dhule</option><option value="Dhulian">Dhulian</option><option value="Dhuri">Dhuri</option><option value="Dibrugarh">Dibrugarh</option><option value="Didwana">Didwana</option><option value="Digdoh">Digdoh</option><option value="DighaMainpura">DighaMainpura</option><option value="Diglur">Diglur</option><option value="Dilli Cantonment">Dilli Cantonment</option><option value="Dimapur">Dimapur</option><option value="Dinapur">Dinapur</option><option value="Dindigul">Dindigul</option><option value="Dinhata">Dinhata</option><option value="Diphu">Diphu</option><option value="Disa">Disa</option><option value="Dod Ballapur">Dod Ballapur</option><option value="Dum Dum">Dum Dum</option><option value="Dumraon">Dumraon</option><option value="Durg">Durg</option><option value="Durgapur">Durgapur</option><option value="Edakkara">Edakkara</option><option value="Edathala">Edathala</option><option value="Eluru">Eluru</option><option value="Erode">Erode</option><option value="Etah">Etah</option><option value="Etawah">Etawah</option><option value="Faizabad">Faizabad</option><option value="Faridabad">Faridabad</option><option value="Faridkot">Faridkot</option><option value="Faridpur">Faridpur</option><option value="Farrukhabad">Farrukhabad</option><option value="Fatehpur">Fatehpur</option><option value="Fatehpur">Fatehpur</option><option value="Fazilka">Fazilka</option><option value="Firozabad">Firozabad</option><option value="Firozpur">Firozpur</option><option value="Firozpur Cantonment">Firozpur Cantonment</option><option value="Gadag">Gadag</option><option value="Gadchiroli">Gadchiroli</option><option value="Gaddiannaram">Gaddiannaram</option><option value="Gadwal">Gadwal</option><option value="Gajraula">Gajraula</option><option value="Gajuwaka">Gajuwaka</option><option value="Gandhidham">Gandhidham</option><option value="Gandhinagar">Gandhinagar</option><option value="Ganga Ghat">Ganga Ghat</option><option value="Ganganagar">Ganganagar</option><option value="Gangapur">Gangapur</option><option value="Gangarampur">Gangarampur</option><option value="Gangawati">Gangawati</option><option value="Gangoh">Gangoh</option><option value="Garulia">Garulia</option><option value="Gaya">Gaya</option><option value="Gayespur">Gayespur</option><option value="Gharoli">Gharoli</option><option value="Ghatal">Ghatal</option><option value="Ghatlodiya">Ghatlodiya</option><option value="Ghaziabad">Ghaziabad</option><option value="Ghazipur">Ghazipur</option><option value="Gobindgarh">Gobindgarh</option><option value="Godhra">Godhra</option><option value="Gohad">Gohad</option><option value="Gohana">Gohana</option><option value="Gokak">Gokak</option><option value="Gokalpur">Gokalpur</option><option value="Gola Gokarannath">Gola Gokarannath</option><option value="Gola Range">Gola Range</option><option value="Gonda">Gonda</option><option value="Gondal">Gondal</option><option value="Gondiya">Gondiya</option><option value="Gopalganj">Gopalganj</option><option value="Gopalpur">Gopalpur</option><option value="Gopichettipalaiyam">Gopichettipalaiyam</option><option value="Gorakhpur">Gorakhpur</option><option value="Goura">Goura</option><option value="Gudalur">Gudalur</option><option value="Gudivada">Gudivada</option><option value="Gudiyattam">Gudiyattam</option><option value="Gudur">Gudur</option><option value="Gulbarga">Gulbarga</option><option value="Guna">Guna</option><option value="Guntakal">Guntakal</option><option value="Guntur">Guntur</option><option value="Gurdaspur">Gurdaspur</option><option value="Guwahati">Guwahati</option><option value="Gwalior">Gwalior</option><option value="Habra">Habra</option><option value="Hajipur">Hajipur</option><option value="Haldwani">Haldwani</option><option value="Halisahar">Halisahar</option><option value="Hanumangarh">Hanumangarh</option><option value="Haora">Haora</option><option value="Hapur">Hapur</option><option value="Harda">Harda</option><option value="Hardoi">Hardoi</option><option value="Haridwar">Haridwar</option><option value="Harihar">Harihar</option><option value="Hasanpur">Hasanpur</option><option value="Hassan">Hassan</option><option value="Hastsal">Hastsal</option><option value="Hathras">Hathras</option><option value="Haveri">Haveri</option><option value="Hazaribag">Hazaribag</option><option value="Himatnagar">Himatnagar</option><option value="Hindaun">Hindaun</option><option value="Hindupur">Hindupur</option><option value="Hinganghat">Hinganghat</option><option value="Hingoli">Hingoli</option><option value="Hiriyur">Hiriyur</option><option value="Hisar">Hisar</option><option value="Hosakote">Hosakote</option><option value="Hoshangabad">Hoshangabad</option><option value="Hoshiarpur">Hoshiarpur</option><option value="Hospet">Hospet</option><option value="Hosur">Hosur</option><option value="Hubli">Hubli</option><option value="HugliChunchura">HugliChunchura</option><option value="Hyderabad">Hyderabad</option><option value="Ichalkaranji">Ichalkaranji</option><option value="Idappadi">Idappadi</option><option value="Ilkal">Ilkal</option><option value="Imphal">Imphal</option><option value="Indore">Indore</option><option value="Ingraj Bazar">Ingraj Bazar</option><option value="Islampur">Islampur</option><option value="Itanagar">Itanagar</option><option value="Itarsi">Itarsi</option><option value="Jabalpur">Jabalpur</option><option value="Jabalpur Cantonment">Jabalpur Cantonment</option><option value="Jaffrabad">Jaffrabad</option><option value="Jagadhri">Jagadhri</option><option value="Jagdalpur">Jagdalpur</option><option value="Jagraon">Jagraon</option><option value="Jagtial">Jagtial</option><option value="Jahanabad">Jahanabad</option><option value="Jahangirabad">Jahangirabad</option><option value="Jaipur">Jaipur</option><option value="Jaisalmer">Jaisalmer</option><option value="Jalandhar">Jalandhar</option><option value="Jalaun">Jalaun</option><option value="Jalgaon">Jalgaon</option><option value="Jalna">Jalna</option><option value="Jalor">Jalor</option><option value="Jalpaiguri">Jalpaiguri</option><option value="Jamalpur">Jamalpur</option><option value="Jamkhandi">Jamkhandi</option><option value="Jammu">Jammu</option><option value="Jamnagar">Jamnagar</option><option value="Jamnagar">Jamnagar</option><option value="Jamshedpur">Jamshedpur</option><option value="Jamui">Jamui</option><option value="Jamuria">Jamuria</option><option value="Jangipur">Jangipur</option><option value="Jaora">Jaora</option><option value="Jaunpur">Jaunpur</option><option value="Jaypur">Jaypur</option><option value="Jetpur">Jetpur</option><option value="Jhalawar">Jhalawar</option><option value="Jhansi">Jhansi</option><option value="Jhargram">Jhargram</option><option value="Jharia">Jharia</option><option value="Jharsuguda">Jharsuguda</option><option value="Jhumri Tilaiya">Jhumri Tilaiya</option><option value="Jhunjhunun">Jhunjhunun</option><option value="Jind">Jind</option><option value="Jodhpur">Jodhpur</option><option value="Jorapokhar">Jorapokhar</option><option value="Jorhat">Jorhat</option><option value="Junagadh">Junagadh</option><option value="Kadayanallur">Kadayanallur</option><option value="Kadi">Kadi</option><option value="Kadiri">Kadiri</option><option value="Kagaznagar">Kagaznagar</option><option value="Kairana">Kairana</option><option value="Kaithal">Kaithal</option><option value="Kakinada">Kakinada</option><option value="Kalamassery">Kalamassery</option><option value="Kaliyaganj">Kaliyaganj</option><option value="Kallur">Kallur</option><option value="Kalna">Kalna</option><option value="Kalol">Kalol</option><option value="Kalyan">Kalyan</option><option value="Kalyani">Kalyani</option><option value="Kamareddi">Kamareddi</option><option value="Kamarhati">Kamarhati</option><option value="Kambam">Kambam</option><option value="Kamthi">Kamthi</option><option value="Kanakapura">Kanakapura</option><option value="Kanchipuram">Kanchipuram</option><option value="Kanchrapara">Kanchrapara</option><option value="Kandi">Kandi</option><option value="Kannan Devan Hills">Kannan Devan Hills</option><option value="Kannangad">Kannangad</option><option value="Kannauj">Kannauj</option><option value="Kannur">Kannur</option><option value="Kanpur">Kanpur</option><option value="Kanpur Cantonment">Kanpur Cantonment</option><option value="Kapra">Kapra</option><option value="Kapurthala">Kapurthala</option><option value="Karaikal">Karaikal</option><option value="Karanja">Karanja</option><option value="Karauli">Karauli</option><option value="Karawal Nagar">Karawal Nagar</option><option value="Karimganj">Karimganj</option><option value="Karimnagar">Karimnagar</option><option value="Karnal">Karnal</option><option value="Karnul">Karnul</option><option value="Karsiyang">Karsiyang</option><option value="Karur">Karur</option><option value="Karwar">Karwar</option><option value="Kasganj">Kasganj</option><option value="Kashipur">Kashipur</option><option value="Kataka">Kataka</option><option value="Kathua">Kathua</option><option value="Katihar">Katihar</option><option value="Katras">Katras</option><option value="Katwa">Katwa</option><option value="Kavali">Kavali</option><option value="Kavundampalaiyam">Kavundampalaiyam</option><option value="Kayankulam">Kayankulam</option><option value="Kendujhar">Kendujhar</option><option value="Keshod">Keshod</option><option value="Khadki">Khadki</option><option value="Khagaria">Khagaria</option><option value="Khagaul">Khagaul</option><option value="Khajuri Khas">Khajuri Khas</option><option value="Khambhat">Khambhat</option><option value="Khamgaon">Khamgaon</option><option value="Khammam">Khammam</option><option value="Khandwa">Khandwa</option><option value="Khanna">Khanna</option><option value="Kharagpur">Kharagpur</option><option value="Kharagpur Railway Settlement">Kharagpur Railway Settlement</option><option value="Khardaha">Khardaha</option><option value="Khargone">Khargone</option><option value="Kharia">Kharia</option><option value="Khatauli">Khatauli</option><option value="Khopoli">Khopoli</option><option value="Khora">Khora</option><option value="Khurja">Khurja</option><option value="Kirari Suleman Nagar">Kirari Suleman Nagar</option><option value="Kiratpur">Kiratpur</option><option value="Kishanganj">Kishanganj</option><option value="Kishangarh">Kishangarh</option><option value="Koch Bihar">Koch Bihar</option><option value="Kochi">Kochi</option><option value="Kodar">Kodar</option><option value="Kohima">Kohima</option><option value="Kolar">Kolar</option><option value="Kolhapur">Kolhapur</option><option value="Kollam">Kollam</option><option value="Kollegal">Kollegal</option><option value="Kondukur">Kondukur</option><option value="Konnagar">Konnagar</option><option value="Kopargaon">Kopargaon</option><option value="Koppal">Koppal</option><option value="Koratla">Koratla</option><option value="Korba">Korba</option><option value="Kosi Kalan">Kosi Kalan</option><option value="Kot Kapura">Kot Kapura</option><option value="Kota">Kota</option><option value="Kottagudem">Kottagudem</option><option value="Kottayam">Kottayam</option><option value="Kovilpatti">Kovilpatti</option><option value="Koyampattur">Koyampattur</option><option value="Koyilandi">Koyilandi</option><option value="Kozhikkod">Kozhikkod</option><option value="Krishnagiri">Krishnagiri</option><option value="Krishnanagar">Krishnanagar</option><option value="Krishnarajapura">Krishnarajapura</option><option value="Kuchaman">Kuchaman</option><option value="Kukatpalle">Kukatpalle</option><option value="Kulti">Kulti</option><option value="Kumarapalaiyam">Kumarapalaiyam</option><option value="Kumbakonam">Kumbakonam</option><option value="Kundla">Kundla</option><option value="Kuniyamuthur">Kuniyamuthur</option><option value="Kunnamkulam">Kunnamkulam</option><option value="Kurichi">Kurichi</option><option value="Ladnun">Ladnun</option><option value="Laharpur">Laharpur</option><option value="Lakhimpur">Lakhimpur</option><option value="Lakhimpur">Lakhimpur</option><option value="Lakhisarai">Lakhisarai</option><option value="Lakhnau">Lakhnau</option><option value="Lakhnau Cantonment">Lakhnau Cantonment</option><option value="Lalbahadur Nagar">Lalbahadur Nagar</option><option value="Lalitpur">Lalitpur</option><option value="Lanka">Lanka</option><option value="Latur">Latur</option><option value="Lohardaga">Lohardaga</option><option value="Lonavale">Lonavale</option><option value="Loni">Loni</option><option value="Ludhiana">Ludhiana</option><option value="Lunglei">Lunglei</option><option value="Machilipatnam">Machilipatnam</option><option value="Madgaon">Madgaon</option><option value="Madhavaram">Madhavaram</option><option value="Madhipura">Madhipura</option><option value="Madhubani">Madhubani</option><option value="Madhyamgram">Madhyamgram</option><option value="Madras">Madras</option><option value="Madurai">Madurai</option><option value="Maduravoyal">Maduravoyal</option><option value="Mahadevapura">Mahadevapura</option><option value="Mahbubnagar">Mahbubnagar</option><option value="Maheshtala">Maheshtala</option><option value="Mahoba">Mahoba</option><option value="Mahuva">Mahuva</option><option value="Mainpuri">Mainpuri</option><option value="Maisuru">Maisuru</option><option value="Makrana">Makrana</option><option value="Malappuram">Malappuram</option><option value="Malaut">Malaut</option><option value="Malegaon">Malegaon</option><option value="Maler Kotla">Maler Kotla</option><option value="Malkajgiri">Malkajgiri</option><option value="Malkapur">Malkapur</option><option value="Mancheral">Mancheral</option><option value="Mandamarri">Mandamarri</option><option value="Mandidip">Mandidip</option><option value="Mandoli">Mandoli</option><option value="Mandsaur">Mandsaur</option><option value="Mandya">Mandya</option><option value="Mangalagiri">Mangalagiri</option><option value="Mangaluru">Mangaluru</option><option value="Mango">Mango</option><option value="Mangrol">Mangrol</option><option value="Manjeri">Manjeri</option><option value="Manmad">Manmad</option><option value="Mannargudi">Mannargudi</option><option value="Mansa">Mansa</option><option value="Markapur">Markapur</option><option value="Masaurhi">Masaurhi</option><option value="Mathura">Mathura</option><option value="Mau">Mau</option><option value="Mau">Mau</option><option value="Mauranipur">Mauranipur</option><option value="Mawana">Mawana</option><option value="Mayiladuthurai">Mayiladuthurai</option><option value="Memari">Memari</option><option value="Mettupalayam">Mettupalayam</option><option value="Mettur">Mettur</option><option value="Midnapur">Midnapur</option><option value="Mira Bhayandar">Mira Bhayandar</option><option value="Mirat">Mirat</option><option value="Mirat Cantonment">Mirat Cantonment</option><option value="Miryalaguda">Miryalaguda</option><option value="Mirzapur">Mirzapur</option><option value="Mithe Pur">Mithe Pur</option><option value="Modasa">Modasa</option><option value="Modinagar">Modinagar</option><option value="Moga">Moga</option><option value="Mohali">Mohali</option><option value="Mokama">Mokama</option><option value="Molarband">Molarband</option><option value="Moradabad">Moradabad</option><option value="Morena">Morena</option><option value="Mormugao">Mormugao</option><option value="Morvi">Morvi</option><option value="Motihari">Motihari</option><option value="Mubarakpur">Mubarakpur</option><option value="Mughal Sarai">Mughal Sarai</option><option value="Mumbai">Mumbai</option><option value="Mundka">Mundka</option><option value="Munger">Munger</option><option value="Muradnagar">Muradnagar</option><option value="Murwara">Murwara</option><option value="Mustafabad">Mustafabad</option><option value="Muzaffarnagar">Muzaffarnagar</option><option value="Muzaffarpur">Muzaffarpur</option><option value="Nadiad">Nadiad</option><option value="Nagaon">Nagaon</option><option value="Nagapattinam">Nagapattinam</option><option value="Nagaur">Nagaur</option><option value="Nagda">Nagda</option><option value="Nagercoil">Nagercoil</option><option value="Nagina">Nagina</option><option value="Nagpur">Nagpur</option><option value="Naihati">Naihati</option><option value="Najibabad">Najibabad</option><option value="Nalasopara">Nalasopara</option><option value="Nalgonda">Nalgonda</option><option value="Namakkal">Namakkal</option><option value="Nanded">Nanded</option><option value="Nandurbar">Nandurbar</option><option value="Nandyal">Nandyal</option><option value="Nangloi Jat">Nangloi Jat</option><option value="Narasapur">Narasapur</option><option value="Narasaraopet">Narasaraopet</option><option value="Narnaul">Narnaul</option><option value="Narwana">Narwana</option><option value="Nashik">Nashik</option><option value="Navadwip">Navadwip</option><option value="Navagam Ghed">Navagam Ghed</option><option value="Navghar">Navghar</option><option value="Navi Mumbai">Navi Mumbai</option><option value="Navi Mumbai">Navi Mumbai</option><option value="Navsari">Navsari</option><option value="Nawabganj">Nawabganj</option><option value="Nawada">Nawada</option><option value="Nawalgarh">Nawalgarh</option><option value="Nedumangad">Nedumangad</option><option value="Nellur">Nellur</option><option value="Nerkunram">Nerkunram</option><option value="Neyveli">Neyveli</option><option value="Neyyattinkara">Neyyattinkara</option><option value="Ni Barakpur">Ni Barakpur</option><option value="Ni Dilli">Ni Dilli</option><option value="Nimach">Nimach</option><option value="Nimbahera">Nimbahera</option><option value="Nipani">Nipani</option><option value="Nirmal">Nirmal</option><option value="Nizamabad">Nizamabad</option><option value="Noida">Noida</option><option value="Nokha">Nokha</option><option value="North Barakpur">North Barakpur</option><option value="North Dum Dum">North Dum Dum</option><option value="Nuzvid">Nuzvid</option><option value="Obra">Obra</option><option value="Old Maldah">Old Maldah</option><option value="Ongole">Ongole</option><option value="Orai">Orai</option><option value="Osmanabad">Osmanabad</option><option value="Ozhukarai">Ozhukarai</option><option value="Palakkad">Palakkad</option><option value="Palakollu">Palakollu</option><option value="Palasa">Palasa</option><option value="Palghar">Palghar</option><option value="Pali">Pali</option><option value="Palitana">Palitana</option><option value="Pallavaram">Pallavaram</option><option value="Pallichal">Pallichal</option><option value="Palwal">Palwal</option><option value="Palwancha">Palwancha</option><option value="Pammal">Pammal</option><option value="Panaji">Panaji</option><option value="Panchkula">Panchkula</option><option value="Pandharpur">Pandharpur</option><option value="Panihati">Panihati</option><option value="Panipat">Panipat</option><option value="Pannuratti">Pannuratti</option><option value="Paradwip">Paradwip</option><option value="Paramakkudi">Paramakkudi</option><option value="Parbhani">Parbhani</option><option value="Patan">Patan</option><option value="Patancheru">Patancheru</option><option value="Pathankot">Pathankot</option><option value="Patiala">Patiala</option><option value="Patna">Patna</option><option value="Pattanagere">Pattanagere</option><option value="Pattukkottai">Pattukkottai</option><option value="Payyannur">Payyannur</option><option value="Phagwara">Phagwara</option><option value="Phaltan">Phaltan</option><option value="Phulia">Phulia</option><option value="Phulwari">Phulwari</option><option value="Phusro">Phusro</option><option value="Piduguralla">Piduguralla</option><option value="Pilibhit">Pilibhit</option><option value="Pilkhuwa">Pilkhuwa</option><option value="Pimpri">Pimpri</option><option value="Pithampur">Pithampur</option><option value="Pithoragarh">Pithoragarh</option><option value="Pollachi">Pollachi</option><option value="Pondicherry">Pondicherry</option><option value="Ponnani">Ponnani</option><option value="Ponnur">Ponnur</option><option value="Porbandar">Porbandar</option><option value="Port Blair">Port Blair</option><option value="Proddatur">Proddatur</option><option value="Pudukkottai">Pudukkottai</option><option value="Pujali">Pujali</option><option value="Pul Pehlad">Pul Pehlad</option><option value="Puliyankudi">Puliyankudi</option><option value="Puna">Puna</option><option value="Punamalli">Punamalli</option><option value="Pune">Pune</option><option value="Pune Cantonment">Pune Cantonment</option><option value="Puri">Puri</option><option value="Purnia">Purnia</option><option value="Puruliya">Puruliya</option><option value="Pusad">Pusad</option><option value="Puth Kalan">Puth Kalan</option><option value="Puttur">Puttur</option><option value="Qutubullapur">Qutubullapur</option><option value="Rabkavi">Rabkavi</option><option value="Rae Bareli">Rae Bareli</option><option value="Raghogarh">Raghogarh</option><option value="Raichur">Raichur</option><option value="Raiganj">Raiganj</option><option value="Raigarh">Raigarh</option><option value="Raipur">Raipur</option><option value="Rajamahendri">Rajamahendri</option><option value="Rajampet">Rajampet</option><option value="Rajapalaiyam">Rajapalaiyam</option><option value="Rajendranagar">Rajendranagar</option><option value="Rajkot">Rajkot</option><option value="Rajnandgaon">Rajnandgaon</option><option value="Rajpur">Rajpur</option><option value="Rajpura">Rajpura</option><option value="Rajsamand">Rajsamand</option><option value="Ramachandrapuram">Ramachandrapuram</option><option value="Ramagundam">Ramagundam</option><option value="Ramanagaram">Ramanagaram</option><option value="Ramanathapuram">Ramanathapuram</option><option value="Ramgarh">Ramgarh</option><option value="Ramgarh Nagla Kothi">Ramgarh Nagla Kothi</option><option value="Ramod">Ramod</option><option value="Rampur">Rampur</option><option value="Rampur Hat">Rampur Hat</option><option value="Ranaghat">Ranaghat</option><option value="Ranchi">Ranchi</option><option value="Ranibennur">Ranibennur</option><option value="Raniganj">Raniganj</option><option value="Ranip">Ranip</option><option value="Ratangarh">Ratangarh</option><option value="Rath">Rath</option><option value="Ratlam">Ratlam</option><option value="Ratnagiri">Ratnagiri</option><option value="Raurkela">Raurkela</option><option value="Raurkela Industrial Township">Raurkela Industrial Township</option><option value="Raxaul">Raxaul</option><option value="Rayachoti">Rayachoti</option><option value="Rayadrug">Rayadrug</option><option value="Rayagada">Rayagada</option><option value="Renukut">Renukut</option><option value="Rewa">Rewa</option><option value="Rewari">Rewari</option><option value="Rishikesh">Rishikesh</option><option value="Rishra">Rishra</option><option value="Robertsonpet">Robertsonpet</option><option value="Rohtak">Rohtak</option><option value="Roshan Pura">Roshan Pura</option><option value="Rudrapur">Rudrapur</option><option value="Rupnagar">Rupnagar</option><option value="Rurki">Rurki</option><option value="Sadat Pur Gujran">Sadat Pur Gujran</option><option value="Sagar">Sagar</option><option value="Sagar">Sagar</option><option value="Saharanpur">Saharanpur</option><option value="Saharsa">Saharsa</option><option value="Sahaswan">Sahaswan</option><option value="Sahibganj">Sahibganj</option><option value="Salem">Salem</option><option value="Samalkot">Samalkot</option><option value="Samana">Samana</option><option value="Samastipur">Samastipur</option><option value="Sambalpur">Sambalpur</option><option value="Sambhal">Sambhal</option><option value="Sandila">Sandila</option><option value="Sangareddi">Sangareddi</option><option value="SangliMiraj">SangliMiraj</option><option value="Sangrur">Sangrur</option><option value="Sankarankoil">Sankarankoil</option><option value="Sardarshahr">Sardarshahr</option><option value="Sarni">Sarni</option><option value="Sasaram">Sasaram</option><option value="Satara">Satara</option><option value="Satna">Satna</option><option value="Sattenapalle">Sattenapalle</option><option value="Saunda">Saunda</option><option value="Sawai Madhopur">Sawai Madhopur</option><option value="Sehore">Sehore</option><option value="Sendhwa">Sendhwa</option><option value="Seoni">Seoni</option><option value="Serilungampalle">Serilungampalle</option><option value="Shahabad">Shahabad</option><option value="Shahabad">Shahabad</option><option value="Shahada">Shahada</option><option value="Shahdol">Shahdol</option><option value="Shahjahanpur">Shahjahanpur</option><option value="Shahpur">Shahpur</option><option value="Shajapur">Shajapur</option><option value="Shamli">Shamli</option><option value="Shantipur">Shantipur</option><option value="Shegaon">Shegaon</option><option value="Sheopur">Sheopur</option><option value="Sherkot">Sherkot</option><option value="Shikohabad">Shikohabad</option><option value="Shiliguri">Shiliguri</option><option value="Shillong">Shillong</option><option value="Shimla">Shimla</option><option value="Shimoga">Shimoga</option><option value="Shirpur">Shirpur</option><option value="Shivapuri">Shivapuri</option><option value="Sholapur">Sholapur</option><option value="Shorapur">Shorapur</option><option value="Shrirampur">Shrirampur</option><option value="Shrirampur">Shrirampur</option><option value="Sibsagar">Sibsagar</option><option value="Siddhapur">Siddhapur</option><option value="Siddipet">Siddipet</option><option value="Sidhi">Sidhi</option><option value="Sidlaghatta">Sidlaghatta</option><option value="Sihor">Sihor</option><option value="Sikandarabad">Sikandarabad</option><option value="Sikandarabad">Sikandarabad</option><option value="Sikar">Sikar</option><option value="Silchar">Silchar</option><option value="Sillod">Sillod</option><option value="Sindari">Sindari</option><option value="Singrauli">Singrauli</option><option value="Sira">Sira</option><option value="Sirhind">Sirhind</option><option value="Sirsa">Sirsa</option><option value="Sirsi">Sirsi</option><option value="Sirsilla">Sirsilla</option><option value="Sitamarhi">Sitamarhi</option><option value="Sitapur">Sitapur</option><option value="Siuri">Siuri</option><option value="Sivakasi">Sivakasi</option><option value="Siwan">Siwan</option><option value="Sonipat">Sonipat</option><option value="Sopur">Sopur</option><option value="South Dum Dum">South Dum Dum</option><option value="Srikakulam">Srikakulam</option><option value="Srikalahasti">Srikalahasti</option><option value="Srinagar">Srinagar</option><option value="Srivilliputtur">Srivilliputtur</option><option value="Sujangarh">Sujangarh</option><option value="Sukhmalpur Nizamabad">Sukhmalpur Nizamabad</option><option value="Sultanpur">Sultanpur</option><option value="Sultanpur Majra">Sultanpur Majra</option><option value="Sunabeda">Sunabeda</option><option value="Sunam">Sunam</option><option value="Supaul">Supaul</option><option value="Surat">Surat</option><option value="Suratgarh">Suratgarh</option><option value="Surendranagar">Surendranagar</option><option value="Suriapet">Suriapet</option><option value="Tadepalle">Tadepalle</option><option value="Tadepallegudem">Tadepallegudem</option><option value="Tadpatri">Tadpatri</option><option value="Tajpul">Tajpul</option><option value="Talipparamba">Talipparamba</option><option value="Tambaram">Tambaram</option><option value="Tanda">Tanda</option><option value="Tandur">Tandur</option><option value="Tanuku">Tanuku</option><option value="Tarn Taran">Tarn Taran</option><option value="Tenali">Tenali</option><option value="Tenkasi">Tenkasi</option><option value="Tezpur">Tezpur</option><option value="Thalassery">Thalassery</option><option value="Thaltej">Thaltej</option><option value="Thana">Thana</option><option value="Thanesar">Thanesar</option><option value="Thanjavur">Thanjavur</option><option value="Theni Allinagaram">Theni Allinagaram</option><option value="Thiruthangal">Thiruthangal</option><option value="Thiruvananthapuram">Thiruvananthapuram</option><option value="Thiruvarur">Thiruvarur</option><option value="Thrippunithura">Thrippunithura</option><option value="Thrissur">Thrissur</option><option value="Thuthukkudi">Thuthukkudi</option><option value="Tigri">Tigri</option><option value="Tikamgarh">Tikamgarh</option><option value="Tilhar">Tilhar</option><option value="Tindivanam">Tindivanam</option><option value="Tinsukia">Tinsukia</option><option value="Tiptur">Tiptur</option><option value="Tiruchchirappalli">Tiruchchirappalli</option><option value="Tiruchengode">Tiruchengode</option><option value="Tirunelveli">Tirunelveli</option><option value="Tirupathur">Tirupathur</option><option value="Tirupati">Tirupati</option><option value="Tiruppur">Tiruppur</option><option value="Tirur">Tirur</option><option value="Tiruvalla">Tiruvalla</option><option value="Tiruvannamalai">Tiruvannamalai</option><option value="Tiruvottiyur">Tiruvottiyur</option><option value="Titagarh">Titagarh</option><option value="Tohana">Tohana</option><option value="Tonk">Tonk</option><option value="Tumkur">Tumkur</option><option value="Tundla">Tundla</option><option value="Tuni">Tuni</option><option value="Tura">Tura</option><option value="Udagamandalam">Udagamandalam</option><option value="Udaipur">Udaipur</option><option value="Udgir">Udgir</option><option value="Udhampur">Udhampur</option><option value="Udumalaipettai">Udumalaipettai</option><option value="Udupi">Udupi</option><option value="Ujhani">Ujhani</option><option value="Ujjain">Ujjain</option><option value="Ulhasnagar">Ulhasnagar</option><option value="Ullal">Ullal</option><option value="Ulubaria">Ulubaria</option><option value="Una">Una</option><option value="Unjha">Unjha</option><option value="Unnao">Unnao</option><option value="Upleta">Upleta</option><option value="Uppal Kalan">Uppal Kalan</option><option value="Uran Islampur">Uran Islampur</option><option value="UttarparaKotrung">UttarparaKotrung</option><option value="Vadakara">Vadakara</option><option value="Vadodara">Vadodara</option><option value="Valparai">Valparai</option><option value="Valsad">Valsad</option><option value="Vaniyambadi">Vaniyambadi</option><option value="Vapi">Vapi</option><option value="Varanasi">Varanasi</option><option value="Vasai">Vasai</option><option value="Vastral">Vastral</option><option value="Vejalpur">Vejalpur</option><option value="Velampalaiyam">Velampalaiyam</option><option value="Velluru">Velluru</option><option value="Veraval">Veraval</option><option value="Vidisha">Vidisha</option><option value="Vijalpor">Vijalpor</option><option value="Vijayawada">Vijayawada</option><option value="Viluppuram">Viluppuram</option><option value="Vinukonda">Vinukonda</option><option value="Virappanchatram">Virappanchatram</option><option value="Virar">Virar</option><option value="Virudhachalam">Virudhachalam</option><option value="Virudunagar">Virudunagar</option><option value="Visakhapatnam">Visakhapatnam</option><option value="Visnagar">Visnagar</option><option value="Vizianagaram">Vizianagaram</option><option value="Vrindavan">Vrindavan</option><option value="Vuyyuru">Vuyyuru</option><option value="Wadhwan">Wadhwan</option><option value="Wadi">Wadi</option><option value="Wani">Wani</option><option value="Wanparti">Wanparti</option><option value="Warangal">Warangal</option><option value="Wardha">Wardha</option><option value="Warud">Warud</option><option value="Washim">Washim</option><option value="Wokha">Wokha</option><option value="Yadgir">Yadgir</option><option value="Yamunanagar">Yamunanagar</option><option value="Yavatmal">Yavatmal</option><option value="Yelahanka">Yelahanka</option><option value="Yemmiganur">Yemmiganur</option><option value="Ziauddin Pur">Ziauddin Pur</option> 
                            </select>
                            </span>
                        </span>
                        <span class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <select name="reference" id="r1" class="form-control">
                                <option selected disabled>Select Reference</option>
                                <option value="Facebook">Facebook</option>
                                <option value="Whatsapp">Whatsapp</option>
                                <option value="SMS">SMS</option>
                                <option value="Email">Email</option>
                                <option value="Internet">Internet</option>
                                <option value="Friend">Friend</option>
                                <option value="Coaching/Tuition">Coaching/Tuition</option>
                                <option value="School/College">School/College</option>
                                <option value="Others">Others</option>
                            </select>
                            <input type="text" class="col-md-6 form-control" id="reference_name" name="reference_name" placeholder="Name Source" style="display: none;" />
                            </span>
                        </span>
                        <!--<center><div style="ppadding: 0px;" class="g-recaptcha pull-right" data-sitekey="6LdkqGsUAAAAAHaGJsKsrkrvewL8eWH2U_xGOttR"></div></center>-->
                        <div class="col-md-12" style="padding: 0px;">
                        <div class="col-md-5">
                            Already Registered?</b>
                            <br /><a href="#" data-toggle="modal" data-target="#login" data-dismiss="modal"><b>Login Here</b></a>
                        </div>
                        <div class="col-md-7">
                            <div id="msg">
                                <span id="rsuccess" class="pull-right" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> <span id="m1"></span></span>
                                <span id="rerror" class="pull-right" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <span id="m2"></span></span>
                            </div>
                            <button id="sub" type="submit" class="btn btn-primary pull-right">Register</button>
                        </div>
                        <div id="regButton" class="col-md-4" style="display: none; background: #DE4313;">
                        </div>
                        </div>
                        <br /><br />
                    </form>
        		</div>
        		<div id="col3" class="col-md-12" style="display: none; color: black; background: transparent; z-index: 1000; padding: 0px 40px 20px 40px;">
                    <div class=".why" style="ddisplay: none; background: #DAEBFA; padding: 10px; text-align: left; color: black!important;">
                <h3 style="color: #5D9BD0;"><i class="fas fa-info-circle fa-lg"></i>
                <b>Premium Membership Offer</h3>
                <span title="Close" style="position: absolute; top: 10px; right: 30px; cursor: pointer;" onclick="window.history.back();"><i class="fa fa-times" aria-hidden="true"></i></span> </b>
                <br /><h4>Get the <b style="color: green;">Premium</b> benifits <strong>only @ <i class="fa fa-inr"></i> 199/- </strong></h4>
                <br />
                
                    
                    <span><!--<i class="pull-right fa fa-info"></i>-->
                    <span id="msg1" class="div-no-mobile"><br />
                        <lh><h4><strong> What will you get: </strong></h4></lh></br>
                    <ul>
                                                
                       
                        
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp There will be more 40,000 questions</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Minimum 10 sets of chapter wise practice test for each subject in MBA syllabus</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Unlimited full length practice test & Colleges</li>
                    </br>
                   
                        <lh><h4><strong> Information About:</strong></h4></lh></br>
                    <ul>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp   Exams </li>
                       
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp  Courses</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspTop Colleges & Universities</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspEligibility Criteria For Admission</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspRanking of Universities & Colleges</li>
                       
                    </ul>
                </br>
                   </span>
             <!--   <table class="table stable-striped" border=1>
                    <tr style="background: gray; color: white;"><td width="45%"><b>Benifits</b></td><td><b>Standard</b></td><td style="background: green"><b>Premium</b></td></tr>
                    <tr><td class="first">10 Years Questions Bank</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Tests History & Progress Tracking</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Important Dates - Mobile Alerts</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>

                    
                    
                    <tr><td class="first">Top Colleges & Universities</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Eligibility & Admission</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">College Rankings</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">College Brochures</td><td><img src="../img/tick.png" height="20" /><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    
                   <tr><td class="first">365 Days Support</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>
                    <tr><td class="first">Career Guidance</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>
                </table> -->
                <center>
                	   <form method="POST" name="customerData" action="https://www.searchurcollege.com/cca/ccavRequestHandler.php">
                            <!--<input type="hhidden" id="na" name="na" />
                            <input type="hhidden" id="ct" name="ct" />
                            <input type="hhidden" id="ph" name="ph" />
                            <input type="hhidden" id="em" name="em" />-->
                                                        <input type="hidden" name="tid" id="tid" value="20181122105315" rreadonly />
                            <input type="hidden" name="merchant_id" value="188437"/>
                            <input type="hidden" name="order_id" value="-20181122105315"/>
                            <input type="hidden" name="amount" value="199"/>
                            <input type="hidden" name="currency" value="INR"/>
                            <input type="hidden" name="redirect_url" value="https://www.searchurcollege.com/cca/success.php" />
                            <input type="hidden" name="cancel_url" value="https://www.searchurcollege.com/cca/failure.php" />
                            <input type="hidden" name="language" value="EN"/>
                            <input type="hidden" id="na" name="billing_name" value="" />
                            <input type="hidden" id="ct" name="billing_city" />
                            <input type="hidden" id="ph" name="billing_tel" value="" />
        		        	<input type="hidden" id="em" name="billing_email" value="" />
                        <button type="submit" class="btn btn-primary">Complete your Payment</button>
                    </form>
                </center>
            </div>
                </div>
            </div>
        </div>
      </div>
    </div>
</div>

<!-- #modal 2 -->



<div id="otp" style="display: none; z-index: 10000; color: black;">
    <center>
    <form id="frmOTP">
        <h4>Enter OTP sent to your mobile</h4>
        <br />
        <div class="input-group">
            <input type="text" class="form-control" id="otp_box" name="otp" placeholder="OTP" sstyle="width: 150px;" required />
            <span class="input-group-btn">
                <button type="submit" class="btn btn-success">Go</button>
            </span>
        </div>
        <div id="v5" style="display: block;">Not received? <a class="resendOTP" href="">Resend OTP</a></div>
        <div id="v4" style="display: none;"><span style="font-weight: bold;">OTP sent</span><i class="fa fa-send" style="margin-left: 5px; margin-top: 20px;"></i></div>
        <div id="v1" style="display: none;"><span style="font-size: 20px; font-weight: bold;">Verifying</span><i class="fa fa-circle-o-notch fa-spin" style="font-size: 24px; margin-left: 5px; margin-top: 20px;"></i></div>
        <div id="v2" style="display: none;"><span style="color: green; font-weight: bold;">Number Verified</span><i class="fa fa-check" style="font-size: 24px; margin-left: 5px; margin-top: 20px; color: green;"></i></div>
        <div id="v3" style="display: none;"><span style="color: red; font-weight: bold;">Incorrect OTP</span><!--<i class="fa fa-close" style="margin-left: 5px; margin-top: 20px; color: red; margin-right: 10px; font-weight: bold;"></i><a class="resendOTP" href="">Resend OTP?</a></div>-->
    </form>
    </center>
</div>

<sscript src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    $('#why_head').click(function(){
        $(this).find('i').toggleClass('fa-plus fa-minus')
        $('#msg1').toggle().fade();
    });
</script>

<script type="text/javascript">
    $(document).ready(function(){
        $('#L1').change(function(event) {
           // alert('ss');
          $('#L2').val('');
          id=$('#L1').val();
          $.post(
           'https://www.searchurcollege.com/connection/info.php?id='+id,
            $(this).serialize(),
            function(data){
              $("#course_interested").html(data);
            }
          );
          return false;
        });   

        //Register User
        $('#frmRegister').submit(function(event) {
          $.post(
           'https://www.searchurcollege.com/connection/user_register.php',
            $(this).serialize(),
            function(data){
                //$('#v3').fadeIn().delay(2000).fadeOut();
                if(data==1 || data.substring(0,3)=="Log")
                {
                    $('#m1').text(data);
                    $("#frmRegister input").prop("disabled", true);
                    $("#frmRegister select").prop("disabled", true);
                    $('#sub').prop('disabled', true);
                    //$('#rsuccess').css('display','block');
                    //$('#rsuccess').fadeIn().delay(2000).fadeOut();
                    $('#otp').css('display', 'block');
                    $('#otp_box').focus();
                }
                else
                {
                    $('#m2').text(data);
                    $('#rerror').css('display','block');
                    //$('#rerror').fadeIn().delay(2000).fadeOut();
                }
          });
          return false;   
        });

        //Verify OTP
        $('#frmOTP').submit(function(event) {
          phone=$('#phone').val();
          $('#v1').show();
          $.post(
           'https://www.searchurcollege.com/connection/verify_otp.php?phone='+phone,
            $(this).serialize(),
            function(data){
              $('#v1').hide();
                if(data=='found' || data.substring(0,3)=="Log")
              {
                $('#v2').show();
                $('#v3').hide();
                $('#v4').hide();
                $('#v5').hide();
                $('#na').val($('#first_name').val()+' '+$('#last_name').val());
                $('#ct').val($('#city').val());
                $('#ph').val($('#phone').val());
                $('#em').val($('#email2').val());

                $("#d").removeClass("modal-lg"); 
                $('#otp').css('display','none');
                $('#col1').css('display','none');
                $('#col2').css('display','none');
                $('#col3').css('display','block');
                //$('#register .close').click();
                /*setTimeout(function() {
                    $('#otp').hide();
                    //$('#col3').css('display','block');
                    location.reload();
                    $("#d").removeClass("modal-lg"); 
                    $("#register").removeClass("modal-lg");
                    //alert("11");
                    $('#col1').css('display','none');
                    $('#col2').css('display','none');
                }, 2000);*/
              }
              else
              {
                $('#v2').hide();
                $('#v3').show();
                $('#v4').hide();
              }
            }
          );
          return false;   
        });   

        //Resend OTP
        $('.resendOTP').click(function(event) {
          $('#v1').hide();
          $('#v2').hide();
          $('#v3').hide();
          $('#v4').fadeIn().delay(2000).fadeOut();
          $('#v5').fadeOut().delay(2000).fadeIn();
          phone=$('#phone').val();
          $.post(
           'https://www.searchurcollege.com/connection/resend_otp.php?phone='+phone,
            $(this).serialize(),
            function(data){

            }
          );
          return false;   
        });   
    });
    $('#pclose').on('click', function () {
        location.reload();
    });
    $("#r1").on('input', function () {
        var val = this.value;
        if(val=='Others' || val=='Coaching/Tuition' || val=='School/College')
        {

            $("#r1").removeClass("col-md-12");
            $("#r1").addClass("col-md-6");

            $('#reference_name').show();
            $('#reference_name').focus();
             $('#reference_name').prop('required',true);
        }
        else
        {
            $("#r1").removeClass("col-md-6");
            $("#r1").addClass("col-md-12");
            $('#reference_name').hide();
            $('#reference_name').removeAttr('required',true);
        }
    });
</script>



 

   <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
        a:active, a:focus {
          outline: 0;
          border: none;
          -moz-outline-style: none;
        }
        .locFil
        {
          height: 200px;
          overflow: auto;
        }
    </style>
    <sscript src="//code.jquery.com/jquery-1.11.1.min.js"></script>
      <body style="background: white;">

<div class="col-md-12" style="background:#F4F4F4; mmargin-top: 10px;">
  <div class="col-md-3"></div>
<div class="col-md-6" style="bbackground:#F4F4F4; fheight: 50px; margin-top: 50px;">
<h4 style="margin-left: 20px;">Modify Your Search</h4>
  
  <!DOCTYPE html>
<html>

<style type="text/css">
   ul{
    bbackground-color: lightgray;
    cursor: pointer;
    bborder: 1px solid black;
    
   } 
   #countryList1 ul
   {
    cursor: pointer;
    border: 1px solid lightgray;
   }
   li{
    padding:5px; 

   }
.search {
    width: 100px;
    height: 100px;
    background-color: orange    ;

    position: absolute;
    top:0;
    bottom: 0;
    left: 0;
    right: 0;

    margin: auto;
    margin-top: 0px;
}    
</style>
<head>
   <script>
    $(document).ready(function(){
      
    
    $("#country1").keyup(function(){
        var a=$("#country1").val();
        if(a<1)
        {
          $('#countryList1').fadeOut(); 
        }
          var query= $(this).val();
          //alert(query.length);
            if(query.length >= 2){
                $.ajax({
                    url:"https://www.searchurcollege.com/search2/search.php",
                    method:"POST",
                    data:{query:query},
                    success:function(data)
                    {

                        $('#countryList1').fadeIn(); 
                        $('#countryList1').html(data);
                    }
                });
            }
    });

    $(document).on('click','li',function(){
        $('#country1').val($(this).text());
        $('#countryList1').fadeOut();
    });

});
</script>
</head>

      <form action="https://www.searchurcollege.com/search2/listC.php" method="POST">
       <div class="col-md-7"> <input type="text" name="country1"style="height: 40px; font-size: 16px; font-family:  Helvetica" autocomplete="off" id="country1" class="form-control" placeholder="Enter College Name , Course Name "> </div>
       <div class="col-md-3"> <select class="form-control" id="location_id" name="location_id" style="height: 40px;" rrequired>
                                            <option selected disabled>Location (Optional)</option>
                                              <option  value="1">Abohar</option>  <option  value="2">Achalpur</option>  <option  value="3">Adilabad</option>  <option  value="4">Adityapur</option>  <option  value="5">Adoni</option>  <option  value="6">Agartala</option>  <option  value="8">Agra</option>  <option  value="9">Ahmadabad</option>  <option  value="10">Ahmadnagar</option>  <option  value="11">Aizawl</option>  <option  value="12">Ajmer</option>  <option  value="13">Akola</option>  <option  value="14">Akot</option>  <option  value="15">Alandur</option>  <option  value="16">Alappuzha</option>  <option  value="17">Aligarh</option>  <option  value="18">Alipur Duar</option>  <option  value="19">Allahabad</option>  <option  value="20">Alwal</option>  <option  value="21">Alwar</option>  <option  value="22">Amalner</option>  <option  value="23">Ambajogai</option>  <option  value="24">Ambala</option>  <option  value="25">Ambala Cantonment</option>  <option  value="26">Ambala Sadar</option>  <option  value="27">Ambattur</option>  <option  value="28">Ambikapur</option>  <option  value="29">Ambur</option>  <option  value="30">Amravati</option>  <option  value="31">Amreli</option>  <option  value="32">Amritsar</option>  <option  value="33">Amroha</option>  <option  value="34">Anakapalle</option>  <option  value="35">Anand</option>  <option  value="36">Anantapur</option>  <option  value="37">Anantnag</option>  <option  value="38">Anjangaon</option>  <option  value="39">Anjar</option>  <option  value="40">Aonla</option>  <option  value="41">Arakonam</option>  <option  value="42">Arambagh</option>  <option  value="43">Arani</option>  <option  value="44">Araria</option>  <option  value="45">Arrah</option>  <option  value="46">Aruppukkottai</option>  <option  value="47">Asansol</option>  <option  value="48">Ashoknagar</option>  <option  value="49">Ashoknagar Kalyangarh</option>  <option  value="50">Attur</option>  <option  value="51">Auraiya</option>  <option  value="52">Aurangabad</option>  <option  value="53">Aurangabad</option>  <option  value="54">Avadi</option>  <option  value="55">Avaniapuram</option>  <option  value="56">Ayodhya</option>  <option  value="57">Azamgarh</option>  <option  value="58">Badharghat</option>  <option  value="59">Badlapur</option>  <option  value="60">Bagaha</option>  <option  value="61">Bagalkot</option>  <option  value="62">Bagbahra</option>  <option  value="63">Bahadurgarh</option>  <option  value="64">Baharampur</option>  <option  value="65">Baheri</option>  <option  value="66">Bahraich</option>  <option  value="67">Baidyabati</option>  <option  value="68">Baj Baj</option>  <option  value="69">Balaghat</option>  <option  value="70">Balangir</option>  <option  value="71">Baleshwar</option>  <option  value="72">Ballarpur</option>  <option  value="73">Ballia</option>  <option  value="74">Bally</option>  <option  value="75">Bally Cantonment</option>  <option  value="76">Balotra</option>  <option  value="77">Balrampur</option>  <option  value="78">Balurghat</option>  <option  value="79">Banda</option>  <option  value="80">Bangalore</option>  <option  value="81">Bangaon</option>  <option  value="82">Bankra</option>  <option  value="83">Bankura</option>  <option  value="84">Bansbaria</option>  <option  value="85">Banswara</option>  <option  value="86">Bapatla</option>  <option  value="87">Baramati</option>  <option  value="88">Baramula</option>  <option  value="89">Baran</option>  <option  value="90">Baranagar</option>  <option  value="91">Baraut</option>  <option  value="92">Barbil</option>  <option  value="93">Barddhaman</option>  <option  value="94">Bardoli</option>  <option  value="95">Bareli</option>  <option  value="96">Bargarh</option>  <option  value="97">Bari</option>  <option  value="98">Bari Brahmana</option>  <option  value="99">Baripada</option>  <option  value="100">Barmer</option>  <option  value="101">Barnala</option>  <option  value="102">Barpeta</option>  <option  value="103">Barsi</option>  <option  value="104">Basavakalyan</option>  <option  value="105">Basirhat</option>  <option  value="106">Basmat</option>  <option  value="107">Basoda</option>  <option  value="108">Basti</option>  <option  value="109">Batala</option>  <option  value="110">Bathinda</option>  <option  value="111">Beawar</option>  <option  value="112">Begusarai</option>  <option  value="113">Behta Hajipur</option>  <option  value="114">Bela</option>  <option  value="115">Belampalli</option>  <option  value="116">Belgaum</option>  <option  value="117">Bellary</option>  <option  value="118">Bettiah</option>  <option  value="119">Betul</option>  <option  value="120">Beypur</option>  <option  value="121">Bhabua</option>  <option  value="122">Bhadohi</option>  <option  value="123">Bhadrak</option>  <option  value="124">Bhadravati</option>  <option  value="125">Bhadravati</option>  <option  value="126">Bhadreswar</option>  <option  value="127">Bhagalpur</option>  <option  value="128">Bhalswa Jahangirpur</option>  <option  value="129">Bhandara</option>  <option  value="130">Bharatpur</option>  <option  value="131">Bharuch</option>  <option  value="132">Bhatpara</option>  <option  value="133">Bhavnagar</option>  <option  value="134">Bhawanipatna</option>  <option  value="135">Bhilai</option>  <option  value="136">Bhilwara</option>  <option  value="137">Bhimavaram</option>  <option  value="138">Bhind</option>  <option  value="139">Bhiwadi</option>  <option  value="140">Bhiwandi</option>  <option  value="141">Bhiwani</option>  <option  value="142">Bhongir</option>  <option  value="143">Bhopal</option>  <option  value="144">Bhubaneswar</option>  <option  value="145">Bhuj</option>  <option  value="146">Bhuli</option>  <option  value="147">Bhusawal</option>  <option  value="148">Bid</option>  <option  value="149">Bidar</option>  <option  value="150">Bidhannagar</option>  <option  value="151">Bihar</option>  <option  value="152">Bijapur</option>  <option  value="153">Bijnor</option>  <option  value="154">Bikaner</option>  <option  value="155">Bilaspur</option>  <option  value="156">BinaEtawa</option>  <option  value="157">Binnaguri</option>  <option  value="158">Bisalpur</option>  <option  value="159">Bishnupur</option>  <option  value="160">Biswan</option>  <option  value="161">Bobbili</option>  <option  value="162">Bodhan</option>  <option  value="163">Bodinayakkanur</option>  <option  value="164">Bokaro</option>  <option  value="165">Bolpur</option>  <option  value="166">Bommanahalli</option>  <option  value="167">Bongaigaon</option>  <option  value="168">Borsad</option>  <option  value="169">Botad</option>  <option  value="170">Brahmapur</option>  <option  value="171">Brajrajnagar</option>  <option  value="172">Budaun</option>  <option  value="173">Bulandshahr</option>  <option  value="174">Buldana</option>  <option  value="175">Bundi</option>  <option  value="176">Burari</option>  <option  value="177">Burhanpur</option>  <option  value="178">Buxar</option>  <option  value="179">Byatarayanapura</option>  <option  value="180">Calcutta</option>  <option  value="181">Chaibasa</option>  <option  value="182">Chakdaha</option>  <option  value="183">Chalisgaon</option>  <option  value="184">Challakere</option>  <option  value="185">Champdani</option>  <option  value="186">Chamrajnagar</option>  <option  value="187">Chandannagar</option>  <option  value="188">Chandausi</option>  <option  value="189">Chandigarh</option>  <option  value="190">Chandkheda</option>  <option  value="191">Chandlodiya</option>  <option  value="192">Chandpur</option>  <option  value="193">Chandrapur</option>  <option  value="194">Channapatna</option>  <option  value="195">Charkhi Dadri</option>  <option  value="196">Charoda</option>  <option  value="197">Chas</option>  <option  value="198">Chengalpattu</option>  <option  value="199">Cheruvannur</option>  <option  value="200">Chhapra</option>  <option  value="201">Chhatarpur</option>  <option  value="202">Chhibramau</option>  <option  value="203">Chhindwara</option>  <option  value="204">Chik Ballapur</option>  <option  value="205">Chikhli</option>  <option  value="206">Chikmagalur</option>  <option  value="207">Chilakalurupet</option>  <option  value="208">Chilla Saroda Bangar</option>  <option  value="209">Chinna Chawk</option>  <option  value="210">Chintamani</option>  <option  value="211">Chiplun</option>  <option  value="212">Chirala</option>  <option  value="213">Chirmiri</option>  <option  value="214">Chitradurga</option>  <option  value="215">Chitrakut Dham</option>  <option  value="216">Chittaurgarh</option>  <option  value="217">Chittur</option>  <option  value="218">Chomun</option>  <option  value="219">Chopda</option>  <option  value="220">Churu</option>  <option  value="221">Contai</option>  <option  value="222">Cuddapah</option>  <option  value="223">Dabgram</option>  <option  value="224">Dabhoi</option>  <option  value="225">Dabra</option>  <option  value="226">Dabwali</option>  <option  value="227">Dadri</option>  <option  value="228">Dahanu</option>  <option  value="229">Dahod</option>  <option  value="230">Dallo Pura</option>  <option  value="231">Daltenganj</option>  <option  value="232">Damoh</option>  <option  value="233">Daosa</option>  <option  value="234">Darbhanga</option>  <option  value="235">Darjiling</option>  <option  value="236">Dasarahalli</option>  <option  value="237">Datia</option>  <option  value="238">Davanagere</option>  <option  value="239">Dehra Dun</option>  <option  value="240">Dehra Dun Cantonment</option>  <option  value="241">Dehri</option>  <option  value="242">Delhi</option>  <option  value="243">Deoband</option>  <option  value="244">Deolali</option>  <option  value="245">Deoli</option>  <option  value="246">Deoria</option>  <option  value="247">Devghar</option>  <option  value="248">Dewas</option>  <option  value="249">Dhamtari</option>  <option  value="250">Dhanbad</option>  <option  value="251">Dhar</option>  <option  value="252">Dharapuram</option>  <option  value="253">Dharmapuri</option>  <option  value="254">Dharmavaram</option>  <option  value="255">Dhaulpur</option>  <option  value="256">Dhenkanal</option>  <option  value="257">Dholka</option>  <option  value="258">Dhone</option>  <option  value="259">Dhoraji</option>  <option  value="260">Dhrangadhra</option>  <option  value="261">Dhuburi</option>  <option  value="262">Dhule</option>  <option  value="263">Dhulian</option>  <option  value="264">Dhuri</option>  <option  value="265">Dibrugarh</option>  <option  value="266">Didwana</option>  <option  value="267">Digdoh</option>  <option  value="268">DighaMainpura</option>  <option  value="269">Diglur</option>  <option  value="270">Dilli Cantonment</option>  <option  value="271">Dimapur</option>  <option  value="272">Dinapur</option>  <option  value="273">Dindigul</option>  <option  value="274">Dinhata</option>  <option  value="275">Diphu</option>  <option  value="276">Disa</option>  <option  value="277">Dod Ballapur</option>  <option  value="278">Dum Dum</option>  <option  value="279">Dumraon</option>  <option  value="280">Durg</option>  <option  value="281">Durgapur</option>  <option  value="282">Edakkara</option>  <option  value="283">Edathala</option>  <option  value="284">Eluru</option>  <option  value="285">Erode</option>  <option  value="286">Etah</option>  <option  value="287">Etawah</option>  <option  value="288">Faizabad</option>  <option  value="289">Faridabad</option>  <option  value="290">Faridkot</option>  <option  value="291">Faridpur</option>  <option  value="292">Farrukhabad</option>  <option  value="293">Fatehpur</option>  <option  value="294">Fatehpur</option>  <option  value="295">Fazilka</option>  <option  value="296">Firozabad</option>  <option  value="297">Firozpur</option>  <option  value="298">Firozpur Cantonment</option>  <option  value="299">Gadag</option>  <option  value="300">Gadchiroli</option>  <option  value="301">Gaddiannaram</option>  <option  value="302">Gadwal</option>  <option  value="303">Gajraula</option>  <option  value="304">Gajuwaka</option>  <option  value="305">Gandhidham</option>  <option  value="306">Gandhinagar</option>  <option  value="307">Ganga Ghat</option>  <option  value="308">Ganganagar</option>  <option  value="309">Gangapur</option>  <option  value="310">Gangarampur</option>  <option  value="311">Gangawati</option>  <option  value="312">Gangoh</option>  <option  value="313">Garulia</option>  <option  value="314">Gaya</option>  <option  value="315">Gayespur</option>  <option  value="316">Gharoli</option>  <option  value="317">Ghatal</option>  <option  value="318">Ghatlodiya</option>  <option  value="319">Ghaziabad</option>  <option  value="320">Ghazipur</option>  <option  value="321">Gobindgarh</option>  <option  value="322">Godhra</option>  <option  value="323">Gohad</option>  <option  value="324">Gohana</option>  <option  value="325">Gokak</option>  <option  value="326">Gokalpur</option>  <option  value="327">Gola Gokarannath</option>  <option  value="328">Gola Range</option>  <option  value="329">Gonda</option>  <option  value="330">Gondal</option>  <option  value="331">Gondiya</option>  <option  value="332">Gopalganj</option>  <option  value="333">Gopalpur</option>  <option  value="334">Gopichettipalaiyam</option>  <option  value="335">Gorakhpur</option>  <option  value="336">Goura</option>  <option  value="337">Gudalur</option>  <option  value="338">Gudivada</option>  <option  value="339">Gudiyattam</option>  <option  value="340">Gudur</option>  <option  value="341">Gulbarga</option>  <option  value="342">Guna</option>  <option  value="343">Guntakal</option>  <option  value="344">Guntur</option>  <option  value="345">Gurdaspur</option>  <option  value="346">Guwahati</option>  <option  value="347">Gwalior</option>  <option  value="348">Habra</option>  <option  value="349">Hajipur</option>  <option  value="350">Haldwani</option>  <option  value="351">Halisahar</option>  <option  value="352">Hanumangarh</option>  <option  value="353">Haora</option>  <option  value="354">Hapur</option>  <option  value="355">Harda</option>  <option  value="356">Hardoi</option>  <option  value="357">Haridwar</option>  <option  value="358">Harihar</option>  <option  value="359">Hasanpur</option>  <option  value="360">Hassan</option>  <option  value="361">Hastsal</option>  <option  value="362">Hathras</option>  <option  value="363">Haveri</option>  <option  value="364">Hazaribag</option>  <option  value="365">Himatnagar</option>  <option  value="366">Hindaun</option>  <option  value="367">Hindupur</option>  <option  value="368">Hinganghat</option>  <option  value="369">Hingoli</option>  <option  value="370">Hiriyur</option>  <option  value="371">Hisar</option>  <option  value="372">Hosakote</option>  <option  value="373">Hoshangabad</option>  <option  value="374">Hoshiarpur</option>  <option  value="375">Hospet</option>  <option  value="376">Hosur</option>  <option  value="377">Hubli</option>  <option  value="378">HugliChunchura</option>  <option  value="379">Hyderabad</option>  <option  value="380">Ichalkaranji</option>  <option  value="381">Idappadi</option>  <option  value="382">Ilkal</option>  <option  value="383">Imphal</option>  <option  value="384">Indore</option>  <option  value="385">Ingraj Bazar</option>  <option  value="386">Islampur</option>  <option  value="387">Itanagar</option>  <option  value="388">Itarsi</option>  <option  value="389">Jabalpur</option>  <option  value="390">Jabalpur Cantonment</option>  <option  value="391">Jaffrabad</option>  <option  value="392">Jagadhri</option>  <option  value="393">Jagdalpur</option>  <option  value="394">Jagraon</option>  <option  value="395">Jagtial</option>  <option  value="396">Jahanabad</option>  <option  value="397">Jahangirabad</option>  <option  value="398">Jaipur</option>  <option  value="399">Jaisalmer</option>  <option  value="400">Jalandhar</option>  <option  value="401">Jalaun</option>  <option  value="402">Jalgaon</option>  <option  value="403">Jalna</option>  <option  value="404">Jalor</option>  <option  value="405">Jalpaiguri</option>  <option  value="406">Jamalpur</option>  <option  value="407">Jamkhandi</option>  <option  value="408">Jammu</option>  <option  value="409">Jamnagar</option>  <option  value="410">Jamnagar</option>  <option  value="411">Jamshedpur</option>  <option  value="412">Jamui</option>  <option  value="413">Jamuria</option>  <option  value="414">Jangipur</option>  <option  value="415">Jaora</option>  <option  value="416">Jaunpur</option>  <option  value="417">Jaypur</option>  <option  value="418">Jetpur</option>  <option  value="419">Jhalawar</option>  <option  value="420">Jhansi</option>  <option  value="421">Jhargram</option>  <option  value="422">Jharia</option>  <option  value="423">Jharsuguda</option>  <option  value="424">Jhumri Tilaiya</option>  <option  value="425">Jhunjhunun</option>  <option  value="426">Jind</option>  <option  value="427">Jodhpur</option>  <option  value="428">Jorapokhar</option>  <option  value="429">Jorhat</option>  <option  value="430">Junagadh</option>  <option  value="431">Kadayanallur</option>  <option  value="432">Kadi</option>  <option  value="433">Kadiri</option>  <option  value="434">Kagaznagar</option>  <option  value="435">Kairana</option>  <option  value="436">Kaithal</option>  <option  value="437">Kakinada</option>  <option  value="438">Kalamassery</option>  <option  value="439">Kaliyaganj</option>  <option  value="440">Kallur</option>  <option  value="441">Kalna</option>  <option  value="442">Kalol</option>  <option  value="443">Kalyan</option>  <option  value="444">Kalyani</option>  <option  value="445">Kamareddi</option>  <option  value="446">Kamarhati</option>  <option  value="447">Kambam</option>  <option  value="448">Kamthi</option>  <option  value="449">Kanakapura</option>  <option  value="450">Kanchipuram</option>  <option  value="451">Kanchrapara</option>  <option  value="452">Kandi</option>  <option  value="453">Kannan Devan Hills</option>  <option  value="454">Kannangad</option>  <option  value="455">Kannauj</option>  <option  value="456">Kannur</option>  <option  value="457">Kanpur</option>  <option  value="458">Kanpur Cantonment</option>  <option  value="459">Kapra</option>  <option  value="460">Kapurthala</option>  <option  value="461">Karaikal</option>  <option  value="462">Karanja</option>  <option  value="463">Karauli</option>  <option  value="464">Karawal Nagar</option>  <option  value="465">Karimganj</option>  <option  value="466">Karimnagar</option>  <option  value="467">Karnal</option>  <option  value="468">Karnul</option>  <option  value="469">Karsiyang</option>  <option  value="470">Karur</option>  <option  value="471">Karwar</option>  <option  value="472">Kasganj</option>  <option  value="473">Kashipur</option>  <option  value="474">Kataka</option>  <option  value="475">Kathua</option>  <option  value="476">Katihar</option>  <option  value="477">Katras</option>  <option  value="478">Katwa</option>  <option  value="479">Kavali</option>  <option  value="480">Kavundampalaiyam</option>  <option  value="481">Kayankulam</option>  <option  value="482">Kendujhar</option>  <option  value="483">Keshod</option>  <option  value="484">Khadki</option>  <option  value="485">Khagaria</option>  <option  value="486">Khagaul</option>  <option  value="487">Khajuri Khas</option>  <option  value="488">Khambhat</option>  <option  value="489">Khamgaon</option>  <option  value="490">Khammam</option>  <option  value="491">Khandwa</option>  <option  value="492">Khanna</option>  <option  value="493">Kharagpur</option>  <option  value="494">Kharagpur Railway Settlement</option>  <option  value="495">Khardaha</option>  <option  value="496">Khargone</option>  <option  value="497">Kharia</option>  <option  value="498">Khatauli</option>  <option  value="499">Khopoli</option>  <option  value="500">Khora</option>  <option  value="501">Khurja</option>  <option  value="502">Kirari Suleman Nagar</option>  <option  value="503">Kiratpur</option>  <option  value="504">Kishanganj</option>  <option  value="505">Kishangarh</option>  <option  value="506">Koch Bihar</option>  <option  value="507">Kochi</option>  <option  value="508">Kodar</option>  <option  value="509">Kohima</option>  <option  value="510">Kolar</option>  <option  value="511">Kolhapur</option>  <option  value="512">Kollam</option>  <option  value="513">Kollegal</option>  <option  value="514">Kondukur</option>  <option  value="515">Konnagar</option>  <option  value="516">Kopargaon</option>  <option  value="517">Koppal</option>  <option  value="518">Koratla</option>  <option  value="519">Korba</option>  <option  value="520">Kosi Kalan</option>  <option  value="521">Kot Kapura</option>  <option  value="522">Kota</option>  <option  value="523">Kottagudem</option>  <option  value="524">Kottayam</option>  <option  value="525">Kovilpatti</option>  <option  value="526">Koyampattur</option>  <option  value="527">Koyilandi</option>  <option  value="528">Kozhikkod</option>  <option  value="529">Krishnagiri</option>  <option  value="530">Krishnanagar</option>  <option  value="531">Krishnarajapura</option>  <option  value="532">Kuchaman</option>  <option  value="533">Kukatpalle</option>  <option  value="534">Kulti</option>  <option  value="535">Kumarapalaiyam</option>  <option  value="536">Kumbakonam</option>  <option  value="537">Kundla</option>  <option  value="538">Kuniyamuthur</option>  <option  value="539">Kunnamkulam</option>  <option  value="540">Kurichi</option>  <option  value="541">Ladnun</option>  <option  value="542">Laharpur</option>  <option  value="543">Lakhimpur</option>  <option  value="544">Lakhimpur</option>  <option  value="545">Lakhisarai</option>  <option  value="546">Lakhnau</option>  <option  value="547">Lakhnau Cantonment</option>  <option  value="548">Lalbahadur Nagar</option>  <option  value="549">Lalitpur</option>  <option  value="550">Lanka</option>  <option  value="551">Latur</option>  <option  value="552">Lohardaga</option>  <option  value="553">Lonavale</option>  <option  value="554">Loni</option>  <option  value="555">Ludhiana</option>  <option  value="556">Lunglei</option>  <option  value="557">Machilipatnam</option>  <option  value="558">Madgaon</option>  <option  value="559">Madhavaram</option>  <option  value="560">Madhipura</option>  <option  value="561">Madhubani</option>  <option  value="562">Madhyamgram</option>  <option  value="563">Madras</option>  <option  value="564">Madurai</option>  <option  value="565">Maduravoyal</option>  <option  value="566">Mahadevapura</option>  <option  value="567">Mahbubnagar</option>  <option  value="568">Maheshtala</option>  <option  value="569">Mahoba</option>  <option  value="570">Mahuva</option>  <option  value="571">Mainpuri</option>  <option  value="572">Maisuru</option>  <option  value="573">Makrana</option>  <option  value="574">Malappuram</option>  <option  value="575">Malaut</option>  <option  value="576">Malegaon</option>  <option  value="577">Maler Kotla</option>  <option  value="578">Malkajgiri</option>  <option  value="579">Malkapur</option>  <option  value="580">Mancheral</option>  <option  value="581">Mandamarri</option>  <option  value="582">Mandidip</option>  <option  value="583">Mandoli</option>  <option  value="584">Mandsaur</option>  <option  value="585">Mandya</option>  <option  value="586">Mangalagiri</option>  <option  value="587">Mangaluru</option>  <option  value="588">Mango</option>  <option  value="589">Mangrol</option>  <option  value="590">Manjeri</option>  <option  value="591">Manmad</option>  <option  value="592">Mannargudi</option>  <option  value="593">Mansa</option>  <option  value="594">Markapur</option>  <option  value="595">Masaurhi</option>  <option  value="596">Mathura</option>  <option  value="597">Mau</option>  <option  value="598">Mau</option>  <option  value="599">Mauranipur</option>  <option  value="600">Mawana</option>  <option  value="601">Mayiladuthurai</option>  <option  value="602">Memari</option>  <option  value="603">Mettupalayam</option>  <option  value="604">Mettur</option>  <option  value="605">Midnapur</option>  <option  value="606">Mira Bhayandar</option>  <option  value="607">Mirat</option>  <option  value="608">Mirat Cantonment</option>  <option  value="609">Miryalaguda</option>  <option  value="610">Mirzapur</option>  <option  value="611">Mithe Pur</option>  <option  value="612">Modasa</option>  <option  value="613">Modinagar</option>  <option  value="614">Moga</option>  <option  value="615">Mohali</option>  <option  value="616">Mokama</option>  <option  value="617">Molarband</option>  <option  value="618">Moradabad</option>  <option  value="619">Morena</option>  <option  value="620">Mormugao</option>  <option  value="621">Morvi</option>  <option  value="622">Motihari</option>  <option  value="623">Mubarakpur</option>  <option  value="624">Mughal Sarai</option>  <option  value="625">Mumbai</option>  <option  value="626">Mundka</option>  <option  value="627">Munger</option>  <option  value="628">Muradnagar</option>  <option  value="629">Murwara</option>  <option  value="630">Mustafabad</option>  <option  value="631">Muzaffarnagar</option>  <option  value="632">Muzaffarpur</option>  <option  value="633">Nadiad</option>  <option  value="634">Nagaon</option>  <option  value="635">Nagapattinam</option>  <option  value="636">Nagaur</option>  <option  value="637">Nagda</option>  <option  value="638">Nagercoil</option>  <option  value="639">Nagina</option>  <option  value="640">Nagpur</option>  <option  value="641">Naihati</option>  <option  value="642">Najibabad</option>  <option  value="643">Nalasopara</option>  <option  value="644">Nalgonda</option>  <option  value="645">Namakkal</option>  <option  value="646">Nanded</option>  <option  value="647">Nandurbar</option>  <option  value="648">Nandyal</option>  <option  value="649">Nangloi Jat</option>  <option  value="650">Narasapur</option>  <option  value="651">Narasaraopet</option>  <option  value="652">Narnaul</option>  <option  value="653">Narwana</option>  <option  value="654">Nashik</option>  <option  value="655">Navadwip</option>  <option  value="656">Navagam Ghed</option>  <option  value="657">Navghar</option>  <option  value="658">Navi Mumbai</option>  <option  value="659">Navi Mumbai</option>  <option  value="660">Navsari</option>  <option  value="661">Nawabganj</option>  <option  value="662">Nawada</option>  <option  value="663">Nawalgarh</option>  <option  value="664">Nedumangad</option>  <option  value="665">Nellur</option>  <option  value="666">Nerkunram</option>  <option  value="667">Neyveli</option>  <option  value="668">Neyyattinkara</option>  <option  value="669">Ni Barakpur</option>  <option  value="670">Ni Dilli</option>  <option  value="671">Nimach</option>  <option  value="672">Nimbahera</option>  <option  value="673">Nipani</option>  <option  value="674">Nirmal</option>  <option  value="675">Nizamabad</option>  <option  value="676">Noida</option>  <option  value="677">Nokha</option>  <option  value="678">North Barakpur</option>  <option  value="679">North Dum Dum</option>  <option  value="680">Nuzvid</option>  <option  value="681">Obra</option>  <option  value="682">Old Maldah</option>  <option  value="683">Ongole</option>  <option  value="684">Orai</option>  <option  value="685">Osmanabad</option>  <option  value="686">Ozhukarai</option>  <option  value="687">Palakkad</option>  <option  value="688">Palakollu</option>  <option  value="689">Palasa</option>  <option  value="690">Palghar</option>  <option  value="691">Pali</option>  <option  value="692">Palitana</option>  <option  value="693">Pallavaram</option>  <option  value="694">Pallichal</option>  <option  value="695">Palwal</option>  <option  value="696">Palwancha</option>  <option  value="697">Pammal</option>  <option  value="698">Panaji</option>  <option  value="699">Panchkula</option>  <option  value="700">Pandharpur</option>  <option  value="701">Panihati</option>  <option  value="702">Panipat</option>  <option  value="703">Pannuratti</option>  <option  value="704">Paradwip</option>  <option  value="705">Paramakkudi</option>  <option  value="706">Parbhani</option>  <option  value="707">Patan</option>  <option  value="708">Patancheru</option>  <option  value="709">Pathankot</option>  <option  value="710">Patiala</option>  <option  value="711">Patna</option>  <option  value="712">Pattanagere</option>  <option  value="713">Pattukkottai</option>  <option  value="714">Payyannur</option>  <option  value="715">Phagwara</option>  <option  value="716">Phaltan</option>  <option  value="717">Phulia</option>  <option  value="718">Phulwari</option>  <option  value="719">Phusro</option>  <option  value="720">Piduguralla</option>  <option  value="721">Pilibhit</option>  <option  value="722">Pilkhuwa</option>  <option  value="723">Pimpri</option>  <option  value="724">Pithampur</option>  <option  value="725">Pithoragarh</option>  <option  value="726">Pollachi</option>  <option  value="727">Pondicherry</option>  <option  value="728">Ponnani</option>  <option  value="729">Ponnur</option>  <option  value="730">Porbandar</option>  <option  value="731">Port Blair</option>  <option  value="732">Proddatur</option>  <option  value="733">Pudukkottai</option>  <option  value="734">Pujali</option>  <option  value="735">Pul Pehlad</option>  <option  value="736">Puliyankudi</option>  <option  value="737">Puna</option>  <option  value="738">Punamalli</option>  <option  value="739">Pune</option>  <option  value="740">Pune Cantonment</option>  <option  value="741">Puri</option>  <option  value="742">Purnia</option>  <option  value="743">Puruliya</option>  <option  value="744">Pusad</option>  <option  value="745">Puth Kalan</option>  <option  value="746">Puttur</option>  <option  value="747">Qutubullapur</option>  <option  value="748">Rabkavi</option>  <option  value="749">Rae Bareli</option>  <option  value="750">Raghogarh</option>  <option  value="751">Raichur</option>  <option  value="752">Raiganj</option>  <option  value="753">Raigarh</option>  <option  value="754">Raipur</option>  <option  value="755">Rajamahendri</option>  <option  value="756">Rajampet</option>  <option  value="757">Rajapalaiyam</option>  <option  value="758">Rajendranagar</option>  <option  value="759">Rajkot</option>  <option  value="760">Rajnandgaon</option>  <option  value="761">Rajpur</option>  <option  value="762">Rajpura</option>  <option  value="763">Rajsamand</option>  <option  value="764">Ramachandrapuram</option>  <option  value="765">Ramagundam</option>  <option  value="766">Ramanagaram</option>  <option  value="767">Ramanathapuram</option>  <option  value="768">Ramgarh</option>  <option  value="769">Ramgarh Nagla Kothi</option>  <option  value="770">Ramod</option>  <option  value="771">Rampur</option>  <option  value="772">Rampur Hat</option>  <option  value="773">Ranaghat</option>  <option  value="774">Ranchi</option>  <option  value="775">Ranibennur</option>  <option  value="776">Raniganj</option>  <option  value="777">Ranip</option>  <option  value="778">Ratangarh</option>  <option  value="779">Rath</option>  <option  value="780">Ratlam</option>  <option  value="781">Ratnagiri</option>  <option  value="782">Raurkela</option>  <option  value="783">Raurkela Industrial Township</option>  <option  value="784">Raxaul</option>  <option  value="785">Rayachoti</option>  <option  value="786">Rayadrug</option>  <option  value="787">Rayagada</option>  <option  value="788">Renukut</option>  <option  value="789">Rewa</option>  <option  value="790">Rewari</option>  <option  value="791">Rishikesh</option>  <option  value="792">Rishra</option>  <option  value="793">Robertsonpet</option>  <option  value="794">Rohtak</option>  <option  value="795">Roshan Pura</option>  <option  value="796">Rudrapur</option>  <option  value="797">Rupnagar</option>  <option  value="798">Rurki</option>  <option  value="799">Sadat Pur Gujran</option>  <option  value="800">Sagar</option>  <option  value="801">Sagar</option>  <option  value="802">Saharanpur</option>  <option  value="803">Saharsa</option>  <option  value="804">Sahaswan</option>  <option  value="805">Sahibganj</option>  <option  value="806">Salem</option>  <option  value="807">Samalkot</option>  <option  value="808">Samana</option>  <option  value="809">Samastipur</option>  <option  value="810">Sambalpur</option>  <option  value="811">Sambhal</option>  <option  value="812">Sandila</option>  <option  value="813">Sangareddi</option>  <option  value="814">SangliMiraj</option>  <option  value="815">Sangrur</option>  <option  value="816">Sankarankoil</option>  <option  value="817">Sardarshahr</option>  <option  value="818">Sarni</option>  <option  value="819">Sasaram</option>  <option  value="820">Satara</option>  <option  value="821">Satna</option>  <option  value="822">Sattenapalle</option>  <option  value="823">Saunda</option>  <option  value="824">Sawai Madhopur</option>  <option  value="825">Sehore</option>  <option  value="826">Sendhwa</option>  <option  value="827">Seoni</option>  <option  value="828">Serilungampalle</option>  <option  value="829">Shahabad</option>  <option  value="830">Shahabad</option>  <option  value="831">Shahada</option>  <option  value="832">Shahdol</option>  <option  value="833">Shahjahanpur</option>  <option  value="834">Shahpur</option>  <option  value="835">Shajapur</option>  <option  value="836">Shamli</option>  <option  value="837">Shantipur</option>  <option  value="838">Shegaon</option>  <option  value="839">Sheopur</option>  <option  value="840">Sherkot</option>  <option  value="841">Shikohabad</option>  <option  value="842">Shiliguri</option>  <option  value="843">Shillong</option>  <option  value="844">Shimla</option>  <option  value="845">Shimoga</option>  <option  value="846">Shirpur</option>  <option  value="847">Shivapuri</option>  <option  value="848">Sholapur</option>  <option  value="849">Shorapur</option>  <option  value="850">Shrirampur</option>  <option  value="851">Shrirampur</option>  <option  value="852">Sibsagar</option>  <option  value="853">Siddhapur</option>  <option  value="854">Siddipet</option>  <option  value="855">Sidhi</option>  <option  value="856">Sidlaghatta</option>  <option  value="857">Sihor</option>  <option  value="858">Sikandarabad</option>  <option  value="859">Sikandarabad</option>  <option  value="860">Sikar</option>  <option  value="861">Silchar</option>  <option  value="862">Sillod</option>  <option  value="863">Sindari</option>  <option  value="864">Singrauli</option>  <option  value="865">Sira</option>  <option  value="866">Sirhind</option>  <option  value="867">Sirsa</option>  <option  value="868">Sirsi</option>  <option  value="869">Sirsilla</option>  <option  value="870">Sitamarhi</option>  <option  value="871">Sitapur</option>  <option  value="872">Siuri</option>  <option  value="873">Sivakasi</option>  <option  value="874">Siwan</option>  <option  value="875">Sonipat</option>  <option  value="876">Sopur</option>  <option  value="877">South Dum Dum</option>  <option  value="878">Srikakulam</option>  <option  value="879">Srikalahasti</option>  <option  value="880">Srinagar</option>  <option  value="881">Srivilliputtur</option>  <option  value="882">Sujangarh</option>  <option  value="883">Sukhmalpur Nizamabad</option>  <option  value="884">Sultanpur</option>  <option  value="885">Sultanpur Majra</option>  <option  value="886">Sunabeda</option>  <option  value="887">Sunam</option>  <option  value="888">Supaul</option>  <option  value="889">Surat</option>  <option  value="890">Suratgarh</option>  <option  value="891">Surendranagar</option>  <option  value="892">Suriapet</option>  <option  value="893">Tadepalle</option>  <option  value="894">Tadepallegudem</option>  <option  value="895">Tadpatri</option>  <option  value="896">Tajpul</option>  <option  value="897">Talipparamba</option>  <option  value="898">Tambaram</option>  <option  value="899">Tanda</option>  <option  value="900">Tandur</option>  <option  value="901">Tanuku</option>  <option  value="902">Tarn Taran</option>  <option  value="903">Tenali</option>  <option  value="904">Tenkasi</option>  <option  value="905">Tezpur</option>  <option  value="906">Thalassery</option>  <option  value="907">Thaltej</option>  <option  value="908">Thana</option>  <option  value="909">Thanesar</option>  <option  value="910">Thanjavur</option>  <option  value="911">Theni Allinagaram</option>  <option  value="912">Thiruthangal</option>  <option  value="913">Thiruvananthapuram</option>  <option  value="914">Thiruvarur</option>  <option  value="915">Thrippunithura</option>  <option  value="916">Thrissur</option>  <option  value="917">Thuthukkudi</option>  <option  value="918">Tigri</option>  <option  value="919">Tikamgarh</option>  <option  value="920">Tilhar</option>  <option  value="921">Tindivanam</option>  <option  value="922">Tinsukia</option>  <option  value="923">Tiptur</option>  <option  value="924">Tiruchchirappalli</option>  <option  value="925">Tiruchengode</option>  <option  value="926">Tirunelveli</option>  <option  value="927">Tirupathur</option>  <option  value="928">Tirupati</option>  <option  value="929">Tiruppur</option>  <option  value="930">Tirur</option>  <option  value="931">Tiruvalla</option>  <option  value="932">Tiruvannamalai</option>  <option  value="933">Tiruvottiyur</option>  <option  value="934">Titagarh</option>  <option  value="935">Tohana</option>  <option  value="936">Tonk</option>  <option  value="937">Tumkur</option>  <option  value="938">Tundla</option>  <option  value="939">Tuni</option>  <option  value="940">Tura</option>  <option  value="941">Udagamandalam</option>  <option  value="942">Udaipur</option>  <option  value="943">Udgir</option>  <option  value="944">Udhampur</option>  <option  value="945">Udumalaipettai</option>  <option  value="946">Udupi</option>  <option  value="947">Ujhani</option>  <option  value="948">Ujjain</option>  <option  value="949">Ulhasnagar</option>  <option  value="950">Ullal</option>  <option  value="951">Ulubaria</option>  <option  value="952">Una</option>  <option  value="953">Unjha</option>  <option  value="954">Unnao</option>  <option  value="955">Upleta</option>  <option  value="956">Uppal Kalan</option>  <option  value="957">Uran Islampur</option>  <option  value="958">UttarparaKotrung</option>  <option  value="959">Vadakara</option>  <option  value="960">Vadodara</option>  <option  value="961">Valparai</option>  <option  value="962">Valsad</option>  <option  value="963">Vaniyambadi</option>  <option  value="964">Vapi</option>  <option  value="965">Varanasi</option>  <option  value="966">Vasai</option>  <option  value="967">Vastral</option>  <option  value="968">Vejalpur</option>  <option  value="969">Velampalaiyam</option>  <option  value="970">Velluru</option>  <option  value="971">Veraval</option>  <option  value="972">Vidisha</option>  <option  value="973">Vijalpor</option>  <option  value="974">Vijayawada</option>  <option  value="975">Viluppuram</option>  <option  value="976">Vinukonda</option>  <option  value="977">Virappanchatram</option>  <option  value="978">Virar</option>  <option  value="979">Virudhachalam</option>  <option  value="980">Virudunagar</option>  <option  value="981">Visakhapatnam</option>  <option  value="982">Visnagar</option>  <option  value="983">Vizianagaram</option>  <option  value="984">Vrindavan</option>  <option  value="985">Vuyyuru</option>  <option  value="986">Wadhwan</option>  <option  value="987">Wadi</option>  <option  value="988">Wani</option>  <option  value="989">Wanparti</option>  <option  value="990">Warangal</option>  <option  value="991">Wardha</option>  <option  value="992">Warud</option>  <option  value="993">Washim</option>  <option  value="994">Wokha</option>  <option  value="995">Yadgir</option>  <option  value="996">Yamunanagar</option>  <option  value="997">Yavatmal</option>  <option  value="998">Yelahanka</option>  <option  value="999">Yemmiganur</option>  <option  value="1000">Ziauddin Pur</option>                
                                          </select> </div>
       <div class="col-md-2"> <button type="submit" class="btn btn-info" style=" wwidth=:100%; padding: 8px 32px; margin-left: -10px; font-size: 16px;">Search</button> </div>
        <div  class="pull-center col-md-10" id="countryList1" style="font-size: 16px; font-family: Helvetica"></div>
      </form>

</div>
<div class="col-md-3"></div>
</div>
<div class="col-md-12" style="background:#F4F4F4; height: 50px; mmargin-top: 10px;"><center><h3 style="color: black;"><strong>Search Results</strong></h3></center></div>

<div class="col-md-12 filter_data" style="background: #F4F4F4;">

<div class="col-md-3" style="background: white; hheight: auto; margin-bottom:  20px; width: 20%; border: 1px solid lightgray">

  <div style="margin-top: 10px;">
  <p style="background: #f2f2f2; border: 1px solid lightgray; padding: 10px; font-size: 15px;"><b>Filter Your Search</b></p>
</div>
  <div class="list-group" style="border: 1px solid lightgray; width: 100%; top: 0px;">
     <h5 style="padding:10px; "><b>Fee</b></h5>
     <div class="checkbox " style="margin-left: 0px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="0.0, 100000.00"> >1 Lakh </label>
      </p></div>
      <div class="checkbox " style="margin-left: 0px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="100000, 200000">  1-2Lakh </label>
      </p></div>
      <div class="checkbox " style="margin-left: 00px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" value="200000, 300000" name="fee">  2-3Lakh </label>
      </p></div><div class="checkbox " style="margin-left: 00px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" value="300000, 400000" name="fee">  3-4Lakh </label>
      </p></div><div class="checkbox " style="margin-left: 0px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="400000, 500000"> > 5Lakh </label>
      </p></div>      

     <!-- <input type="hidden" id="hidden_minimum_price" value="0" />
                    <input type="hidden" id="hidden_maximum_price" value="65000" />
                    <p id="price_show">1000 - 65000</p>
                    <div id="price_range"></div> -->
                </div>  

                <!-- <div data-role="rangeslider">
        <label for="price-min">Price:</label>
        <input type="range" name="price-min" id="price-min" value="200" min="0" max="1000">
        <label for="price-max">Price:</label>
        <input type="range" name="price-max" id="price-max" value="800" min="0" max="1000">
      </div> -->
  
    <div style="border:1px solid lightgray; margin-top: -10px;">
    <h5 style="padding:10px; "><b>Location</b></h5>
    <input iid="myInput" class="myInput" type="text" placeholder="Search Location" style="padding: 8px;  width: 90%; margin: 10px; ">
    <div iid="locFil" class="locFil" > 
    
    <br>
  <!--FIlter Location -->

    <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl ">
      <input  type="checkbox" class="common_selector brand" value="242">Delhi(1)</label>
      </p></div><div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl ">
      <input  type="checkbox" class="common_selector brand" value="676">Noida(1)</label>
      </p></div></div>
  </div>
  
  <div style="border: 1px solid lightgray; margin-top: 10px;" >
    <h5 style="padding:10px; "><b>Couese</b></h5>
    <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="18">B.Tech</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="12">M.Tech</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="11">MBA</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="13">MBBS</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="17">BBA</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="19">BCA</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="20">MCA</label>
      </p></div>
  </div >
  <!-- Stream Section-->
  <!-- <div  id=style-1" sstyle="overflow-y: scroll;max-height: 150px;">
    <h5 style="padding:10px; "> <b>Stream</b> </h5>
    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Engineering

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Science

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Business and Management Studies

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      IT and Software

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Medicine and Health Science

    </p></div>
    </div> -->
  

    <!-- <a href="https://www.searchurcollege.com/exams/mat-details"><img src="https://www.searchurcollege.com/exams/img/exams/MAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/cmat-details"><img src="https://www.searchurcollege.com/exams/img/exams/CMAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/iift-details"><img src="https://www.searchurcollege.com/exams/img/exams/IIFT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/atma-details"><img src="https://www.searchurcollege.com/exams/img/engineering/JEEMAIN.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/nmat-details"><img src="https://www.searchurcollege.com/exams/img/engineering/GATE.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/atma-details"><img src="https://www.searchurcollege.com/exams/img/law/CLAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/nmat-details"><img src="https://www.searchurcollege.com/exams/img/law/AILET.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>  -->

</div >
<div class="col-md-9" style="bbackground: grey; hheight: auto;">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.1.0/css/font-awesome.min.css"/>

            <div class="wwell col-md-12 " style="background: white;height: 22%; margin-bottom: 20px; padding: 10px padding-left: 15px;  border:1px solid #D3D3D3; ">
              <form target="_blank" action="demo.php" method="post"> 
              <label style="position:absolute; right:0px; color:black;">Compare
             <input type="checkbox" name="Compare" class="largerCheckbox"  style="hheight:20px; margin-right:10px;">
             </label>
                  <input type="hidden" name="resultCol" value="2" />
                  <input type="hidden" name="resultColName" value="Shri Ram College of Commerce" />
                  <div class="mmedia col-md-2" style="bbackground: red;">
                    <button type="submit" style="background: transparent; border: 0px;"><img cclass="img-thumbnail"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/col__2.jpg" sstyle="margin-left: -30px; ppadding-right: 10px; min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px;" style="position:absolute; top:0px; left:-13px; height:125px; width: 150px;"/></button>
                  </div>
                <div class="mmedia-body col-md-10" style="bbackground: yellow; mmargin-left:-20px; margin-top: 10px;">
                 <h4 class="memdia-heading" style="color:black; font-family: system-ui; "> <button type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left">Shri Ram College of Commerce                 </button></h4><p style="font-size :14px; color:#696969;">   &nbsp &nbsp&nbsp<i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp Delhi,Delhi                   &nbsp| &nbsp&nbsp<i class="fa fa-university" aria-hidden="true"></i>&nbsp DU                   
                    &nbsp| &nbsp&nbsp Courses: 5&nbsp &nbsp| &nbsp Rating <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i> <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i> <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i> <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i> <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i>                   </p> <p style="color:#696969; font-size:14px;" > &nbsp Ownership :&nbsp  Goverment                  &nbsp |  &nbsp Established &nbsp2018&nbsp|  &nbsp AICTE Approval  <i class="fa fa-info-circle" aria-hidden="true"></i></p> <img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_2_10.jpg" title="Library"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_2_11.jpg" title="Cafeteria"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_2_12.jpg" title="Hostel"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_2_13.jpg" title="Sports Complex"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_2_14.jpg" title="Labs"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_2_15.jpg" title="Wi-Fi Campus"> &nbsp                  
             </div>
            </form>
          </div>
       
            <div class="wwell col-md-12 " style="background: white;height: 22%; margin-bottom: 20px; padding: 10px padding-left: 15px;  border:1px solid #D3D3D3; ">
              <form target="_blank" action="demo.php" method="post"> 
              <label style="position:absolute; right:0px; color:black;">Compare
             <input type="checkbox" name="Compare" class="largerCheckbox"  style="hheight:20px; margin-right:10px;">
             </label>
                  <input type="hidden" name="resultCol" value="8" />
                  <input type="hidden" name="resultColName" value="CII School of Logistic " />
                  <div class="mmedia col-md-2" style="bbackground: red;">
                    <button type="submit" style="background: transparent; border: 0px;"><img cclass="img-thumbnail"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/col_8.jpg" sstyle="margin-left: -30px; ppadding-right: 10px; min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px;" style="position:absolute; top:0px; left:-13px; height:125px; width: 150px;"/></button>
                  </div>
                <div class="mmedia-body col-md-10" style="bbackground: yellow; mmargin-left:-20px; margin-top: 10px;">
                 <h4 class="memdia-heading" style="color:black; font-family: system-ui; "> <button type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left">CII School of Logistic                  </button></h4><p style="font-size :14px; color:#696969;">   &nbsp &nbsp&nbsp<i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp Noida,Uttar Pradesh                   &nbsp| &nbsp&nbsp<i class="fa fa-university" aria-hidden="true"></i>&nbsp Amity University                   
                    &nbsp| &nbsp&nbsp Courses: 2                   </p> <p style="color:#696969; font-size:14px;" > &nbsp Ownership :&nbsp  Private                  &nbsp &nbsp</p> <img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_30.png" title="Library"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_31.png" title="Wi-fi"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_32.png" title="Labs"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_33.png" title="Medical Facility"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_34.png" title="Auditorium"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_35.png" title="Gym"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_36.png" title="Auditorium"> &nbsp<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/facility_8_38.png" title="Sports"> &nbsp                  
             </div>
            </form>
          </div>
         <script type="text/javascript">
    </script>


</div>


</div>





<input type="hhidden" name="" class="college_like" value="bba">
<input type="hidden" name="" class="c_id" value="2, 8, ">
<div style="margin-top: ">
<script>
$(function() {
        $(this).bind("contextmenu", function(e) {
            e.preventDefault();
        });
    });
</script>

<style type="text/css">
    .footer-bottom {
    padding: 0px 0 0px;
    border-top: 1px solid #666;
    background: #1e1e1e;
   
}
.copyright-text p {
    color: #ccc;
    margin-top: 9px;
    margin-bottom: 0;
}
.social-link li {
    display: inline-block;
    margin: 0 5px;
}
.social-link li a {
    color: #ccc;
    border: 1px solid #ccc;
    width: 40px;
    height: 40px;
    line-height: 40px;
    border-radius: 50%;
    text-align: center;
    display: inline-block;
    font-size: 20px;
    transition: .5s;
    padding-top: 6px;
    padding-left: 6px;
    padding-right: 6px;
    padding-bottom: 6px;
}    

}
</style>
<link href="https://fonts.googleapis.com/css?family=Karla" rel="stylesheet"> 

<!--<link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro" rel="stylesheet"> 
 <link href="https://fonts.googleapis.com/css?family=Abel|PT+Sans+Narrow|Source+Sans+Pro" rel="stylesheet"> -->
<style> 
body{
  /*   font-family: 'Source Serif Pro', serif;
   font-family: 'PT Sans Narrow', sans-serif; */ 
   font-family: 'Karla', sans-serif;
}
</style>
<div class="clearfix" ></div>
        <div class="footer-bottom" style="margin-top: 0px;">
           <div class="container">
	      <div class="row">
		<div class="col-sm-9">							
			<p><ul class="list-inline form-control" style="background:transparent; border:#000000; padding-left: 5px; margin-top: 8px; ">
				<li><a href="https://www.searchurcollege.com/about/about-us.php"><font color="white">About Us</font></a></li>
                <li><a href="#"><font color="white">Add Colleges</font></a></li>
				<li><a href="#"><font color="white">Advertise With Us</font></a></li>
				<li><a href="#"><font color="white">College Login</font></a></li>
				<li><a href="https://www.searchurcollege.com/privacy_policy.php"><font color="white">Privacy Policy</font></a></li>
				<li><a href="https://www.searchurcollege.com/terms_conditions.php"><font color="white">Terms & Conditions</font></a></li>
				<!--<li><a href="#"><font color="white">Sitemap</font></a></li>-->
                <li><a href="https://www.searchurcollege.com/contact/contactus.php"><font color="white">Contact</font></a></li>
			   </ul></p>								
		</div>
                <div class="col-md-3 footer-ns animated fadeInRight" style="padding-top: 5px;">
                   <!--<p>
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Newsletter">
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="button"><span class="glyphicon glyphicon-envelope"></span></button>
                      </span>
                    </div><!-- /input-group -->
                 <!--</p>-->
            </div>                    
				<!-- End Col -->
		</div>
		</div>
                </div>		
<div class="footer-bottom">
<div class="container" style="padding: 0px 10px 0px 10px;">
		<div class="row" style="padding: 0px 10px 0px 10px;">
			<div class="col-sm-5">
				<div class="copyright-text" style="color: #fff!important;">
					Copyright &copy; 2018 - Searchurcollege - All Rights Reserved<br /><a href="https://www.searchurcollege.com/sitemap.xml" target="_blank">Sitemap</a>
				</div>
			</div>
							<!-- End Col -->
				<div class="col-sm-7 text-right">
                           <ul class="social-link">
				<li><font color="white">Connect with us</font></li>
				<li><a href="https://www.facebook.com/searchurcollege/" target="_blank"><font color="white"><i class="fab fa-facebook-f"></i></font></a></li>						
				<li><a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
				<!--<li><a href=""><span class="fa fa-twitter"></span></a></li>-->
			  </ul>							
				</div> <!-- End Col -->
					</div>
				</div>
</div>	
    <div class="clearfix"></div>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
  $(".myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".locFil div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
$(document).ready(function(){

    //filter_data();

    function filter_data()
    {
      alert("x");
     // alert($(".brand").val());
        // $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var brand = get_filter('brand');
         alert(brand)
         var c_id = $('.c_id').val();
         var loc_name=$('.location_name').val();
         
         var college_like = $('.college_like').val();
         //alert(college_like)
         //alert(college_like);
        var fee=get_filter('fee');
        //alert(fee);
        var course=get_filter('course');
        //alert(course);
        var ram = get_filter('ram');
        var storage = get_filter('storage');
        $.ajax({
            url:"../filter/fetch_data1.php",
            method:"POST",
            data:{action:action,fee:fee, brand:brand, loc_name:loc_name ,college_like:college_like, c_id:c_id, course:course,storage:storage},
            success:function(data){
                    //alert(data);
                if(data!="")
                  $('.filter_data').html(data);
                $('.myInput').val("");
            }
        });
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            //alert($(this))
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function(){
        filter_data();
    });

    $('#price_range').slider({
        range:true,
        min:1000,
        max:65000,
        values:[1000, 65000],
        step:500,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data();
        }
    });

});
</script>
<!-- <script type="text/javascript">
    $(document).ready(function(){
        $('input[type="checkbox"]').click(function(){
            if($(this).prop("checked") == true){
                alert($(this).val());
            }
            else if($(this).prop("checked") == false){
                alert("Checkbox is unchecked.");
            }
        });
    });
</script> -->
