<?php
include("../../connection/dbconnect");
if(isset($_REQUEST["country1"]))
{
  $colleLike=$_REQUEST["country1"];
  $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_name like '%$colleLike%' " ;
}
else
  $sql="SELECT uni_id,college_id ,college_name, college_image_path , college_desc ,college_location_id,college_type, college_establishment_dt , college_aicte_approved, college_no_of_courses FROM suc_college " ;

        //$sql="SELECT uni_id,college_id ,college_name FROM suc_college " ;
        $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
        {
            $uni_id=$row['uni_id'];
            $unisql="SELECT uni_name from suc_university where uni_id=$uni_id";
            $result1=$conn->query($unisql);
          while($row1=$result1->fetch_assoc())
            $uni_name=$row1["uni_name"];
           // $d=strip_tags($des);
           $c_name=$row["college_name"];
            $c_id=$row['college_id'];
            $c_desc=$row['college_desc'];
            $c_type=$row['college_type'];
            $c_location=$row['college_location_id'];
            $c_e_dt=$row['college_establishment_dt'];
            $c_e_dt=substr($c_e_dt, 0,4);
            if(substr($c_e_dt, 0,1)!="0")
            {
              $c_e_dt='|  &nbsp Established &nbsp'.$c_e_dt;
            }
            else
              $c_e_dt=""; 
            $c_aicte=$row['college_aicte_approved'];
            $c_no_courses=$row['college_no_of_courses'];
            $c_img=$row['college_image_path'];
            $sql2="SELECT college_rating from suc_college_rating where college_id=$c_id";
            $result2=$conn->query($sql2);
          while($row2=$result2->fetch_assoc())
             $rating=$row2["college_rating"];
          $sqlLocation="SELECT location_name,state from location where id=$c_location";
          $resultLocation=$conn->query($sqlLocation);
          while($rowLocation=$resultLocation->fetch_assoc()){
            $l_name=$rowLocation["location_name"];
            $l_state=$rowLocation["state"];
          }
          if($c_type=="1")
            $type="Goverment";
          else
            $type="Private";
          if($c_aicte=="1")
             $aprroval='|  &nbsp AICTE Approval  <i class="fa fa-info-circle" aria-hidden="true"></i>';
           else
             $aprroval='';
           
           ?>

            <div class="wwell col-md-12 filter_data" style="background: white;height: 22%; margin-bottom: 20px; padding: 10px padding-left: 15px;  border:1px solid #D3D3D3; ">
              <form target="_blank" action="demo.php" method="post"> 
              <label style="position:absolute; right:0px; color:black;">Compare
             <input type="checkbox" name="Compare" class="largerCheckbox"  style="hheight:20px; margin-right:10px;">
             </label>
                  <input type="hidden" name="resultCol" value="<?php echo $c_id;?>" />
                  <input type="hidden" name="resultColName" value="'.$c_name.'" />
                  <div class="mmedia col-md-2" style="bbackground: red;">
                    <button type="submit" style="background: transparent; border: 0px;"><img cclass="img-thumbnail"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/<?php echo $c_img ?>" sstyle="margin-left: -30px; ppadding-right: 10px; min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px;" style="position:absolute; top:0px; left:-13px; height:125px; width: 150px;"/></button>
                  </div>
                <div class="mmedia-body col-md-10" style="bbackground: yellow; mmargin-left:-20px; margin-top: 10px;">
                 <h4 class="memdia-heading" style="color:black; font-family: system-ui; "> <button type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left"><?php echo $c_name;?>
                 </button></h4><p style="font-size :14px; color:#696969;">   &nbsp &nbsp&nbsp<i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp <?php echo $l_name.','.$l_state;?>
                   &nbsp| &nbsp&nbsp<i class="fa fa-university" aria-hidden="true"></i>&nbsp <?php echo $uni_name; ?>
                   
                   &nbsp| &nbsp&nbsp Courses: <? echo $c_no_courses ;
                 if($rating>=1){
                  echo "&nbsp &nbsp| &nbsp Rating";
                 for($i=0;$i<$rating;$i++)
                 {
                  echo ' <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i>';
                 }}
                 $rating="";
                 ?>
                  </p> <p style="color:#696969; font-size:14px;" > &nbsp Ownership :&nbsp  <?php echo $type; ?>
                  &nbsp <?php echo $c_e_dt.'&nbsp'.$aprroval.'</p>';?> <?
                 $sqlfacilities="SELECT facility_name, facility_image_path from suc_college_facilities where college_id=$c_id";
                 $resultfacilities=$conn->query($sqlfacilities);
                 while($rowfacilities=$resultfacilities->fetch_assoc()){
                   $facility_name=$rowfacilities["facility_name"];
                  $facility_image_path=$rowfacilities["facility_image_path"];
                  echo '<img cclass="img-thumbnail " style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/'.$facility_image_path.'" title="'.$facility_name.'"> &nbsp';
                  }
                  ?>
                  
            </div>
            </form>
          </div>
       <? } ?>