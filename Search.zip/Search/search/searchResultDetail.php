<head>
	<?php
	if(isset($_REQUEST["resultColName"]))
		echo '<title>'.$_REQUEST["resultColName"].'</title>  ';
	?>
    
    <META NAME="Description" CONTENT="View Article on Searchurcollege."/>
    <META NAME="Keywords" CONTENT="Searchurcollege, Article, Ranking, Course, Exam, College, Scholarship"/>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<style >
  .example1 {
    /*border: .5px solid lightgray;
    
    box-shadow: 2px 2px blue;
    height: 120px;*/
}
.example2 {
    border: .5px solid lightgray;
    
    box-shadow: 1px 1px gray;
    height: 120px;
    width:100%;
}
.example1:hover
{
  background: #DCF2F3;
}
.gallery {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    wwidth: 180px;
}

.gallery:hover {
    border: 1px solid #777;
}

.gallery img {
    wwidth: 100%;
    hheight: auto;
}

.desc {
    padding: 15px;
    text-align: center;
}
</style>
  <div>  
<?php
    include('../connection/dbconnect.php');
    $useragent=$_SERVER['HTTP_USER_AGENT'];
    if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
        include('..connection/header3.php');
    else
        include('../connection/header1.php');
 ?>
 </div>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
if(isset($_REQUEST["resultCol"]))
{ 
  $resultCol=$_REQUEST["resultCol"];
        echo "&nbsp;";
       //$sql="SELECT uni_id,college_id ,college_name, college_image_path , college_desc FROM suc_college where college_id=$resultCol" ;
        $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_id=$resultCol" ;

        //$sql="SELECT uni_id,college_id ,college_name FROM suc_college " ;
        $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
        {
           $uni_id=$row['uni_id'];
            $unisql="SELECT uni_name from suc_university where uni_id=$uni_id";
            $result1=$conn->query($unisql);
          while($row1=$result1->fetch_assoc())
            $uni_name=$row1["uni_name"];
           // $d=strip_tags($des);
           $c_name=$row["college_name"];
            $c_id=$row['college_id'];
            $c_desc=$row['college_desc'];
            $c_type=$row['college_type'];
            $c_location=$row['college_location_id'];
            $c_e_dt=$row['college_establishment_dt'];
            $c_e_dt=substr($c_e_dt, 0,4);
            if(substr($c_e_dt, 0,1)!="0")
            {
              $c_e_dt='|  &nbsp Established &nbsp'.$c_e_dt;
            }
            else
              $c_e_dt=""; 
            $c_aicte=$row['college_aicte_approved'];
            $c_no_courses=$row['college_no_of_courses'];
            $c_img=$row['college_image_path'];
            $sql2="SELECT college_rating from suc_college_rating where college_id=$c_id";
            $result2=$conn->query($sql2);
          while($row2=$result2->fetch_assoc())
             $rating=$row2["college_rating"];
          $sqlLocation="SELECT location_name,state from location where id=$c_location";
          $resultLocation=$conn->query($sqlLocation);
          while($rowLocation=$resultLocation->fetch_assoc()){
            $l_name=$rowLocation["location_name"];
            $l_state=$rowLocation["state"];
          }
          if($c_type=="1")
            $type="Goverment";
          else
            $type="Private";
          if($c_aicte=="1")
             $aprroval='AICTE Approval  
                <i class="fa fa-info-circle " title="The All India Council for Technical Education (AICTE) is the statutory body and a national-level council for technical education, under Department of Higher Education, Ministry of Human Resource Development"> </i>
              ';

        }

}
else if($_REQUEST["resultUni"])
{
  echo 111;
}
?>
<div class="content-wrapper">
    <section class="content-header">
      <h1>
       
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div cclass="box">
        <div class="box-header with-border">
          
        </div>
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="box-body">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#Basic" data-toggle="tab">Basic Detail</a></li>
              <li><a href="#course" data-toggle="tab">Courses</a></li>
              <li><a href="#Place" data-toggle="tab">Placements</a></li>
               <li><a href="#review" data-toggle="tab">Review</a></li>
               <li><a href="#facility" data-toggle="tab">Facilities</a></li>
              <li><a href="#gallery" data-toggle="tab">Gallery</a></li>
              
              <li><a href="#Document" data-toggle="tab">Document</a></li>
              <li><a href="#Contact" data-toggle="tab">Contact</a></li>
             
              
            </ul>
            </nav>
            <div class="tab-content">
              <div class="active tab-pane" id="Basic">
                    <?php
                          $sql112="SELECT college_rating from suc_college_rating where college_id=$c_id";
                        $result112=$conn->query($sql112);
                      while($row112=$result112->fetch_assoc())
                         $rating=$row112["college_rating"];
                  //      echo '<div class="sswell col-md-12 img-thumbnail" style="bbackground: lightgray; margin-bottom: 10px; padding: 10px padding-left: 15px;  bborder:1px solid gray;">';
                  //      echo '<div class="mmedia col-md-2" style="bbackground: red;">
                  //   <button style="background: transparent; border: 0px;"><img class="img-thumbnail"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/'.$c_img.'" style="margin-left: -30px; padding-right: 10px; min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px;"/></button>
                  // </div>';
                  //      echo '</div>'; style="background:#F4F4F4;

                  echo '<div class="sswell col-md-12 " style="bbackground: #F4F4F4;">
                  <div class="mmedia col-md-2" style="bbackground: red;">
                    <img class="img-thumbnail"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/'.$c_img.'" style="   width:200px; height: 190px; "/>
                  </div>
                <div class="mmedia-body col-md-10" style="bbackground: yellow; mmargin-left:-20px;">
                <label for="Compare" style="position:absolute; right:0px;">Compare
                <input type="checkbox" style="position:absolute; height:20px; width:20px; right:10px;" name="vehicle1" value="Bike">
                </label>
                 <h5 class="memdia-heading" style="font-size:25px!important;"> <strong>'.strip_tags($c_name).'<sup>';
                 for($i=0;$i<$rating;$i++)
                 {
                  echo '<i class="fa fa-star" style="color:yellow;text-shadow:1px 1px black;" aria-hidden="true"></i>';
                 }
                 echo '('.$rating.')</sup></strong></h5><div style="align-left"><p style="font-size :14px; color:gray">   &nbsp &nbsp&nbsp<i class="fa fa-map-marker" style="color:red;" aria-hidden="true"></i>&nbsp<b>'.$l_name.'</b>,'.$l_state;
                 echo '  &nbsp'.$c_e_dt;
                 echo '  &nbsp| &nbsp&nbsp '.$type;
                 echo' </p></div><br><div style="align-left"><p style="color:black; font-size:18px;"><b> &nbsp Affiliated to </b>:&nbsp<a href="https://www.searchurcollege.com/img/dd/searchResultDetail.php?resultUni='.$uni_id.'">'.$uni_name.'</a>';
                 echo '  &nbsp &nbsp &nbsp &nbsp  &nbsp'.$aprroval.' </p> </div>';
                
                 echo' 
            </div>
            </form>
          </div>';

                        
                    ?>
              </div>
              <div class="tab-pane" id="course">
                    <?php
                      $os=array();
                      $oos=array();
                      $butC=array();
                      $butS=array();
                       $sql1="SELECT college_course_name, college_course_full_part, college_course_duration, college_course_fee_id,college_course_seats, master_course_id from suc_college_courses where college_id=$c_id";
                        $result1=$conn->query($sql1);
                        echo '<h3 style="padding:10px;">Courses Offered</h3><div class="col-md-12">';
                        $q=1;
                        while($row1=$result1->fetch_assoc())
                        {
                           //$course_count=$row1["c"];
                           $course_name=$row1["college_course_name"];
                           $course_type=$row1["college_course_full_part"];
                           $course_duration=$row1["college_course_duration"];
                           $course_fee=$row1["college_course_fee_id"];
                           $course_seats=$row1["college_course_seats"];
                           $master_course_id=$row1["master_course_id"];

                           $sqlCourseM="SELECT distinct course_cat_id, course_stream_id from suc_master_course where course_id=$master_course_id";
                           $resultCourseM=$conn->query($sqlCourseM);
                           while($rowCourseM=$resultCourseM->fetch_assoc())
                           {
                            if (in_array($rowCourseM["course_cat_id"], $os)) {
                               
                            }
                            else{
                              $os[]=$course_cat_id=$rowCourseM["course_cat_id"];
                              $sqlCourseM1="SELECT course_cat_name from suc_master_course_category where course_cat_id=$course_cat_id group by course_cat_id";
                            $resultCourseM1=$conn->query($sqlCourseM1);
                            while($rowCourseM1=$resultCourseM1->fetch_assoc())
                              $butC[]=$rowCourseM1["course_cat_name"];
                              //echo '<button class="btn btn-default>"'.$rowCourseM1["course_cat_name"].'</button>';
                           // echo '<button class="btn btn-default>"';
                            }
                            if (in_array($rowCourseM["course_stream_id"], $oos)) {
                               
                            }
                            else{
                            $oos[]=$course_stream_id=$rowCourseM["course_stream_id"];
               $sqlCourseM2="SELECT course_stream_name from suc_master_course_stream where course_stream_id=$course_stream_id";
                            $resultCourseM2=$conn->query($sqlCourseM2);
                            while($rowCourseM2=$resultCourseM2->fetch_assoc())
                               $butS[]=$rowCourseM2["course_stream_name"];
                           }
                           }
                           $sql2="SELECT cc_total_fee  from suc_college_course_fee_structure where cc_fee_id=$course_fee";
                           $result2=$conn->query($sql2);
                           while($row2=$result2->fetch_assoc())
                            $fee=$row2["cc_total_fee"];
                           echo '<div class="sswell col-md-3 img-thumbnail  example1" style="bbackground:red; min-height:120px; mmargin-bottom:30px;  bborder:1px solid lightgray;">
                               
                                  
                                 
                                <div  style="bbackground: yellow; mmargin-left:-20px;"> <br>
                                 <h4 class="memdia-heading" > <button type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left"><strong><u>'.$course_name.'</u></strong></button></h4><div style="align-left"><p style="font-size :14px; color:gray;"> '.$course_type.' &nbsp  | &nbsp    Course Duration:&nbsp'.$course_duration.'</p></div>
                            </div>
                            
                          </div>';

                          if($q%3==0)
                          {
                            //echo " dd";
                           // echo'<div class="row" style="margin-top:120px; "></div>';
                          }
                          $q++;
                        }
                        echo '<div class="col-md-12" style="bbackground:red; margin-top:30px;"> ';
                        echo '<div class="col-md-2" style="bbackground:red; width:11%;"><i class="align-center">Search By Course</i></div>
                        <div class="col-md-10" style="bbackground:yellow;">
                        ';
                        foreach ($butC as $b ) {

                          echo '<button class="btn btn-default " style="background:white; margin-right:15px; border:1px solid lightgrey">'.$b.'</button>';
                        }

                        echo '</div></div> ';
                       echo '<div class="col-md-12" style="bbackground:red; margin-top:10px;"> ';
                        echo '<div class="col-md-2" style="bbackground:red; width:11%;"><i class="align-center">Search By Stream</i></div>
                        <div class="col-md-10" style="bbackground:yellow;">
                        ';
                        foreach ($butS as $b1 ) {

                          echo '<button class="btn btn-dange" style="background:white; margin-right:15px; border:1px solid lightgrey">'.$b1.'</button>';
                        }

                        echo '</div></div><br><br>';

                        echo "</div>";  /// col-md-12 main div
                    ?>
              </div>
              <div class="tab-pane" id="Place">
                    <?php
                        //echo '<p style="padding:10px;"><br> Placement at <b>'.$c_name.'</b><br /><br /></p>';

                        $sqlPlace="SELECT id, college_top_recruiters, college_top_recruiters_logo_path, college_highest_placementmet, college_average_placement,college_lowest_placement from suc_college_other_details where college_id=$c_id";
                    $resultPlace=$conn->query($sqlPlace);
                    echo '<div class="col-md-12">';
                    while($rowPlace=$resultPlace->fetch_assoc())
                    {
                      $college_top_recruiters=$rowPlace["college_top_recruiters"];
                      $college_top_recruiters_logo_path=$rowPlace["college_top_recruiters_logo_path"];
                      $college_highest_placementmet=$rowPlace["college_highest_placementmet"];
                      $college_average_placement=$rowPlace["college_average_placement"];
                      $college_lowest_placement=$rowPlace["college_lowest_placement"];
                      $c_place_id=$rowPlace["id"];
                      echo '<div class="col-md-2 img-thumbnail"><center><img class="" style ="max-width: 100%; max-height:50px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/placements/'.$college_top_recruiters_logo_path.'" alt="'.$college_top_recruiters.'"> &nbsp';
                  echo '<p>'.$college_top_recruiters.'<center></p> </div>';
                  }
                  
                    
                  echo '</div>';
                        
                        
                    ?>
              </div>
              <div class="tab-pane" id="gallery">
                    <?php
                    $sqlgallery="SELECT college_gallery_desc, college_gallery_content_path from suc_college_gallery where college_id=$c_id";
                    $resultgallery=$conn->query($sqlgallery);
                    while($rowgallery=$resultgallery->fetch_assoc())
                    {
                      $college_gallery_desc=$rowgallery["college_gallery_desc"];
                       $college_gallery_content_path=$rowgallery["college_gallery_content_path"];
                      echo '<div class="gallery"><img src="https://www.searchurcollege.com/exam/admin/search/gallery/'.$college_gallery_content_path.'"  wwidth="100%" height="150"><div class="desc">'.$college_gallery_desc.'</div></div>';
                    }
                     //$cc="https://www.searchurcollege/exam/admin/search/gallery/college/gallery/college/facility/facility_".$c_id.'*.*';
                    
                    ?>
              </div>
              <div class="tab-pane" id="review">
                    <?php
                    $queryReviews="SELECT college_review_date, college_review_user,college_review_comment,college_review_likes from suc_college_reviews where college_id=$c_id";
                       echo '<h3 style="margin-left:20px;margin-top:20px; bbackground:lightgray;">Reviews  <i class="fa fa-comment" aria-hidden="true"></i></h3>';   
                       $resultReview=$conn->query($queryReviews);
                        while($rowReview=$resultReview->fetch_assoc())
                        {
                           $college_review_user=$rowReview["college_review_user"];
                           $college_review_date=$rowReview["college_review_date"];
                           $college_review_comment=$rowReview["college_review_comment"];
                           $college_review_likes=$rowReview["college_review_likes"];
                           echo '<div style="padding:20px;">
                           <div>
                           <blockquote><q style="font-size:15px;">'.$college_review_comment.'</q></blockquote>
                           <strong><p style="font-size:20px; color:blue; margin-top:-15px;">'.$college_review_user.' </p></strong> <small><i class="fa fa-thumbs-up" style="color:skyblue;" aria-hidden="true"></i> ('.$college_review_likes.')</small> &nbsp  &nbsp
                           '.$college_review_date.'
                           
                            </div>
                           </div>';
                         }
                    ?>
              </div>
              <div class="tab-pane" id="Contact">
                    <?php
                    //echo "contact";
                   $sqlContact="SELECT college_address, college_website, college_phone_1,college_phone_2,college_email from suc_college_contacts where college_id=$c_id";
                    $resultContact=$conn->query($sqlContact);
                     while($rowContact=$resultContact->fetch_assoc())
                     {
                      $college_address=$rowContact["college_address"];
                      $college_website=$rowContact["college_website"];
                      $college_phone_1=$rowContact["college_phone_1"];
                      $college_phone_2=$rowContact["college_phone_2"];
                      $college_email=$rowContact["college_email"];

                     }
                     echo '<div class="sswell col-md-12" style="background: white; margin-bottom: 10px; padding: 10px">
                           <div class="sswell col-md-10">
                                     <div class="mmedia-body col-md-3" style="bbackground: yellow; mmargin-left:-20px;">
                                     <p style="color:gray;">Address<p>
                                      '.$college_address.'
                                  </div>
                                  <div class="mmedia-body col-md-3" style="bbackground: red; mmargin-left:-20px;">
                                  <p style="color:gray;">Website<p>
                                  <p><a href='.$college_website.'>'.$college_website.'</a></p>
                                  </div>
                                  <div class="mmedia-body col-md-3" style="bbackground: blue; mmargin-left:-20px;">
                                  <p style="color:gray;">Contact<p>
                                  <p>'.$college_phone_1.'</p>
                                  <p>'.$college_phone_2.'</p>
                                  </div>
                                  <div class="mmedia-body col-md-3" style="bbackground: blue; mmargin-left:-20px;">
                                   <p style="color:gray;">Email Address<p>
                                  <p>'.$college_email.'</p>
                                  </div>
                            </div>
                            <div class=col-md-4"></div>
                          </div>';


                          	
                      //include("../img/dd/temp.php");

                    ?>
              </div>
              <div class="tab-pane" id="facility">
                    <?php
                     //$cc="https://www.searchurcollege/exam/admin/search/gallery/college/gallery/college/facility/facility_".$c_id.'*.*';
                     $sqlfacilities="SELECT facility_name, facility_image_path from suc_college_facilities where college_id=$c_id";
                 $resultfacilities=$conn->query($sqlfacilities);
                 echo '<div class="col-md-12">';
                 while($rowfacilities=$resultfacilities->fetch_assoc()){
                   $facility_name=$rowfacilities["facility_name"];
                  $facility_image_path=$rowfacilities["facility_image_path"];
                  echo '<div class="col-md-1"><center><img class="" style ="max-width: 70px; max-height:50px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/'.$facility_image_path.'" alt="'.$facility_name.'"> &nbsp';
                  echo '<p>'.$facility_name.'</center></p> </div>';
                  }
                  echo "</div>";
                    ?>
              </div>
              <div class="tab-pane" id="Document">
                    <?php
                    $sqlDoc="SELECT   college_doc_id, college_doc_name, college_doc_desc, college_doc from suc_college_documents where college_id=$c_id";
                    $resultDoc=$conn->query($sqlDoc);
                    echo '<div class="col-md-12">';
                    while($rowDoc=$resultDoc->fetch_assoc())
                    {
                      $college_doc_id=$rowDoc["college_doc_id"];
                      $college_doc_name=$rowDoc["college_doc_name"];
                      $college_doc_desc=$rowDoc["college_doc_desc"];
                      $college_doc=$rowDoc["college_doc"];
                      $s= substr($college_doc, strpos($college_doc, ".")+1);
                      if($s=="pdf" or $s=="doc")
                        $college_doc="pdficon.png";
                      $c_download=$rowDoc["college_doc"];

                      echo '<div class="col-md-3"><center><a href="https://www.searchurcollege.com/exam/admin/search/college-documents/documents/'.$c_download.'"  download ><img class="mmmedia-object col-xs-12"  title="Click to download" src="https://www.searchurcollege.com/exam/admin/search/college-documents/documents/'.$college_doc.'" style=" width:100px  ;"/> &nbsp';
                  echo '<p>'.$college_doc_name.'</center></p> </a>  </div>';


          //              echo '<div class="sswell col-md-4" style="background: white; margin-bottom: 10px; padding: 20px">
                        
              
          //         <div class="mmedia col-md-2" style="bbackground: red;">
          //          <a href="https://www.searchurcollege.com/exam/admin/search/college-documents/documents/'.$c_download.'"  download ><img class="mmmedia-object col-xs-12"  title="Click to download" src="https://www.searchurcollege.com/exam/admin/search/college-documents/documents/'.$college_doc.'" style="max-height:140px; width:100%;"/> </a>
                   
          //         </div>
          //       <div class="mmedia-body col-md-10" style="bbackground: yellow; ">
          //        <h4 class="memdia-heading" ><strong>'.strip_tags($college_doc_name).'</strong></h4><div style="align-left"><p style="font-size :13px;"> ';
          //          echo' </p></div><p style="color:black; font-size:13px;">'.$college_doc_desc.'</p>
          //   </div>
            

          // </div>
          // ';
                 
           
                    }
                    echo '</div>';
                       
                    ?>
              </div>
              
      </div>
    </section>
    <!-- /.content -->
  </div>

  