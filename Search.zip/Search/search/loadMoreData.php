<?
echo $_REQUEST["last_id"];
echo $_REQUEST["sqlQ"];
?>	