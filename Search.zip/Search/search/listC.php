<head>
    <title>SearchurCollege - Results</title>  
    <META NAME="Description" CONTENT="View all Article on Searchurcollege."/>
    <META NAME="Keywords" CONTENT="Searchurcollege, Article, Ranking, Course, Exam, College, Scholarship"/>
    <!-- <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script> -->
</head>
<style>
    .lbl:hover
    {
        color: #00b3b3;
    }
    .scrollbar
    {
    	mmargin-left: 30px;
    	float: le0t;
    	height: 400px;
    	width: 100%;
    	background: #F5F5F5;
    	overflow-y: scroll;
    	margin-bottom: 25px;
    }
    .style-4::-webkit-scrollbar-track
    {
    	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    	background-color: #F5F5F5;
    }
    .style-4::-webkit-scrollbar
    {
    	width: 10px;
    	background-color: #F5F5F5;
    }
    .style-4::-webkit-scrollbar-thumb
    {
    	background-color: #000000;
    	border: 2px solid #555555;
    }
</style>
<?php
    include('../connection/dbconnect.php');
    $useragent=$_SERVER['HTTP_USER_AGENT'];
    if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
        include('../connection/header3.php');
    else
        include('../connection/header1.php');
 ?>
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
        a:active, a:focus {
          outline: 0;
          border: none;
          -moz-outline-style: none;
        }
        #locFil
        {
          height: 300px;
          overflow: auto;
        }
    </style>
    <sscript src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<div class="col-md-12" style="background: #EBE9E7; bbackground: url('https://www.searchurcollege.com/connection/images/books.jpg'); background-attachment: fixed; bbackground:#F4F4F4; padding-right: 0px;">
  <div class="col-md-3" style="width: 20%;"></div>
<div class="col-md-8" style="width: 80%; bbackground:#F4F4F4; fheight: 50px; margin-top: 10px; mmargin-bottom: 20px;">
<h4 style="margin-left: 20px;">Modify Your Search...</h4>
  
  <?php include("index.php");?>
</div>

<div class="col-md-3" style="width: 20%;"></div>
<div class="ccol-md-9" style="width: 80%;"></div>
    <center><h3 style="color: black;"><strong>Search Results</strong></h3></center>
</div>

<div class="col-md-12" style="width: 100% ;background:#EBE9E7">

<div class="col-sm-12 col-xs-12" style="background: white; width: 20%; hheight: auto; mmargin-top: 20px; wwidth: 20%; border: 1px solid lightgray">
  <h5 style="bbackground: gray; border: 1px solid lightgray; padding: 10px;"><b>Filter Your Search</b></h5>
  <div class="list-group">
     <h5 style="padding:10px; "><b>FEE</b></h5>
     <div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="0.0, 100000.00"> >1 Lakh </label>
      </p></div>
      <div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="100000, 200000">  1-2Lakh </label>
      </p></div>
      <div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" value="200000, 300000" name="fee">  2-3Lakh </label>
      </p></div><div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" value="300000, 400000" name="fee">  3-4Lakh </label>
      </p></div><div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="400000, 500000"> > 5Lakh </label>
      </p></div>      

     <!-- <input type="hidden" id="hidden_minimum_price" value="0" />
                    <input type="hidden" id="hidden_maximum_price" value="65000" />
                    <p id="price_show">1000 - 65000</p>
                    <div id="price_range"></div> -->
                </div>  
<hr>
                <!-- <div data-role="rangeslider">
        <label for="price-min">Price:</label>
        <input type="range" name="price-min" id="price-min" value="200" min="0" max="1000">
        <label for="price-max">Price:</label>
        <input type="range" name="price-max" id="price-max" value="800" min="0" max="1000">
      </div> -->
      <div>
    <h5 style="padding:10px;"><b>COURSE</b></h5>
    <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="18">B.Tech</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="12">M.Tech</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="11">MBA</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="13">MBBS</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="17">BBA</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="19">BCA</label>
      </p></div>
      <div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl">
      <input  type="checkbox" class="common_selector course" value="20">MCA</label>
      </p></div>
  </div>
      <hr>
  <div>
    <h5 style="padding:10px;"><b>LOCATION</b></h5>
    <input id="myInput" type="text" placeholder="Search Location" style="padding: 8px;  width: 100%;">
    <div id="locFil" class="style-4" style="overflow-x: hidden; margin-top: 10px;"> 
  <!--FIlter Location -->
<br>
    <?php
  $filterLoc="SELECT location_name,id from location";
  $resultLoc=$conn->query($filterLoc);
  while($rowLoc=$resultLoc->fetch_assoc())
    {
      echo '<div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl ">
      <input  type="checkbox" class="common_selector brand" value="'.$rowLoc["id"].'">'.$rowLoc["location_name"].'</label>
      </p></div>';
    }
  ?>

  </div>
  <hr>
  
  <!-- Stream Section-->
  <!-- <div  id=style-1" sstyle="overflow-y: scroll;max-height: 150px;">
    <h5 style="padding:10px; "> <b>Stream</b> </h5>
    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Engineering

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Science

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Business and Management Studies

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      IT and Software

    </p></div>

    <div style="margin-left: 10px;">
    <p style="font-size: 15px;" class=lbl>
      Medicine and Health Science

    </p></div>
    </div> -->
  </div>

    <!-- <a href="https://www.searchurcollege.com/exams/mat-details"><img src="https://www.searchurcollege.com/exams/img/exams/MAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/cmat-details"><img src="https://www.searchurcollege.com/exams/img/exams/CMAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/iift-details"><img src="https://www.searchurcollege.com/exams/img/exams/IIFT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/atma-details"><img src="https://www.searchurcollege.com/exams/img/engineering/JEEMAIN.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/nmat-details"><img src="https://www.searchurcollege.com/exams/img/engineering/GATE.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/atma-details"><img src="https://www.searchurcollege.com/exams/img/law/CLAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/nmat-details"><img src="https://www.searchurcollege.com/exams/img/law/AILET.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>  -->

</div>
<div id="post-data" class="col-sm-12 col-xs-12  filter_data" style=" hheight: auto; width: 80%; padding-right: 0px;">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.1.0/css/font-awesome.min.css"/>
<?php
if(isset($_REQUEST["location_id"]))
{
 $loc=$_REQUEST["location_id"];
 if($loc>=5000)
 {
  $loc=$loc-5000;
    $sqL='SELECT state from location where id='.$loc;
 $resulT=$conn->query($sqL);
  while($roW=$resulT->fetch_assoc())
     $state=$roW['state'];
   $sqL1="SELECT id from location where state='".$state."'";
  $resulT1=$conn->query($sqL1);
   while($roW1=$resulT1->fetch_assoc()){
       $loc1.="'".$roW1['id']."', ";
   }
    
    $loc1=rtrim($loc1,", ");
 }
 else
 {
  $loc1=$loc;
 }
  


}
if(isset($_REQUEST["country1"]) && ($_REQUEST["country1"])!="")
{
 $s=$_REQUEST["country1"];
 $query="select search_tag_type from suc_search_tag where search_tag_value like '%$s%'";
 $result=$conn->query($query);
  while($row=$result->fetch_assoc())
        {
          $name=$row["search_tag_type"];
        }
        if($name==1 && isset($_REQUEST["location_id"]))
        {
            $sql="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_master_course c
            ON b.master_course_id = c.course_id
        INNER JOIN suc_master_course_category d
            ON d.course_cat_id = c.course_cat_id
WHERE   d.course_cat_name like'%".$s."%' and a.college_location_id IN ( ".$loc1.")";
        }
        elseif ($name==1 && !isset($_REQUEST["location_id"])) {
             $sql="SELECT  DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved, a.college_no_of_courses
FROM    suc_college a
        INNER JOIN suc_college_courses b
            ON a.college_id = b.college_id
        INNER JOIN suc_master_course c
            ON b.master_course_id = c.course_id
        INNER JOIN suc_master_course_category d
            ON d.course_cat_id = c.course_cat_id
WHERE   course_cat_name like'%".$s."%' ";
         } 
        else
        {
          if(isset($_REQUEST["location_id"]))
          {
              $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_name like '%$s%' and college_location_id IN (".$loc1.")" ;
          }
          else
             $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where college_name like '%$s%' " ;
        }
}
else
{

  $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college ";
}
if(isset($_REQUEST["location_id"]) && ($_REQUEST["country1"])=="")
{
   $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_aicte_approved, college_no_of_courses FROM suc_college where  college_location_id IN (".$loc1.")" ;
}
//echo $sql;
        //$sql="SELECT uni_id,college_id ,college_name FROM suc_college " ;
        $i=1;
        $result=$conn->query($sql);
        $c_id_A="";
        while($row=$result->fetch_assoc())
        {
            $uni_id=$row['uni_id'];
            $unisql="SELECT uni_name from suc_university where uni_id=$uni_id";
            $result1=$conn->query($unisql);
           while($row1=$result1->fetch_assoc())
             $uni_name=$row1["uni_name"];
           // $d=strip_tags($des);
           $c_name=$row["college_name"];
           echo '<div class="post-id" id="'.$row['college_id'].'"></div>';
            $c_id=$row['college_id'];
            $c_id_A.=$c_id.", ";
            $c_desc=$row['college_desc'];
            $c_type=$row['college_type'];
            $c_location=$row['college_location_id'];
            $c_e_dt=$row['college_establishment_dt'];
            $c_e_dt=substr($c_e_dt, 0,4);
            if(substr($c_e_dt, 0,1)!="0")
            {
              $c_e_dt='|  &nbsp Established &nbsp'.$c_e_dt;
            }
            else
              $c_e_dt=""; 
            $c_aicte=$row['college_aicte_approved'];
            $c_no_courses=$row['college_no_of_courses'];
            $c_img=$row['college_image_path'];
            $sql2="SELECT college_rating from suc_college_rating where college_id=$c_id";
            $result2=$conn->query($sql2);
           while($row2=$result2->fetch_assoc())
              $rating=$row2["college_rating"];
          $sqlLocation="SELECT location_name,state from location where id=$c_location";
          $resultLocation=$conn->query($sqlLocation);
          while($rowLocation=$resultLocation->fetch_assoc()){
            $l_name=$rowLocation["location_name"];
            $l_state=$rowLocation["state"];
          }
          if($c_type=="1")
            $type="Government";
          else
            $type="Private";
          if($c_aicte=="1")
             $aprroval='|  &nbsp AICTE Approved  <i class="fa fa-info-circle" aria-hidden="true"></i>';
           else
             $aprroval='';
           
           ?>

            <div class="wwell col-md-12 " style="background: white;height: 22%; margin-bottom: 20px; padding: 10px padding-left: 15px;  border:1px solid #D3D3D3; ">
              <form target="_blank" action="college_info.php" method="post"> 
              <!--<label style="position:absolute; right:0px; color:black;">Compare
             <input type="checkbox" name="Compare" class="largerCheckbox"  style="hheight:20px; margin-right:10px;">
             </label>-->
                  <input type="hidden" name="resultCol" value="<?php echo $c_id;?>" />
                  <input type="hidden" name="resultColName" value="<?php echo $c_name;?>" />
                  <div class="mmedia col-md-2" style="bbackground: red;">
                    <button type="submit" style="background: transparent; border: 0px;"><img class="img-thumbnail" src="https://www.searchurcollege.com/exam/admin/search/gallery/college/<?php echo $c_img ?>" sstyle="margin-left: -30px; ppadding-right: 10px; min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px;" style="position:absolute; top:10px; left: -5px; height:125px; width: 150px;"/></button>
                  </div>
                <div class="mmedia-body col-md-10" style="bbackground: yellow; mmargin-left:-20px; margin-top: 10px;">
                 <h4 class="memdia-heading" style="color:black; font-family: system-ui; "> <button class="bsubmit" type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left"><?php echo $c_name;?>
                 </button>
                 <?php
                    echo '<span class="pull-right"><small>';
                    if($rating>=1)
                    {
                        echo "Rating";
                        for($i=0;$i<$rating;$i++)
                            echo ' <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i>';
                    }
                    echo '</small></span>';
                 ?>                 
                 </h4>
                 
                 
                 <p style="font-size :14px; color:#696969;"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp <?php echo $l_name.','.$l_state;?>
                   &nbsp| &nbsp&nbsp<i class="fa fa-university" aria-hidden="true"></i>&nbsp <?php echo $uni_name; ?>
                   
                    &nbsp| &nbsp&nbsp Courses: <? echo $c_no_courses ; 
                 if($rating>=1){
                  //echo "&nbsp &nbsp| &nbsp Rating";
                 for($i=0;$i<$rating;$i++)
                 {
                  //echo ' <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i>';
                 }}
                 $rating="";
                 ?>
                   </p> <p style="color:#696969; font-size:14px;">Ownership :&nbsp  <?php echo $type; ?>
                  &nbsp <?php echo $c_e_dt.'&nbsp'.$aprroval.'</p>';?> <?
                 $sqlfacilities="SELECT facility_name, facility_image_path from suc_college_facilities where college_id=$c_id";
                 $resultfacilities=$conn->query($sqlfacilities);
                 while($rowfacilities=$resultfacilities->fetch_assoc()){
                   $facility_name=$rowfacilities["facility_name"];
                  $facility_image_path=$rowfacilities["facility_image_path"];
                  echo '<img cclass="img-thumbnail" style ="width: 25px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/'.$facility_image_path.'" title="'.$facility_name.'"> &nbsp';
                  }
                  ?>
                  
             </div>
            </form>
            
          </div>
       <? $i++ ;
     } ?>

     
  <script type="text/javascript">
    </script>


</div>


</div>




<?php 
if($s!="")
  echo '<input type="hidden" name="" class="college_like" value="'.$s.'">';
if($loc!="")
  echo '<input type="hidden" name="" class="location_name" value="'.$loc1.'">';
?>

<input type="hidden" name="" class="c_id" value="<? echo $c_id_A;?>">
<div style="margin-top: ">
<?php
    include('../footer.php');
?>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#locFil div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


</script>

<script>
$(document).ready(function(){

    //filter_data();

    function filter_data()
    {
      //alert(x);
     // alert($(".brand").val());
        // $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var brand = get_filter('brand');
         //alert(brand)
         var c_id = $('.c_id').val();
         var loc_name=$('.location_name').val();
         
         var college_like = $('.college_like').val();
         //alert(college_like)
         //alert(college_like);
        var fee=get_filter('fee');
        //alert(fee);
        var course=get_filter('course');
        //alert(course);
        var ram = get_filter('ram');
        var storage = get_filter('storage');
        $.ajax({
            url:"../filter/fetch_data.php",
            method:"POST",
            data:{action:action,fee:fee, brand:brand, loc_name:loc_name ,college_like:college_like, c_id:c_id, course:course,storage:storage},
            success:function(data){
                    //alert(data);
                if(data!="")
                  $('.filter_data').html(data);
                //$('#myInput').val("");
            }
        });
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            //alert($(this))
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function(){
        filter_data();
    });

    $('#price_range').slider({
        range:true,
        min:1000,
        max:65000,
        values:[1000, 65000],
        step:500,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data();
        }
    });

});
</script>

<script type="text/javascript">
    // $(window).scroll(function() {
    //     if($(window).scrollTop() + $(window).height() >= $(document).height()) {
    //         var last_id = $(".post-id:last").attr("id");
    //         alert(last_id);
    //         //loadMoreData(last_id);
    //     }
    // });
$(window).scroll(function() {
   var hT = $('#scroll-to').offset().top,
       hH = $('#scroll-to').outerHeight(),
       wH = $(window).height(),
       wS = $(this).scrollTop();
    // console.log((hT-wH) , wS);
   if (wS> 500 ){
    console.log("s "+ (wS%600)+" s1 "+ hH+" s2 " + wH+" s3 "+ wS);
   //if (wS > (hT+hH-wH)){
     //alert('you have scrolled to the h1!');
   }
});

    function loadMoreData(last_id){
      $.ajax(
            {
                url: '/loadMoreData.php?last_id=' + last_id,
                type: "get",
                beforeSend: function()
                {
                    $('.ajax-load').show();
                }
            })
            // .done(function(data)
            // {
            //     $('.ajax-load').hide();
            //     $("#post-data").append(data);
            // })
            // .fail(function(jqXHR, ajaxOptions, thrownError)
            // {
            //       alert('server not responding...');
            // });
    }
</script>
<script type="text/javascript">
history.pushState(null, null, '<?php echo $_SERVER["REQUEST_URI"]; ?>');
window.addEventListener('popstate', function(event) {
    window.location.assign("https://www.searchurcollege.com/");
});
</script>


<!-- <script type="text/javascript">
    $(document).ready(function(){
        $('input[type="checkbox"]').click(function(){
            if($(this).prop("checked") == true){
                alert($(this).val());
            }
            else if($(this).prop("checked") == false){
                alert("Checkbox is unchecked.");
            }
        });
    });
</script> -->
