<?php
    include('dbconnect.php');
    $table=$_REQUEST['table'];
    $field=$_REQUEST['field'];
    $id=$_REQUEST['id'];
    $status=$_REQUEST['status'];
    if($table=='suc_partner_referral_code') 
        $sql="UPDATE $table SET referral_code_status=$status WHERE $field=$id";
    else
        $sql="UPDATE $table SET $field=$status WHERE $field=$id";
    $result=$conn->query($sql);
?>
