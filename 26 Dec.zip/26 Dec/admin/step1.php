<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<style>
    .col-md-4 { float: left; }
</style>
<div class="col-md-4">&nbsp;</div>
<div class="col-md-4">
    <h1>Register</h1><br>
    <form id="frmRegister" action="step2.php" method="post">
        <span class="input-group">
            <span class="input-group-addon"><i class="fa fa-book"></i></span>
            <select id="L1" name="last_qualification" class="form-control" rrequired>
                <option disabled selected>Last Qualification</option>
                <?php
                    include_once('functions.php');
                    include_once('dbconnect.php');
                    $result=selectCourse();
                    while($row=$result->fetch_assoc())
                    {
                        $id=$row['id'];
                        echo '<option value="'.$id.'">'.$row["course_master_name"].'</option>';
                    }
                ?>
            </select>
        </span>
        <span class="input-group">
            <span class="input-group-addon"><i class="fa fa-book"></i></span>
            <select id="course_interested" name="course_interested" class="form-control" style="width: 100%; text-align :center; ackground: red;" rrequired>
            <option disabled selected>Course Looking for</option>
            
            
            </select>
        </span>
        <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-user"></i></span>
          <input type="text" class="form-control iinput-md" id="first_name" name="first_name" placeholder="First Name" rrequired />
          <span class="input-group-btn" style="width: 0px;"></span>
          <input type="text" class="form-control input-md" id="last_name" name="last_name" placeholder="Last Name" rrequired />
        </div>
        <span class="input-group">
            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
            <input id="email2" type="email" class="form-control" name="email" placeholder="Email" rrequired />
        </span>
        <span class="input-group">
            <span class="input-group"><span class="input-group-addon"><i class="fa fa-key"></i></span>
            <input type="password" class="form-control" name="password1" placeholder="Password" rrequired />
        </span>
        <span class="input-group">
            <span class="input-group"><span class="input-group-addon"><i class="fa fa-key"></i></span>
            <input type="password" class="form-control" name="password2" placeholder="Confirm Password" rrequired />
        </span>
        <span class="input-group">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="Contact No." rrequired />
            </div>
        </span>
        <span class="input-group" style="margin-top: -10px;">
            <span class="input-group-addon"><i class="fa fa-flag"></i></span>
            
            <select id="cl" name="current_location" class="form-control" style="width: 100%!important;" rrequired>
                <option disabled selected>Current Location</option>
                <?php
                   include('dbconnect.php');
                   $sql="SELECT * FROM location";
                   $result=$conn->query($sql);
                   while($row=$result->fetch_assoc())
                   {
                        $id=$row['id'];
                        echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
                   }
                ?> 
            </select>
            </span>
        </span>
        <span class="input-group" style="margin-top: 10px;">
            <span class="input-group-addon"><i class="fa fa-flag-checkered"></i></span>
            <select id="c2" name="preferred_location" class="form-control" style="width: 100%!important;" rrequired>
            <!-- <input list="preferred_location" id="c2" name="preferred_location" class="form-control" placeholder="Preferred Location" required /> -->
            <option disabled selected>Preferred Location</option>
                <?php
                   $sql="SELECT * FROM location";
                   $result=$conn->query($sql);
                   while($row=$result->fetch_assoc())
                   {
                        $id=$row['id'];
                        echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
                   }
                ?> 
            </select>
        </span>
        <span class="input-group" style="margin-top: 10px;">
            <span class="input-group-addon"><i class="fa fa-user"></i></span>
            <select name="reference" id="r1" class="form-control">
                <option selected disabled>Select Reference</option>
                <option value="Facebook">Facebook</option>
                <option value="Whatsapp">Whatsapp</option>
                <option value="SMS">SMS</option>
                <option value="Email">Email</option>
                <option value="Internet">Internet</option>
                <option value="Friend">Friend</option>
                <option value="Coaching/Tuition">Coaching/Tuition</option>
                <option value="School/College">School/College</option>
                <option value="Others">Others</option>
            </select>
            <input type="text" class="col-md-6 form-control" id="reference_name" name="reference_name" placeholder="Name Source" style="display: none;" />
            </span>
        </span>
        <center><div style="ppadding: 0px;" class="g-recaptcha pull-right" data-sitekey="6LdkqGsUAAAAAHaGJsKsrkrvewL8eWH2U_xGOttR"></div></center>
        <div class="col-md-12" style="padding: 0px;"><br />
        <div class="col-md-5">
            Already Registered ?</b>
            <br /><a href="https://www.searchurcollege.com/connection/login1.php" style="color: #5D9BD0;"><b>Login Here</b></a>
        </div>
        <div class="col-md-7">
            <div id="msg">
                <span id="rsuccess" class="pull-right" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> <span id="m1"></span></span>
                <span id="rerror" class="pull-right" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <span id="m2"></span></span>
            </div>
            <button id="sub" type="submit" class="btn btn-primary pull-right">Register</button>
        </div>
        <div id="regButton" class="col-md-4" style="display: none; background: #DE4313;">
        </div>
        </div>
        <br /><br />
    </form>
</div>
</div>

