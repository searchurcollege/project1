<?php
    session_start();
    $partner_id=$_SESSION['partner_id'];
    $created_by=$_SESSION['partner_email'];
    $partner_no_of_users=$_REQUEST['nou'];
    $chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXY@#$";
    $res="";
    for($i=0;$i<6;$i++)
        $res.=$chars[mt_rand(0, strlen($chars)-1)];
    $partner_referral_code=strtoupper($res);
    include('dbconnect.php');
    $sql="INSERT INTO suc_partner_referral_code (partner_id, partner_referral_code, partner_no_of_users, referral_code_status, created_by) VALUES ($partner_id, '$partner_referral_code', $partner_no_of_users, 0, '$created_by')";
    if($conn->query($sql)==TRUE)
       echo 0;
    else
       echo 1;
?>