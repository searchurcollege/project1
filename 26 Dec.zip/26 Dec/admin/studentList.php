<?php
    include('header.php');
    include('left.php');
?>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css"/>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <?php
            if($_SESSION['partner_email']=='admin@searchurcollege.com')
                echo 'Total Students';
            else
                echo 'My Students';
        ?>
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <?php
            if($_SESSION['partner_email']=='admin@searchurcollege.com')
                echo '<h3 class="box-title">Total Students</h3>';
            else
                echo '<h3 class="box-title">My Students</h3>';
          ?>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
            <div class="col-md-12">
            <div class="box-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered table-striped">
        <thead>
            <tr style="background: orange;">
                <th width="3%">Sr</th>
                <th width="13%">Registered on</th>
                <th><center>Name</center></th>
                <th><center>Email</center></th>
                <th><center>Phone</center></th>
                <th><center>Course</center></th>
                <th><center>Tests Given</center></th>
                <th><center>Qualified</center></th>
                <th><center></center></th>
            </tr>
        </thead>
        <tbody>
        <?php
        $ij=1;
            $count=0;
            if($_SESSION['partner_email']!='admin@searchurcollege.com')
            {
                $partner_id=$_SESSION['partner_id'];
                $sql="SELECT id,first_name, last_name, email, contact, course_interested, current_location, preferred_location, created_at,balance_amt ,token, reference, reference_name FROM users where  partner_id=$partner_id ORDER BY first_name";
            }
            else
                $sql="SELECT id,first_name, last_name, email, contact, course_interested, current_location, preferred_location, created_at,balance_amt ,token, reference, reference_name FROM users ORDER BY first_name";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
            {
                $id=$row["id"];
                $fname=$row["first_name"];
                $lname=$row["last_name"];
                $name=ucwords(strtolower($fname)).' '.ucwords(strtolower($lname));
                $email=strtolower($row["email"]);
                $contact=$row["contact"];
                $course=$row["course_interested"];
                $c_location=$row["current_location"];
                $p_location=$row["preferred_location"];
                $tkn=$row["token"];
                $date=$row["created_at"];
                $preimum=$row["balance_amt"];
                $ref=$row["reference"];
                $ref_name=$row["reference_name"];
                $sql2="SELECT COUNT(id) AS count FROM user_exam WHERE user_id='$email'";
                $result2=$conn->query($sql2);
                while($row2=$result2->fetch_assoc())
                    $count=$row2["count"];

                    echo '<tr>';

                $sql1="SELECT count(user_id) as test_given from user_exam where user_id='$email'" ;
                $result1=$conn->query($sql1);
                while($row1=$result1->fetch_assoc())
                    {
                        $test_count=$row1["test_given"];
                    }
                 $test_count; //


                 $sql2="SELECT count(user_id) as test_pass from user_exam where user_id='$email' AND result_status='PASS'" ;
                $result2=$conn->query($sql2);
                while($row2=$result2->fetch_assoc())
                    {
                        $test_pass=$row2["test_pass"];
                    }

                echo '
                    <td align="center">'.$ij.'</td>
                    <td aalign="center">'.$date.'</td>
                    <td aalign="center">'.ucwords(strtolower($name)).'</td>
                    <td aalign="center">'.$email.'</td>
                    
                    <td aalign="center">'.$contact.'</td>
                    <td aalign="center">'.$course.'</td>
                    <td align="center">'.$test_count.'</td>
                    <td align="center">'.$test_pass.'</td>';
                    echo '<td align="center">';
                   if($preimum==0 && $count>0)
                   {
                        echo '<form method="POST" action="studentDetail.php">
                            <input type="hidden" name="email" value="'.$email.'" /> 
                            <input type="hidden" name="name" value="'.$name.'" /> 
                            <input type="hidden" name="contact" value="'.$contact.'" /> 
                            <button type="submit" class="btn btn-primary btn-xs" title="View Tests"><i class="fa fa-eye fa-lg"></i></button>
                    </form>';
                   } 
                   $ij++;
                echo '</td>
                </tr>';
            }
        
        ?>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script type="text/javascript" src="/code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js"></script>

<script>
$(document).ready(function() {
    $('#example').DataTable( {
    aaSorting: [[0, 'asc']],
    aLengthMenu: [[25, 50, 75, -1], [25, 50, 75, "All"]],
    iDisplayLength: 25,
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ],
        buttons: [
            'pageLength', 'copy', 'excel', 'pdf', 'print'
        ]
    });
});
</script>

