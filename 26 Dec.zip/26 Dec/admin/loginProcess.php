<?php
    include('functions.php');
    $email=$_REQUEST['email'];
    $password=$_REQUEST['password'];
    $v=authentication($email,$password);
?>