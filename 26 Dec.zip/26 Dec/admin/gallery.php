<?php
    include('header.php');
    include('left.php');
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Gallery
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#category" data-toggle="tab">Category</a></li>
              <li><a href="#sub-category" data-toggle="tab">Sub-Category</a></li>
              <li><a href="#deals" data-toggle="tab">Deals</a></li>
              <li><a href="#business" data-toggle="tab">Business</a></li>
              <li><a href="#contact_person" data-toggle="tab">Contact Person</a></li>
              <li><a href="#customer" data-toggle="tab">Customer</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="category">
                    <?php
                        foreach(glob('images/category/*.*') as $filename)
                        {
                            echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                            echo '<div class="info-box">';
                            echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                            echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="sub-category">
                    <?php
                        foreach(glob('images/subcategory/*.*') as $filename)
                        {
                            echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                            echo '<div class="info-box">';
                            echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                            echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="deals">
                    <?php
                        foreach(glob('images/deals/*.*') as $filename)
                        {
                            echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                            echo '<div class="info-box">';
                            echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                            echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="business">
                    <?php
                        foreach(glob('images/vendor/business_logo/*.*') as $filename)
                        {
                            echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                            echo '<div class="info-box">';
                            echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                            echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="contact_person">
                    <?php
                        foreach(glob('images/vendor/vendor_image/*.*') as $filename)
                        {
                            echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                            echo '<div class="info-box">';
                            echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                            echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="customer">
                    <?php
                        foreach(glob('images/customer/*.*') as $filename)
                        {
                            echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                            echo '<div class="info-box">';
                            echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                            echo '</div></div>';
                        }
                    ?>
              </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>

