<?php
    include('header.php');
    include('left.php');
?>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css"/>
  <title> - Student List</title> 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        My Packages
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">My Packages</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
            <div class="col-md-12">
            <div class="box-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered table-striped">
              <thead>
                <tr style="background: orange;">
                    <th width="3%">Sr</th>
                    <th><center>Request Date</center></th>
                    <th><center>Referral Code</center></th>
                    <th><center>Usage Limit</center></th>
                    <th><center>Consumed</center></th>
                    <th><center>Valid Till</center></th>
                    <th><center>Status</center></th>
                </tr>
              </thead>
              <tbody>
              <?php
                $partner_id=$_SESSION['partner_id'];
                $sql="SELECT created_dt, partner_referral_code, partner_no_of_users, referral_code_status FROM suc_partner_referral_code WHERE partner_id=$partner_id ORDER BY partner_id DESC";
                $result=$conn->query($sql);
                $i=1;
                while($row=$result->fetch_assoc())
                {
                    $created_date=date('d-M-Y H:m:i',strtotime($row['created_dt']));
                    $partner_referral_code=$row['partner_referral_code'];
                    $partner_no_of_users=$row['partner_no_of_users'];
                    $referral_code_status=$row['referral_code_status'];
                    $date=strtotime($row['created_dt']);
                    $valid_till=date('d-M-Y',strtotime("+364 days",$date));

                    $sql2="SELECT COUNT(partner_id) AS count FROM users WHERE partner_id=$partner_id AND referral_code='$partner_referral_code'";
                    $result2=$conn->query($sql2);
                    while($row2=$result2->fetch_assoc())
                        $count=$row2["count"];

                    echo '<tr>
                    <td align="center">'.$i.'</th>
                    <td><center>'.$created_date.'</center></td>
                    <td><center>'.$partner_referral_code.'</center></td>
                    <td><center>'.$partner_no_of_users.'</center></td>
                    <td><center>'.$count.'</center></td>
                    <td><center>'.$valid_till.'</center></td>';
                    if($referral_code_status==0)
                        echo '<td><center style="color: red;">Inactive</center></td>';
                    else
                        echo '<td><center>Active</center></td>';
                    $i++;
                }
               ?>  
               </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script type="text/javascript" src="/code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js"></script>

<script>
$(document).ready(function() {
    $('#example').DataTable( {
    aaSorting: [[0, 'asc']],
    aLengthMenu: [[25, 50, 75, -1], [25, 50, 75, "All"]],
    iDisplayLength: 25,
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ],
        buttons: [
            'pageLength', 'copy', 'excel', 'pdf', 'print'
        ]
    });
});
</script>


