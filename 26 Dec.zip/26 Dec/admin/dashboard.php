<?php
    include('header.php');
    include('left.php');
    if($_SESSION['partner_email']=='admin@searchurcollege.com')
        include('dashboard_admin.php');
    else
        include('dashboard_partner.php');
?>
