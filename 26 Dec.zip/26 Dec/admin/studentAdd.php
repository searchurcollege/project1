<?php
    include('header.php');
    include('left.php');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Student
        <span id="success" class="label label-success pull-right" style="display: none; font-size: 70%;">Record Added</span>
        <span id="error1" class="label label-warning pull-right" style="display: none; font-size: 70%;">Record Exists</span>
        <span id="error2" class="label label-warning pull-right" style="display: none; font-size: 70%;">Something went wrong with content/image)</span>
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Register New Student</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
            <div class="col-md-12">
                <form id="frmstudentAdd" enctype="multipart/form-data" method="POST" class="form-horizontal">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Last Qualification <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <select id="L1" name="last_qualification" class="form-control select2" required>
                            <option disabled selected>Select Qualification</option>
                            <?php
                                $result=selectCourse();
                                foreach($result as $row)
                                {
                                    $id=$row['id'];
                                    echo '<option value="'.$id.'">'.$row["course_master_name"].'</option>';
                                }
                            ?>
                            </select>
                        </div>
                        <label class="col-sm-2 control-label">Course Interested <span class="req">*</span></label>
                        <div class="col-sm-4">
            				<select id="course_interested" name="course_interested" class="form-control select2" required>
            					<option disabled selected>Course Looking for</option>
            				</select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">First Name <span class="req">*</span> </label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="first_name" placeholder="First Name" required />
                        </div>
                        <label class="col-sm-2 control-label">Last Name <!--<span class="req">*</span>--></label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="last_name" placeholder="Last Name" rrequired />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Email <span class="req">*</span> </label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="email" placeholder="Email" required />
                        </div>
                        <label class="col-sm-2 control-label">Phone <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="phone" placeholder="Phone" required />
                        </div>
                    </div>
                    <div class="form-group" style="display: none;">
                        <label class="col-sm-2 control-label">Password <span class="req">*</span> </label>
                        <div class="col-sm-4">
                            <input type="hidden" class="form-control" name="password1" placeholder="Password" value="1" required />
                        </div>
                        <label class="col-sm-2 control-label">Repeat Password <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <input type="hidden" class="form-control" name="password2" placeholder="Repeat Password" value="1" required />
                        </div>
                    </div>
                    <div class="form-group" sstyle="display: none;">
                        <label class="col-sm-2 control-label">Current Location <span class="req">*</span> </label>
                        <div class="col-sm-4">
                            <input ttype="hidden" class="form-control" name="current_location" placeholder="Repeat Password" value="<?php echo $_SESSION['partner_location'];?>" required />
                        </div>
                        <label class="col-sm-2 control-label">Preferred Location <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <input ttype="hidden" class="form-control" name="preferred_location" placeholder="Repeat Password" value="<?php echo $_SESSION['partner_location'];?>" required />
                        </div>
                    </div>
                    <div class="form-group" style="display: none;">
                        <label class="col-sm-2 control-label">Select Reference <span class="req">*</span> </label>
                        <div class="col-sm-4">
                            <input type="hidden" class="form-control" name="preferred_location" placeholder="Repeat Password" value="<?php echo $_SESSION['partner_location'];?>" required />
                        </div>
                        <div id="reference_name" style="display: none;">
                            <label class="col-sm-2 control-label">Name of Source <span class="req">*</span></label>
                            <div class="col-sm-4">
                				<input type="text" class="col-md-6 form-control" name="reference_name" placeholder="Name Source" value="<?php echo $_SESSION['partner_business_name'];?>" />
                            </div>
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-info pull-right">Add</button>
                    </div>
                </form>
            </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>

<script type="text/javascript">
    $("#frmstudentAdd").submit(function(e) {
        alert('Student Added');
        var formData = new FormData($(this)[0]);
            //url: "studentProcess.php?action=add",
        $.ajax({
            url: "https://www.searchurcollege.com/connection/user_register",
            type: "POST",
            data: formData,
            success: function(data) {
                if(data==0)
                {
                    $("#frmstudentAdd").trigger("reset");
                    $("#remove").click();
                    $("#remove2").click();
                    $("#success").show();
                    setTimeout(function() { $("#success").hide(); }, 3000);
                }
                else
                if(data==1)
                {
                    $("#error1").show();
                    setTimeout(function() { $("#error1").hide(); }, 3000);
                }
                else
                {
                    $("#error2").show();
                    setTimeout(function() { $("#error2").hide(); }, 3000);
                }
            },
            cache: false,
            contentType: false,
            processData: false
        });
        e.preventDefault();
    });
</script>

<script type="text/javascript">
    $(document).ready(function(){
        $('#L1').change(function(event) {
          $('#L2').val('');
          id=$('#L1').val();
          $.post(
           'https://www.searchurcollege.com/connection/info.php?id='+id,
            $(this).serialize(),
            function(data){
              $("#course_interested").html(data);
            }
          );
          return false;
        });   

        $("#r1").on('input change', function () {
            var val = this.value;
            if(val=='Others' || val=='Coaching/Tuition' || val=='School/College')
            {
    
                $("#r1").removeClass("col-md-12");
                $("#r1").addClass("col-md-6");
    
                $('#reference_name').show();
                $('#reference_name').focus();
                 $('#reference_name').prop('required',true);
            }
            else
            {
                $("#r1").removeClass("col-md-6");
                $("#r1").addClass("col-md-12");
                $('#reference_name').hide();
                $('#reference_name').removeAttr('required',true);
            }
        });
    });
</script>




