<?php
    if($_SESSION['partner_email']!='admin@searchurcollege.com')
    {
        ?>
  <aside class="main-sidebar" style="position: fixed;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image">
            <td><img src="images/admin.png" class="img-circle" alt="User Image" /></td>
            <td><span style="color: white; margin-left: 20px;"><?php echo $_SESSION['partner_business_name'];?></span></td>
        </div>
      </div>
      <ul class="sidebar-menu" data-widget="tree">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <!-- Students -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Students</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="studentAdd.php"><i class="fa fa-plus"></i> Register New</a></li>
            <li><a href="studentManage.php"><i class="fa fa-circle-o"></i> Manage</a></li>
          </ul>
        </li>
        <li><a href="packageRequest.php"><i class="fa fa-sign-out"></i> <span>Packages</span></a></li>
        <!-- Reports -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="studentList.php"><i class="fa fa-users"></i> My Students</a></li>
            <li><a href="packageList.php"><i class="fa fa-qrcode"></i> My Packages</a></li>
          </ul>
        </li>
        <!-- Settings -->
        <!--<li class="treeview">
          <a href="#">
            <i class="fa fa-gear"></i> <span>Setting</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-envelope"></i> Email</a></li>
            <li><a href=""><i class="fa fa-mobile"></i> SMS</a></li>
            <li><a href=""><i class="fa fa-inr"></i> Payment Gateway</a></li>
          </ul>
        </li>-->
        <li><a href="logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
    <div style="position: fixed; bottom: 20px; padding: 10px;">
      <img src="https://www.searchurcollege.com/img/Miracles.jpg" width="200" />
    </div>    
  </aside>
  <?php
    }
    else
    {
  ?>
  <aside class="main-sidebar" style="position: fixed;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image">
            <td><img src="images/admin.png" class="img-circle" alt="User Image" /></td>
            <td><span style="color: white; margin-left: 20px;"><?php echo $_SESSION['partner_business_name'];?></span></td>
        </div>
      </div>
      <ul class="sidebar-menu" data-widget="tree">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <!-- Partner -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Partner</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="partnerAdd.php"><i class="fa fa-plus"></i> Add New</a></li>
            <li><a hhref="partnerManage.php"><i class="fa fa-circle-o"></i> Manage</a></li>
          </ul>
        </li>
        <!-- Students -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Students</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="studentAdd.php"><i class="fa fa-plus"></i> Register New</a></li>
            <li><a href="studentManage.php"><i class="fa fa-circle-o"></i> Manage</a></li>
          </ul>
        </li>
        <li><a href="packageRequest.php"><i class="fa fa-sign-out"></i> <span>Packages</span></a></li>
        <!-- Reports -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="studentList.php"><i class="fa fa-users"></i> Student List</a></li>
            <li><a href="packageList.php"><i class="fa fa-qrcode"></i> Package List</a></li>
            <li><a href="partnerList.php"><i class="fa fa-qrcode"></i> Partner List</a></li>
          </ul>
        </li>
        <!-- Settings -->
        <!--<li class="treeview">
          <a href="#">
            <i class="fa fa-gear"></i> <span>Setting</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-envelope"></i> Email</a></li>
            <li><a href=""><i class="fa fa-mobile"></i> SMS</a></li>
            <li><a href=""><i class="fa fa-inr"></i> Payment Gateway</a></li>
          </ul>
        </li>-->
        <li><a href="logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
  <?php 
  }
  ?>  