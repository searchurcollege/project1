<!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"> -->
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<?php include_once '../includes/header.php';
include ('../../../connection/dbconnect.php');
session_start ();
$email=$_SESSION['ademail'];?>
<!-- <head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
    <title>SearchUrCollege - Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <style>
        .input-group {
            margin-bottom: 10px;
        }
    </style>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head> -->
<style>
	.input-group
	{
		margin-top: 10px; 
	}
</style>
    <div class="wrapper row-offcanvas row-offcanvas-left">

        <!-- Left side column. Contains the navbar and content of the page -->

		<?php include_once '../includes/left_sidebar.php';?>

        <aside class="right-side">                

            <!-- Content Header (Page header) -->

            

            <!-- Main content -->

            <section class="content">

				<!-- Small boxes (Stat box) -->
				<div class="col-md-3"></div>
				<div class="col-md-6">
				<div class="loginmodal-container" style="background: #F3F3F3; padding: 10px;">
                  <h3 style="margin-top: -5px;">Partner Register</h3>
                  <form id="frmRegister" action="partner_Register_Action.php?table_name=suc_partners" method="POST" enctype="multipart/form-data">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control iinput-md" id="partner_contact_firstname" name="partner_contact_firstname" placeholder="First Name" rrequired />
                          <span class="input-group-btn" style="width: 0px;"></span>
                          <input type="text" class="form-control input-md" id="partner_contact_lastname" name="partner_contact_lastname" placeholder="Last Name" rrequired />
                        </div>
                        <input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                       <!--  <input id="table_name" name="table_name"  value="<?php echo $email; ?>" type="hidden"> -->
                        <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-building-o"></i></span>
                            <input  type="bname" class="form-control" name="partner_business_name" id="partner_business_name" placeholder="Intitution/Business Name" rrequired />
                        </span>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-picture-o"></i></span>Logo
                          <input id="partner_logo" type="file" class="form-control"name="partner_logo" />
                          <span class="input-group-btn" style="width: 0px;"></span>Banner
                          <input type="file" class="form-control" id="partner_banner" name="partner_banner" />
                        </div>
                        
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-building-o"></i></span>
                            <select class="form-control" name="partner_business_type" id="partner_business_type">
                                <option selected disabled>Business/Institution Type</option>
                                <option value="1">School</option>
                                <option value="2">College</option>
                                <option value="3">University</option>
                                <option value="4">Learning Academy</option>
                            </select>
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input id="partner_email" type="email" class="form-control" name="partner_email" placeholder="Email" rrequired />
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                            <input type="text" class="form-control" id="partner_phone" name="partner_phone" placeholder="Contact No." rrequired />
                        </span>
                        
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-location-arrow"></i></span>
                            <select class="form-control" name="	partner_location" id="	partner_location">
                            	<option selected disabled>Location </option>
                            	<?php 
                            	$loc="SELECT location_name from location";
                            	$result=$conn->query($loc);
                            	while ($row=$result->fetch_assoc()) {
					               echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
					            }
                            	?>
                            </select>
                        </span>

                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-home"></i></span>
                            <textarea id="partner_address" class="form-control" name="partner_address">Address</textarea>
                        </span>

                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" id="partner_login_password" name="partner_login_password" placeholder="Password" rrequired />
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm Password" rrequired />
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                            <input type="text" class="form-control" style="width: 100px;" placeholder="No.of Users" name="partner_no_of_users" id="partner_no_of_users" />
                            <button id="btn" type="button" class="btn btn-info">Generate Referral Code</button>
                            <span id="code" name="code" placeholder="Referral Code" /></span>
                        </span>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div id="msg">
                                <span id="rsuccess" class="pull-right" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> <span id="m1"></span></span>
                                <span id="rerror" class="pull-right" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <span id="m2"></span></span>
                            </div>
                            <button id="sub" type="button" onclick="passconfm()" class="btn btn-primary pull-right">Register Partner</button>
                        </div>
                        <br /><br />
                            <label class="pull-right">
                                <input type="checkbox" name="term" checked> Send Mail to Partner
                            </label>
                    </form>
                    <br />
                </div>
            </div>
        </div>
            </section><!-- /.content -->

        </aside><!-- /.right-side -->

    </div>

<?php //include_once '../includes/footer.php';?>

<script type="text/javascript">
    $(document).ready(function(){
        $("#btn").click(function(){
        	//alert("s");
            $.ajax({
                type: 'POST',
                url: 'codeGenerator.php',
                success: function(data) {
                    $("#code").html(data);
                }
            });
   });
});
</script>
<script >
	function passconfm()
	{
		var a=$("#password2").val();
		var b=$("#partner_login_password").val();
		if(a==b)
		{
			$("#frmRegister").submit();
		}
		else
		{
			alert("password not match");
		}
	}
</script>
