<?php


// $file = "words.txt";
// $file_arr = file($file);
// $num_lines = count($file_arr);
// $last_arr_index = $num_lines - 1;
// $rand_index = rand(0, $last_arr_index);
// $rand_text = $file_arr[$rand_index];
// //echo $rand_text;


$chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXY@#$%&";
$res = "";
for ($i = 0; $i < 6; $i++) {
    $res .= $chars[mt_rand(0, strlen($chars)-1)];
}
echo '<span style="font-size: 20px; font-weight: bold; color: green;">'.strtoupper($res).'</span>';


    //echo '<span style="font-size: 20px; font-weight: bold; color: green;">'.strtoupper(substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, 6)).'</span>';
?>