	<?php
include("../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
	if($key=="password2")
	{

	}

	else
	{
		if($key=="term")
		{

		}
		else
		{
			$k.=$key.", ";
		$v.="'".$value."', ";
		}
		
	}

  
  
}
  $k=rtrim($k,', ');
  $v=rtrim($v,', ');
//echo $_FILES['partner_banner']['name'];
//echo $_FILES['partner_logo']['name'];

$s="";
 $tbl_name=$_REQUEST["table_name"];
 $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
if ($conn->query($sql) == TRUE) {
	 $last_id = $conn->insert_id;
    $s=1;
    echo "Record Updated </br>";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
if(!empty($_FILES['partner_logo']['name']) && $s==1)
{
	//echo "string";
	 
            
             $allowedExts = array("gif", "jpeg", "jpg", "png");
            //chdir('images');
             $currentDir = getcwd();
            $uploadDirectory = "/images/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['partner_logo']['name'];
            $fileSize = $_FILES['partner_logo']['size'];
            $fileTmpName  = $_FILES['partner_logo']['tmp_name'];
            $fileType = $_FILES['partner_logo']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="logo_".$last_id.'.'.$fileExtension;
             $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                          $sql1="UPDATE $tbl_name SET partner_logo='$fn' WHERE partner_id='$last_id'";
                          $result=$conn->query($sql1);
                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
       echo 'Logo Uploaded </br>';
}
if(!empty($_FILES['partner_banner']['name']) && $s==1)
{
	//echo "string";
	 
            
             $allowedExts = array("gif", "jpeg", "jpg", "png");
            //chdir('images');
             $currentDir = getcwd();
            $uploadDirectory = "/images/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['partner_banner']['name'];
            $fileSize = $_FILES['partner_banner']['size'];
            $fileTmpName  = $_FILES['partner_banner']['tmp_name'];
            $fileType = $_FILES['partner_banner']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="banner_".$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET partner_banner='$fn' WHERE partner_id='$last_id'";
                          $result=$conn->query($sql1);
                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
      echo "banner uploaded";  
}
?>