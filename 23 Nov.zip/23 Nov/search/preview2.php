<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 
<?php
    include('../includes/header.php');
    $tab1="gallery/*.*";
    $tab2="gallery/university/*.*";
    $tab3="gallery/college/*.*";
    $tab4="gallery/college/facility/*.*";
    $tab5="gallery/college/placements/*.*";
    include("../../../connection/dbconnect.php");
    // $tab1="https://www.searchurcollege.com/exam/admin/search/gallery";
    // $tab1="https://www.searchurcollege.com/exam/admin/search/gallery";
    //include('../includes/left_sidebar1.php');
?>
  <div class="content-wrapper">
    <?php include_once '../includes/left_sidebar1.php';?>
    <aside class="right-side">
    <section class="content-header">
      <h1>
        Gallery
      </h1>
      
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          
        </div>
        <div class="box-body">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="" id="gallery1" ><a href="#gallery" data-toggle="tab">Gallery</a></li>
              <li id="university1"><a href="#university" data-toggle="tab">University</a></li>
              <li id="college1"><a href="#college" data-toggle="tab">College</a></li>
              <li id="facility1"><a href="#facility" data-toggle="tab">College-facility</a></li>
              <li id="placement1"><a href="#placement" data-toggle="tab">College-placement</a></li>
             <!--  <li><a href="#customer" data-toggle="tab">Customer</a></li> -->
            </ul>
            <div class="tab-content">
              <div class=" tab-pane" id="gallery">
                <div class="row">
                <div class="form-group col-xs-8">
                  <form id="selectfrm"action="preview2.php?id=<?php echo $college_id; ?>">
                      <label for="catName">All College's Gallery</label>
                      <select class="form-control sselect2"  id="uni_id" name="uni_id" required>
                       <!--  <option>Select College</option> -->
                        <option value="0">All Colleges</option>

                                                 <?php 
                                                
                                                $sql="SELECT college_id,college_name from suc_college";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $college_id=$row["college_id"];
                                       $college_name=$row["college_name"];

                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if(isset($_REQUEST["uni_id"]))
                                       {
                                        if($_REQUEST["uni_id"]==$college_id)
                                          echo ' <option selected value="'.$college_id.'">'.$college_name.'</option> ';
                                        else
                                          echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                       }
                                       else
                                        echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                      
                                    }
                                                 ?>               
                      </select>
                       <input type="hidden" name="a" class="a" value="gallery">
                      <input type="hidden" name="b" class="b" value="gallery1">
                      </form>
                    </div>
                    
                  </div>
                  
                    <?php
                    // $tbl="suc_college_gallery";
                    // $con_field="college_gallery_content_path";
                    $com="gallery/*.*";
                    if(isset($_REQUEST["uni_id"])&& $_REQUEST["uni_id"]!="0")
                    {
                      $flag=0;
                      $conditional_id=$_REQUEST["uni_id"];
                      $ssql="SELECT  college_gallery_id,college_gallery_content_path from suc_college_gallery where college_id=$conditional_id group by college_id" ;
                      $result=$conn->query($ssql);
                        while($row=$result->fetch_assoc()){
                          $cc=$row["college_gallery_content_path"];
                        
                        
                        }
                        //echo $cc;
                    //echo "ssssssssssss===".$c_gallery_id;
                        $cc="gallery/".$cc;
                        $pos1 = strpos($cc, "_");
                    $pos2 = strpos($cc, "_", $pos1 + strlen("_"));
                        $com=substr($cc, 0,$pos2);
                        //echo $com;
                         $flag=1;

                    }
                        foreach(glob($tab1) as $filename)
                        {
                          $tbl="suc_college_gallery";
                          $con_field="college_gallery_content_path";
                          //echo $flag;
                          //echo $pos1;
                          //echo "<br><br><br>".substr($filename, 0,$pos2);
                          if($flag==1)
                          {
                            $pos1 = strpos($filename, "_");
                            $pos2 = strpos($filename, "_", $pos1 + strlen("_"));
                          if(substr($filename, 0,$pos2)==$com){
                            $file=substr($filename,8);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                         }
                       }
                       else
                       {
                        $file=substr($filename,8);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                       }
                        }
                    ?>
              </div>
              <div class="tab-pane " id="university">
                 <div class="row">
                <div class="form-group col-xs-8">
                  <form id="selectfrmUni"action="preview2.php">
                      <label for="catName">University</label>
                      <select class="form-control sselect2" id="uni_record" name="uni_record" required>
                       <!--  <option>Select College</option> -->
                        <option value="0">All University</option>

                                                 <?php 
                                                
                                                $sql="SELECT uni_id,uni_name from suc_university";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $u_id=$row["uni_id"];
                                       $u_name=$row["uni_name"];

                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if(isset($_REQUEST["uni_record"]))
                                       {
                                        if($_REQUEST["uni_record"]==$u_id)
                                          echo ' <option selected value="'.$u_id.'">'.$u_name.'</option> ';
                                        else
                                          echo ' <option  value="'.$u_id.'">'.$u_name.'</option> ';
                                       }
                                       else
                                        echo ' <option  value="'.$u_id.'">'.$u_name.'</option> ';
                                      
                                    }
                                                 ?>               
                      </select>
                      <input type="hidden" name="a" class="a" value="university">
                      <input type="hidden" name="b" class="b" value="university1">
                      </form>
                    </div>
                    
                  </div>
                    <?php
                      $com="gallery/university/*.*";
                    if(isset($_REQUEST["uni_record"])&& $_REQUEST["uni_record"]!="0")
                    {
                      $flag=0;
                      $conditional_id=$_REQUEST["uni_record"];
                      $ssql="SELECT   uni_image_path from suc_university where uni_id=$conditional_id group by uni_id" ;
                      $result=$conn->query($ssql);
                        while($row=$result->fetch_assoc()){
                          $cc=$row["uni_image_path"];
                        }
                        //echo $cc;
                      //echo "ssssssssssss===".$c_gallery_id;
                        $cc="gallery/university/".$cc;
                        $pos1 = strpos($cc, "_");
                    // $pos2 = strpos($cc, "_", $pos1 + strlen("_"));
                    //     $com=substr($cc, 0,$pos2);
                         $com=$cc;
                         $flag=1;

                    }
                        foreach(glob($tab2) as $filename)
                        {
                          $tbl="suc_university";
                          $con_field="uni_image_path";
                          //echo $flag;
                          //echo $pos1;
                          //echo "<br><br><br>".substr($filename, 0,$pos2);
                          if($flag==1)
                          {
                            // $pos1 = strpos($filename, "_");
                            // $pos2 = strpos($filename, "_", $pos1 + strlen("_"));
                          //if(substr($filename, 0,$pos2)==$com){
                            if($filename==$com){
                            $file=substr($filename,19);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                         }
                       }
                       else
                       {
                        $file=substr($filename,19);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                       }
                        }
                    ?>
              </div>
              <div class="tab-pane" id="college">
                <div class="row">
                <div class="form-group col-xs-8">
                  <form id="selectfrmcol"action="preview2.php">
                      <label for="catName">Colleges</label>
                      <select class="form-control sselect2" id="college_record" name="college_record" required>
                       <!--  <option>Select College</option> -->
                        <option value="0">All Colleges</option>

                                                 <?php 
                                                
                                                $sql="SELECT college_id,college_name,college_image_path from suc_college";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $c_id=$row["college_id"];
                                       $c_name=$row["college_name"];
                                      $college_image_path=$row["college_image_path"];

                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if(isset($_REQUEST["college_record"]))
                                       {
                                        if($_REQUEST["college_record"]==$c_id)
                                          echo ' <option selected value="'.$c_id.'">'.$c_name.'</option> ';
                                        else
                                          echo ' <option   value="'.$c_id.'">'.$c_name.'</option> ';
                                       }
                                       else
                                        echo ' <option  value="'.$c_id.'">'.$c_name.'</option> ';
                                      
                                    }
                                                 ?>               
                      </select>
                      <input type="hidden" name="a" class="a" value="college">
                      <input type="hidden" name="b" class="b" value="college1">
                      </form>
                    </div>
                    
                  </div>
                    <?php
                    $com=$tab3;
                    if(isset($_REQUEST["college_record"])&& $_REQUEST["college_record"]!="0")
                    {
                      $flag=0;
                      $conditional_id=$_REQUEST["college_record"];
                      $sql3="SELECT college_image_path from suc_college where college_id=$conditional_id ";
                        $result3=$conn->query($sql3);
                        while($row3=$result3->fetch_assoc()){
                         $cc=$row3["college_image_path"];
                        }
                        //echo $cc;
                      //echo "ssssssssssss===".$c_gallery_id;
                        $cc="gallery/college/".$cc;
                        // $pos1 = strpos($cc, "_");
                        // $pos2 = strpos($cc, "_", $pos1 + strlen("_"));
                        // $com=substr($cc, 0,$pos2);
                      $com=$cc;
                         $flag=1;

                    }

                        foreach(glob($tab3) as $filename)
                        {
                          $tbl="suc_college";
                          $con_field="college_image_path";
                          //echo $flag;
                          //echo $pos1;
                          //echo "<br><br><br>".substr($filename, 0,$pos2);
                          if($flag==1)
                          {
                            $pos1 = strpos($filename, "_");
                            $pos2 = strpos($filename, "_", $pos1 + strlen("_"));
                          //if(substr($filename, 0,$pos2)==$com){
                            if($filename==$com){
                            $file=substr($filename,16);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                         }
                       }
                       else
                       {
                        $file=substr($filename,16);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                       }
                        }
                    ?>
              </div>
              <div class="tab-pane" id="facility">

                <div class="row">
                <div class="form-group col-xs-8">
                  <form id="selectfrmfacility"action="preview2.php">
                      <label for="catName">Colleges</label>
                      <select class="form-control sselect2" id="facility_record" name="facility_record" required>
                       <!--  <option>Select College</option> -->
                        <option value="0">All Colleges</option>

                                                 <?php 
                                                
                                                $sql="SELECT college_id,college_name,college_image_path from suc_college";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $c_id=$row["college_id"];
                                       $c_name=$row["college_name"];
                                      $college_image_path=$row["college_image_path"];

                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if(isset($_REQUEST["facility_record"]))
                                       {
                                        if($_REQUEST["facility_record"]==$c_id)
                                          echo ' <option selected value="'.$c_id.'">'.$c_name.'</option> ';
                                        else
                                          echo ' <option   value="'.$c_id.'">'.$c_name.'</option> ';
                                       }
                                       else
                                        echo ' <option  value="'.$c_id.'">'.$c_name.'</option> ';
                                      
                                    }
                                                 ?>               
                      </select>
                      <input type="hidden" name="a" class="a" value="facility">
                      <input type="hidden" name="b" class="b" value="facility1">
                      </form>
                    </div>
                    
                  </div>

                    <?php

                    $com=$tab4;
                    if(isset($_REQUEST["facility_record"])&& $_REQUEST["facility_record"]!="0")
                    {
                      $flag=0;
                      $conditional_id=$_REQUEST["facility_record"];
                      $ssql="SELECT  facility_image_path from suc_college_facilities where college_id=$conditional_id group by college_id" ;
                      $result=$conn->query($ssql);
                        while($row=$result->fetch_assoc()){
                          $cc=$row["facility_image_path"];
                        
                        
                        }
                        //echo $cc;
                    //echo "ssssssssssss===".$c_gallery_id;
                        $cc="gallery/college/facility/".$cc;
                        $pos1 = strpos($cc, "_");
                    $pos2 = strpos($cc, "_", $pos1 + strlen("_"));
                        $com=substr($cc, 0,$pos2);
                        $com;
                         $flag=1;

                    }

                        foreach(glob($tab4) as $filename)
                        {

                          $tbl="suc_college_facilities";
                          $con_field="facility_image_path";
                         
                          //echo $flag;
                          //echo $pos1;
                          //echo "<br><br><br>".substr($filename, 0,$pos2);
                          if($flag==1)
                          {
                            $pos1 = strpos($filename, "_");
                            $pos2 = strpos($filename, "_", $pos1 + strlen("_"));
                          if(substr($filename, 0,$pos2)==$com){
                            $file=substr($filename,25);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                         }
                       }
                       else
                       {
                        $file=substr($filename,25);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                       }

                             
                        }
                    ?>
              </div>
              <div class="tab-pane" id="placement">

                <div class="row">
                <div class="form-group col-xs-8">
                  <form id="selectfrmplacement"action="preview2.php">
                      <label for="catName">Colleges</label>
                      <select class="form-control sselect2" id="placement_record" name="placement_record" required>
                       <!--  <option>Select College</option> -->
                        <option value="0">All Colleges</option>

                                                 <?php 
                                                
                                                $sql="SELECT college_id,college_name from suc_college";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $c_id=$row["college_id"];
                                       $c_name=$row["college_name"];
                                     
                                       if(isset($_REQUEST["placement_record"]))
                                       {
                                        if($_REQUEST["placement_record"]==$c_id)
                                          echo ' <option selected value="'.$c_id.'">'.$c_name.'</option> ';
                                        else
                                          echo ' <option   value="'.$c_id.'">'.$c_name.'</option> ';
                                       }
                                       else
                                        echo ' <option  value="'.$c_id.'">'.$c_name.'</option> ';
                                      
                                    }
                                                 ?>               
                      </select>
                      <input type="hidden" name="a" class="a" value="placement">
                      <input type="hidden" name="b" class="b" value="placement1">
                      </form>
                    </div>
                    
                  </div>

                    <?php

                    $com=$tab5;
                    if(isset($_REQUEST["placement_record"])&& $_REQUEST["placement_record"]!="0")
                    {
                      $flag=0;
                      $conditional_id=$_REQUEST["placement_record"];
                      $ssql="SELECT  college_top_recruiters_logo_path from suc_college_other_details where college_id=$conditional_id group by college_id" ;
                      $result=$conn->query($ssql);
                        while($row=$result->fetch_assoc()){
                          $cc=$row["college_top_recruiters_logo_path"];
                        
                        
                        }
                        $cc="gallery/college/placements/".$cc;
                        $pos1 = strpos($cc, "_");
                    $pos2 = strpos($cc, "_", $pos1 + strlen("_"));
                        $com=substr($cc, 0,$pos2);
                        $com;
                         $flag=1;

                    }

                        foreach(glob($tab5) as $filename)
                        {
                             $tbl="suc_college_other_details";
                          $con_field="college_top_recruiters_logo_path";
                          if($flag==1)
                          {
                            $pos1 = strpos($filename, "_");
                            $pos2 = strpos($filename, "_", $pos1 + strlen("_"));
                          if(substr($filename, 0,$pos2)==$com){
                            $file=substr($filename,27);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                         }
                       }
                       else
                       {
                        $file=substr($filename,27);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                       }
                        }
                    ?>
              </div>
      </div>
    </section>
    <!-- /.content -->
  </aside>
  </div>
<?php
if(isset($_REQUEST["a"]))
{
  echo '<input type="hidden" name="" id="tab_Ac" value="'.$_REQUEST["a"].'">';
  echo '<input type="hidden" name="" id="li_Ac" value="'.$_REQUEST["b"].'">';  
}
?>

  <div id="deleteRecord" class="modal fade" role="dialog">

    <div class="modal-dialog" style="width:30%">

      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header" style="background:#3c8dbc; color:#fff;">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title"><b>Delete Category</b></h4>

        </div>

        <form name="formDeleteModal" id="formDeleteRecord" method="post" action="">

          <div class="modal-body text-center">

            <p><h5>You are going to Delete Course Category .</h5></p>

            <h5>

            Do you realy want to <span class="label label-danger" id="stDel"></span></h5>

           
            <input type="hhidden" name="gallery_file_id" id="gallery_file_id" />
             <input type="hhidden" name="gallery_file_name" id="gallery_file_name" />
             <input type="hhidden" name="gallery_tbl_name" id="gallery_tbl_name" />
             <input type="hhidden" name="gallery_tbl_field" id="gallery_tbl_field" />

          </div>

          <div class="modal-footer" style="background:#3c8dbc; color:#fff;">

            <button type="button" class="btn btn-primary" data-dismiss="modal">No</button>

            <button type="button" id="btnDleterecord" name="btnDleterecord" class="btn btn-primary" data-dismiss="modal">Yes</button>

          </div>

        </form>

      </div>

    </div>

  </div>
  <!-- /.content-wrapper -->
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.min.js"></script>
<script >
function xyz(x, y, z, k){
       $("#gallery_file_id").val(x);
      $("#gallery_file_name").val(y);
      $("#gallery_tbl_name").val(z);
      $("#gallery_tbl_field").val(k);

     }

$( "#uni_id" ).change(function() {
  $("#selectfrm").submit();
});
$( "#uni_record" ).change(function() {
  $("#selectfrmUni").submit();

});

$( "#college_record" ).change(function() {
  $("#selectfrmcol").submit();

});
$( "#facility_record" ).change(function() {
  $("#selectfrmfacility").submit();

});
$( "#placement_record" ).change(function() {
  $("#selectfrmplacement").submit();

});


</script>
<script>
$(document).ready(function(){
  $( "#uni_id" ).select2();
  $( "#uni_record" ).select2();
  $( "#college_record" ).select2();
  $( "#facility_record" ).select2();
  $( "#placement_record" ).select2();
 var cc=$("#tab_Ac").val();
 var dd=$("#li_Ac").val();
// alert(cc);
 if( cc == undefined)
 {
  $('#gallery').addClass("active");
    $('#gallery1').addClass("active");

 }

    $('#'+cc).addClass("active");
    $('#'+dd).addClass("active");
});
</script>
<script>

      $('#btnDleterecord').click(function(){
        //alert("model");
        var gallery_file_id=$("#gallery_file_id").val();
        var gallery_file_name=$("#gallery_file_name").val();
        var gallery_tbl_name=$("#gallery_tbl_name").val();
        var gallery_tbl_field=$("#gallery_tbl_field").val();
        //alert(collegeRecord);
        $.ajax({

          type: "POST",

          url: "delete_Action.php?table_name="+gallery_tbl_name+"&cond_id="+gallery_tbl_field+"&filename="+gallery_file_name+"&collegeRecord="+gallery_file_id,
            success: function(response) {
            (response);
            if(response==1){
            
            $("#deleteRecord").modal('hide');
            alert("image deleted");
            
            //$('#sucess').show();
            setTimeout("location.href = 'preview2.php'",2000); 
            }
            else {

             alert("error");
              setTimeout("location.href = 'preview2.php'",2000);
            }

          },

        });

        return false;

      });

    </script>