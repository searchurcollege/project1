<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 
<?php
    include('../includes/header.php');
    $tab1="gallery/*.*";
    $tab2="gallery/university/*.*";
    $tab3="gallery/college/*.*";
    $tab4="gallery/college/facility/*.*";
    $tab5="gallery/college/placements/*.*";
    include("../../../connection/dbconnect.php");
    // $tab1="https://www.searchurcollege.com/exam/admin/search/gallery";
    // $tab1="https://www.searchurcollege.com/exam/admin/search/gallery";
    //include('../includes/left_sidebar1.php');
?>
  <div class="content-wrapper">
    <?php include_once '../includes/left_sidebar1.php';?>
    <aside class="right-side">
    <section class="content-header">
      <h1>
        Gallery
      </h1>
      
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="" id="category1" ><a href="#category" data-toggle="tab">Gallery</a></li>
              <li id="sub-category1"><a href="#sub-category" data-toggle="tab">University</a></li>
              <li><a href="#deals" data-toggle="tab">College</a></li>
              <li><a href="#business" data-toggle="tab">College-facility</a></li>
              <li><a href="#contact_person" data-toggle="tab">College-placement</a></li>
             <!--  <li><a href="#customer" data-toggle="tab">Customer</a></li> -->
            </ul>
            <div class="tab-content">
              <div class=" tab-pane" id="category">
                <div class="row">
                <div class="form-group col-xs-8">
                  <form id="selectfrm"action="preview1.php?id=<?php echo $college_id; ?>">
                      <label for="catName">University</label>
                      <select class="form-control sselect2" id="uni_id" name="uni_id" required>
                       <!--  <option>Select College</option> -->
                        <option value="0">All Colleges</option>

                                                 <?php 
                                                
                                                $sql="SELECT college_id,college_name from suc_college";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $college_id=$row["college_id"];
                                       $college_name=$row["college_name"];

                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if(isset($_REQUEST["uni_id"]))
                                       {
                                        if($_REQUEST["uni_id"]==$college_id)
                                          echo ' <option selected value="'.$college_id.'">'.$college_name.'</option> ';
                                        else
                                          echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                       }
                                       else
                                        echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                      
                                    }
                                                 ?>               
                      </select>
                       <input type="hidden" name="a" class="a" value="category">
                      <input type="hidden" name="b" class="b" value="category1">
                      </form>
                    </div>
                    
                  </div>
                  
                    <?php
                    $tbl="suc_college_gallery";
                    $con_field="college_gallery_content_path";
                    $com="gallery/*.*";
                    if(isset($_REQUEST["uni_id"])&& $_REQUEST["uni_id"]!="0")
                    {
                      $flag=0;
                      $conditional_id=$_REQUEST["uni_id"];
                      $ssql="SELECT  college_gallery_id,college_gallery_content_path from suc_college_gallery where college_id=$conditional_id group by college_id" ;
                      $result=$conn->query($ssql);
                        while($row=$result->fetch_assoc()){
                          $cc=$row["college_gallery_content_path"];
                        
                        
                        }
                        //echo $cc;
                    //echo "ssssssssssss===".$c_gallery_id;
                        $cc="gallery/".$cc;
                        $pos1 = strpos($cc, "_");
                    $pos2 = strpos($cc, "_", $pos1 + strlen("_"));
                        $com=substr($cc, 0,$pos2);
                        //echo $com;
                         $flag=1;

                    }
                        foreach(glob($tab1) as $filename)
                        {
                          //echo $flag;
                          //echo $pos1;
                          //echo "<br><br><br>".substr($filename, 0,$pos2);
                          if($flag==1)
                          {
                            $pos1 = strpos($filename, "_");
                            $pos2 = strpos($filename, "_", $pos1 + strlen("_"));
                          if(substr($filename, 0,$pos2)==$com){
                            $file=substr($filename,8);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                         }
                       }
                       else
                       {
                        $file=substr($filename,8);
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                            
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<button type="button" style="position:absolute; right:15px; background:white;" class="btn  "  title="Remove" onclick=xyz("'.$file.'","'.$filename.'","'.$tbl.'","'.$con_field.'") data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-times"></i></button>';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                       }
                        }
                    ?>
              </div>
              <div class="tab-pane " id="sub-category">
                 <div class="row">
                <div class="form-group col-xs-8">
                  <form id="selectfrmUni"action="preview1.php">
                      <label for="catName">University</label>
                      <select class="form-control sselect2" id="uni_record" name="uni_record" required>
                       <!--  <option>Select College</option> -->
                        <option value="0">All University</option>

                                                 <?php 
                                                
                                                $sql="SELECT uni_id,uni_name from suc_university";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $u_id=$row["uni_id"];
                                       $u_name=$row["uni_name"];

                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if(isset($_REQUEST["uni_id"]))
                                       {
                                        if($_REQUEST["uni_record"]==$u_id)
                                          echo ' <option selected value="'.$u_id.'">'.$u_name.'</option> ';
                                        else
                                          echo ' <option  value="'.$u_id.'">'.$u_name.'</option> ';
                                       }
                                       else
                                        echo ' <option  value="'.$u_id.'">'.$u_name.'</option> ';
                                      
                                    }
                                                 ?>               
                      </select>
                      <input type="hidden" name="a" class="a" value="sub-category">
                      <input type="hidden" name="b" class="b" value="sub-category1">
                      </form>
                    </div>
                    
                  </div>
                    <?php
                        foreach(glob($tab2) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="deals">
                    <?php
                        foreach(glob($tab3) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="business">
                    <?php
                        foreach(glob($tab4) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="contact_person">
                    <?php
                        foreach(glob($tab5) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
      </div>
    </section>
    <!-- /.content -->
  </aside>
  </div>
<?php
if(isset($_REQUEST["a"]))
{
  echo '<input type="hidden" name="" id="tab_Ac" value="'.$_REQUEST["a"].'">';
  echo '<input type="hidden" name="" id="li_Ac" value="'.$_REQUEST["b"].'">';  
}
elseif()
?>

  <div id="deleteRecord" class="modal fade" role="dialog">

    <div class="modal-dialog" style="width:30%">

      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header" style="background:#3c8dbc; color:#fff;">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title"><b>Delete Category</b></h4>

        </div>

        <form name="formDeleteModal" id="formDeleteRecord" method="post" action="">

          <div class="modal-body text-center">

            <p><h5>You are going to Delete Course Category .</h5></p>

            <h5>

            Do you realy want to <span class="label label-danger" id="stDel"></span></h5>

           
            <input type="hhidden" name="gallery_file_id" id="gallery_file_id" />
             <input type="hhidden" name="gallery_file_name" id="gallery_file_name" />
             <input type="hhidden" name="gallery_tbl_name" id="gallery_tbl_name" />
             <input type="hhidden" name="gallery_tbl_field" id="gallery_tbl_field" />

          </div>

          <div class="modal-footer" style="background:#3c8dbc; color:#fff;">

            <button type="button" class="btn btn-primary" data-dismiss="modal">No</button>

            <button type="button" id="btnDleterecord" name="btnDleterecord" class="btn btn-primary" data-dismiss="modal">Yes</button>

          </div>

        </form>

      </div>

    </div>

  </div>
  <!-- /.content-wrapper -->
<?php// include('footer.php');?>
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<script >
//  function myfunction($x)
//  {
//   $("#c_id").val($x);
//  }
function xyz(x, y, z, k){
       $("#gallery_file_id").val(x);
      $("#gallery_file_name").val(y);
      $("#gallery_tbl_name").val(z);
      $("#gallery_tbl_field").val(k);

     }

$( "#uni_id" ).change(function() {
  //alert( "Handler for .change() called." );
  //var id =$("#uni_id").val();
  $("#selectfrm").submit();
});
$( "#uni_record" ).change(function() {
  $("#selectfrmUni").submit();

});

//  $("#gobtn").click(function(){
//  //alert("btn press");
//  // var id =$("#uni_id").val();
//  // $("#c_id").val(id);
//  var id=$("#c_id").val();
//  $.ajax({
//     type: "POST",
//     url: "preview1.php?id="+id,
   
//     success: function() {   
//         location.reload();  
//     }
// });
// });
</script>
<script>
$(document).ready(function(){
 var cc=$("#tab_Ac").val();
 var dd=$("#li_Ac").val();
  //alert(dd);
    $('#'+cc).addClass("active");
    $('#'+dd).addClass("active");
});
</script>
<script>

      $('#btnDleterecord').click(function(){
        //alert("model");
        var gallery_file_id=$("#gallery_file_id").val();
        var gallery_file_name=$("#gallery_file_name").val();
        var gallery_tbl_name=$("#gallery_tbl_name").val();
        var gallery_tbl_field=$("#gallery_tbl_field").val();
        //alert(collegeRecord);
        $.ajax({

          type: "POST",

          url: "delete_Action.php?table_name="+gallery_tbl_name+"&cond_id="+gallery_tbl_field+"&filename="+gallery_file_name+"&collegeRecord="+gallery_file_id,

          // data: $('#formDeleteModal').serialize(),

          success: function(response) {
            alert(response);
            if(response==12){
            alert(response);
            $("#deleteRecord").modal('hide');
            //$('#sucess').show();
            
             setTimeout("location.href = 'preview1.php'",2000);
             // location.reload(); 
            }
            else {
             // $('#failure').show();
             alert("error");
              setTimeout("location.href = 'preview1.php'",2000);
            }

          },

        });

        return false;

      });

    </script>