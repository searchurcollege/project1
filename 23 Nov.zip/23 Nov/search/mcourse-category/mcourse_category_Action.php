	<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
 $k=rtrim($k,', ');
 $v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];

$k1 = explode(", ",$k);
unset($k1[2]);
unset($k1[3]);
$k1 = implode(", ",$k1);
//print "$k1\n";

$k2 = explode(", ",$k);
unset($k2[1]);
unset($k2[5]);
unset($k2[6]);
$k2 = implode(", ",$k2);
$k2.=", search_tag_id";
//print "$k2\n";

$v1 = explode(", ",$v);
unset($v1[2]);
unset($v1[3]);
$v1 = implode(", ",$v1);
//print "$v1\n";

$v2 = explode(", ",$v);
unset($v2[1]);
unset($v2[5]);
unset($v2[6]);
$v2 = implode(", ",$v2);
$v2.=", '".$_REQUEST["course_cat_name"]."'";
//print "$v2\n";
	

 $sql ="INSERT INTO $tbl_name(".$k1.") VALUES (".$v1.")" ;
 
if ($conn->query($sql) == TRUE) {
	$sql1="INSERT INTO suc_search_tag(".$k2.") VALUES (".$v2.")" ;
	if($conn->query($sql1) == TRUE)
	{	
		echo 1;
	}
    //echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
//echo 1;//"success";
?>