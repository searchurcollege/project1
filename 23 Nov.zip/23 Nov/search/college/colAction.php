
<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
$k=rtrim($k,', ');
$v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];

$k1 = explode(", ",$k);
unset($k1[4]);
unset($k1[5]);
$k1 = implode(", ",$k1);
//print "$k1\n";

$k2 = explode(", ",$k);
foreach($k2 as $i =>$key) {

    if($i!=4 && $i!=5 && $i!=1 && $i!=13)
    {
      unset($k2[$i]);
    }

}

$k2 = implode(", ",$k2);
$k2.=", search_tag_id";
//print "$k2\n";

$v1 = explode(", ",$v);
unset($v1[5]);
unset($v1[4]);
$v1 = implode(", ",$v1);
//print "$v1\n";

$v2 = explode(", ",$v);
foreach($v2 as $i =>$key) {

    if($i!=4 && $i!=5 && $i!=1 && $i!=13)
    {
      unset($v2[$i]);
    }

}
$v2 = implode(", ",$v2);
$v2.=", '".$_REQUEST["college_name"]."'";
//echo $_FILES['college_image_path']['name'];
 
if(!empty(array_filter($_FILES['college_image_path']['name']))){
    //echo "1";
        foreach($_FILES['college_image_path']['name'] as $key=>$val){
            $sql ="INSERT INTO $tbl_name(".$k1.") VALUES (".$v1.")" ;
            if ($conn->query($sql) == TRUE) {
                 $last_id = $conn->insert_id;
                 $sql1 ="INSERT INTO suc_search_tag(".$k2.") VALUES (".$v2.")" ;
                 $conn->query($sql1);

              // echo "success";
            } else {
                 // "Error: " . $sql . "<br>" . $conn->error;
                echo "error";
            }
             $allowedExts = array("gif", "jpeg", "jpg", "png");
           // $extension = end(explode(".", $_FILES["college_image_path"]["name"]));

            // $currentDir = '../'.getcwd().'/gallery/college/facility';
            chdir('../gallery/college');
            $currentDir = getcwd();
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['college_image_path']['name'][$key];
            $fileSize = $_FILES['college_image_path']['size'][$key];
            $fileTmpName  = $_FILES['college_image_path']['tmp_name'][$key];
            $fileType = $_FILES['college_image_path']['type'][$key];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="col_".$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET college_image_path='$fn' WHERE college_id='$last_id'";
                          $result=$conn->query($sql1);
                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
        }
        echo $last_id;
         
    }
    
?>
