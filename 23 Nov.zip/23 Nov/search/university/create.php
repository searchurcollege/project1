<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->

<?php
  session_start ();
  $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Add University
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi"  class="well" aaction="https://www.searchurcollege.com/exam/admin/search/university/universityAction.php?table_name=suc_university" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										<div class="form-group col-xs-4">
											<label for="catName">University Name</label>
											<input type="text" placeholder="University Name" class="form-control " required name="uni_name" id="uni_name" value="" />
										</div>
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                        <div class="form-group col-xs-4">
											<label for="catName">Location</label>
											<select class="form-control " required id="uni_location_id" name="uni_location_id"> 
												<option>Select Location</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                $sql="SELECT id,location_name from location";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $lid=$row["id"];
            						               $lname=$row["location_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
            						              echo ' <option  value="'.$lid.'">'.$lname.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>
										<input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>"> 
                                        <div class="form-group col-xs-4">
											<label for="catName">University Image</label>
											<input type="file" placeholder="University Name" class="form-control" name="uni_image_path[]" multiple id="uni_image_path" value="" required />
										</div>
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Address</label>
											<textarea class="form-control summernote" id="Address" name="uni_address"></textarea>
										</div>
                                        <div class="form-group col-xs-6">
											<label for="catName">University Contact 1</label>
											<input type="text" placeholder="University Contact 1" class="form-control " required name="uni_phone1" id="uni_phone1" value="" />
										</div>
                                        <div class="form-group col-xs-6">
											<label for="catName">University Contact 2</label>
											<input type="text" placeholder="University Contact 2" class="form-control " required name="uni_phone2" id="uni_phone2" value="" />
										</div>
                                        <div class="form-group col-xs-6">
											<label for="catName">University Email</label>
											<input type="text" placeholder="University Email" class="form-control " required name="uni_email" id="uni_email" value="" />
										</div>
                                        <div class="form-group col-xs-6">
											<label for="catName">University Website</label>
											<input type="text" placeholder="University Website" class="form-control " required name="uni_website" id="uni_website" value="" />
										</div>
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Description</label>
											<textarea class="form-control summernote" id="Description" name="uni_desc"></textarea>
										</div>
                                        	
										<div class="form-group col-xs-6">
											<label for="catName">Establishment Date</label>
											<input type="text" placeholder="MM/DD/YYYY" class="form-control " name="uni_establishment_dt" id="datepicker" value=""required />
										</div>
                                        <div class="form-group col-xs-6">
											<label for="catName">Type</label>
											<select class="selectpicker form-control" id="uni_type" name="uni_type">
                                     <option>Select Type</option>
                                    <option  value="1">Goverment</option>
                                     <option  value="2">Private</option>
                                  </select>  
										</div>
                                        			
										 <div class="form-group col-xs-12"> 
											<label for="cat_Description">Admission Notes</label>
											<textarea class="form-control summernote" placeholder="Admission Notes" id="uni_admission_notes" name="uni_admission_notes"></textarea>
										</div>
                                         <div class="form-group col-xs-4">
											<label for="catName">University Management</label>
											<input type="text" placeholder="University Management" class="form-control " required name="uni_management_style" id="uni_management_style" value="" />
										</div>
                                         <div class="form-group col-xs-4">
											<label for="catName">University Code Flag</label>
											<input type="text" placeholder="University Email" class="form-control " required name="uni_code_flag" id="uni_code_flag" value="" />
										</div>
                                         <div class="form-group col-xs-4">
											<label for="catName">Minority Type</label>
											<input type="text" placeholder="Minority Type" class="form-control " required name="uni_minority_type" id="uni_minority_type" value="" />
										</div>
                                         <div class="form-group col-xs-3">
											<label for="catName">UGC Approved</label>
											<input checked  id="uni_ucg_status" name="uni_ucg_status" value="1" type="checkbox" />
										</div>
                                         <div class="form-group col-xs-3">
											<label for="catName">AIU Approved</label>
											<input checked data-toggle="toggle" data-onstyle="warning" value="1" id="uni_aiu_status" name="uni_aiu_status" type="checkbox" />
										</div>
                                         <div class="form-group col-xs-3">
											<label for="catName">AICTE Approved</label>
											<input checked data-toggle="toggle" data-onstyle="warning" value="1" id="uni_aicte_approved" name="uni_aicte_approved" type="checkbox"/>
										</div>
                                         <div class="form-group col-xs-3">
											<label for="catName">Status</label>
											<input checked  id="uni_ucg_status" name="uni_status" value="1" type="checkbox" />
										</div>
                                       
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
						<div id="success" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record INSERTED</h4> </center></div>
<div id="failure" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: red; width: 30%; color: ">ERROR....</h4> </center></div>
					</div>	
				</div>
			</section>
		</aside>
	</div>
	
<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
 

 <script>
    $(document).ready(function(){

      $("#frmSubmi").submit(function(e){
      	//alert("s0");
      	 e.preventDefault();
       $.ajax({
            url:"universityAction2.php?table_name=suc_university",
            method:"POST",
           // data: $('#frmSubmi').serialize(),
            data: new FormData(this),
      	  contentType: false,       // The content type used when sending data to the server.
        	cache: false,             // To unable request pages to be cached
      	  processData:false, 
            success:function(data)
            {
            	alert(data);
            	if(data==1)
            	{
                	$("#success").fadeIn().delay(1000).fadeOut();
            		setTimeout("location.href = 'create.php'",2000);
            	}
                
            	else
            	{
                	$('#failure').fadeIn().delay(1000).fadeOut();
                	setTimeout("location.href = 'create.php'",2000);
            	}
            	//
                //alert(data);
    		}
        });
      });
    });
    </script>