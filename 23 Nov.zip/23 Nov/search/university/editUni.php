  <?php 
include("../../../../connection/dbconnect.php");

$id=$_REQUEST['id'];
$ssql="SELECT * from suc_university where uni_id=$id";
$rslt=$conn->query($ssql);
      
            while($rw=$rslt->fetch_assoc())
            {
                $u_name=$rw["uni_name"];
                $u_desc=$rw["uni_desc"];
                $u_img=$rw["uni_image_path"];
                $u_location_id=$rw["uni_location_id"];
                $u_address=$rw["uni_address"];
                $u_phone1=$rw["uni_phone1"];
                $u_phone2=$rw["uni_phone2"];
                $u_email=$rw["uni_email"];
                $u_website=$rw["uni_website"];

                $u_establishment_dt=$rw["uni_establishment_dt"];
                $u_type=$rw["uni_type"];
                $u_ucg_status=$rw["uni_ucg_status"];
                $u_aiu_status=$rw["uni_aiu_status"];
                $u_aicte_approved=$rw["uni_aicte_approved"];
                $u_code_flag=$rw["uni_code_flag"];
                $u_minority_type=$rw["uni_minority_type"];
                $u_management_style=$rw["uni_management_style"];
                $u_admission_notes=$rw["uni_admission_notes"];
                $u_status=$rw["uni_status"];
            }
            $sql="SELECT id,location_name from location where id=$u_location_id;";
			$result=$conn->query($sql);
				while($row=$result->fetch_assoc())
            {
                $c_lid=$row["id"];
               $c_lname=$row["location_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
    		}

?>


 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script src="https://code.jquery.com/jquery-1.12.4.js" integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU=" crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Edit University
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi"  class="well" aaction="https://www.searchurcollege.com/exam/admin/search/university/universityAction.php?table_name=suc_university" method="POST">
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-12">
                    <div class="form-group col-xs-4">
                      <label for="catName">University Name</label>
                      <input type="text" placeholder="University Name" class="form-control " required name="uni_name" id="uni_name" value="<?php echo $u_name; ?>" />
                    </div>
                    
                                        <div class="form-group col-xs-4">
                      <label for="catName">Location</label>
                      <select class="form-control " required id="uni_location_id" name="uni_location_id"> 
                        <option>Select Location</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                $sql="SELECT id,location_name from location";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                        $lid=$row["id"];
                                       $lname=$row["location_name"];
                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                      if($u_location_id==$lid)
                                        echo ' <option selected value="'.$lid.'">'.$lname.'</option> ';
                                      else
                                        echo ' <option  value="'.$lid.'">'.$lname.'</option> ';  
                                      
                                    }
                                                 ?>               
                      </select>
                    </div>
                    
                                        <div class="form-group col-xs-4">
                      <img src="../gallery/university/<?php echo $u_img; ?>" style="height: 100px;">
                    </div>
                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">Address</label>
                      <textarea class="form-control summernote" id="Address" name="uni_address"><?php echo $u_address; ?></textarea>
                    </div>
                                        <div class="form-group col-xs-6">
                      <label for="catName">University Contact 1</label>
                      <input type="text" placeholder="University Contact 1" class="form-control " required name="uni_phone1" id="uni_phone1" value="<?php echo $u_phone1; ?>" />
                    </div>
                                        <div class="form-group col-xs-6">
                      <label for="catName">University Contact 2</label>
                      <input type="text" placeholder="University Contact 2" class="form-control " required name="uni_phone2" id="uni_phone2" value="<?php echo $u_phone2; ?>" />
                    </div>
                                        <div class="form-group col-xs-6">
                      <label for="catName">University Email</label>
                      <input type="text" placeholder="University Email" class="form-control " required name="uni_email" id="uni_email" value="<?php echo $u_email; ?>" />
                    </div>
                                        <div class="form-group col-xs-6">
                      <label for="catName">University Website</label>
                      <input type="text" placeholder="University Website" class="form-control " required name="uni_website" id="uni_website" value="<?php echo $u_website; ?>" />
                    </div>
                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">Description</label>
                      <textarea class="form-control summernote" id="Description" name="uni_desc"><?php echo $u_desc; ?></textarea>
                    </div>
                                          
                    <div class="form-group col-xs-6">
                      <label for="catName">Establishment Date</label>
                      <input type="text" placeholder="MM/DD/YYYY" class="form-control " name="uni_establishment_dt" id="datepicker" value="<?php echo $u_establishment_dt; ?>"required />
                    </div>
                                        <div class="form-group col-xs-6">
                      <label for="catName">Type</label>
                      <select class="selectpicker form-control" id="uni_type" name="uni_type">
                        <?php
                        if($u_type=="1")
                          echo '<option>Select Type</option>
                                <option selected value="1">Goverment</option>
                                <option  value="2">Private</option>';
                        else
                          echo '<option>Select Type</option>
                                <option  value="1">Goverment</option>
                                <option selected value="2">Private</option>';
                        ?>
                                     
                                  </select>  
                    </div>
                                              
                     <div class="form-group col-xs-12"> 
                      <label for="cat_Description">Admission Notes</label>
                      <textarea class="form-control summernote" placeholder="Admission Notes" id="uni_admission_notes" name="uni_admission_notes"><?php echo $u_admission_notes; ?></textarea>
                    </div>
                                         <div class="form-group col-xs-4">
                      <label for="catName">University Management</label>
                      <input type="text" placeholder="University Management" class="form-control " required name="uni_management_style" id="uni_management_style" value="<?php echo $u_management_style; ?>" />
                    </div>
                                         <div class="form-group col-xs-4">
                      <label for="catName">University Code Flag</label>
                      <input type="text" placeholder="University Email" class="form-control " required name="uni_code_flag" id="uni_code_flag" value="<?php echo $u_code_flag; ?>" />
                    </div>
                                         <div class="form-group col-xs-4">
                      <label for="catName">Minority Type</label>
                      <input type="text" placeholder="Minority Type" class="form-control " required name="uni_minority_type" id="uni_minority_type" value="<?php echo $u_minority_type; ?>" />
                    </div>
                                         <div class="form-group col-xs-3">
                                          <?php
                                          if($u_ucg_status==1)
                                            echo ' <label for="catName">UGC Approved</label>
                                                   <input checked  id="uni_ucg_status" name="uni_ucg_status" value="1" type="checkbox" />';
                                          else
                                            echo ' <label for="catName">UGC Approved</label>
                                                    <input   id="uni_ucg_status" name="uni_ucg_status" value="1" type="checkbox" />';
                                          ?>
                     
                    </div>
                                         <div class="form-group col-xs-3">
                                          <?php
                                          if($u_aiu_status==1)
                                            echo '<label for="catName">AIU Approved</label>
                                                     <input checked data-toggle="toggle" data-onstyle="warning" value="1" id="uni_aiu_status" name="uni_aiu_status" type="checkbox" />';
                                          else
                                            echo '<label for="catName">AIU Approved</label>
                                                     <input  data-toggle="toggle" data-onstyle="warning" value="1" id="uni_aiu_status" name="uni_aiu_status" type="checkbox" />';
                                          ?>
                     
                    </div>
                                         <div class="form-group col-xs-3">
                                          <?php
                                          if($u_aicte_approved==1)
                                            echo '<label for="catName">AICTE Approved</label>
                                                  <input checked data-toggle="toggle" data-onstyle="warning" value="1" id="uni_aicte_approved" name="uni_aicte_approved" type="checkbox"/>';
                                          else
                                            echo '<label for="catName">AICTE Approved</label>
                                                  <input  data-toggle="toggle" data-onstyle="warning" value="1" id="uni_aicte_approved" name="uni_aicte_approved" type="checkbox"/>';
                                          ?>
                      
                    </div>
                                         <div class="form-group col-xs-3">
                                           <?php
                                          if($u_status==1)
                                            echo '<label for="catName">Status</label>
                                                   <input checked  id="uni_ucg_status" name="uni_status" value="1" type="checkbox" />';
                                          else
                                            echo '<label for="catName">Status</label>
                                                   <input   id="uni_ucg_status" name="uni_status" value="1" type="checkbox" />';
                                          ?>
                      
                    </div>
                                       
                 </div>
              </div>
              <div class="box-footer clearfix"> 
                <div class="col-xs-12"> 
                  <div class="col-xs-12 pull-right">
                    <button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
                  </div>
                </div>
              </div>
            </form>
            <div id="success" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Updated....</h4> </center></div>
<div id="failure" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: red; width: 30%; color:red ;">ERROR....</h4> </center></div>
					</div>	
				</div>
			</section>
		</aside>
	</div>
  

<!-- <div style="background: red ; height: 30px;"></div> -->
<script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  
 <script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
        e.preventDefault();
        //alert("ajax");
       
       //alert(ugcstatus);
       $.ajax({
        url:"updateUniversity.php?table_name=suc_university&location_id=<?php  echo $id;?>",
        method:"POST",
       data: new FormData(this),
          contentType: false,       // The content type used when sending data to the server.
          cache: false,             // To unable request pages to be cached
          processData:false, 
            
            success:function(data)
            {
             // alert(data);
                if(data==1)
                {
                    $("#success").show();
                    setTimeout("location.href = 'viewUniversity.php'",2000);
                }
                else
                    $('#failure').show();
                  setTimeout("location.href = 'viewUniversity.php'",2000);
                //setTimeout("location.href = 'viewUniversity.php'",2000);
            }
        });
       });
    });
    </script>
    