
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
<!-----------------------------End------------------------------->
<?php include_once '../../includes/header.php';
session_start ();
	 $email=$_SESSION['ademail'];?>
<center><h1 ><?php //echo $email; ?></h1> </center>
    <div class="wrapper row-offcanvas row-offcanvas-left">

        <!-- Left side column. Contains the navbar and content of the page -->

		<?php include_once '../../includes/left_sidebar.php';?>

        <aside class="right-side">                

            <!-- Content Header (Page header) -->

            <section class="content-header">
            <form id="frmSubmitt" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/university/universityAction.php" method="POST">
                <h4>University
                <button id="frmSubmit" type="submit" class="btn btn-success pull-right" >Submit</button>

                </h4>
            </section>

            <!-- Main content -->

            
                    <div class="container" sstyle="margin-right: 30px;"><br /><br />
      
                   
                      <fieldset>
                         <div class="form-group">
                            <label class="col-md-2 control-label">University Name</label>
                            
                            
                            <div class="col-md-4 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="UniName" name="UniName" placeholder="University Name" class="form-control" required="true" value="" type="text"></div>
                            </div><br /><br />
                            <input id="email" name="emaill"  value="<?php echo $email; ?>" type="hidden">
                         </div>
                         <div class="form-group">
                            <label class="col-md-2 control-label">Description</label>
                            <div class="col-md-4 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><textarea class="form-control " id="description" name="description" rows="3"></textarea></div>
                            </div>
                         </div><br /><br /><br />
                         <div class="form-group"><br /><br />
                            <label class="col-md-2 control-label">Location</label>
                            <div class="col-md-4 inputGroupContainer">
                            	<div class="input-group">
                                  <span class="input-group-addon" style="max-width: 100%;"><i class="glyphicon glyphicon-user" ></i></span>
                                  <select class="selectpicker form-control" name="unilocation">
                                     <option>Select Location</option>
                                     <?php 
                                    include("../../../../connection/dbconnect.php");
                                    $sql="SELECT id,location_name from location";
									$result=$conn->query($sql);
       								while($row=$result->fetch_assoc())
						            {
						                $lid=$row["id"];
						               $lname=$row["location_name"];
						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
						              echo ' <option  value="'.$lid.'">'.$lname.'</option> ';
						            }
                                     ?>
                                  </select>
                               </div>
                               <!-- <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="unilocation" name="unilocation" placeholder="Location" class="form-control" required="true" value="" type="text"></div> -->
                            </div>
                         </div><br /><br />
                         <div class="form-group">
                            <label class="col-md-2 control-label">Establishment Date</label>
                            <div class="col-md-4 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"></span><input id="datepicker" name="establishdt" placeholder="Establishment Date" class="form-control" required="true" width="310"></div>

                            </div>
                         </div><br /><br />
                         <div class="form-group">
                            <label class="col-md-2 control-label">Type</label>
                            <div class="col-md-4 inputGroupContainer">
                              <div class="input-group">
                                  <span class="input-group-addon" style="max-width: 100%;"><i class="glyphicon glyphicon-list" ></i></span>
                                  <select class="selectpicker form-control" name="unitype">
                                     <option>Select Type</option>
                                    <option  value="1">Goverment</option>
                                     <option  value="2">Private</option>
                                  </select>
                               </div>
                            </div>
                         </div><br /><br />
                         <div class="form-group">
                            <label class="col-md-2 control-label">Admission Notes</label>
                            <div class="col-md-4 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><textarea class="form-control rounded-0" id="exampleFormControlTextarea2" name="admissionNote"rows="3"></textarea></div>
                            </div>
                         </div><br /><br />
                         <div class="row"><br /><br />
                          <div class="col-md-12 ">
                            <div class="col-md-3 inputGroupContainer">
                                <label class="col-md-8">UGC Approved</label>
                                <div class="col-md-2">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input checked  name="ugcstatus" value="1" type="checkbox"></div>
                            </div>
                            </div>
                            <div class="col-md-3 inputGroupContainer">
                                <label class="col-md-8 text-right">AICTE Approved</label>
                                <div class="col-md-2">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input checked data-toggle="toggle" data-onstyle="warning" value="1" name="aiustatus" type="checkbox"></div>
                            </div>
                            </div>
                            <div class="col-md-3 inputGroupContainer">
                                <label class="col-md-8 text-right">Status</label>
                                <div class="col-md-2">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input checked data-toggle="toggle" data-onstyle="warning" name="unistatus" type="checkbox" value="1"></div>
                            </div>
                            </div>
                          </div>  
                        
                         </div>
                      </fieldset>
                   </form>
               
                    </div>
                    </div>
		

<?php include_once '../includes/footer.php';?>

<script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script>

 <script>
    $(document).ready(function(){
      $("#frmSubmitt").click(function(e){
       // alert("ajax");
        var email=$("#email").val();
        var 
        alert(email);
          $.ajax({
                    url:"https://www.searchurcollege.com/exam/admin/search/university/universityAction.php",
                    method:"POST",
                    // data:{query:query},
                    success:function(data)
                    {
                    alert(data);
                    }
                });
      //     e.preventDefault();
      //   $.ajax({type: "POST",
      //           url: "/imball-reagens/public/shareitem",
      //           data: { id: $("#Shareitem").val(), access_token: $("#access_token").val() },
      //           success:function(result){
      //     $("#sharelink").html(result);
      //   }});
       });
    });
    </script>
<!-- 
<script type="text/javascript">
	$('#frmRegister').submit(function(event) {
          $.post(
           'https://www.searchurcollege.com/exam/admin/search/university/universityAction.php',
            $(this).serialize(),
            function(data){
            	alert(data);
                // if()
                // {
                    
                // }
                // else
                // {
                   
                // }
          });
          return false;   
        });
	$(document).ready(function () {
    $('#datepicker').datepicker({
      uiLibrary: 'bootstrap'
    });
});
	</script> -->