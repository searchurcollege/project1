<?php
 $a=$_REQUEST['uniRecord'];
 include("../../../../connection/dbconnect.php");
  $sql="DELETE FROM suc_university WHERE uni_id='$a' ";
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>