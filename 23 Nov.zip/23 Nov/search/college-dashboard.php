<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>

<?php include_once '../includes/header.php';?>

    <div class="wrapper row-offcanvas row-offcanvas-left">

        <!-- Left side column. Contains the navbar and content of the page -->

		<?php include_once '../includes/left_sidebar1.php';?>

                
           
        <aside class="right-side"> 
         <section class="content-header">

                <h4>Add College</h4>
                <form action="college-dashboard.php">
                    <input type="submit" name="Reset">
                </form>
                

            </section>    
                      
        <!-- Main content -->
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#college" data-toggle="pill" >Basic Details</a></li>
                <li><a href="#gallery" data-toggle="pill" >Gallery</a></li>
                <li><a href="#placement" data-toggle="pill" >Placement</a></li>
                <li><a href="#contact" data-toggle="pill" >Contact</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="college">
                    <?php include('college/college.php');?>
                </div>
               
               <div class="tab-pane" id="gallery">
                    <?php include('college-gallery/college-gallery.php');?> 
                </div> 
                <div class="tab-pane" id="placement">
                    <?php  include('college-other-details/college-other-details.php');?> 
                </div>
                
                <div class="tab-pane" id="contact">
                    <?php  include('college-contact/college-contact.php');?> 
                </div>
                
            </div>            
        </div>
        </aside><!-- /.right-side -->

    </div>

<?php// include_once '../includes/footer.php';?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.min.js"></script>

<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
