 <?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$id=$_REQUEST['id'];
 $ssql="SELECT * from suc_master_course where course_id='$id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
               $c_name=$rw["course_name"];
              $c_cat_id=$rw["course_cat_id"];
              $c_stream=$rw["course_stream_id"];
              $c_desc=$rw["course_desc"];  
              $u_status=$rw["course_status"];
            }
          $sql="SELECT course_cat_id,course_cat_name from suc_master_course_category where course_cat_id=$c_cat_id;";
          $result=$conn->query($sql);
          while($row=$result->fetch_assoc())
            {
              $c_ccatid=$row["course_cat_id"];
              $c_ccatname=$row["course_cat_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
        $sql="SELECT course_stream_id,course_stream_name from suc_master_course_stream where course_stream_id=$c_stream;";
      $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
            {
                $c_cstreamid=$row["course_stream_id"];
                $c_cstreamname=$row["course_stream_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
?>

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Edit Master Course
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi" class="well" action="https://www.searchurcollege.com/exam/admin/search/college-mcourse/college_mcourse_Update.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Category Name</label>
											<select class="form-control" id="course_cat_id" name="course_cat_id" required>
												<option>Select Course Category</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                $sql="SELECT course_cat_id,course_cat_name from suc_master_course_category";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $course_id=$row["course_cat_id"];
            						               $course_name=$row["course_cat_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if($course_id==$c_ccatid)
            						              echo ' <option selected value="'.$course_id.'">'.$course_name.'</option> ';
                                    else
                                      echo ' <option value="'.$course_id.'">'.$course_name.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>

                                        <div class="form-group col-xs-4">
                                          <label for="catName">Stream Name</label>
                                          <select class="form-control" id="course_stream_id" name="course_stream_id" required>
                                            <option>Select Stream Name</option>
                                                                     <?php 
                                                                    include("../../../../connection/dbconnect.php");
                                                                    $sql="SELECT course_stream_id,course_stream_name from suc_master_course_stream";
                                                  $result=$conn->query($sql);
                                                      while($row=$result->fetch_assoc())
                                                        {
                                                            $stream_id=$row["course_stream_id"];
                                                           $stream_name=$row["course_stream_name"];
                                                         //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                                           if($stream_id==$c_cstreamid)
                                                          echo ' <option selected value="'.$stream_id.'">'.$stream_name.'</option> ';
                                                        else
                                                          echo ' <option  value="'.$stream_id.'">'.$stream_name.'</option> ';
                                                        }
                                                                     ?>               
                                          </select>
                                        </div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Name</label>
											<input type="text" placeholder="Course Name" class="form-control" name="course_name" id="course_name" value="<?php echo $c_name; ?>" required />
										</div>
                    
                    <!-- <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>"> -->
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Description</label>
											<textarea class="form-control summernote" id="course_desc" name="course_desc"><?php echo $c_desc; ?></textarea>
										</div>
                                        	
										<div class="col-md-3 inputGroupContainer">
                                            <label class="col-md-4">Status</label>
                                            <div class="col-md-2">
                                              <?php
                                                    if($u_status==1)
                                                        echo '<div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="course_status" name="course_status" type="checkbox" value="1"></div>';
                                                    else
                                                        echo '<div class="input-group"><input  data-toggle="toggle" data-onstyle="warning" id="course_status" name="course_status" type="checkbox" value="1"></div>';
                                                ?>
                                           
                                        </div>
                                        </div>
                                      </div>  
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>	
				</div>
			</section>
		</aside>

    
	</div>
  <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Updated..</h4></center></div>
	<!-- <div style="background: red ; height: 30px;"></div> -->
<?php include_once '../includes/footer.php';?>
<!-- <script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script> -->
  <script>
	//CKEDITOR.replace( 'course_desc' );
    
  </script>

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
        //alert("ajax");
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_mcourse_Update.php?table_name=suc_master_course&course_id=<?php echo $id ?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
         // alert(data);
          if(data=="success"){
            $('#success').show();
            setTimeout("location.href = 'college_mcourse_View.php'",2000);
        }
        }
      });
      
      
    });
  });
</script>