<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 
<?php
    include('../includes/header.php');
    $tab1="gallery/*.*";
    $tab2="gallery/university/*.*";
    $tab3="gallery/college/*.*";
    $tab4="gallery/college/facility/*.*";
    $tab5="gallery/college/placements/*.*";
    // $tab1="https://www.searchurcollege.com/exam/admin/search/gallery";
    // $tab1="https://www.searchurcollege.com/exam/admin/search/gallery";
    //include('../includes/left_sidebar1.php');
?>
  <div class="content-wrapper">
    <?php include_once '../includes/left_sidebar1.php';?>
    <aside class="right-side">
    <section class="content-header">
      <h1>
        Gallery
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#category" data-toggle="tab">Gallery</a></li>
              <li><a href="#sub-category" data-toggle="tab">University</a></li>
              <li><a href="#deals" data-toggle="tab">College</a></li>
              <li><a href="#business" data-toggle="tab">College-facility</a></li>
              <li><a href="#contact_person" data-toggle="tab">College-placement</a></li>
             <!--  <li><a href="#customer" data-toggle="tab">Customer</a></li> -->
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="category">
                    <?php
                        foreach(glob($tab1) as $filename)
                        {
                           echo '<div class="col-md-3 col-sm-6 col-xs-12" title="'.$filename.'">';
                           echo '<div class="info-box" style="padding-bottom: 30px;">';
                           echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                           echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="sub-category">
                    <?php
                        foreach(glob($tab2) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="deals">
                    <?php
                        foreach(glob($tab3) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="business">
                    <?php
                        foreach(glob($tab4) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
              <div class="tab-pane" id="contact_person">
                    <?php
                        foreach(glob($tab5) as $filename)
                        {
                             echo '<div class="col-md-2 col-sm-6 col-xs-12" title="'.$filename.'">';
                             echo '<div class="info-box">';
                             echo '<img class="fancybox" src="'.$filename.'" style="width: 100%; height: 150px; border: 1px dotted gray;" />';
                             echo '</div></div>';
                        }
                    ?>
              </div>
      </div>
    </section>
    <!-- /.content -->
  </aside>
  </div>
  <!-- /.content-wrapper -->
<?php// include('footer.php');?>
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>