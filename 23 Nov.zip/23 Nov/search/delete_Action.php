<?php
 $a=$_REQUEST['collegeRecord'];
 include("../../../connection/dbconnect.php");
 $tbl_name=$_REQUEST["table_name"];
 $condition=$_REQUEST["cond_id"];
 if(isset($_REQUEST["filename"]))
 {
 	 $fileName=$_REQUEST["filename"];
 }
 $sql="select * from $tbl_name where $condition='$a'";
  $sql="DELETE FROM ".$tbl_name." WHERE ". $condition."='$a' ";
if ($conn->query($sql) == TRUE) {
	echo 1;
	if(unlink($fileName));
    	//echo 2;

} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}

?>