 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];
   include("../../../../connection/dbconnect.php");
   ?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Add College Course
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                       <div class="form-group col-xs-4">
                      <label for="catName">College Name</label>
                      <select class="form-control" id="college_id" name="college_id" required>
                        <option>Select College</option>
                                                 <?php 
                                                
                                                $sql="SELECT college_id,college_name from suc_college";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                        $college_id=$row["college_id"];
                                       $college_name=$row["college_name"];
                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                      echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                    }
                                                 ?>               
                      </select>
                    </div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Master Course</label>
											<select class="form-control" id="master_course_id" name="master_course_id" required>
												<option>Select Master Course</option>
                                                 <?php 
                                                
                                                $sql="SELECT course_id,course_name from suc_master_course";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $course_id=$row["course_id"];
            						               $course_name=$row["course_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
            						              echo ' <option  value="'.$course_id.'">'.$course_name.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>
                    
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Name</label>
											<input type="text" placeholder="Course Name" class="form-control" name="college_course_name" id="college_course_name" value="" required />
										</div>
                                        <div class="form-group col-xs-4">
                                          <label for="catName">Course Type</label>
                                          <select class="form-control" id="college_course_type" name="college_course_type" required>
                                                <option>Select Course Type</option>
                                                <option  value="regular">Regular</option>
                                                <option  value="Distance">Distance</option>
                                            </select> 
                                        </div>
                                        <div class="form-group col-xs-3">
                                          <label for="catName">Mode of Study</label>
                                          <select class="form-control" id="college_course_full_part" name="college_course_full_part" required>
                                                <option>Select Mode of Study</option>
                                                <option  value="Full Time">Full Time</option>
                                                <option  value="Part Time">Part Time</option>
                                                
                                            </select> 
                                        </div>
                                        <div class="form-group col-xs-4">
                                          <label for="catName">Course Duration</label>
                                          <select class="form-control" id="college_course_duration" name="college_course_duration" required />
                                                <option>Select Mode of Study</option>
                                                <option  value="1 Month">1 Month</option>
                                                <option  value="6 Month">6 Month</option>
                                                <option  value="1 Year">1 Year</option>
                                                <option  value="2 Year">2 Year</option>
                                                <option  value="3 Year">3 Year</option>
                                                <option  value="4 Year">4 Year</option>
                                            </select> 
                                        </div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Language</label>
											<select class="form-control" id="college_course_language" name="college_course_language" required />
												<option>Select Type</option>
                                                <option  value="English">English</option>
                                                <option  value="Hindi">Hindi</option>
                                            </select> 
										</div>
                    <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Fees</label>
											<select class="form-control" id="college_course_fee_id" name="college_course_fee_id" required />
												<option>Select Type</option>
												<?php 
                                                //include("../../../../connection/dbconnect.php");
                                                $sql1="SELECT cc_fee_id,cc_total_fee from suc_college_course_fee_structure";
            									$result1=$conn->query($sql1);
                   								while($row1=$result1->fetch_assoc())
            						            {
            						                $cc_fee=$row1["cc_fee_id"];
            						               $cc_total_fee=$row1["cc_total_fee"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
            						              echo ' <option  value="'.$cc_fee.'">'.$cc_total_fee.'</option> ';
            						            }
                                                 ?>
                                            </select> 
										</div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Seats</label>
											<input type="text" placeholder="Course Name" class="form-control" name="college_course_seats" id="college_course_seats" value="" required />
										</div>
                                        <div class="col-md-4 inputGroupContainer">
                                            <label class="col-md-4">Status</label>
                                            <div class="col-md-2">
                                           <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="college_course_status" name="college_course_status" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                      
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
            <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Inserted</h4></center></div>
					</div>

				</div>
			</section>
			
		</aside>

    
	</div>
  

<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_course_Action.php?table_name=suc_college_courses",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          //alert(data);
          if(data==1){
            $('#success').fadeIn().delay(1000).fadeOut();
            setTimeout("location.href = 'college-course.php'",2000);
        }
        }
      });
      
      
    });
  });
</script>
