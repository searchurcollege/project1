 <?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$id=$_REQUEST['id'];
 $ssql="SELECT * from suc_college_courses where college_course_id='$id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
               $c_name=$rw["college_course_name"];
               $c_master_id=$rw["master_course_id"];
              $c_type=$rw["college_course_type"];
              $c_fullpart=$rw["college_course_full_part"];
              $c_duration=$rw["college_course_duration"];
              $c_language=$rw["college_course_language"];
              $c_fee_id=$rw["college_course_fee_id"];
              $c_status=$rw["college_course_status"];
            }
           $sql="SELECT course_id,course_name from suc_master_course where course_id=$c_master_id";
          $result=$conn->query($sql);
          while($row=$result->fetch_assoc())
            {
            $c_cmasterid=$row["course_id"];
              $c_cmastername=$row["course_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
        $sql="SELECT cc_fee_id,cc_total_fee from suc_college_course_fee_structure where cc_fee_id=$c_fee_id";
      $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
            {
                $c_cfeeid=$row["cc_fees_id"];
                $c_ctotalfee=$row["cc_total_fee"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
?>

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Edit College Course
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                        <div class="form-group col-xs-4">
											<label for="catName">Master Course</label>
											<select class="form-control" id="master_course_id" name="master_course_id" required>
												<option>Select Master Course</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                $sql="SELECT course_id,course_name from suc_master_course";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $course_id=$row["course_id"];
            						               $course_name=$row["course_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if($course_id==$c_cmasterid)
            						              echo ' <option selected value="'.$course_id.'">'.$course_name.'</option> ';
                                    else
                                      echo ' <option  value="'.$course_id.'">'.$course_name.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Name</label>
											<input type="text" placeholder="Course Name" class="form-control" name="college_course_name" id="college_course_name" value="<?php echo $c_name; ?>" required />
										</div>
                                        <div class="form-group col-xs-4">
                                          <label for="catName">Course Type</label>
                                          <select class="form-control" id="college_course_type" name="college_course_type" required>
                                                <option>Select Course Type</option>
                                                <?php if($c_type=="1")
                                                { 
                                                echo '<option selected value="1">Type 1</option>';
                                                echo '<option  value="2">Type 2</option>';
                                                }
                                                else{
                                                 echo '<option  value="1">Type 1</option>';
                                                echo '<option selected value="2">Type 2</option>'; 
                                                }
                                                ?>
                                            </select> 
                                        </div>
                                        <div class="form-group col-xs-4">
                                          <label for="catName">Mode of Study</label>
                                          <select class="form-control" id="college_course_full_part" name="college_course_full_part" required>
                                            <option>Select Mode of Study</option>
                                            <?php 
                                            if($c_fullpart=="Full Time"){
                                              echo '<option selected  value="Full Time">Full Time</option>';
                                              echo  '<option  value="Part Time">Part Time</option>';
                                              echo '<option  value="Distance">Distance/Correspondence</option>';
                                            }
                                            else if($c_fullpart=="Part Time"){
                                              echo '<option  value="Full Time">Full Time</option>';
                                              echo  '<option selected value="Part Time">Part Time</option>';
                                              echo '<option  value="Distance">Distance/Correspondence</option>';
                                            }
                                            else{
                                              echo '<option  value="Full Time">Full Time</option>';
                                              echo  '<option  value="Part Time">Part Time</option>';
                                              echo '<option selected value="Distance">Distance/Correspondence</option>';
                                            }
                                            ?>
                                            </select> 
                                        </div>
                                        <div class="form-group col-xs-4">
                                          <label for="catName">Course Duration</label>
                                          <select class="form-control" id="college_course_duration" name="college_course_duration" required />
                                                <option>Select Mode of Study</option>
                                                <?php
                                                if($c_duration=="1 Month"){ 
                                                echo '<option selected value="1 Month">1 Month</option>';
                                                echo '<option  value="6 Month">6 Month</option>';
                                                echo '<option  value="1 Year">1 Year</option>';
                                                echo '<option  value="2 Year">2 Year</option>';
                                                echo '<option  value="3 Year">3 Year</option>';
                                                echo '<option  value="4 Year">4 Year</option>';
                                              }
                                                else if($c_duration=="6 Month"){
                                                  echo '<option  value="1 Month">1 Month</option>';
                                                echo '<option selected value="6 Month">6 Month</option>';
                                                echo '<option  value="1 Year">1 Year</option>';
                                                echo '<option  value="2 Year">2 Year</option>';
                                                echo '<option  value="3 Year">3 Year</option>';
                                                echo '<option  value="4 Year">4 Year</option>';
                                                }
                                                else if($c_duration=="1 year"){
                                                  echo '<option  value="1 Month">1 Month</option>';
                                                echo '<option  value="6 Month">6 Month</option>';
                                                echo '<option selected value="1 Year">1 Year</option>';
                                                echo '<option  value="2 Year">2 Year</option>';
                                                echo '<option  value="3 Year">3 Year</option>';
                                                echo '<option  value="4 Year">4 Year</option>';
                                                }
                                                else if($c_duration=="2 year"){echo '<option  value="1 Month">1 Month</option>';
                                                echo '<option  value="6 Month">6 Month</option>';
                                                echo '<option  value="1 Year">1 Year</option>';
                                                echo '<option selected value="2 Year">2 Year</option>';
                                                echo '<option  value="3 Year">3 Year</option>';
                                                echo '<option  value="4 Year">4 Year</option>';
                                              }
                                                else if($c_duration=="3 year"){
                                                  echo '<option  value="1 Month">1 Month</option>';
                                                echo '<option  value="6 Month">6 Month</option>';
                                                echo '<option  value="1 Year">1 Year</option>';
                                                echo '<option  value="2 Year">2 Year</option>';
                                                echo '<option selected value="3 Year">3 Year</option>';
                                                echo '<option  value="4 Year">4 Year</option>';
                                                }
                                                else {echo '<option  value="1 Month">1 Month</option>';
                                                echo '<option  value="6 Month">6 Month</option>';
                                                echo '<option  value="1 Year">1 Year</option>';
                                                echo '<option  value="2 Year">2 Year</option>';
                                                echo '<option  value="3 Year">3 Year</option>';
                                                echo '<option selected value="4 Year">4 Year</option>';}
                                                 ?>
                                            </select> 
                                        </div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Language</label>
											<select class="form-control" id="college_course_language" name="college_course_language" required />
												                        <option>Select Type</option>
                                                <?php 
                                                if($c_language=="English"){ 
                                                echo '<option selected value="English">English</option>';
                                                echo '<option  value="Hindi">Hindi</option>';
                                              }else{
                                                echo '<option  value="English">English</option>';
                                                echo '<option selected value="Hindi">Hindi</option>';
                                              }
                                                ?>
                                              
                                            </select> 
										</div>
                    
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Fees</label>
											<select class="form-control" id="college_course_fee_id" name="college_course_fee_id" required />
												<option>Select Type</option>
												<?php 
                                                //include("../../../../connection/dbconnect.php");
                                                $sql1="SELECT cc_fee_id,cc_total_fee from suc_college_course_fee_structure";
            									$result1=$conn->query($sql1);
                   								while($row1=$result1->fetch_assoc())
            						            {
            						                $cc_fee=$row1["cc_fee_id"];
            						               $cc_total_fee=$row1["cc_total_fee"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                       if($c_fee_id==$cc_fee)
            						              echo ' <option selected value="'.$cc_fee.'">'.$cc_total_fee.'</option> ';
                                    else
                                      echo ' <option selected value="'.$cc_fee.'">'.$cc_total_fee.'</option> ';
            						            }
                                                 ?>
                                            </select> 
										</div>
                                        <div class="col-md-4 inputGroupContainer">
                                            <label class="col-md-4">Status</label>
                                            <div class="col-md-2">
                                              <?php
                                                    if($c_status==1)
                                                        echo '<div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="college_course_status" name="college_course_status" type="checkbox" value="1"></div>';
                                                    else
                                                        echo '<div class="input-group"><input  data-toggle="toggle" data-onstyle="warning" id="college_course_status" name="college_course_status" type="checkbox" value="1"></div>';
                                                ?>
                                           
                                        </div>
                                        </div>
                                      
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>

				</div>
			</section>
			<div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Updated</h4></center></div>
		</aside>

    
	</div>
  
	<!-- <div style="background: red ; height: 30px;"></div> -->
<?php include_once '../includes/footer.php';?>
<!-- <script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
 -->  

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_course_Update.php?table_name=suc_college_courses&course_id=<?php echo $id ?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
         // alert(data);
          if(data==1){
            $('#success').show();
            setTimeout("location.href = 'college_course_View.php'",2000);
        }
        else{
          alert("failure");
        }
        }
      });
      
      
    });
  });
</script>
