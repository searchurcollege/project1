<?php include_once '../includes/header.php';?>

    <div class="wrapper row-offcanvas row-offcanvas-left">

        <!-- Left side column. Contains the navbar and content of the page -->

		<?php include_once '../includes/left_sidebar1.php';?>

        <aside class="right-side"> 
         <section class="content-header">

                <h4>Add College Details</h4>

            </section>              
        <!-- Main content -->
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#college" data-toggle="pill" >Basic Details</a></li>
                <li><a href="#gallery" data-toggle="pill" >Gallery</a></li>
                <li><a href="#placement" data-toggle="pill" >Placement</a></li>
                <li><a href="#contact" data-toggle="pill" >Contact</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="college">
                    <?php include('college/college.php');?>
                </div>
               
               <div class="tab-pane" id="gallery">
                    <?php include('college-gallery/college-gallery.php');?> 
                </div> 
                <div class="tab-pane" id="placement">
                    <?php include('college-other-details/college-other-details.php');?> 
                </div>
                
                <div class="tab-pane" id="contact">
                    <?php include('college-contact/college-contact.php');?> 
                </div>
                
            </div>            
        </div>
        </aside><!-- /.right-side -->

    </div>

<?php include_once '../includes/footer.php';?>