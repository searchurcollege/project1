 
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
       
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi11" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
									
    										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                        
                        <input id="id04" name="college_id"  value="" type="hhidden">                   
                                          <div class="form-group col-xs-4">
                    						<label for="catName">College Website</label>
                    						<input type="text" placeholder="College Website" class="form-control" name="college_website" id="college_website" value="" required />
                    					</div>
                                        <div class="form-group col-xs-4">
                    						<label for="catName">College Email</label>
                    						<input type="text" placeholder="College Email" class="form-control" name="college_email" id="college_email" value="" required />
                    					</div>
                                        <div class="form-group col-xs-4">
    											<label for="catName">College Contact Type</label>
    											<select class="form-control" id="college_contact_type" name="college_contact_type" required>
    												<option>Select Contact Type</option>
                                                    <option value="Contact Type 1">Contact Type 1</option>
                                                    <option value="Contact Type 2">Contact Type 2</option>
                                                </select>
    										</div>
                              <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">
                                        
                                        <div class="form-group col-xs-4">
                    						<label for="catName">College Contact 1</label>
                    						<input type="text" placeholder="College Contact 1" class="form-control" name="college_phone_1" id="college_phone_1" value="" required />
                    					</div>
                                        <div class="form-group col-xs-4">
                    						<label for="catName">College Contact 2</label>
                    						<input type="text" placeholder="College Contact 2" class="form-control" name="college_phone_2" id="college_phone_2" value=""  />
                    					</div>
                                        <div class="form-group col-xs-4">
                    						<label for="catName">College Contact 3</label>
                    						<input type="text" placeholder="College Contact 3" class="form-control" name="college_phone_3" id="college_phone_3" value=""  />
                    					</div>
                                            
                                        
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">College Address</label>
											<textarea class="form-control summernote" placeholder="College Address" id="college_address" name="college_address"></textarea>
                                            
										</div>
                                        <div class="form-group col-xs-4">
                    						<label for="catName">Contact Person Name</label>
                    						<input type="text" placeholder="College Contact 2" class="form-control" name="college_contact_name" id="college_contact_name" value=""  />
                    					</div>
                                        <div class="form-group col-xs-4">
                    						<label for="catName">Contact Hours</label>
                    						<input type="text" placeholder="College Contact 3" class="form-control" name="college_contact_hours" id="college_contact_hours" value=""  />
                    					</div>	
										<div class="col-md-4 inputGroupContainer">
                                            <label class="col-md-8 text-left">Status</label>
                                            <div class="col-md-2">
                                           <div class="input-group" style="margin-left: -120px;"><input checked data-toggle="toggle" data-onstyle="warning" id="college_contact_status" name="college_contact_status" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                     
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
            <div id ="successss"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 30%; color: green;">New Record Inserted</h4></center></div>
					</div>	
				</div>
			</section>
		</div>
  
	<!-- <div style="background: red ; height: 30px;"></div> -->

<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
	//CKEDITOR.replace( 'college_address' );
    
  </script>

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi11").submit(function(e){
       // alert("ss");
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college-contact/college_contact_Action.php?table_name=suc_college_contacts",
        method:"POST",
        data: $('#frmSubmi11').serialize(),
        success:function(data)
        {
          //alert(data);
          if(data==1){
            alert(data);
            $('#successss').fadeIn().delay(2000).fadeOut();

              //setTimeout("location.href = 'college-contact.php'",2000);
        }
        }
      });
      
      
    });
  });
</script>