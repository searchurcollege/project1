<?php 
$date = date('Y-m-d H:i:s');
 $college_status=$_REQUEST["college_contact_status"];
$tbl_name=$_REQUEST["table_name"];
$suc_id=$_REQUEST["Contact_id"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", college_contact_status='0' "; 
}




include("../../../../connection/dbconnect.php");
// $servername="localhost";
//     $username="searchurcollege";
//     $password="Newme7503415202";
//     $dbname="searchurcollege_main";
//     $conn = new mysqli($servername, $username, $password, $dbname);
	// $sql ="UPDATE suc_university set uni_name='$uni_name', uni_desc='$description', uni_location_id='$uni_location', uni_establishment_dt='$establish_dt', uni_type='$unitype', uni_ucg_status='$ugcstatus',uni_aiu_status='$aiustatus',uni_admission_notes='$admissionNote', uni_status='$uni_status',updated_dt='$date' where uni_id='$suc_id'" ;
//echo	$sql="INSERT into suc_university(uni_name,uni_desc,uni_location_id) VALUES ('$uni_name','$description','$uni_location')";
  $sql="update ".$tbl_name." set ".$k." where college_contact_id=".$suc_id;
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>