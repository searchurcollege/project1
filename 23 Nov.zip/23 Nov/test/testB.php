<?php 
include('../connection/dbconnect.php');
$id=$_REQUEST['id'];
$sql="SELECT page_title, meta_keyword, meta_description FROM cat00_super_category WHERE super_cat_id=$id";
$result=$conn->query($sql);
       
            while($row=$result->fetch_assoc())
            {
                $page_title=$row["page_title"];
                $meta_keyword=$row["meta_keyword"];
                $meta_description=$row["meta_description"];
            }

echo '<title>'.$page_title.'</title>';
echo '<meta name="Description" content="'.$meta_description.'"/>';
echo '<meta name="Keywords" content="Searchurcollege,'.$meta_keyword.'"/>';
include('../connection/header.php');
?>


<style>
@media screen and (min-width: 200px) and (max-width: 786px){
    .testp{
        padding: 0px;
        
    }
    
}

</style> 

<div class="col-md-12 testp" style="nbackground: yellow;">
<div class="col-md-10 testp" style="bnackground: red;">

<?php include('t_test.php'); ?>

</div>
<?php
if($id==1)
 {
echo'<div class="col-md-2" style="bbackground: blue;">
 <div id="dv" class="col-md-2 scrollbar style-4" style="padding: 0px 10px 0px 0px; margin-top: 100px; min-height: 550px;">
    <a href="https://www.searchurcollege.com/"><div style="background: #ff9934;"><img alt="logo" src="https://www.searchurcollege.com/img/header-logo.png" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></div></a>
    <a href="https://www.searchurcollege.com/exams/cat-details.php"><img alt="cat" src="https://searchurcollege.com/exams/img/exams/CAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/xat-details.php"><img alt="xat" src="https://searchurcollege.com/exams/img/exams/XAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/mat-details.php"><img alt="mat" src="https://searchurcollege.com/exams/img/exams/MAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/cmat-details.php"><img alt="cmat" src="https://searchurcollege.com/exams/img/exams/CMAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/iift-details.php"><img alt="iift" src="https://searchurcollege.com/exams/img/exams/IIFT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/atma-details.php"><img alt="atma" src="https://searchurcollege.com/exams/img/exams/ATMA.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/nmat-details.php"><img alt="nmat" src="https://searchurcollege.com/exams/img/exams/NMAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
  </div>
</div>';
}
?>
<?php
if($id==3)
 {
echo'<div class="col-md-2" style="bbackground: blue;">
 <div id="dv" class="col-md-2 scrollbar style-4" style="padding: 0px 10px 0px 0px; margin-top: 100px; min-height: 550px;">
    <a href="https://searchurcollege.com/"><div style="background: #ff9934;"><img alt="logo" src="https://searchurcollege.com/img/header-logo.png" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></div></a>
    <a href="https://searchurcollege.com/exams/jeemain-details.php"><img alt="JEE Main" src="https://searchurcollege.com/exams/img/engineering/JEEMAIN.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/jeeadv-details.php"><img alt="JEE Adv" src="https://searchurcollege.com/exams/img/engineering/JEEADV.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/gate-details.php"><img alt="GATE" src="https://searchurcollege.com/exams/img/engineering/GATE.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/viteee-details.php"><img alt="VITEEE" src="https://searchurcollege.com/exams/img/engineering/VITEEE.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/srmjeee-details.php"><img alt="SRMJEEE" src="https://searchurcollege.com/exams/img/engineering/SRMJEEE.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/bitsat-details.php"><img alt="BITSAT" src="https://searchurcollege.com/exams/img/engineering/BITSAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="#"><img alt="AJEE" src="https://searchurcollege.com/exams/img/engineering/AJEE.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
  </div>
</div>';
}
?>
<?php
if($id==4)
 {
echo'<div class="col-md-2" style="bbackground: blue;">
 <div id="dv" class="col-md-2 scrollbar style-4" style="padding: 0px 10px 0px 0px; margin-top: 100px; min-height: 550px;">
    <a href="https://searchurcollege.com/"><div style="background: #ff9934;"><img alt="logo" src="https://searchurcollege.com/img/header-logo.png" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></div></a>
    <a href="https://searchurcollege.com/exams/neet-details.php"><img alt="NEET" src="https://searchurcollege.com/exams/img/medical/NEET.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="#"><img alt="AIIMS" src="https://searchurcollege.com/exams/img/medical/AIIMS.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="#"><img alt="JIPMER" src="https://searchurcollege.com/exams/img/medical/JIPMER.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="#"><img alt="cmat" src="https://searchurcollege.com/exams/img/medical/AFMC.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="#"><img alt="iift" src="https://searchurcollege.com/exams/img/medical/BHUMBBS.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="#"><img alt="atma" src="https://searchurcollege.com/exams/img/medical/CMC.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="#"><img alt="nmat" src="https://searchurcollege.com/exams/img/medical/COMEDK.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
  </div>
</div>';
}
?>
<?php
if($id==5)
 {
echo'<div class="col-md-2" style="bbackground: blue;">
 <div id="dv" class="col-md-2 scrollbar style-4" style="padding: 0px 10px 0px 0px; margin-top: 100px; min-height: 550px;">
    <a href="https://searchurcollege.com/"><div style="background: #ff9934;"><img alt="logo" src="https://searchurcollege.com/img/header-logo.png" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></div></a>
    <a href="https://searchurcollege.com/exams/clat-details.php"><img alt="CLAT" src="https://searchurcollege.com/exams/img/law/CLAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://www.searchurcollege.com/exams/ailet-details.php"><img alt="AILET" src="https://searchurcollege.com/exams/img/law/AILET.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    
  </div>
</div>';
}
?>
<?php
if($id==6)
 {
echo'<div class="col-md-2" style="bbackground: blue;">
 <div id="dv" class="col-md-2 scrollbar style-4" style="padding: 0px 10px 0px 0px; margin-top: 100px; min-height: 550px;">
    <a href="https://searchurcollege.com/"><div style="background: #ff9934;"><img alt="logo" src="https://searchurcollege.com/img/header-logo.png" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></div></a>
    <a href="https://searchurcollege.com/exams/ceed-details.php"><img alt="CLAT" src="https://searchurcollege.com/exams/img/design/CEED.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    
    
  </div>
</div>';
}
?>
</div>

     
<style>
.ad {
   position: fixed;
   top: 50%;
   left: 50%;
   transform: translate(-50%, -50%);
   z-index :100000000;
   opacity: .9;
}
</style>
<!-- <div class="ad" onclick="hideAd(); z-index: 10;">
    <div style="right: 20px; top: 20px; position: absolute; cursor: pointer;" onclick="hideAd();">
        <img src="https://www.searchurcollege.com/img/close.png" height="30" title="Close Offer"/>
    </div>
    <a href="#" data-toggle="modal" data-target="#register">
        <img src="https://www.searchurcollege.com/ad1.gif" onclick="hideAd();" />
    </a>
</div> -->
<script>
    function hideAd()
    {
        $('.ad').hide();
    }
</script>


<?php 
include('../footer.php');

?>