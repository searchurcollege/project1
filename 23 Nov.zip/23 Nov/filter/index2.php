<html lang="en">

<head>

    <script async='async' src='//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js'></script>
		<script>
		  (adsbygoogle = window.adsbygoogle || []).push({
			google_ad_client: "ca-pub-4529508631166774",
			enable_page_level_ads: true
		  });
		</script>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Product filter in php</title>

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    
    <link href="style.css" rel="stylesheet">
</head>

<body>
    <!-- Page Content -->
    <div class="container">
        <div class="row">
        	<br />
        	<h2 align="center">Back to Tutorial - <a href="https://www.webslesson.info/2018/08/how-to-make-product-filter-in-php-using-ajax.html">Advance Ajax Product Filters in PHP</a></h2>
            <br />
            <script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <!-- webslesson_mainblogsec_Blog1_1x1_as -->
            <br />
            <ins class="adsbygoogle" data-ad-client="ca-pub-4529508631166774" data-ad-format="auto" data-ad-host-channel="L0007" data-ad-host="ca-host-pub-1556223355139109" data-ad-slot="6573078845" style="display: block;"></ins><script>
            (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
            <br />
            <div class="col-md-3">                				
				<div class="list-group">
					<h3>Price</h3>
					<input type="hidden" id="hidden_minimum_price" value="0" />
                    <input type="hidden" id="hidden_maximum_price" value="65000" />
                    <p id="price_show">1000 - 65000</p>
                    <div id="price_range"></div>
                </div>				
                <div class="list-group">
					<h3>Brand</h3>
                    <div style="height: 180px; overflow-y: auto; overflow-x: hidden;">
					                    <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Google"  > Google</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Intex"  > Intex</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="MI"  > MI</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Asus"  > Asus</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="OPPO"  > OPPO</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Panasonic"  > Panasonic</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Samsung"  > Samsung</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Lenevo"  > Lenevo</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Moto"  > Moto</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="VIVO"  > VIVO</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Infinix"  > Infinix</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="Honor"  > Honor</label>
                    </div>
                                        </div>
                </div>

				<div class="list-group">
					<h3>RAM</h3>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector ram" value="6" > 6 GB</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector ram" value="4" > 4 GB</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector ram" value="3" > 3 GB</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector ram" value="2" > 2 GB</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector ram" value="1" > 1 GB</label>
                    </div>
                                    </div>
				
				<div class="list-group">
					<h3>Internal Storage</h3>
					                    <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector storage" value="64"  > 64 GB</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector storage" value="32"  > 32 GB</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector storage" value="16"  > 16 GB</label>
                    </div>
                                        <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector storage" value="128"  > 128 GB</label>
                    </div>
                    	
                </div>
            </div>

            <div class="col-md-9">
            	<br />
                <div class="row filter_data">

                </div>
            </div>
        </div>

    </div>
<style>
#loading
{
	text-align:center; 
	background: url('loader.gif') no-repeat center; 
	height: 150px;
}
</style>

<script>
$(document).ready(function(){

    filter_data();

    function filter_data()
    {
        $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var brand = get_filter('brand');
        var ram = get_filter('ram');
        var storage = get_filter('storage');
        $.ajax({
            url:"fetch_data.php",
            method:"POST",
            data:{action:action, minimum_price:minimum_price, maximum_price:maximum_price, brand:brand, ram:ram, storage:storage},
            success:function(data){
                $('.filter_data').html(data);
            }
        });
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function(){
        filter_data();
    });

    $('#price_range').slider({
        range:true,
        min:1000,
        max:65000,
        values:[1000, 65000],
        step:500,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data();
        }
    });

});
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-87739877-1', 'auto');
  ga('send', 'pageview');

</script>

</body>

</html>
