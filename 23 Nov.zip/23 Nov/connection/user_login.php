<?php
    include('dbconnect.php');
    $email=$_REQUEST['email'];
    $password=$_REQUEST['password'];
    $sql="SELECT id, first_name, email, contact, super_cat_id, course_interested,contact_verification, token, balance_amt, photo FROM users WHERE email='$email' AND password='$password'";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        while($row=$result->fetch_assoc())
        {
            $id=$row["id"];
            $first_name=$row["first_name"];
            $email=$row["email"];
            $contact=$row["contact"];
            $sid=$row["super_cat_id"];
            $stream=$row["course_interested"];
            $contact_verification=$row["contact_verification"];
            $token=$row["token"];
            $ba=$row["balance_amt"];
            $photo=$row["photo"];
            if($photo=="")
                $photo="user1.png";
        }
        if($token=='')
        {
            $token = getToken(10);
            $sqll="update users set token='$token' where email='$email'";
            $result1=$conn->query($sqll);

            session_start();
            $_SESSION['uid']=$id;
            $_SESSION['user_name']=$first_name;
            $_SESSION['email']=$email;
            $_SESSION['contact']=$contact;
    		$_SESSION['regUsrId']=$email;
    		$_SESSION['stream']=$stream;
            $_SESSION['contact_verification']=$contact_verification;
    		$_SESSION['ba']=$ba;
            $_SESSION['photo']=$photo;
            $_SESSION['sid']=$sid;
            $_SESSION['token']=$token;
            
    
            
    
            if($ba>0)
                echo '2';   //Not Paid
            else
                echo '1';   //Paid
        }
        else 
        if($token!=NULL)
            echo $email;
    }
    else
        echo '0';       //Not Registered

function getToken($length){
     $token = "";
     $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
     $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
     $codeAlphabet.= "0123456789";
     $max = strlen($codeAlphabet); // edited

    for ($i=0; $i < $length; $i++) {
        $token .= $codeAlphabet[rand(0, $max-1)];
    }

    return $token;
}
?>