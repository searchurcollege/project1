<?php
    include('dbconnect.php');
    $phone=$_REQUEST['phone'];
    $otp=$_REQUEST['otp'];
    $sql="SELECT otp FROM users WHERE contact='$phone' AND otp='$otp'";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        $sql="UPDATE users SET contact_verification=1 WHERE contact='$phone' AND otp='$otp'";
        $result=$conn->query($sql);
        $data='found';
        $msg='Welcome to SearchUrCollege "One Stop Solution for Students". Your account is activated successfully.';
        $url='http://nimbusit.co.in/api/swsendSingle.asp?username=t1searchurcollege&password=ranjay786&sender=SEARCH&sendto='.$phone.'&message='.$msg;
        $url=str_replace(" ", '%20', $url);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        //$response = curl_exec($ch);
        curl_close($ch);
    }
    else
        $data='not found';
    echo $data;
?>