<html>
<body>

<?php
$to="project1973@gmail.com";
$from="SUC";
$from_name="SearchUrCollege";
$subject="SUC - Registration";
$body="Once upon a time, there was a kind in isreal.";
    include("phpmailer/class.phpmailer.php");
    //if(isset($_REQUEST['name']))
    {
        $name='KV';//$_REQUEST['name'];
        $phone='9873452073';//$_REQUEST['phone'];
        $subject='My Subject';//$_REQUEST['subject'];
        $img='<img src="https://www.searchurcollege.com/img/header-logo.png" width="150px">';
        $address='Noida';//$_REQUEST['address'];
	    $website="www.searchurcollege.com";
        $from_name='SearchUrCollege';
        $from="contact@searchurcollege.com";
        $pwd='asdfgh@123@';
        $signature='Regards<br />Administrator<br /><br />
        '.$img.'<br />'.$address.'<br /> Website : '.$website;
        ob_start();
    	$mail = new PHPMailer;
    	$mail->IsSMTP();                           // Set mailer to use SMTP
    	$mail->Host = 'mail.searchurcollege.com';  // Specify main and backup server
        $mail->SMTPSecure = 'ssl';
        $mail->Port='567';
        $mail->SMTPDebug  = 1;
    	$mail->SMTPAuth = true;                    // Enable SMTP authentication
    	$mail->Username = $from;                   // SMTP username
    	$mail->Password = $pwd;                    // SMTP password
    	$mail->From = $from;
    	$mail->FromName = $from_name;
    	$mail->AddReplyTo($from);
    	$mail->WordWrap = 50;                      // Set word wrap to 50 characters
    	$mail->IsHTML(true);                       // Set email format to HTML
    	$mail->Subject = $subject;

        //To User
        $email='project1973@gmail.com';//$_REQUEST['email'];
        $message=$body;//$_REQUEST['message'];
        $to=$email;
        $mail_message='Dear '.$name.',<br /><br />Thanks for contacting <b>Eugenix</b>.
        <br />One of our representatives will contact you shortly.<br /><br />'.$signature;
    	$mail->AddAddress($to);
    	$mail->Body = $mail_message;
    	if($mail->Send())
            echo "<br />Mail Sent";
        else
            echo "<br />Mail Not Sent";

        exit;
        //To Admin
    	$mail = new PHPMailer;
    	$mail->IsSMTP();                           // Set mailer to use SMTP
    	$mail->Host = 'smtp.searchurcollege.com';  // Specify main and backup server
        $mail->SMTPSecure = 'ssl';
        $mail->Port='465';
    	$mail->SMTPAuth = true;                    // Enable SMTP authentication
    	$mail->Username = $from;                   // SMTP username
    	$mail->Password = $pwd;                    // SMTP password
    	$mail->From = $from;
    	$mail->FromName = $from_name;
    	$mail->AddReplyTo($from);
    	$mail->WordWrap = 50;                      // Set word wrap to 50 characters
    	$mail->IsHTML(true);                       // Set email format to HTML
	    $mail->Subject = $subject;
        $mail_message='Dear Sir,<br /><br />A new Enquiry is made. Details below:<br />
        <table width="50%">
        <tr><td>Name</td><td>'.$name.'</td></tr>
        <tr><td>Phone</td><td>'.$phone.'</td></tr>
        <tr><td>Email</td><td>'.$email.'</td></tr>';
        $mail_message.='<tr><td>Message</td><td>'.$message.'</td></tr>';
        $mail_message.='</table><br /><br />'.$signature;
    	$mail->AddAddress($from);
    	$mail->AddCC('project1973@gmail.com');
    	//$mail->AddBCC('abc.com');
    	$mail->Body = $mail_message;
    	if($mail->Send())
            echo "<br />Mail Sent";
        else
            echo "<br />Mail Not Sent";
    }
?>
