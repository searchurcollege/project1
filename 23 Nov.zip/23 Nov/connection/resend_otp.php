<?php
    include('dbconnect.php');
    $phone=$_REQUEST['phone'];
    $otp=(rand(1000,9999));
    $sql="UPDATE users SET otp='$otp' WHERE contact='$phone'";
    $result=$conn->query($sql);
    $data='send';
    $msg=$otp.' is your One-Time-Password for mobile verfication. www.searchurcollege.com';
    $url='http://nimbusit.co.in/api/swsendSingle.asp?username=t1searchurcollege&password=ranjay786&sender=SEARCH&sendto='.$phone.'&message='.$msg;
    $url=str_replace(" ", '%20', $url);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
?>