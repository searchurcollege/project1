<?php
    function selectStream()
    {
        include('dbconnect.php');
        $sql="SELECT super_cat_id, super_cat_name FROM cat00_super_category WHERE super_cat_status=1";
        $result=$conn->query($sql);
        if($result->num_rows>0) 
            return($result);
        else
            return(0);
    }
	function selectStreamc2($id)
    {
        include('dbconnect.php');
        $sql="SELECT super_cat_name FROM cat00_super_category where super_cat_id=$id";
        
		$result=$conn->query($sql);
       
            while($row=$result->fetch_assoc())
            {
                $name=$row["super_cat_name"];
            }
			return($name);
		
    }

    function selectCourse()
    {
        include('dbconnect.php');
        $sql="SELECT id, course_master_name FROM tbl_course_master";
        $result=$conn->query($sql);
        if($result->num_rows>0)
            return($result);
        else
            return(0);
    }

    function selectCategory($id)
    {
        include('dbconnect.php');
        $sql="SELECT id, category FROM tbl_course_category WHERE master_id=$id";
        $result=$conn->query($sql);
        if($result->num_rows>0)
            return($result);
        else
            return(0);
    }

    function selectCity()
    {
        include('dbconnect.php');
        $sql="SELECT * FROM location";
        $result=$conn->query($sql);
        if($result->num_rows>0)
            return($result);
        else
            return(0);
    }


    function level2()
    {
        include('dbconnect.php');
        $sql="SELECT main_cat_id, main_cat_name FROM cat01_main_category";
        $result=$conn->query($sql);
        if($result->num_rows>0)
            return($result);
        else
            return(0);
    }

    function level2b($id)
    {
        include('dbconnect.php');
        $sql="SELECT main_cat_name FROM cat01_main_category WHERE main_cat_id=$id ORDER BY sort_order";
        $result=$conn->query($sql);
        if($result->num_rows>0)
            return($result);
        else
            return(0);
    }



   function level3($id)
   {
       include('dbconnect.php');
       $v=$_REQUEST['id'];
       $sql="SELECT exam_cat_id, exam_cat_name FROM cat02_exam_category where main_cat_id=$id AND super_cat_id=$v";
       $result=$conn->query($sql);
       if($result->num_rows>0)
           return($result);
       else
           return(0);
   }
   

   function level4($id)
   {
       include('dbconnect.php');
     $sql = "SELECT cat03_exam_exercise.main_cat_id, cat03_exam_exercise.exam_exercise_id, cat03_exam_exercise.exam_exercise_name FROM cat03_exam_exercise inner join exam on cat03_exam_exercise.exam_exercise_id=exam.exam_exercise_id  AND cat03_exam_exercise.exam_cat_id=$id AND exam_exercise_status=1 group by cat03_exam_exercise.exam_exercise_id order by sort_order";

       //$sql="SELECT exam_cat_id, exam_exercise_id, exam_exercise_name FROM cat03_exam_exercise where exam_cat_id=$id";
       $result=$conn->query($sql);
       if($result->num_rows>0)
       {
           return($result);
       }
       else
           return(0);
   }

   function level4b($id)
   {
       include('dbconnect.php');
       $sql="SELECT exam_exercise_id, exam_exercise_name FROM cat03_exam_exercise where main_cat_id=$id LIMIT 4";
       $result=$conn->query($sql);
       if($result->num_rows>0)
       {
           return($result);
       }
       else
           return(0);
   }
   
   function level5($id)
   {
       include('dbconnect.php');
       $sql="SELECT exam_id, exam_name, main_cat_id FROM exam where exam_exercise_id=$id AND STATUS=1";
       //$sql="SELECT exam_id, exam_name, main_cat_id FROM exam where exam_exercise_id=$id and STATUS=1 ORDER BY `exam`.`exam_name` DESC";
       $result=$conn->query($sql);
       if($result->num_rows>0)
           return($result);
       else
           return(0);
   }
   
   function level5b($id)
   {
       include('dbconnect.php');
       $sql="SELECT exam_id, exam_name FROM exam where exam_exercise_id=$id LIMIT 5 order by 'sort_order'";
       //echo '<br>'.$sql;
       $result=$conn->query($sql);
       if($result->num_rows>0)
           return($result);
       else
           return(0);
   }

   function chk($exam_id)
   {
       include('dbconnect.php');
       $email=$_SESSION['email'];
       $sql="SELECT user_id, user_exam_id FROM user_exam WHERE user_id='$email' AND user_exam_id=$exam_id";
       $result=$conn->query($sql);
       if($result->num_rows>0)
           return(1);
       else
           return(0);
   }

?>
