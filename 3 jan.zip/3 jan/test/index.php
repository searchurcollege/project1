<?php 
$url =  "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$parts = parse_url($url);
$str = $parts['path'];
if($str=='/test/MBA')
    $id=1;
else
if($str=='/test/Engineering')
    $id=3;
else
if($str=='/test/Medical')
    $id=4;
else
if($str=='/test/Law')
    $id=5;
else
if($str=='/test/Design')
    $id=6;
include('../connection/dbconnect.php');
//$id=$_REQUEST['id'];
$sql="SELECT page_title, meta_keyword, meta_description FROM cat00_super_category WHERE super_cat_id=$id";
$result=$conn->query($sql);
       
            while($row=$result->fetch_assoc())
            {
                $page_title=$row["page_title"];
                $meta_keyword=$row["meta_keyword"];
                $meta_description=$row["meta_description"];
            }

echo '<title>'.$page_title.'</title>';
echo '<META NAME="Description" CONTENT="'.$meta_description.'"/>';
echo '<META NAME="Keywords" CONTENT="Searchurcollege,'.$meta_keyword.'"/>';
include('../connection/header.php');
?>


<style>
@media screen and (min-width: 200px) and (max-width: 786px){
    .testp{
        padding: 0px;
        
    }
    
}

</style> 

<div class="col-md-12 testp" style="nbackground: yellow;">
<div class="col-md-10 testp" style="bnackground: red;">

<?php include('test1.1.php'); ?>

</div>

<div class="col-md-2" style="bbackground: blue;">
 <div id="dv" class="col-md-2 scrollbar style-4" style="padding: 0px 10px 0px 0px; margin-top: 100px; min-height: 550px;">
    <a href="https://searchurcollege.com/"><div style="background: #ff9934;"><img alt="logo" src="https://searchurcollege.com/img/header-logo.png" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></div></a>
    <a href="https://searchurcollege.com/exams/cat-details"><img alt="cat" src="https://searchurcollege.com/exams/img/exams/CAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/xat-details"><img alt="xat" src="https://searchurcollege.com/exams/img/exams/XAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/mat-details"><img alt="mat" src="https://searchurcollege.com/exams/img/exams/MAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/cmat-details"><img alt="cmat" src="https://searchurcollege.com/exams/img/exams/CMAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/iift-details"><img alt="iift" src="https://searchurcollege.com/exams/img/exams/IIFT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/atma-details"><img alt="atma" src="https://searchurcollege.com/exams/img/exams/ATMA.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
    <a href="https://searchurcollege.com/exams/nmat-details"><img alt="nmat" src="https://searchurcollege.com/exams/img/exams/NMAT.jpg" width="100%" class="img-responsive" style="margin-bottom: 20px;" /></a>
  </div>
</div>

</div>

<?php 
include('../footer.php');

?>