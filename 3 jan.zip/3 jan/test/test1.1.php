<sscript src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<sscript src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style class="cp-pen-styles">

*, *:before, *:after {
  box-sizing: border-box;
}

.load-more-container {
  background: transparent;
  width: 100%!important;
  min-height: 0px;
  margin: 20px auto;
  position: relative;
}
.load-more-container ul {
  list-style-type: none;
  padding: 0;
}
.load-more-container ul:after {
  content: "";
  display: table;
  clear: both;
}
.load-more-container ul li {
  width: calc(20% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 5px;
}
.load-more-container ul li:nth-child(1n + 7) {
  max-height: 0;
  opacity: 0;
  transition: 0.1s ease-in;
}
.load-more-container .load-more-btn {
  width: 150px;
  line-height: 40px;
  border-radius: 2px;
  margin: 0 auto;
  display: block;
  background: #219150;
  color: #fff;
  cursor: pointer;
  text-align: center;
}
.load-more-container .load-more-btn:hover {
  background: green;
}
.load-more-container .load-more-btn .loaded {
  display: none;
}
.load-more-container #load-more {
  display: none;
}
.load-more-container #load-more:checked ~ ul li:nth-child(1n + 5) {
  max-height: 999px;
  opacity: 1;
  transition: 0.2s ease-in;
}
.load-more-container #load-more:checked ~ .load-more-btn .loaded {
  display: block; 
}
.load-more-container #load-more:checked ~ .load-more-btn .unloaded {
  display: none;
  
}
#sorrycontent
{
    background: #ff9935;
    color: white;
    border: 5px solid white;    
    padding: 10px;
    height: 150px;
}
@media (max-width: 500px) {
 .load-more-container ul li {
  width: calc(100% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 2px;
}
.modal-content {
  margin-bottom: 50px;  
}


}

@media screen and (min-width: 200px) and (max-width: 499px){
    #dv{display: none;}
    #mv{display: inline;}
    #userloginbase{
      height: 230px!important;
    }
    #sorrycontent
{
    background: #ff9935;
    color: white;
    border: 5px solid white;    
    padding: 10px;
    height: 150px;
}
    
    .blocks2
    {
        background: white;
        margin-right: 15px;
        margin-bottom: 20px;
        width: 200px!important;
        border-radius: 5px;
        height: 70px;
        margin-left: 5px!important;
    }
    
}
section.study-section .nav-tabs {
    border-bottom: 2px solid transparent!important;
}




</style>
  
  
  <style type="text/css">
    .blocks
    {
        background: white;
        ddisplay: inline-flexbox!important;
        padding: 5px;
        border-radius: 5px;
        text-align: center;
        width: 100px;
        min-width: 70px!important;
        margin-right: 15px!important;
    }
    .blocks2
    {
        background: white;
        margin-right: 15px;
        margin-bottom: 20px;
        width: 150px;
        border-radius: 5px;
        height: 70px;
    }
    .bB1
    {
        margin-left: -10px;
        margin-top: 28px;
    }
    .B2
    {
        margin-left: -30px;
        mmargin-top: -40px;
    }
    .nav-pills>li.active>a, .nav-pills>li.active>a:hover, .nav-pills>li.active>a:focus
    {
        background: #596f7c!important;
    }
    

.tabs-content {
       @include clearfix;
       margin-bottom: $tabs-content-margin-bottom;
       width: 100%;
       > .content {

          // Replacement for display: none;, a fix for carousel in tabs
         overflow-y: hidden;
         height: 0;

         float: $default-float;
         padding: $tabs-content-padding 0;
         width: 100%;
         &.active { display: block; float: none;  height: auto;}  // height: auto; added. Also part of the display: none; replacement, a fix for carousel in tabs
         &.contained { padding: $tabs-content-padding; }
       }
       &.vertical {
         display: block;
         > .content { padding: 0 $tabs-content-padding; }
      }
        
        section.study-section .tab-content {
        margin-top: 40px!important;
}
    }
    
   body{
    background: white!important;
   }
   
.exam-tab .nav>li>a {
    position: relative;
    display: block;
    padding: 0px 50px!important;
    padding-bottom: 3px;
    font-size: 22px!important;
    border-radius: 0px;
    color: #596F7C; 
    
} 

@media screen and (min-width: 486px) and (max-width: 786px){
    
 .exam-tab .nav>li>a {
     position: relative;
        display: block;
        padding: 0px 60px;
        padding-bottom: 3px;
        padding-top: 3px;
        font-size: 16px!important;
        border-radius: 0px;
        color: #596F7C;
        margin-left: 10px!important;
        margin-right: 10px!important;
        padding-left: 20px!important;
        padding-right: 20px!important;
        
        
}
}  
@media screen and (min-width: 200px) and (max-width: 486px){
    
 .exam-tab .nav>li>a {
     position: relative;
        display: block;
        padding: 0px 10px;
        padding-bottom: 3px;
        padding-top: 3px;
        font-size: 14px!important;
        border-radius: 0px;
        color: #596F7C;
        margin-left: 0px!important;
        margin-right: 0px!important;
        padding-left: 3px!important;
        padding-right: 3px!important;
        
    
}   
 .btn-group-lg>.btn, .btn-lg {
    padding: 05px 16px!important;
    font-size: 15px!important;
    line-height: 1.3333333;
    border-radius: 6px;
} 
#title{
    
    font-size:20px!important;
}  
} 
.btn-group-lg>.btn, .btn-lg {
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.3333333;
    border-radius: 6px;
} 

.scrollbar
{
mmargin-left: 30px;
float: le0t;
height: 400px;
width: 100%;
background: #ffffff;
overflow-y: scroll;
margin-bottom: 25px;
}
  
      </style>
      <style class="cp-pen-styles">

*, *:before, *:after {
  box-sizing: border-box;
}

.load-more-container {
  background: transparent;
  width: 100%!important;
  min-height: 100px;
  margin: 20px auto;
  position: relative;
}
.load-more-container ul {
  list-style-type: none;
  padding: 0;
}
.load-more-container ul:after {
  content: "";
  display: table;
  clear: both;
}
.load-more-container ul li {
  width: calc(20% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 5px;
}
.load-more-container ul li:nth-child(1n + 7) {
  max-height: 0;
  opacity: 0;
  transition: 0.1s ease-in;
}
.load-more-container .load-more-btn {
  width: 150px;
  line-height: 40px;
  border-radius: 2px;
  margin: 0 auto;
  display: block;
  background: #219150;
  color: #fff;
  cursor: pointer;
  text-align: center;
}
.load-more-container .load-more-btn:hover {
  background: green;
}
.load-more-container .load-more-btn .loaded {
  display: none;
}
.load-more-container #load-more {
  display: none;
}
.load-more-container #load-more:checked ~ ul li:nth-child(1n + 5) {
  max-height: 999px;
  opacity: 1;
  transition: 0.2s ease-in;
}
.load-more-container #load-more:checked ~ .load-more-btn .loaded {
  display: block; 
}
.load-more-container #load-more:checked ~ .load-more-btn .unloaded {
  display: none;
  
}

@media (max-width: 500px) {
 .load-more-container ul li {
  width: calc(100% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 2px;
}

}

@media screen and (min-width: 200px) and (max-width: 499px){
    #dv{display: none;}
    #mv{display: inline;}
}
section.study-section .nav-tabs {
    border-bottom: 2px solid transparent!important;
}


.scrollbar
{
mmargin-left: 30px;
float: le0t;
height: 400px;
width: 100%;
background: #ffffff;
overflow-y: scroll;
margin-bottom: 25px;
}
.force-overflow
{
min-height: 450px;
}
.style-4::-webkit-scrollbar-track
{
-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
background-color: #596f7c;
}
.style-4::-webkit-scrollbar
{
width: 10px;
background-color: #F5F5F5;
}
.style-4::-webkit-scrollbar-thumb
{
background-color: #000000;
border: 2px solid #555555;
}

</style>
  
  
  <style type="text/css">
    .blocks
    {
        background: white;
        display: inline-flexbox!important;
        padding: 5px;
        border-radius: 5px;
        text-align: center;
        width: 100px;
        min-width: 70px!important;
        margin-right: 15px!important;
    }
    .bB1
    {
        margin-left: -10px;
        margin-top: 28px;
    }
    .B2
    {
        margin-left: -30px;
        mmargin-top: -40px;
    }
    .nav-pills>li.active>a, .nav-pills>li.active>a:hover, .nav-pills>li.active>a:focus
    {
        background: #596f7c!important;
    }
    .slick-prev:before, .slick-next:before
    {
        color: white!important;   
    }
    * {
      box-sizing: border-box;
    }

    .slider {
        width: 100%;
        margin-top: 10px;
    }

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 100%;
    }

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }
    .slick-prev
    {
          margin-left: 15px;
    }
    .slick-next
    {
          margin-right: 15px;
    }


    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: 1;
    }
    
    .slick-active {
      opacity: 1;
    }

    .slick-current {
      opacity: 1;
    }


.tabs-content {
       @include clearfix;
       margin-bottom: $tabs-content-margin-bottom;
       width: 100%;
       > .content {

          // Replacement for display: none;, a fix for carousel in tabs
         overflow-y: hidden;
         height: 0;

         float: $default-float;
         padding: $tabs-content-padding 0;
         width: 100%;
         &.active { display: block; float: none;  height: auto;}  // height: auto; added. Also part of the display: none; replacement, a fix for carousel in tabs
         &.contained { padding: $tabs-content-padding; }
       }
       &.vertical {
         display: block;
         > .content { padding: 0 $tabs-content-padding; }
      }
        
        section.study-section .tab-content {
        margin-top: 40px!important;
}
    }
    
   body{
    background: white!important;
   }
   

@media screen and (min-width: 200px) and (max-width: 499px){
    
 
 .btn-group-lg>.btn, .btn-lg {
    padding: 05px 16px!important;
    font-size: 15px!important;
    line-height: 1.3333333;
    border-radius: 6px;
} 
#title{
    
    font-size:20px!important;
}  

#my-test{
    margin: 0px;
    padding: 0px;
    margin-left: 15px; 
    height: 110vh!important;
}  
} 
.btn-group-lg>.btn, .btn-lg {
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.3333333;
    border-radius: 6px;
}



.length1 {
    height: 100vh;
    
}
#my-test{
    margin: 0px;
    padding: 0px;
    margin-left: 15px; 
    height: 95vh;
}
 
 
      </style>
<?php

$bgcolor='';
//include('../connection/header.php');



$id=$_REQUEST['id'];
echo '<input type="hidden" id="id" value="'.$id.'" />';
$name=selectStreamc2($id);

?>

        <div class="text-center free-text" style="margin-top: 12px; margin-bottom: 10px;">
         <span id="title" style="font-size: 30px; color: black;"><b><?php echo strtoupper($name);?> TEST</b></span><br />
        </div>
        <div class="exam-tab">
          <ul class="nav nav-pills" style="border: 0px; bbackground: yellow!important;">
            <?php
                $n=0;            
                $z2=1;            
                $z3=$w=0;            
                $main_cat_id=array();
                $exam_cat_id=array();
                $result=level2();
                foreach($result as $var)
                    $main_cat_id[]=$var['main_cat_id'];
                for($i=0;$i<sizeof($main_cat_id);$i++)
                {
                    $v=$main_cat_id[$i];
                    $result=level3($v);
                    $x=0;
                    foreach($result as $var)
                    {
                        $exam_cat_id[]=$var['exam_cat_id'];
                        $x++;
                    }
                    if($x>0)
                    {
                        $result=level2b($v);
                        foreach($result as $var)
                            $title=$var['main_cat_name'];
                            
                        if($i==0)
                            echo '<li class="active"><a data-toggle="pill" href="#exam-one'.$i.'" style="border-radius: 10px;"><b>'.$title.'</b></a></li>';
                        else
                        if($i==1)
                            echo '<li onclick=setHeight();><a data-toggle="pill" href="#exam-one'.$i.'" style="border-radius: 10px;"><b>'.$title.'</b></a></li>';
                        else
                            echo '<li><a data-toggle="pill" href="#exam-one'.$i.'" style="border-radius: 10px;"><b>'.$title.'</b></a></li>';
                    }
                }
        echo '</ul>
        <div class="row"></div>
        <div class="col-md-12 tab-content" style="bbackground: red; margin-top: 20px!important; padding: 0px!important;">';
        $x=0;
        $p=0;
        $q=0;
        for($j=0;$j<$i;$j++)
        {
            if($j==0)
                echo '<div id="exam-one'.$j.'" class="tab-pane fade in active" style="bbackground: green; paddin-bottom: 0px!important;">';
            else
                echo '<div id="exam-one'.$j.'" class="tab-pane fade in">';
            echo '<div style="padding: 15px!important;">';

            echo '<section class="study-section" style="background: white; padding: 0px;"><div class="#">';
            $v=$main_cat_id[$j];

            $result=level3($v);     //Level 3
            echo'<div style="bbackground: green; margin-top: -22px; margin-bottom: 10px;">';
            $e=$f=0;
            $s=1; 
            $clr=array();
            $clr[0]='#ffffff;';
            $clr[1]='#ffffff;';
            $clr[2]='#ffffff;';
            $clr[3]='#ffffff;';
            $clr[4]='#ffffff;';
            foreach($result as $var)
            {
                $exam_cat_name=$var['exam_cat_name'];
                if($exam_cat_name!='Others' && $exam_cat_name!='OtherE' && $exam_cat_name!='OtherL' && $exam_cat_name!='OtherLP' && $exam_cat_name!='OthersEP' && $exam_cat_name!='OthersMP' && $exam_cat_name!='OthersM')
                {                
                 if($e==0)
                  echo '<a class="varc active" data-toggle="pill" href="#home'.$p.'" style="color: white; margin-right: 20px; min-width: 0px;"><button id="btn'.$p.'" class="varc btn btn-lg" style="min-width: 100px; background: #596F7C; min-width: 0px;" onclick="show('.$p.');">'.$exam_cat_name.'</button></a>';
                 else                     
                  echo '<a data-toggle="pill" href="#home'.$p.'" style="color: black; margin-right: 20px;"><button id="btn'.$p.'" class="btn btn-lg" style="min-width: 100px;  min-width: 0px; background: '.$clr[$f].'" onclick="show('.$p.');">'.$exam_cat_name.'</button></a>';                    
                 $n++;                    
                }
                $e++;
                $f++;
                $p++;
                if($f==5)
                    $f=0;
            }
            echo '</div>';
            $result=level3($v);     //Level 3

//VARC TABS
//echo '<br>N='.$e.'<br>';
if($e>=0 && $e<=1)
    echo '<div class="tab-content scrollbar style-4" style="background: #596f7c!important; padding: 20px; padding-bottom: 45px; margin-top: -25px; min-height: 550px;">';
else
    echo '<div class="tab-content scrollbar style-4" style="background: #596f7c!important; padding: 20px; padding-bottom: 45px; margin-top: 0px; min-height: 550px;">';
            $e=1;
            foreach($result as $var)
            {
                $exam_cat_id=$var['exam_cat_id'];
                $exam_cat_name=$var['exam_cat_name'];
                
                if($e==1)
                    echo '<div id="home'.$q.'" class="tab-pane fade in active" style="margin-lefT: 30px;">';
                else
                    echo '<div id="home'.$q.'" class="tab-pane fade in">';
                $result=level4($exam_cat_id);     //Level 4
                foreach($result as $var)
                {
                    $mci=$var['main_cat_id'];
                    $exam_exercise_id=$var['exam_exercise_id'];
                    $title=$var['exam_exercise_name'];
                    echo '<div class="clearfix"></div>';
                    if($title!='Others' && $title!='OthersEP' && $title!='OtherPL' && $title!='OthersPM')
                    {
                        //echo '<ul class="nav nav-tabs">';
        		        //echo '<li class="active"><a data-toggle="tab" href="#" style="background:#fe9837; padding: 0px 20px!important; margin-top: -5px!important; position: relative!important;"><font size="4"><b style="padding-bottom: 15px!important;">'.$title.'</b></font></a></li>';
                        //echo '</ul>';
                        if($z2==1)
                            echo '<div style="Float:left; padding: 5px 10px 5px 10px; border-radius: 5px; background: orange; color: white; font-size: 18px; border: 0px; margin-top: 0px;"><i class="fa fa-folder"></i> <b style="margin-left: 5px; letter-spacing: 2px;">'.$title.'</b></div><br><br><div class="clearfix"></div>';
                        else
                            echo '<div style="Float:left; padding: 5px 10px 5px 10px; border-radius: 5px; background: orange; color: white; font-size: 18px; border: 0px; margin-top: 15px;"><i class="fa fa-folder"></i> <b style="margin-left: 5px; letter-spacing: 2px;">'.$title.'</b></div><br><br><div class="clearfix"></div>';
                    }
                                         
                    $z2++;
                    ///level5 code///
                    if($mci==16)        //Practice Set
                    {
                        echo'<div class="col-md-12" style="bbackground: red; mmargin-top: -28px!important; margin-left: -5px!important; margin-bottom: -28px!important;">
                            <div class="lload-more-containercol-md-12">
                            <input style="display: none;" type="checkbox" id="load-more'.$z3.'"/>';
                    }
                    else
                    {
                        echo'<div class="col-md-12" style="bbackground: red; margin-top: -28px!important; margin-left: -35px!important; margin-bottom: -28px!important;">
                            <div class="load-more-container col-md-12">';
                            echo '<input type="checkbox" id="load-more'.$z3.'"/>';
                    }
                    echo '<ul>';
                   
                        if($mci!=16)
    echo'<style> 
 .load-more-container #load-more'.$z3.' {
  display: none;
}
.load-more-container #load-more'.$z3.':checked ~ ul li:nth-child(1n + 7) {
  max-height: 999px;
  opacity: 1;
  transition: 0.2s ease-in;
}
.load-more-container #load-more'.$z3.':checked ~ .load-more-btn .loaded {
  display: block;
 
}
.load-more-container #load-more'.$z3.':checked ~ .load-more-btn .unloaded{
  display: none;
  
}
 </style>';
                        $result2=level5($exam_exercise_id);
                        $z=1;
                        $z4=1;
                        foreach($result2 as $var2)
                        {
                            //$mci=$var2['main_cat_id'];
                            $exam_id=$var2['exam_id'];
                            $title2=$var2['exam_name'];
                            //echo'<li>';
                            // if($_SESSION["contact_verification"]==0  && $_SESSION["contact_verification"]!=null)
                            // {
                            //   echo '<li><center><span style="font-size: 20px; color: #fe9837; padding-top: 10px; letter-spacing: 1px;"><b>'.$title2.'</b></span>
                            //     <br><span style="cursor: pointer;"><button title="Phone Number not Verified" class="btn btn-success btn-sm" sstyle="bbackground: '.$bgcolor.'; color: white;">Start Test</button></span></center></li>';
                            // }
                            // else {
                            if($mci!=16)
                            {
                                $sqlX="SELECT question_id FROM questions WHERE exam_id=$exam_id LIMIT 1";
                                $resultX=$conn->query($sqlX);
                                $res=$resultX->num_rows;
                                if($res==0)
                                { 
                                    echo '<li><center><span style="font-size: 20px; color: #fe9837; padding-top: 10px; letter-spacing: 1px;"><b>'.$title2.'</b></span>
                                <br><span style="ccursor: pointer;"><button  class="btn btn-success btn-sm" sstyle="bbackground: '.$bgcolor.'; color: white;">Start Test</button></span></center></li>'; //remove disabled attribute...
                                }
                                else
                                {
                                    echo '<li><center><span style="font-size: 20px; color: #fe9837; padding-top: 10px; letter-spacing: 1px;"><b>'.$title2.'</b></span>
                                <br><span style="cursor: pointer;"><button onclick=chk('.$exam_id.'); class="btn btn-success btn-sm" sstyle="bbackground: '.$bgcolor.'; color: white;">Start Test</button></span></center></li>';
                                }
                            }
                            else
                            {
                                echo '<center><div class="col-md-1 blocks2"><span style="font-size: 20px; color: #fe9837; padding-top: 10px; letter-spacing: 1px;"><b>'.$title2.'</b></span>
                                <br><span style="cursor: pointer; padding-bottom: 20px;" class="col-md-1"><button onclick=chk('.$exam_id.'); class="btn btn-success btn-sm" style="background: '.$bgcolor.'; color: white; margin-left: 8px;  ">Start Test</button></span></div></center>';
                            }
                          // }
                            $z4++;
                        }         
 
  echo'</ul>';
if($mci!=16)
{
  if($z4>=6)
      echo '<label class="load-more-btn" for="load-more'.$z3.'">
        <span class="unloaded pull-right"><i class="fa fa-angle-double-down fa-lg" style="color: white; position: absolute; right: -14px; margin-top: -35px"></i></span>
        <span class="loaded pull-right"><i class="fa  fa-angle-double-up fa-lg" style="color: white; position: absolute; right: -14px; margin-top: -35px"></i></span>
      </label>';
}
echo '</div>';
$z3++;
                        
                        
                        
                    echo'</div>';
                    
                   ////level5 code end///// 
                    
                }
                echo '</div>';
            $q++;
            }
echo '<div style="height: 200px;"></div>';
            
        echo '<div></div>';
        echo '</div>';
        //END VARC
 


            echo '</div></section></div></div>';
        }
        echo '<input type="hidden" id="elementc" value="'.$n.'"/>';
        ?>


       </div>
      




    <!-- ...........End js include here.............. -->

<script type="text/javascript">
	$(document).ready(function(){
$('.carousel[data-type="multi"] .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
  for (var i=0;i<4;i++) {
    next=next.next();
    if (!next.length) {
        next = $(this).siblings(':first');
  	}
    
    next.children(':first-child').clone().appendTo($(this));
  }
});
});	</script>
    <sscript src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <sscript src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  <sscript src="js/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    /*$(document).ready(function() {
      $(".regular").slick({
        dots: false,
        infinite: true,
        slidesToShow: 6,
        slidesToScroll: 6
      });
    });

    $(document).ready(function () {
         var screen = $(window).width();  
         if (screen > 768)
         {
              $(".regular").slick({
                dots: false,
                infinite: true,
                slidesToShow: 6,
                slidesToScroll: 6
              });
         }
         else
         {
              $(".regular").slick({
                dots: false,
                infinite: true,
                slidesToShow: 3,
                slidesToScroll: 3
              });
         }
     });*/
     </script>
<script>
$('.nav-tabs').load(
    function()
    {
        $('.exam-tab .nav').removeClass('.nav');
    }
);
    function show2(x)
    {
        x='.'+x;
        $(x).css('display','inline');
    }
</script>

<script>
$('.nav-pills li').on('click', function (e) {
       $('.slick-arrow').trigger('click');

});

function show(x)
{
    
     var s='#btn'+x;
     var n=$('#elementc').val();
     for(i=1;i<=n;i++)
     {          
        s2='#btn'+i;
        $(s2).css("background-color","white");
        $(s2).css("color","black");
     }
     $(s).css("background-color","#596F7C");
     $(s).css("color","White");

}
</script>

<script>
    function show3(x)       //View More
    {
        var obj='#A'+(x);
        var b1='#B'+(x);
        var b2='#C'+(x);
        $(obj).css("display","block");
        $(b1).css("display","none");
        $(b2).css("display","block");
    }
    function show4(x)       //View Less
    {
        var obj='#A'+(x);
        var b1='#B'+(x);
        var b2='#C'+(x);
        $(obj).css("display","none");
        $(b1).css("display","block");
        $(b2).css("display","none");
    }
    function chk(exam_id)
    {
        id=$('#id').val();
        u='https://www.searchurcollege.com/connection/chk_url.php?id='+id+'&eid='+exam_id;
        $.ajax({
            type: "GET",
            url: u,
            success: function(data)
            {
                if(data=='0')
                {
                    $('.log').click();
                    $("#login2").modal().show();
                    $("#login2 #eid").val(exam_id);
                }
                else
                if(data=='1')
                    //$(location).attr('href', '../exam/start-exam/'+exam_id);
                    $(location).attr('href', 'https://www.searchurcollege.com/exam/exam/start_exam.php?examID='+exam_id);
                else
                if(data=='2')
                    //$(location).attr('href', '../connection/pay_now.php');
                    $(location).attr('href', 'https://www.searchurcollege.com/connection/pay_now.php');
                else
                if(data=='3')
                {
                    $('.sorry').click();
                    $("#sorry").modal().show();
                }
            }
         });
    }
    function mv(){
         $("#mv").hide();
    }
</script>

<script type="text/javascript"> 
    var mobile = (/iphone|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()));  
    if(mobile)
    { 
        $('#mv').css('display', 'e');
    }
</script>

<button class="log" style="display: none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#login2">Open Modal</button>


<div id="login2" class="modal fade" role="dialog" style="margin-top: 100px;">
  <div class="modal-dialog">
    <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div iid="userloginbase" class="col-md-12" style="background: white; padding: 10px; padding-bottom: 45px!important;">
              <button type="button" style="position: absolute; right: 20px; color: black;" class="close" data-dismiss="modal" title="Close">&times;</button>
                <h4 class="modal-title"><b><i class="fa fa-user-o"></i> User Login</b><br /><br /></h4>
                <input type="hidden" id="eid" value="<?php //echo $_REQUEST['eid'];?>" />
                <form id="frmLogin2" action="user_login.php">
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="text" class="form-control" name="email" placeholder="Email" required />
                    </div>
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="password" class="form-control" name="password" placeholder="Password" required />
                    </div>
                    <div class="col-md-12 text-right">
                        <button type="submit" class="btn btn-success pull-left">Login</button>
                        
                        <span id="success2" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Login Succeeded.</span>
                        <span id="error2" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Invalid Credentials</span>
                    </div>
                    <div class="col-md-12">
                        <!--<a href="" class="pull-right" style="margin-right: 5px;"><img src="../img/google.png" height="30" /></a>
                        <a href="" class="pull-right" style="margin-right: 5px;"><img src="../img/fb.png" height="30" /></a>-->
                        <span  class="pull-right" style="margin-top: 7px; font-weight: bold;">
                           <p> New user ?  
                            <?php  
                              if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
                                  {

                                echo '<a href="https://searchurcollege.com/connection/register1.php"><span ddata-toggle="modal" ddata-target="#register" ddata-dismiss="modal" style="margin-right: 10px; cursor: pointer; color: #5D9BD0;">Register Here</span></a>';
                             }
                                else {
                                  echo '<a><span data-toggle="modal" data-target="#register" data-dismiss="modal" style="margin-right: 10px; cursor: pointer; color: #5D9BD0;">Register Here</span></a>';
                                }
                             ?>
                            
                            <!--|
                            <a href="" style="margin-left: 10px; margin-right: 10px;">Forget Password</a>-->
                        <!--</span>-->
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<button class="sorry" style="display: none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#sorry">Open Modal</button>
<div id="sorry" class="modal fade" role="dialog" style="margin-top: 100px;">
      <div class="modal-dialog">
        <div id="sorrycontent" class="modal-content">
            <button type="button" class="close" data-dismiss="modal"><b style="ccolor: white;">&times;</b></button>
            <center><h3 style="color: black; ">Sorry! You can't start this Test as your stream is <b>
            <?php
                if(isset($_SESSION['stream'])){ 
                   $s=$_SESSION['stream'];
                    if($s=="")
                      $s='</b>different.';
                    }
                    else 
                    $s='</b>different.';
                  echo $s;
            ?>
            </b></h3>
                <h4 style="color: black; ">You can register a new account with the desired Stream.</h4>
            </center>
        </div>
    </div>
</div>


<script type="text/javascript">
        //Login User 2
        $('#frmLogin2').submit(function(event) {
          $.post(
           'https://www.searchurcollege.com/connection/user_login.php',
            $(this).serialize(),
            function(data)
            {
                if(data=='1')
                {
                    $("#success2").show();
                    eid=$('#eid').val();
                    setTimeout(function() { $("#success2").hide(); }, 3000);
                    if(eid>0)
                        window.location.href = "https://www.searchurcollege.com/exam/start-exam/"+eid;
                    else
                    {
                        location.reload();
                    }
                }
                else
                if(data=='2')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                if(data==0)
                {
                    $("#error2").show();
                    setTimeout(function() { $("#error2").hide(); }, 3000);
                }
                else
                {
                    window.location.href = "https://www.searchurcollege.com/connection/alert.php?email="+data;
                }
            }
          );
          return false;   
        });  
</script>

<script>
    function setHeight()
    {
        $('.varc').click();
        $("#dv").height("10em");
    }
</script>
</div>
