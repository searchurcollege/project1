<?php
  $a=$_REQUEST['tagRecord'];
 include("../../../../connection/dbconnect.php");
   $sql="DELETE FROM suc_search_tag WHERE search_tag_id='$a' ";
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>