<?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$id=$_REQUEST['id'];
 $ssql="SELECT * from suc_college where college_id='$id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
                $u_name=$rw["college_name"];
                $u_uni_id=$rw["uni_id"];
                $u_desc=$rw["college_desc"];
                $u_location_id=$rw["college_location_id"];
                $u_establishment_dt=$rw["college_establishment_dt"];
                $u_type=$rw["college_type"];
                $u_aicte_approved=$rw["college_aicte_approved"];
                $u_code_flag=$rw["college_code_flag"];
                $u_minority_type=$rw["college_minority_type"];
                $u_management_style=$rw["college_management_style"];
                $u_course=$rw["college_no_of_courses"];
                $u_admission_notes=$rw["college_admission_notes"];
                $u_status=$rw["college_status"];

            }
           $sql="SELECT id,location_name from location where id=$u_location_id;";
      $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
            {
                $c_lid=$row["id"];
               $c_lname=$row["location_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
        $sql="SELECT uni_id,uni_name from suc_university where uni_id=$u_uni_id;";
      $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
            {
                $c_uni_id=$row["uni_id"];
                $c_uni_name=$row["uni_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
?>

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
   $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
    <?php include_once '../../includes/left_sidebar1.php';?>
    <!-- left column -->
    <aside class="right-side">  
      <section class="content">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-12">
                    <div class="form-group col-xs-6">
                      <label for="catName">College Name</label>
                      <input type="text" placeholder="College Name" class="form-control" name="college_name" id="college_name" value="<?php echo $u_name;?>" required />
                    </div>
                          
                                        <div class="form-group col-xs-6">
                      <label for="catName">University</label>
                      <select class="form-control sselect2" id="uni_id" name="uni_id" required>
                        <option>Select University</option>
                                                 <?php 
                                                include("../../../connection/dbconnect.php");
                                                $sql="SELECT uni_id,uni_name from suc_university";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                        $uni_id=$row["uni_id"];
                                       $uni_name=$row["uni_name"];
                                    if($u_uni_id==$uni_id)
                                      echo ' <option selected value="'.$uni_id.'">'.$uni_name.'</option> ';
                                    else
                                      echo ' <option  value="'.$uni_id.'">'.$uni_name.'</option> ';
                                    }
                                                 ?>               
                      </select>
                    </div>
                                        

                                        <div class="form-group col-xs-6">
                                          <label for="catName">Location</label>
                                          <select class="form-control" id="college_location_id" name="college_location_id" required>
                                            <option>Select Location</option>
                                             <?php 
                                            include("../../../connection/dbconnect.php");
                                            $sql="SELECT id,location_name from location";
                          $result=$conn->query($sql);
                              while($row=$result->fetch_assoc())
                                {
                                    $lid=$row["id"];
                                   $lname=$row["location_name"];
                                 //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                   if($u_location_id==$lid)
                                    echo ' <option selected  value="'.$lid.'">'.$lname.'</option> ';
                                  else
                                    echo ' <option  value="'.$lid.'">'.$lname.'</option> ';
                                  
                                }
                                             ?>               
                                          </select>
                                        </div>
                                        
                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">Description</label>
                      <textarea class="form-control summernote" placeholder="College Description" id="college_desc" name="college_desc"><?php echo $u_desc;?></textarea>
                    </div>
                                          
                    <div class="form-group col-xs-4">
                      <label for="catName">Establishment Date</label>
                      <input type="text" placeholder="YYYY/MM/DD" class="form-control " name="college_establishment_dt" id="datepicker" value="<?php echo $u_establishment_dt;?>" required />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">Type</label>
                      <select class="selectpicker form-control" id="college_type" name="college_type">
                        <option>Select Type</option>
                        <?php
                        if($u_type=="1")
                          echo '<option selected value="1">Goverment</option>
                                <option  value="2">Private</option>';
                        else
                          echo '<option  value="1">Goverment</option>
                                <option selected value="2">Private</option>';        
                        ?>
                                                
                                            </select> 
                    </div>
                                        <!-- div class="form-group col-xs-4">
                      <label for="catName">No. of Course</label>
                      <input type="text" placeholder="No. of Course" class="form-control " name="college_no_of_courses" id="college_no_of_courses" value="<?php //echo $u_course;?>" required />
                    </div> -->
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Code Flag</label>
                      <input type="text" placeholder="College Code Flag" class="form-control " name="college_code_flag" id="college_code_flag" value="<?php echo $u_code_flag;?>" required />
                    </div>
                                        <!-- <div class="form-group col-xs-4">
                      <label for="catName">College Management</label>
                      <input type="text" placeholder="College Management" class="form-control " name="college_management_style" id="college_management_style" value="<?php// echo $u_management_style;?>" required />
                    </div> -->
                                        <div class="form-group col-xs-4">
                      <label for="catName">Minority Type</label>
                      <input type="text" placeholder="Minority Type" class="form-control " name="college_minority_type" id="college_minority_type" value="<?php echo $u_minority_type;?>" required />
                    </div>
                                        
                          
                                        
                     <div class="form-group col-xs-12"> 
                      <label for="cat_Description">Admission Notes</label>
                      <textarea class="form-control summernote" placeholder="Admission Notes" id="college_admission_notes" name="college_admission_notes"><?php echo $u_admission_notes;?></textarea>
                    </div>
                                        <div class="form-group col-xs-3"> 
                      <label for="cat_Description">AICTE Approved</label>
                      <?php
                      if($u_aicte_approved=="1")
                        echo '<input checked data-toggle="toggle" data-onstyle="warning" id="college_aicte_approved" name="college_aicte_approved" type="checkbox" value="1" />';
                      else
                        echo '<input  data-toggle="toggle" data-onstyle="warning" id="college_aicte_approved" name="college_aicte_approved" type="checkbox" value="1" />';
                      ?>
                      
                    </div>
                                        <div class="form-group col-xs-3"> 
                      <label for="cat_Description">Admission Notes</label>
                      <?php
                      if($u_status=="1")
                        echo '<input checked data-toggle="toggle" data-onstyle="warning" id="college_status" name="college_status" type="checkbox" value="1" />';
                      else
                        echo '<input data-toggle="toggle" data-onstyle="warning" id="college_status" name="college_status" type="checkbox" value="1" />';
                      ?>
                      
                    </div>
                                        
                                      
                  </div>
                 </div>
              </div>
              <div class="box-footer clearfix"> 
                <div class="col-xs-12"> 
                  <div class="col-xs-12 pull-right">
                    <button type="submit"  nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right"> Submit</button>
                  </div>
                </div>
              </div>
            </form>
            <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--RECORD UPDATED--</h4></center></div>
          </div>  
        </div>
      </section>
    </aside>

    
  </div>
  
  <!-- <div style="background: red ; height: 30px;"></div> -->
<?php// include_once '../includes/footer.php';?>
<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
    //CKEDITOR.replace( 'college_desc' );
    //CKEDITOR.replace( 'college_admission_notes' );
  </script>
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"updateCollege.php?table_name=suc_college&college_id=<?php echo $id ?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          if(data=="success"){
            $('#success').fadeIn().delay(1000).fadeOut();
            setTimeout("location.href = '../college-dashboard-view.php'",2000);
        }
        
        }
      });
      
      
    });
  });
</script>