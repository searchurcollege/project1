 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Add College Reviews
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                        <div class="form-group col-xs-6">
											<label>College Name</label>
											<select class="form-control" id="college_id" name="college_id" required>
												<option>College Name</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                $sql="SELECT college_id,college_name from suc_college";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $college_id=$row["college_id"];
            						               $college_name=$row["college_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
            						              echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>
                                        <div class="form-group col-xs-6">
											<label>College Review User</label>
											<input type="text" placeholder="College Review User" class="form-control" name="college_review_user" id="college_review_user" value=""  />
										</div>  
                    <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">
                                        <div class="form-group col-xs-6">
											<label>College Review Likes </label>
											<input type="text" placeholder="College Document" class="form-control" name="college_review_likes" id="college_review_likes" value=""  />
										</div>
                                        <div class="form-group col-xs-6">
											<label>Review Date</label>
											<input type="text" placeholder="YYYY/MM/DD" class="form-control " name="college_review_date" id="datepicker" value=""  />
										</div>
                                        <div class="form-group col-xs-12">
											<label>College Review Comment</label>
											<textarea class="form-control summernote" placeholder="Review Comment" id="college_review_comment" name="college_review_comment"></textarea>
										</div>
                                       </div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
            <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--New RECORD INSERTED--</h4></center></div>
					</div>	
				</div>
			</section>
		</aside>

    
	</div>
  
	<!-- <div style="background: red ; height: 30px;"></div> -->

<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
	//CKEDITOR.replace( 'college_review_comment' );
   
  </script>

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_reviews_Action.php?table_name=suc_college_reviews",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          
          if(data==1){
            $('#success').show();
            setTimeout("location.href = 'college-reviews.php'",2000);
        }
        
        }
      });
      
      
    });
  });
</script>