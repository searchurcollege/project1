<?php
 $a=$_REQUEST['collegeRecord'];
 include("../../../../connection/dbconnect.php");
 $tbl_name=$_REQUEST["table_name"];
 $condition=$_REQUEST["cond_id"];
 if(isset($_REQUEST["filename"]))
 {
 	 $fileName="../gallery/facility_master/".$_REQUEST["filename"];
 }
 $sql="select * from $tbl_name where $condition='$a'";
  $sql="DELETE FROM ".$tbl_name." WHERE ". $condition."='$a' ";
if ($conn->query($sql) == TRUE) {
	// echo 1;
	if($fileName!=""){
		unlink($fileName);
    	echo 1;
	}

} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}

?>