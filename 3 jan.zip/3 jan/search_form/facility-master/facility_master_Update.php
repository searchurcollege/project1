<?php 
 $college_status=$_REQUEST["facility_status"];
$tbl_name=$_REQUEST["table_name"];
$fac_name=$_REQUEST["facility_name"];
$suc_id=$_REQUEST["course_id"];
$c_icon="../gallery/facility_master/".$_REQUEST["c_icon"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", facility_status='0' "; 
}
include("../../../../connection/dbconnect.php");
 $sql="update ".$tbl_name." set ".$k." where facility_code=".$suc_id;
if ($conn->query($sql) == TRUE) {

	if(!empty($_FILES['facility_icon_path']['name'])){
    //echo "1";
        unlink($c_icon);

             $allowedExts = array("gif", "jpeg", "jpg", "png");
           // $extension = end(explode(".", $_FILES["facility_image_path"]["name"]));

            // $currentDir = '../'.getcwd().'/gallery/college/facility';
            chdir('../gallery/facility_master');
            $currentDir = getcwd();
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['facility_icon_path']['name'];
            $fileSize = $_FILES['facility_icon_path']['size'];
            $fileTmpName  = $_FILES['facility_icon_path']['tmp_name'];
            $fileType = $_FILES['facility_icon_path']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn=$fac_name."_facility.".$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET facility_icon_path='$fn' WHERE facility_code='$suc_id'";
                          $result=$conn->query($sql1);
                       // echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
        
       // echo 1;
         
    }

    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>