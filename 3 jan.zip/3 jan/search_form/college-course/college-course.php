 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];
   include("../../../../connection/dbconnect.php");
   ?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Add College Course
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                       <div class="form-group col-xs-4">
                      <label for="catName">College Name</label>
                      <select class="form-control" id="college_id" name="college_id" required>
                        <option>Select College</option>
                                                 <?php 
                                                
                                                $sql="SELECT college_id,college_name from suc_college";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                        $college_id=$row["college_id"];
                                       $college_name=$row["college_name"];
                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                      echo ' <option  value="'.$college_id.'">'.$college_name.'</option> ';
                                    }
                                                 ?>               
                      </select>
                    </div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Master Course</label>
											<select class="form-control" id="master_course_id" name="master_course_id" required>
												<option>Select Master Course</option>
                                                 <?php 
                                                
                                                $sql="SELECT course_id,course_name from suc_master_course order by course_name";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $course_id=$row["course_id"];
            						               $course_name=$row["course_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
            						              echo ' <option  value="'.$course_id.'">'.$course_name.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>

                    <div class="form-group col-xs-4">
                      <label for="catName">Affilated to another university</label>
                      <select class="form-control" id="course_uni_id" name="course_uni_id" required>
                        <option disabled selected>Select University</option>
                                                 <?php 
                                                
                                                $sql="SELECT uni_id,uni_name from suc_university order by uni_name";
                              $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                        $uni_id=$row["uni_id"];
                                       $uni_name=$row["uni_name"];
                                     //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                      echo ' <option  value="'.$uni_id.'">'.$uni_name.'</option> ';
                                    }
                                                 ?>               
                      </select>
                    </div>

                    
                                        <div class="form-group col-xs-4">
											<label for="catName">Course Name</label>
											<input type="text" placeholder="Eg. B.Tech in Computer Science" class="form-control" name="college_course_name" id="college_course_name" value="" required />
										</div>
                                        <div class="form-group col-xs-4">
                                          <label for="catName">Course Type</label>
                                          <select class="form-control" id="college_course_type" name="college_course_type" rrequired>
                                                <option>Select Course Type</option>
                                                <option  value="PG Degree">PG Degree</option>
                                                <option  value="PG Diploma">PG Diploma</option>
                                                <option  value="UG Degree">UG Degree</option>
                                                <option  value="UG Diploma">UG Diploma</option>

                                            </select> 
                                        </div>
                                        <div class="form-group col-xs-3">
                                          <label for="catName">Mode of Study</label>
                                          <select class="form-control" id="college_course_full_part" name="college_course_full_part" rrequired>
                                                <option>Select Mode of Study</option>
                                                <option  value="Full Time">Full Time</option>
                                                <option  value="Distance">Distance</option>
                                                <option  value="Part Time">Part Time</option>
                                                <option  value="Online">Online</option>
                                                <option  value="Online -Real Time ">Online -Real Time </option>
                                                
                                            </select> 
                                        </div>

                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">Highlights</label>
                      <textarea class="form-control summernote" placeholder="Course Highlights" id="college_course_highlights" name="college_course_highlights"></textarea>
                    </div>
                                        <div class="form-group col-xs-3">
                                          <label for="catName">Course Duration</label>
                                          <input type="text" placeholder="Eg. 4 Years / 18 Months" class="form-control" id="college_course_duration" name="college_course_duration" value="" required />
                                        </div>
                                        <div class="form-group col-xs-3">
											<label for="catName">Course Language</label>
											<select class="form-control" id="college_course_language" name="college_course_language" rrequired />
												<option>Select Type</option>
                                                <option  value="English">English</option>
                                                <option  value="Hindi">Hindi</option>
                                            </select> 
										</div>
                    <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">
                      
                                        <div class="form-group col-xs-3">
											<label for="catName">Course Seats</label>
											<input type="text" placeholder="Eg. 120" class="form-control" name="college_course_seats" id="college_course_seats" value="" rrequired />
										</div>
                    
                    <div class="form-group col-xs-3">
                      <label for="catName">Course Brochure</label>
                      <input type="file" class="form-control" name="college_course_brochure_path"  id="college_course_brochure_path"  rrequired />
                    </div>
                    
                                        <div class="col-md-4 inputGroupContainer">
                                            <label class="col-md-4">AICTE Approved</label>
                                            <div class="col-md-2">
                                           <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="course_aicte_flag" name="course_aicte_flag" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                        <div class="col-md-4 inputGroupContainer">
                                            <label class="col-md-4">Doeacc Flag</label>
                                            <div class="col-md-2">
                                           <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="course_doeacc_flag" name="course_doeacc_flag" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                        <div class="col-md-4 inputGroupContainer">
                                            <label class="col-md-4">Status</label>
                                            <div class="col-md-2">
                                           <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="college_course_status" name="college_course_status" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                      
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
            <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Inserted</h4></center></div>
					</div>

				</div>
			</section>
			
		</aside>

    
	</div>
  
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo BASE_URL;?>assets/js/AdminLTE/app.js" type="text/javascript"></script>

 <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
  <
  <script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.full.js"></script>
<script>
  CKEDITOR.replace( 'college_course_highlights' );
   // / CKEDITOR.replace( 'college_admission_notes' );
  </script>

<script>
    $(document).ready(function(){
        $("#college_id").select2();
        $("#master_course_id").select2();
        $("#course_uni_id").select2();
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_course_Action.php?table_name=suc_college_courses",
        method:"POST",
        //data: $('#frmSubmi').serialize(),
         data: new FormData(this),
        contentType: false,       // The content type used when sending data to the server.
        cache: false,             // To unable request pages to be cached
        processData:false, 
        success:function(data)
        {
          //alert(data);
          if(data==1){
            $('#success').fadeIn().delay(1000).fadeOut();
            setTimeout("location.href = 'college-course.php'",2000);
        }
        }
      });
      
      
    });
  });
</script>
