	<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
 $k=rtrim($k,', ');
 $v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];
 $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
if ($conn->query($sql) == TRUE) {
	$last_id = $conn->insert_id;
	if(!empty($_FILES['college_course_brochure_path']['name'])){
    //echo "1";
    	
             $allowedExts = array("pdf","doc");
            $currentDir = getcwd()."/documents";
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here
            $college_id=$_REQUEST["college_id"]."_";
            $fileExtensions = ['pdf','doc']; // Get all the file extensions
             $fileName = $_FILES['college_course_brochure_path']['name'];
            $fileSize = $_FILES['college_course_brochure_path']['size'];
            $fileTmpName  = $_FILES['college_course_brochure_path']['tmp_name'];
            $fileType = $_FILES['college_course_brochure_path']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="Doc_".$college_id.$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (!in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a PDF or DOC file";
                }

                if ($fileSize > 10000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 10MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        $sql2="UPDATE $tbl_name SET college_course_brochure_path='$fn' WHERE college_course_id='$last_id'";
                         $conn->query($sql2);

                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
         
    }
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}



//echo 0;//"success";
?>