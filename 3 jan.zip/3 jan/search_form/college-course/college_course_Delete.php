<?php
  $a=$_REQUEST['courseRecord'];
  $b=$_REQUEST['collegeRecord'];
 include("../../../../connection/dbconnect.php");
   echo $sql="DELETE FROM suc_college_courses WHERE college_course_id='$a' and college_id='$b'";
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>