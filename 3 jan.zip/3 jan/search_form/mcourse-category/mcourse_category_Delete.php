<?php
  $a=$_REQUEST['collegeRecord'];
 include("../../../../connection/dbconnect.php");
   $sql="DELETE FROM suc_master_course_category WHERE course_cat_id='$a' ";
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>