<?php 
 $college_status=$_REQUEST["cc_fee_status"];
$tbl_name=$_REQUEST["table_name"];
$fee_id=$_REQUEST["fee_id"];
$course_id=$_REQUEST["course_id"];
$desc=$_REQUEST["desc"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", cc_fee_status='0' "; 
}

include("../../../../connection/dbconnect.php");
  $sql="update ".$tbl_name." set ".$k." where cc_fee_id=".$fee_id." and college_course_id=".$course_id." and cc_fee_slab_desc='".$desc."'";
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>