<?php
  $a=$_REQUEST['feeRecord'];
  $b=$_REQUEST['courseRecord'];
  $c=$_REQUEST['descRecord'];
 include("../../../../connection/dbconnect.php");
    $sql="DELETE FROM suc_college_course_fee_structure WHERE cc_fee_id='$a' and college_course_id='$b' and cc_fee_slab_desc='$c' ";
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>