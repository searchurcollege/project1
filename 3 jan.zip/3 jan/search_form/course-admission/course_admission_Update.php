<?php 
$date = date('Y-m-d H:i:s');
 $college_status=$_REQUEST["cc_adm_step_status"];
$tbl_name=$_REQUEST["table_name"];
$stp_seq=$_REQUEST["step_seq"];
$course_id=$_REQUEST["course_id"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", cc_adm_step_status='0' "; 
}

include("../../../../connection/dbconnect.php");
 $sql="update ".$tbl_name." set ".$k." where college_course_id='$course_id' and cc_adm_step_seq =".$stp_seq;
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>