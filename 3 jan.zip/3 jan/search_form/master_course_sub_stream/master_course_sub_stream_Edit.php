<?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$id=$_REQUEST['id'];

$tbl="suc_master_course_sub_stream";
 $ssql="SELECT * from $tbl where course_sub_stream_id='$id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
              $c_stream_id=$rw["course_stream_id"];
             $c_sub_stream_name=$rw["course_sub_stream_name"];
              $c_sub_stream_desc=$rw["course_sub_stream_desc"];
              $c_sub_stream_sts=$rw["course_sub_sream_status"];

              
            }
          
?>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
   $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
    <?php include_once '../../includes/left_sidebar1.php';?>
    <!-- left column -->
    <aside class="right-side">  
      <section class="content-header">              
        <h4>Edit Course Admission
          <span class="label label-danger" id="validateError"></span> 
          <a href="<?php echo BASE_URL;?>search/master_course_sub_stream/master_course_sub_stream_View.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
        </h4>         
      </section>
      <section class="content">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-12">
                    
                    
    
                                        <div class="form-group col-xs-6">
                      <label for="catName">Stream Name</label>
                      <select class="form-control" id="course_stream_id" name="course_stream_id" required>

                        <option>Select Course</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                
                                                  $sql="SELECT course_stream_id , course_stream_name from suc_master_course_stream order by course_stream_name";
                                                  $result=$conn->query($sql);
                                  while($row=$result->fetch_assoc())
                                    {
                                      $course_stream_id=$row["course_stream_id"];
                                      $course_stream_name=$row["course_stream_name"];
                                      if($c_stream_id==$course_stream_id)
                                        echo ' <option selected value="'.$course_stream_id.'">'.$course_stream_name.'</option> ';
                                      else
                                        echo ' <option  value="'.$course_stream_id.'">'.$course_stream_name.'</option> ';
                                    }
                                                 ?>               
                      </select>
                    </div>

                                        <div class="form-group col-xs-6">
                                          <label for="catName">course_sub_stream_name</label>
                      <input type="text" placeholder="course_sub_stream_name" class="form-control" name="course_sub_stream_name" id="course_sub_stream_name" value="<?php echo $c_sub_stream_name; ?>" required />
                    </div>
                                        <div class="form-group col-xs-12">
                      <label for="cat_Description">Description</label>
                      <textarea class="form-control summernote" placeholder="Description" id="course_sub_stream_desc" name="course_sub_stream_desc"><?php echo $c_sub_stream_desc; ?></textarea>
                    </div>
                                         
                    
                                        <div class="col-md-12 ">
                            
                                        <div class="col-md-4 inputGroupContainer">
                                          <label class="col-md-8 text-left">Status</label>
                                           <div class="col-md-2">
                                              <div class="input-group" style="margin-left: -120px;">
                                                <?
                                                if($c_sub_stream_sts==1)
                                                  echo '<input checked data-toggle="toggle" data-onstyle="warning" id="course_sub_sream_status" name="course_sub_sream_status" type="checkbox" value="1">';
                                                else
                                                  echo '<input  data-toggle="toggle" data-onstyle="warning" id="course_sub_sream_status" name="course_sub_sream_status" type="checkbox" value="1">';
                                                ?>
                                                </div>
                                        </div>
                                        </div>
                                      </div>  
                                      
                  </div>
                 </div>
              </div>
              <div class="box-footer clearfix"> 
                <div class="col-xs-12"> 
                  <div class="col-xs-12 pull-right">
                    <button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
                  </div>
                </div>
              </div>
            </form>
          </div>  
        </div>
        <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--Record updated--</h4></center></div>
        <div id ="failure"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: red;">--Something Wrong.. Please check data and try again--</h4></center></div>
      </section>
    </aside>

    
  </div>
  
  <!-- <div style="background: red ; height: 30px;"></div> -->
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo BASE_URL;?>assets/js/AdminLTE/app.js" type="text/javascript"></script>

<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
  //CKEDITOR.replace( 'cc_adm_step_desc' );
    
  </script>
  
<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"master_course_sub_stream_Update.php?table_name=<?php echo $tbl; ?>&course_id=<?php  echo $id;?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          //alert(data);
          if(data==1){
            $('#success').show();
            setTimeout("location.href = 'master_course_sub_stream_View.php'",2000);
        }
        
        }
      });
      
      
    });
  });
</script>