 <?php include_once '../../includes/header.php';
include ("../../../../connection/dbconnect.php");
 ?> 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <div class="wrapper row-offcanvas row-offcanvas-left">

        <!-- Left side column. Contains the navbar and content of the page -->

		<?php include_once '../../includes/left_sidebar1.php';
		$tbl="suc_master_course_sub_stream";
		?>

		<!-- left column -->

		<aside class="right-side">  

			<section class="content-header">

				<h4>View Admission List   

					<span class="label label-danger" id="validateError"></span> 

					<a href="<?php echo BASE_URL;?>login/search-dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
                    <button type="button" class="btn btn-info btn-sm pull-right" data-toggle="modal" data-target="#stream" style="margin-right: 20px;"><i class="fa fa-plus"></i> Stream</button>

				</h4>

			</section>

			<section class="content">

				<div class="row">

					<!-- left column -->

					<div class="col-md-12">

						<div class="box-body">																					

							<table class="table table-bordered table-striped table-hover">

								<thead>

									<tr>

										<th></th>

										<th>Stream Name</th>
										<th>Sub Stream Name</th>
										<th>Action</th>

									</tr>

								</thead>

								<tbody>

									<!--- **************** Select query to display all Category Active or In Active ********************************-->

									<?php

										  $stm="SELECT course_sub_stream_id,course_stream_id ,course_sub_stream_name FROM $tbl  ORDER BY course_sub_stream_id DESC";

										if ($stmt = $conn->prepare($stm)) 

										{

											//$stmt->bind_param('i', $status);

											$stmt->execute();

											$stmt->store_result();

											$stmt->bind_result($course_sub_stream_id,$course_stream_id,$course_sub_stream_name);

											$sn=1;

											while ($stmt->fetch()>0) {

										?>									

											<tr>

												<td><?php echo $sn++;?></td>
												<td>
												<?php   $unisql="SELECT course_stream_name from suc_master_course_stream where course_stream_id='$course_stream_id'";
												$result=$myconn->query($unisql);
												while ($row=$result->fetch_assoc()){
									              echo $row["course_stream_name"];
												}
										?></td>     

												<td><? echo $course_sub_stream_name; ?></td>

												<td>

													

													<form name="formEdit" action="master_course_sub_stream_Edit.php?id=<?php echo $course_sub_stream_id; ?>" method="POST" style="float:left; margin-right:5px;">

														<button type="submit" name="editCategory" id="editCategory" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></button> 

																														

													</form>

													<?php

														if(!empty($_SESSION['special_permission'])){

													?>

															<button type="button"  data-id="<?php echo $uni_id; ?>" class="btn btn-danger btn-sm" onclick="xyz(<?php echo 	$course_sub_stream_id;?>)"data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-trash-o"></i></button>
															<!-- <button type="button"  class="btn btn-danger btn-sm" onclick="window.location.href='https://www.searchurcollege.com/exam/admin/search/university/deleteUniRec.php?id=<?php //echo $uni_id; ?>'"><i class="fa fa-trash-o"></i></button>	 -->															

													<?php

														}

													?>	

												</td>

											</tr>

<?php

											}

										}

?>										
								</tbody>

							</table>

						</div><!-- /.box-body -->													

					</div>

				</div>
				<div id="failure" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: red; width: 100%; color:red; position: fixed; left: 0px; top: 50%;">....Error....</h4> </center></div>
<div id="sucess" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: green; width: 100%; color: green; position: fixed; left: 0px; top: 50%;">....Record Deleted....</h4> </center></div>
			</section>

		</aside>

	</div>

<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo BASE_URL;?>assets/js/AdminLTE/app.js" type="text/javascript"></script>


	<div id="deleteRecord" class="modal fade" role="dialog">

		<div class="modal-dialog" style="width:30%">

			<!-- Modal content-->

			<div class="modal-content">

				<div class="modal-header" style="background:#3c8dbc; color:#fff;">

					<button type="button" class="close" data-dismiss="modal">&times;</button>

					<h4 class="modal-title"><b>Delete Category</b></h4>

				</div>

				<form name="formDeleteModal" id="formDeleteRecord" method="post" action="">

					<div class="modal-body text-center">

						<p><h5>You are going to Delete Course Category .</h5></p>

						<h5>

						Do you realy want to <span class="label label-danger" id="stDel"></span></h5>

						<input type="hidden" name="collgeRecord" id="collegeRecord" />

					</div>

					<div class="modal-footer" style="background:#3c8dbc; color:#fff;">

						<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>

						<button type="button" id="btnDleterecord" name="btnDleterecord" class="btn btn-primary" data-dismiss="modal">Yes</button>

					</div>

				</form>

			</div>

		</div>

	</div>


	<script>

			$('#btnDleterecord').click(function(){
				//alert("model");
				var collegeRecord=$("#collegeRecord").val();
				//alert(collegeRecord);
				$.ajax({

					type: "POST",

					url: "../delete_Action.php?table_name=<?php echo $tbl; ?>&cond_id=course_sub_stream_id&collegeRecord="+collegeRecord,

					// data: $('#formDeleteModal').serialize(),

					success: function(response) {
						//alert(response);
						if(response==1){
						//alert(response);
						$("#deleteRecord").modal('hide');
						$('#sucess').show();
						
						 setTimeout("location.href = 'master_course_sub_stream_View.php'",2000);
						 // location.reload(); 
						}
						else {
							$('#failure').show();
							setTimeout("location.href = 'master_course_sub_stream_View.php'",2000);
						}

					},

				});

				return false;

			});

		</script>
		<script type="text/javascript">

			$('#DeleteModel').on('show.bs.modal', function(event){

				var btnDelete = $(event.relatedTarget);

					 

				var categoryId = btnDelete.data('id');

				if(categoryId!=0){$("#stDel").text("Delete ?");}

				

				document.getElementById("examCatID").value = categoryId;

								

			});
			function xyz($x){
				$("#collegeRecord").val($x);
			}

		</script>