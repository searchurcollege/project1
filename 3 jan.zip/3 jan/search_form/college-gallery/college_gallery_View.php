 
 <div class="wrapper row-offcanvas row-offcanvas-left">
	<section class="content">

				<div class="row">

					<!-- left column -->

					<div class="col-md-12">

						<div class="box-body">																					

							<table class="table table-bordered table-striped table-hover">.

								<thead>

									<tr>

										<th></th>

										<th>College Name</th>
										<th>Gallery Description</th>
										<th>Action</th>

									</tr>

								</thead>

								<tbody>

									<!--- **************** Select query to display all Category Active or In Active ********************************-->

									<?php

									 $stmt="SELECT college_id, college_gallery_id, college_gallery_desc ,college_gallery_content_path FROM suc_college_gallery ORDER BY college_id ";

										if ($stmtt = $myconn->prepare($stmt)) 

										{

											//$stmt->bind_param('i', $status);

											$stmtt->execute();

											$stmtt->store_result();

											$stmtt->bind_result($college_id,$college_gallery_id, $college_gallery_desc, $college_gallery_content_path);

											$sn=1;

											while ($stmtt->fetch()>0) {

										?>									

											<tr>

												<td><?php echo $sn++;?></td>

												
												
												<?php   $gsql="SELECT college_name from suc_college where college_id='$college_id'";
												$result2=$myconn->query($gsql);
												while ($row2=$result2->fetch_assoc()){
									              echo "<td>".$row2["college_name"]."</td>";
												}
										?>      

												<td><?php echo $college_gallery_desc; ?></td>
												

												<td>

													

													<form name="formEdit" action="college-gallery/college_gallery_Edit.php?id=<?php echo $college_gallery_id; ?>" method="post" style="float:left; margin-right:5px;">

														<button type="submit" name="editCategory" id="editCategory" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></button> 

														<input type="hidden" name="hfCategoryID" id="hfCategoryID" value="<?php echo $exam_cat_id;?>"/>																	

													</form>

													<?php

														if(!empty($_SESSION['special_permission'])){

													?>

															<button type="button"  data-id="<?php echo $uni_id; ?>" class="btn btn-danger btn-sm" onclick="xyz11(<?php echo 	$college_gallery_id;?>)"data-toggle="modal" data-target="#deleteRecordG"><i class="fa fa-trash-o"></i></button>
															<!-- <button type="button"  class="btn btn-danger btn-sm" onclick="window.location.href='https://www.searchurcollege.com/exam/admin/search/university/deleteUniRec.php?id=<?php //echo $uni_id; ?>'"><i class="fa fa-trash-o"></i></button>	 -->															

													<?php

														}

													?>	

												</td>

											</tr>

<?php

											}

										}

?>										
<div id="failure" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: red; width: 30%; color: ">ERROR....</h4> </center></div>
<div id="sucess" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Deleted....</h4> </center></div>

								</tbody>

							</table>

						</div><!-- /.box-body -->													

					</div>

				</div>

			</section>

		

	</div>



	<div id="deleteRecordG" class="modal fade" role="dialog">

		<div class="modal-dialog" style="width:30%">

			<!-- Modal content-->

			<div class="modal-content">

				<div class="modal-header" style="background:#3c8dbc; color:#fff;">

					<button type="button" class="close" data-dismiss="modal">&times;</button>

					<h4 class="modal-title"><b>Delete Category</b></h4>

				</div>

				<form name="formDeleteModal" id="formDeleteRecord" method="post" action="">

					<div class="modal-body text-center">

						<p><h5>You are going to Delete Category .</h5></p>

						<h5>All Exams and Questions related to this category will be deleted.

						Do you realy want to <span class="label label-danger" id="stDel"></span></h5>

						<input type="hidden" name="collgeRecord" id="collegeRecordG" />

					</div>

					<div class="modal-footer" style="background:#3c8dbc; color:#fff;">

						<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>

						<button type="button" id="btnDleterecordG" name="btnDleterecordG" class="btn btn-primary" data-dismiss="modal">Yes</button>

					</div>

				</form>

			</div>

		</div>

	</div>


	<script>

			$('#btnDleterecordG').click(function(){
				//alert("model");
				var collegeRecordG=$("#collegeRecordG").val();
				//alert(collegeRecord);
				$.ajax({

					type: "POST",

					url: "delete_Action.php?table_name=suc_college_gallery&cond_id=college_gallery_id&filename=gallery/<?php echo $college_gallery_content_path;?>&collegeRecord="+collegeRecordG,

					// data: $('#formDeleteModal').serialize(),

					success: function(response) {
						(response);
						if(response==1){
						//alert(response);
						$("#deleteRecordG").modal('hide');
						$('#sucess').fadeIn().delay(2000).fadeOut();
						
						// setTimeout("location.href = 'viewCollege.php'",2000);
						 // location.reload(); 
						}
						else {
							$('#failure').show();
							//setTimeout("location.href = 'viewCollege.php'",2000);
						}

					},

				});

				return false;

			});

		</script>
		<script type="text/javascript">

			$('#DeleteModel').on('show.bs.modal', function(event){

				var btnDelete = $(event.relatedTarget);

					 

				var categoryId = btnDelete.data('id');

				if(categoryId!=0){$("#stDel").text("Delete ?");}

				

				document.getElementById("examCatID").value = categoryId;

								

			});
			function xyz11($x){
				$("#collegeRecordG").val($x);
			}

		</script>