
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
        
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form  id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college-gallery/college_gallery_Action.php?table_name=suc_college_gallery" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                    <input id="id02" name="college_id"  value="" type="hhidden">
                                        
                                        
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Gallery Description</label>
											<textarea class="form-control summernote" placeholder="Gallery Description" id="college_gallery_desc" name="college_gallery_desc"></textarea>
										</div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Gallery Content ID</label>
											<input type="text" placeholder="Gallery Content ID" class="form-control" name="college_gallery_content_id" id="college_gallery_content_id" value="" required />
										</div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Gallery Content Type</label>
											<input type="text" placeholder="Gallery Content ID" class="form-control" name="college_gallery_content_type" id="college_gallery_content_type" value="" required />
										</div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Upload Gallery Picture</label>
											<input type="file" oonchange="ProfImage(this)" class="form-control" name="college_gallery_content_path[]" multiple id="college_gallery_content_path" required />
                      
										</div>
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Gallery Picture Description</label>
											<textarea class="form-control summernote" placeholder="Picture Description" id="college_gallery_content_desc" name="college_gallery_content_desc"></textarea>
										</div>	
										
                                       <div class="col-md-6 inputGroupContainer">
                                            <label class="col-md-4">Status</label>
                                            <div class="col-md-2">
                                           <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="college_gallery_content_status" name="college_gallery_content_status" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
                   <center> <img id ="loadingImage" style="max-height: 140px; margin-left: -70px; position: absolute; ffloat:left; display: none;" cclass="pull-right" src="https://searchurcollege.com/exam/admin/search/college-gallery/loading.gif"></center>
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>	
				</div>
			</section>
		</div>
  <div id ="successs"style="display: none; hheight: 20px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--New Record Inserted--</h4></center></div>
	<!-- <div style="background: red ; height: 30px;"></div> -->

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
	//CKEDITOR.replace( 'college_gallery_desc' );
    //CKEDITOR.replace( 'college_gallery_content_desc' );
  </script>

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
        $("#loadingImage").show();
       // alert("111");
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college-gallery/college_gallery_Action.php?table_name=suc_college_gallery",
        method:"POST",
        // data: $('#frmSubmi').serialize(),
        data: new FormData(this),
        contentType: false,       // The content type used when sending data to the server.
        cache: false,             // To unable request pages to be cached
        processData:false, 
        success:function(data)
        {
          //alert(data);
          if(data==1){
            $('#loadingImage').hide();
          
            $('#successs').fadeIn().delay(2000).fadeOut();
           // setTimeout("location.href = 'college-gallery.php'",2000);
        }
        else {
          $('#loadingImage').hide();
          alert("error");
          //setTimeout("location.href = 'college-gallery.php'",1000);
        }
        
        }

      });
      
      
    });
  });
</script>