
<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
 $k=rtrim($k,', ');
 $v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];


 $_FILES['college_doc']['name'];
 $college_id=$_REQUEST["college_id"];
 
if(!empty(array_filter($_FILES['college_doc']['name']))){
    //echo "1";
        foreach($_FILES['college_doc']['name'] as $key=>$val){
            $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
            if ($conn->query($sql) == TRUE) {
                 $last_id = $conn->insert_id;
              // echo "success";
            } else {
                 // "Error: " . $sql . "<br>" . $conn->error;
                echo "error";
            }
             $allowedExts = array("gif", "jpeg", "jpg", "png","pdf");
           // $extension = end(explode(".", $_FILES["college_doc"]["name"]));

            // $currentDir = '../'.getcwd().'/gallery/college/facility';
            //chdir('../gallery/college');
            $currentDir = getcwd()."/documents";
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here
            $college_id=$_REQUEST["college_id"]."_";
            $fileExtensions = ['jpeg','jpg','png','pdf','doc']; // Get all the file extensions
             $fileName = $_FILES['college_doc']['name'][$key];
            $fileSize = $_FILES['college_doc']['size'][$key];
            $fileTmpName  = $_FILES['college_doc']['tmp_name'][$key];
            $fileType = $_FILES['college_doc']['type'][$key];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="Doc_".$college_id.$last_id.'.'.$fileExtension;
            $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 2000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET college_doc='$fn' WHERE college_doc_id='$last_id'";
                          $result=$conn->query($sql1);
                        //echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
        }
        echo 1;
         
    }
    
?>
