 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
		<?php include_once '../../includes/left_sidebar1.php';?>
		<!-- left column -->
		<aside class="right-side">  
			<section class="content-header">							
				<h4>Add College Event
					<span class="label label-danger" id="validateError"></span> 
					<a href="<?php echo BASE_URL;?>login/dashboard.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
				</h4>					
			</section>
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<form id="colSub">
              <div class="form-group col-xs-4" >
                          <select class="form-control" id="col_id" name="col_id" required>
                            <option value="0">Select college</option>
                                                     <?php 
                                                    include("../../../../connection/dbconnect.php");
                                                     $sql="SELECT college_id,college_name from suc_college order by college_name";
                                  $result=$conn->query($sql);
                                      while($row=$result->fetch_assoc())
                                        {
                                            $college_id=$row["college_id"];
                                           $college_name=$row["college_name"];
                                         //  echo '<option  value="'.$id'">'.$lname.'</option>';
                                           if(isset($_REQUEST['col_id']))
                                           {
                                            $col_id=$_REQUEST['col_id'];
                                            if($_REQUEST['col_id']==$college_id)
                                              echo '<option selected value="'.$college_id.'">'.$college_name.'</option> ';
                                            else
                                              echo '<option  value="'.$college_id.'">'.$college_name.'</option> ';
                                             
                                           }
                                           else
                                              echo '<option  value="'.$college_id.'">'.$college_name.'</option> ';
                                          
                                        }
                                                     ?>               
                          </select>
                        </div>
            </form>
						<!-- general form elements -->
						<form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
										
										<input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                        <div class="form-group col-xs-4">
											<!-- <label for="catName">College Name</label> -->
											<select class="form-control" id="college_id" style="display: none;" name="college_id" required>
												<option>College Name</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                $sql="SELECT college_id,college_name from suc_college";
            									$result=$conn->query($sql);
                   								while($row=$result->fetch_assoc())
            						            {
            						                $college_id=$row["college_id"];
            						               $college_name=$row["college_name"];
            						             //  echo '<option  value="'.$id'">'.$lname.'</option>';
            						             if(isset($_REQUEST['col_id']))
                                           {
                                            $col_id=$_REQUEST['col_id'];
                                            if($_REQUEST['col_id']==$college_id)
                                              echo '<option selected value="'.$college_id.'">'.$college_name.'</option> ';
                                            else
                                              echo '<option  value="'.$college_id.'">'.$college_name.'</option> ';
                                             
                                           }
                                           else
                                              echo '<option  value="'.$college_id.'">'.$college_name.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>
                                        
                                        <div class="form-group col-xs-4">
											<label for="catName">Event Name</label>
											<input type="text" placeholder="Event Name" class="form-control" name="college_event_name" id="college_event_name" value="" required />
										</div>
                                        <div class="form-group col-xs-4">
											<label for="catName">Event Date</label>
											<input type="text" placeholder="YYYY/MM/DD" class="form-control " name="college_event_date" id="college_event_date" value="" rrequired />
										</div>
										<div class="form-group col-xs-4">
											<label for="catName">Event Image</label>
											<select class="form-control" id="college_event_gallery_id" name="college_event_gallery_id" rrequired>
												<option value="0">Event Image</option>
                                                 <?php 
                                                include("../../../../connection/dbconnect.php");
                                                if(isset($_REQUEST['col_id']))
                                           		{
	                                              $sql1="SELECT college_gallery_id ,college_gallery_desc from suc_college_gallery where college_id =".$_REQUEST['col_id'];
	                                            }
		                                        else
		                                          $sql1="SELECT college_gallery_id ,college_gallery_desc from suc_college_gallery";

                                                
            									$result1=$conn->query($sql1);
                   								while($row1=$result1->fetch_assoc())
            						            {
            						                $c_gallery_id=$row1["college_gallery_id"];
            						                $c_gallery_desc=$row1["college_gallery_desc"];
            						                echo '<option  value="'.$c_gallery_id.'">'.$c_gallery_desc.'</option> ';
            						            }
                                                 ?>								
											</select>
										</div>

                                     <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">   
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">Event Description</label>
											<textarea class="form-control summernote" placeholder="Event Description" id="college_event_desc" name="college_event_desc"></textarea>
										</div>
                                        
                                       <div class="col-md-6 inputGroupContainer">
                                            <label class="col-md-4">Status</label>
                                            <div class="col-md-2">
                                           <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="college_event_status" name="college_event_status" type="checkbox" value="1"></div>
                                        </div>
                                        </div>
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>	
				</div>
				<div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--New Record Inserted--</h4></center></div>
			</section>
		</aside>

    
	</div>
  
	<!-- <div style="background: red ; height: 30px;"></div> -->
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo BASE_URL;?>assets/js/AdminLTE/app.js" type="text/javascript"></script>

  <script>
  $( "#col_id" ).change(function() {
   $("#colSub").submit();
  //alert("ss");

});    
  </script>
<script>
  $( function() {
    $( "#college_event_date" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
	//CKEDITOR.replace( 'college_event_desc' );
   
  </script>

<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college_event_Action.php?table_name=suc_college_events",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          //alert(data);
          if(data==1){
            $('#success').show();
            setTimeout("location.href = 'college-event.php'",2000);
        }
        else{
          alert("error");
        }
        
        }
      });
      
      
    });
  });
</script>