<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
 $k=rtrim($k,', ');
 $v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];

$_FILES['uni_image_path']['name'];
 
if(!empty(array_filter($_FILES['uni_image_path']['name']))){

        foreach($_FILES['uni_image_path']['name'] as $key=>$val){
        	 $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
			if ($conn->query($sql) == TRUE) {
				 $last_id = $conn->insert_id;
			  // echo "success";
			} else {
			     // "Error: " . $sql . "<br>" . $conn->error;
				echo "error";
			}
			 $allowedExts = array("gif", "jpeg", "jpg", "png");
		    //$extension = end(explode(".", $_FILES["uni_image_path"]["name"]));
		    chdir('../gallery/university');
		     $currentDir = getcwd();
		    $uploadDirectory = "/";
		    $errors = []; // Store all foreseen and unforseen errors here
		    $uni_name= $_REQUEST["uni_name"].'_';
		    $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
		  	 $fileName = $_FILES['uni_image_path']['name'][$key];
		    $fileSize = $_FILES['uni_image_path']['size'][$key];
		    $fileTmpName  = $_FILES['uni_image_path']['tmp_name'][$key];
		    $fileType = $_FILES['uni_image_path']['type'][$key];
		    $fileExtension = strtolower(end(explode('.',$fileName)));
		    $fn=$uni_name.$last_id.'.'.$fileExtension;
		    $uploadPath =$currentDir. $uploadDirectory . $fn;

		    if (! in_array($fileExtension,$fileExtensions)) {
		            $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
		        }

		        if ($fileSize > 2000000) {
		            $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
		        }

		        if (empty($errors)) {
		            $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
		           
		            if ($didUpload) {
		                //echo "The file " . basename($fileName) . " has been uploaded";
		                 
		                 //include('../../../connection/dbconnect.php');
		                 $sql1="UPDATE $tbl_name SET uni_image_path='$fn' WHERE uni_id='$last_id'";
		                  $result=$conn->query($sql1);
		                //echo 1;
		            } else {
		                echo "An error occurred somewhere. Try again or contact the admin";
		            }
		        } else {
		            foreach ($errors as $error) {
		                echo $error . "These are the errors" . "\n";
		            }
		        }
			             
		}
		echo 1;
         
    }
    else
    {
    	echo "else";
    }
    
?>
