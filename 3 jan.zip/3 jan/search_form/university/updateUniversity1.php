

<?php 
$date = date('Y-m-d H:i:s');
$aictestatus=$_REQUEST["uni_aicte_approved"];
$codeflag=$_REQUEST["uni_code_flag"];
$minoritytype=$_REQUEST["uni_minority_type"];
$ugcstatus=$_REQUEST["uni_ucg_status"];
$aiustatus=$_REQUEST["uni_aiu_status"];
 $college_status=$_REQUEST["uni_status"];
$tbl_name=$_REQUEST["table_name"];
$suc_id=$_REQUEST["location_id"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", uni_status='0' "; 
}
if($aiustatus==1){
}
else
{
	$k.= ", uni_aiu_status='0' "; 
}
if($ugcstatus==1){
}
else
{
	$k.= ", uni_ucg_status='0' "; 
}
if($aictestatus==1){
}
else
{
	$k.= ", uni_aicte_approved='0' "; 
}
if($codeflag==1){
}
else
{
	$k.= ", uni_code_flag='0' "; 
}
if($minoritytype==1){
}
else
{
	$k.= ", uni_minority_type='0' "; 
}


include("../../../../connection/dbconnect.php");
 $sql="update ".$tbl_name." set ".$k." where uni_id=".$suc_id;
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>