 
<?php
 session_start ();
	 $email=$_SESSION['ademail'];?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
        
			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-12">
						<!-- general form elements -->
						<form id="frmSubmiit" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
							<div class="box-body">
								<div class="row">
									<div class="col-xs-12">
                                    <input id="created_by" name="created_by"  value="<?php echo $email; ?>" type="hidden">
                                   <input id="id03" name="college_id"  value="" type="hhidden">
                                    <input type="hidden" name="created_dt" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>">
										
                                        <div class="form-group col-xs-12">
											<label for="cat_Description">College Awards</label>
											<textarea class="form-control summernote" placeholder="College Awards" id="college_awards" name="college_awards"></textarea>
										</div>
                                        	
										<div class="form-group col-xs-12"> 
											<label for="cat_Description">College Alumina</label>
											<textarea class="form-control summernote" placeholder="College Alumina" id="college_alumina" name="college_alumina"></textarea>
										</div>
                                        <div class="form-group col-xs-12"> 
											<label for="cat_Description">College Collaboration</label>
											<textarea class="form-control summernote" placeholder="College Collaboration" id="college_collaboration" name="college_collaboration"></textarea>
										</div>
                                    	
									</div>
								 </div>
							</div>
							<div class="box-footer clearfix">	
								<div class="col-xs-12">	
									<div class="col-xs-12 pull-right">
										<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
									</div>
								</div>
							</div>
						</form>
					</div>	
				</div>
				<div id ="success1"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--New Record Inserted--</h4></center></div>
				<div id ="error1"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: red; width: 100%;font-size: 20px; color: red;">--Something wrong..please check data and enter again--</h4></center></div>
			</section>
		</div>
  
	<!-- <div style="background: red ; height: 30px;"></div> -->

<script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
  } );
  </script>
  <script>
	//CKEDITOR.replace( 'college_awards' );
    //CKEDITOR.replace( 'college_alumina' );
    //CKEDITOR.replace( 'college_collaboration' );
  </script>

<script>
    $(document).ready(function(){
      $("#frmSubmiit").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"college-other-details/college_other_details_Action.php?table_name=suc_college_other_details",
        method:"POST",
        //data: $('#frmSubmiit').serialize(),
        data: new FormData(this),
        contentType: false,       // The content type used when sending data to the server.
        cache: false,             // To unable request pages to be cached
        processData:false, 
        success:function(data)
        {
         // alert(data);
          if(data==1){
            $('#success1').fadeIn().delay(2000).fadeOut();
            //setTimeout("location.href = 'college.php'",2000);
        }
        else
        	$('#error1').fadeIn().delay(2000).fadeOut();
        	
        
        }
      });
      
      
    });
  });
</script>