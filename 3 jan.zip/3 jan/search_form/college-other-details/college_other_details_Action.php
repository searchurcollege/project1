
<?php
include("../../../../connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
$k=rtrim($k,', ');
$v=rtrim($v,', ');
$tbl_name=$_REQUEST["table_name"];
$college_id= $_REQUEST["college_id"].'_';

$sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
if ($conn->query($sql) == TRUE) {
     //$last_id = $conn->insert_id;
   echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
    echo "error";
}


?>
