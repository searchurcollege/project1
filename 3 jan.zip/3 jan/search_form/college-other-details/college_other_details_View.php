
 <div class="wrapper row-offcanvas row-offcanvas-left">

        

			<section class="content">

				<div class="row">

					<!-- left column -->

					<div class="col-md-12">

						<div class="box-body">																					

							<table class="table table-bordered table-striped table-hover">.

								<thead>

									<tr>

										<th></th>

										<th>College Name</th>
										<th>College Placement Detail</th>

										

										
										<th>Action</th>

									</tr>

								</thead>

								<tbody>

									<!--- **************** Select query to display all Category Active or In Active ********************************-->

									<?php

										 $stm="SELECT  college_placement_details,  college_id FROM suc_college_other_details ORDER BY id ";

										if ($stmt = $myconn->prepare($stm)) 

										{

											//$stmt->bind_param('i', $status);

											$stmt->execute();

											$stmt->store_result();

											$stmt->bind_result($college_placement_details,  $college_id);

											$sn=1;

											while ($stmt->fetch()>0) {

										?>									

											<tr>

												<td><?php echo $sn++;?></td>
												<?php   $unisql="SELECT college_name  from suc_college where college_id='$college_id'";
												$result=$myconn->query($unisql);
												while ($row=$result->fetch_assoc()){
									              echo "<td>".$row["college_name"]."</td>";
												}
												?>

												<td><?php echo $college_placement_details;?></td>
												
												<td>

													

													<form name="formEdit" action="college-other-details/college_other_details_Edit.php?id=<?php echo $college_id; ?>" method="post" style="float:left; margin-right:5px;">

														<button type="submit" name="editCategory" id="editCategory" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></button> 

														

													</form>

													<?php

														if(!empty($_SESSION['special_permission'])){

													?>

															<button type="button"  data-id="<?php echo $uni_id; ?>" class="btn btn-danger btn-sm" onclick="xyzx(<?php echo $college_id;?>)"data-toggle="modal" data-target="#deleteRecord1"><i class="fa fa-trash-o"></i></button>
															<!-- <button type="button"  class="btn btn-danger btn-sm" onclick="window.location.href='https://www.searchurcollege.com/exam/admin/search/university/deleteUniRec.php?id=<?php //echo $uni_id; ?>'"><i class="fa fa-trash-o"></i></button>	 -->															

													<?php

														}

													?>	

												</td>

											</tr>

<?php

											}

										}

?>										
<div id="failure" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: red; width: 30%; color: ">ERROR....</h4> </center></div>
<div id="sucess1" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Deleted....</h4> </center></div>

								</tbody>

							</table>

						</div><!-- /.box-body -->													

					</div>

				</div>

			</section>

		

	</div>



	<div id="deleteRecord1" class="modal fade" role="dialog">

		<div class="modal-dialog" style="width:30%">

			<!-- Modal content-->

			<div class="modal-content">

				<div class="modal-header" style="background:#3c8dbc; color:#fff;">

					<button type="button" class="close" data-dismiss="modal">&times;</button>

					<h4 class="modal-title"><b>Delete Placement Infomation</b></h4>

				</div>

				<form name="formDeleteModal" id="formDeleteRecord" method="post" action="">

					<div class="modal-body text-center">

						<p><h5>You are going to Delete Placement Information .</h5></p>

						<h5>

						Do you realy want to <span class="label label-danger" id="stDel"></span></h5>

						<input type="hhidden" name="collgeRecord1" id="collgeRecord1" />

					</div>

					<div class="modal-footer" style="background:#3c8dbc; color:#fff;">

						<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>

						<button type="button" id="btnDleterecord1" name="btnDleterecord1" class="btn btn-primary" data-dismiss="modal">Yes</button>

					</div>

				</form>

			</div>

		</div>

	</div>


	<script>

			$('#btnDleterecord1').click(function(){
				//alert("model");
				var collgeRecord1=$("#collgeRecord1").val();
				alert(collgeRecord);
				$.ajax({

					type: "POST",

					url: "delete_Action.php?table_name=suc_college_other_details&cond_id=id&collegeRecord="+collgeRecord1,

					// data: $('#formDeleteModal').serialize(),

					success: function(response) {
						alert(response);
						if(response==1){
						//alert(response);
						$("#deleteRecord1").modal('hide');
						$('#sucess1').fadeIn().delay(1000).fadeOut();
						
						 setTimeout("location.href = 'college-dashboard-view.php'",2000);
						 // location.reload(); 
						}
						else {
							$('#failure').show();
							setTimeout("location.href = 'college-dashboard-view.php'",2000);
						}

					},

				});

				return false;

			});

		</script>
		<script type="text/javascript">

			$('#DeleteModel').on('show.bs.modal', function(event){

				var btnDelete = $(event.relatedTarget);

					 

				var categoryId = btnDelete.data('id');

				if(categoryId!=0){$("#stDel").text("Delete ?");}

				

				document.getElementById("examCatID").value = categoryId;

								

			});
			function xyzx($x){
				$("#collgeRecord1").val($x);
			}

		</script>