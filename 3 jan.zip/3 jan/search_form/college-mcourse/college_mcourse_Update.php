<?php 
//$date = date('Y-m-d H:i:s');
 $course_status=$_REQUEST["course_status"];
 $table_name=$_REQUEST["table_name"];
$course_id=$_REQUEST["course_id"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($course_status==1){
}
else
{
	$k.= ", course_status='0' "; 
}




include("../../../../connection/dbconnect.php");
   $sql="update ".$table_name." set ".$k." where course_id=".$course_id;
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>