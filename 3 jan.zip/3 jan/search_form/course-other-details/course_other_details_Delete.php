<?php
  $a=$_REQUEST['collegeRecord'];
  $b=$_REQUEST['courseRecord'];
 include("../../../../connection/dbconnect.php");
     $sql="DELETE FROM suc_course_other_details WHERE college_id='$a' and course_id='$b' ";
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>