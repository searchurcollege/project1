<?php 
//echo "hello";
include("../../../../connection/dbconnect.php");
$college_id=$_REQUEST['college_id'];
$course_id=$_REQUEST['course_id'];
 $ssql="SELECT * from suc_course_other_details where college_id='$college_id' and course_id ='$course_id'";
$rslt=$conn->query($ssql);
       
            while($rw=$rslt->fetch_assoc())
            {
               $c_id=$rw["college_id"];
               $cou_id=$rw["course_id"];
                $c_place_details=$rw["course_placement_details"];
                $c_place_high=$rw["course_highest_placementmet"];
               $c_place_avg=$rw["course_average_placement"];
               $c_place_low=$rw["course_lowest_placement"];
               $c_place_top=$rw["course_top_recruiters"];
               // $c_place_top_logo=$rw["course_top_recruiters_logo_path"];
                
            }
        $sql="SELECT college_name from suc_college where college_id=$c_id;";
      $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
            {
                $c_college_name=$row["college_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
        $sql="SELECT college_course_name from suc_college_courses where college_course_id=$cou_id;";
      $result=$conn->query($sql);
        while($row=$result->fetch_assoc())
            {
                $c_course_name=$row["college_course_name"];
             //  echo '<option  value="'.$id'">'.$lname.'</option>';
              
        }
?>

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <!-- <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
 <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<?php
 session_start ();
   $email=$_SESSION['ademail'];?>
<?php include_once '../../includes/header.php';?>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. Contains the navbar and content of the page -->
    <?php include_once '../../includes/left_sidebar1.php';?>
    <!-- left column -->
    <aside class="right-side">  
      <section class="content-header">              
        <h4><?php echo $c_college_name; ?>
          <span class="label label-danger" id="validateError"></span> 
          <a href="<?php echo BASE_URL;?>search/course-other-details/course_other_details_View.php" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
        </h4>     
        <h4><?php echo "(<b>".$c_course_name."<b>)"; ?>
          
        </h4>         
      </section>
      <section class="content">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <form id="frmSubmi" class="well" aaction="https://www.searchurcollege.com/exam/admin/search/college/colAction.php" method="POST">
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-12">
                                   
                        
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Placement Details</label>
                      <input type="text"  class="form-control" name="course_placement_details" id="course_placement_details" value="<?php echo $c_place_details; ?>" rrequired />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Highest Placementmet</label>
                      <input type="text" class="form-control" name="course_highest_placementmet" id="course_highest_placementmet" value="<?php echo $c_place_high; ?>" rrequired />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Average Placement</label>
                      <input type="text"  class="form-control" name="course_average_placement" id="course_average_placement" value="<?php echo $c_place_avg; ?>" rrequired />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Lowest Placement</label>
                      <input type="text"  class="form-control" name="course_lowest_placement" id="course_lowest_placement" value="<?php echo $c_place_low; ?>" rrequired />
                    </div>
                                        <div class="form-group col-xs-4">
                      <label for="catName">College Top Recruiters</label>
                      <input type="text"  class="form-control" name="course_top_recruiters" id="course_top_recruiters" value="<?php echo $c_place_top; ?>" rrequired />
                    </div>
                                        
                                        
                                      
                  </div>
                 </div>
              </div>
              <div class="box-footer clearfix"> 
                <div class="col-xs-12"> 
                  <div class="col-xs-12 pull-right">
                    <button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
                  </div>
                </div>
              </div>
            </form>
              
          </div>
          
        </div>
        <div id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Updated</h4></center></div>
      </section>
    </aside>

    
  </div>
  
  <!-- <div style="background: red ; height: 30px;"></div> -->
<?php //include_once '../includes/footer.php';?>


<!--   <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script> -->
<script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      }
      $.ajax({
        url:"course_other_details_Update.php?table_name=suc_course_other_details&college_id=<?php echo $college_id; ?>&course_id=<?php echo $course_id; ?>",
        method:"POST",
        data: $('#frmSubmi').serialize(),
        success:function(data)
        {
          //alert(data);
          if(data==1){
            $('#success').fadeIn().delay(1000).fadeOut();
            setTimeout("location.href = 'course_other_details_View.php'",2000);

            
        }
        }
      });
      
      
    });
  });
</script>