<?php
  $a=$_REQUEST['collegeRecord'];
  $b=$_REQUEST['facilityRecord'];
  $table_name=$_REQUEST['table_name'];
 include("../../../../connection/dbconnect.php");
 $sql="DELETE FROM $table_name WHERE facility_id='$b' and college_id= '$a' ";
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>