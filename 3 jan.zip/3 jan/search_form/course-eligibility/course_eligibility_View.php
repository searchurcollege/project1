 <?php include_once '../../includes/header.php';?> 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <div class="wrapper row-offcanvas row-offcanvas-left">

        <!-- Left side column. Contains the navbar and content of the page -->

		<?php include_once '../../includes/left_sidebar1.php';
		$tbl="suc_college_course_eligibility";
		?>

		<!-- left column -->

		<aside class="right-side">  

			<section class="content-header">

				<h4>View Eligibility List   

					<span class="label label-danger" id="validateError"></span> 

					<a href="<?php echo BASE_URL;?>dashboard" class="btn btn-warning btn-sm pull-right"><i class="fa fa-reply"></i> Back</a>
                    <button type="button" class="btn btn-info btn-sm pull-right" data-toggle="modal" data-target="#stream" style="margin-right: 20px;"><i class="fa fa-plus"></i> Stream</button>

				</h4>

			</section>

			<section class="content">

				<div class="row">

					<!-- left column -->

					<div class="col-md-12">

						<div class="box-body">																					

							<table class="table table-bordered table-striped table-hover">.

								<thead>

									<tr>

										<th></th>
										<th>College Name</th>
										<th>course Name</th>
										<th>Action</th>

									</tr>

								</thead>

								<tbody>

									<!--- **************** Select query to display all Category Active or In Active ********************************-->

									<?php

										 $stm="SELECT cc_eligibility_id, college_course_id FROM $tbl  ORDER BY cc_eligibility_id DESC";

										if ($stmt = $myconn->prepare($stm)) 

										{

											//$stmt->bind_param('i', $status);

											$stmt->execute();

											$stmt->store_result();

											$stmt->bind_result($college_eligibility_id,$college_course_id);

											$sn=1;

											while ($stmt->fetch()>0) {

										?>									

											<tr>

												<td><?php echo $sn++;?></td>
												<td><?php   $unisql="select a.college_name from suc_college a INNER JOIN suc_college_courses b on a.college_id= b.college_id where b.college_course_id=".$college_course_id;
												$result=$myconn->query($unisql);
												while ($row=$result->fetch_assoc()){
									              echo $row["college_name"];
												}
										?>     
									</td>
												<?php   $unisql="SELECT college_course_name from suc_college_courses where college_course_id='$college_course_id'";
												$result=$myconn->query($unisql);
												while ($row=$result->fetch_assoc()){
									              echo "<td>".$row["college_course_name"]."</td>";
												}
										?>     

												

												<td>

													

													<form name="formEdit" action="course_eligibility_Edit.php?id=<?php echo $college_eligibility_id; ?>&course_id=<?php echo $college_course_id; ?>" method="post" style="float:left; margin-right:5px;">

														<button type="submit" name="editCategory" id="editCategory" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></button> 															

													</form>

													<?php

														if(!empty($_SESSION['special_permission'])){

													?>

															<button type="button"  data-id="<?php echo $uni_id; ?>" class="btn btn-danger btn-sm" onclick="xyz(<?php echo 	$college_eligibility_id.",".$college_course_id;?>)"data-toggle="modal" data-target="#deleteRecord"><i class="fa fa-trash-o"></i></button>
															<!-- <button type="button"  class="btn btn-danger btn-sm" onclick="window.location.href='https://www.searchurcollege.com/exam/admin/search/university/deleteUniRec.php?id=<?php //echo $uni_id; ?>'"><i class="fa fa-trash-o"></i></button>	 -->															

													<?php

														}

													?>	

												</td>

											</tr>

<?php

											}

										}

?>										
<div id="failure" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: red; width: 30%; color: ">ERROR....</h4> </center></div>
<div id="sucess" style="bbackground: green; height: 30px; display: none;"> <center><h4 align="center" style="bbackground: green; width: 30%; color: green;">Record Deleted....</h4> </center></div>

								</tbody>

							</table>

						</div><!-- /.box-body -->													

					</div>

				</div>

			</section>

		</aside>

	</div>



	<div id="deleteRecord" class="modal fade" role="dialog">

		<div class="modal-dialog" style="width:30%">

			<!-- Modal content-->

			<div class="modal-content">

				<div class="modal-header" style="background:#3c8dbc; color:#fff;">

					<button type="button" class="close" data-dismiss="modal">&times;</button>

					<h4 class="modal-title"><b>Delete Course Eligibility </b></h4>

				</div>

				<form name="formDeleteModal" id="formDeleteRecord" method="post" action="">

					<div class="modal-body text-center">

						<p><h5>You are going to Delete Course Category .</h5></p>

						<h5>

						Do you realy want to <span class="label label-danger" id="stDel"></span></h5>

						<input type="hidden" name="collgeRecord" id="collegeRecord" />
						<input type="hidden" name="courseRecord" id="courseRecord" />

					</div>

					<div class="modal-footer" style="background:#3c8dbc; color:#fff;">

						<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>

						<button type="button" id="btnDleterecord" name="btnDleterecord" class="btn btn-primary" data-dismiss="modal">Yes</button>

					</div>

				</form>

			</div>

		</div>

	</div>


	<script>

			$('#btnDleterecord').click(function(){
				//alert("model");
				var collegeRecord=$("#collegeRecord").val();
				var courseRecord=$("#courseRecord").val();
				//alert(collegeRecord);
				$.ajax({

					type: "POST",

					url: "course_eligibility_Delete.php?courseRecord="+courseRecord+"&collegeRecord="+collegeRecord,

					// data: $('#formDeleteModal').serialize(),

					success: function(response) {
						//alert(response);
						if(response=="success"){
						//alert(response);
						$("#deleteRecord").modal('hide');
						$('#sucess').show();
						
						 setTimeout("location.href = 'course_eligibility_View.php'",2000);
						 // location.reload(); 
						}
						else {
							$('#failure').show();
							setTimeout("location.href = 'course_eligibility_View.php'",2000);
						}

					},

				});

				return false;

			});

		</script>
		<script type="text/javascript">

			$('#DeleteModel').on('show.bs.modal', function(event){

				var btnDelete = $(event.relatedTarget);

					 

				var categoryId = btnDelete.data('id');

				if(categoryId!=0){$("#stDel").text("Delete ?");}

				

				document.getElementById("examCatID").value = categoryId;

								

			});
			function xyz(x,y){
				$("#collegeRecord").val(x);
				$("#courseRecord").val(y);
			}

		</script>