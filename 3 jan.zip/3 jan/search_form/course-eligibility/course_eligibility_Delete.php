<?php
  $a=$_REQUEST['collegeRecord'];
  $b=$_REQUEST['courseRecord'];
 include("../../../../connection/dbconnect.php");
    $sql="DELETE FROM suc_college_course_eligibility WHERE cc_eligibility_id='$a' and college_course_id='$b' ";
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>