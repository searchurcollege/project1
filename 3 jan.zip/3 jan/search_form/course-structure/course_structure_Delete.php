<?php
  $a=$_REQUEST['semRecord'];
  $b=$_REQUEST['courseRecord'];
  $c=$_REQUEST['subRecord'];
 include("../../../../connection/dbconnect.php");
    $sql="DELETE FROM suc_college_course_structure WHERE cc_semester_id='$a' and college_course_id='$b' and cc_semester_subject='$c' ";
if ($conn->query($sql) == TRUE) {
    echo "success";
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo "error";
}
?>