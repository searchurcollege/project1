<?php 
$date = date('Y-m-d H:i:s');
 $college_status=$_REQUEST["cc_semester_subject_status"];
$tbl_name=$_REQUEST["table_name"];
$sem_id=$_REQUEST["sem_id"];
$course_id=$_REQUEST["course_id"];
$subject=$_REQUEST["subject"];

$k="";
foreach ($_POST as $key => $value) {
    $k.=$key."='".$value."', ";
}
 $k=rtrim($k,', ');
if($college_status==1){
}
else
{
	$k.= ", cc_semester_subject_status='0' "; 
}

include("../../../../connection/dbconnect.php");
 $sql="update ".$tbl_name." set ".$k." where cc_semester_id=".$sem_id." and college_course_id=".$course_id." and cc_semester_subject='".$subject."'";
if ($conn->query($sql) == TRUE) {
    echo 1;
} else {
     // "Error: " . $sql . "<br>" . $conn->error;
	echo 0;
}
?>