
<link rel="stylesheet" type="text/css" href="https://searchurcollege.com/exam/admin/assets/css/bootstrap.min.css">

<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<?php 
include('connection/dbconnect.php');
$email=$_REQUEST["email"];
$name=$_REQUEST["name"];
$contact=$_REQUEST["contact"];
?>

<div class="text-right" style="padding: 20px;">
    <a href="https://www.searchurcollege.com/checkUser.php"><button class="btn btn-warning btn-sm">Back</button></a>
    <a href="https://www.searchurcollege.com/check2.php"><button  class="btn btn-info btn-sm">Dashboard</button></a>
</div>
<div class="col-md-2"></div>
<div class="col-md-8 scrollbar style-4" id="main-content" style="padding-bottom: 0px!important;">
<?php echo '<h4><strong>'.$name.'</strong> ('.$contact.')</h4>';?>

                                 <table class="table table-hover" cellspacing="0" width="100%">
									<thead class="bg-red">
										<tr style="background: skyblue;">
										<th><center>Dated</center></th>	
										<th>Exam Name</th>
										<th>No. of Attemptes</th>
										
									<!--	<th>Marks</th>
										<th>Result</th> -->
                                        </tr>
									</thead>
									<tbody>
								<?php
									//*********************************************************************************************
									// 	#: Get Recent Exam Status
									//*********************************************************************************************

       	                                
										
                                        //$userExm="SELECT count(ue.id),  ue.user_exam_id, ue.total_no_of_ques, ue.time_duration, ue .total_marks, ue.pass_marks, ue.total_attempt, ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,e.exam_exercise_id, e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id='$email' ORDER BY ue.created_at DESC";
                                        $userExm="SELECT count(ue.id),  ue.user_exam_id,e.exam_exercise_id, e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id='$email'  GROUP BY user_exam_id ORDER BY ue.created_at DESC";
                                        
                                        if ($userExm = $conn->prepare($userExm)) 
										{
										 # echo "jscj";
											$c=0;
                                            $userExm->execute();
											$userExm->store_result();
											$userExm->bind_result($id,$user_exam_id, $exam_exercise_id ,$exam_name, $exam_id, $date, $code);
											while($userExm->fetch()){
        										
                                                $date=date('d-M-Y H:i',strtotime($date));
												if(empty($exam_name)){
												echo '<tr>
														<td colspan="10">	
															<div class="callout callout-info">
																<h4>No exams have been taken at the moment !</h4>
															</div>
														</td>
													</tr>';
												}
												else{
												   
								?>
													<tr>
														<td align="center"><?php echo $date;?></td>
														
														<td>
															<?php
															$query="select exam_exercise_name from cat03_exam_exercise where exam_exercise_id='$exam_exercise_id'";
																$result2=$conn->query($query);
												                while($row2=$result2->fetch_assoc())
												                    echo $row2["exam_exercise_name"]." (".$exam_name.")";

															?>
														</td>
														
														<td align="center"><?php echo $id;?></td>
													
														
														
													</tr>
								<?php
												}
                                                $c=$c+$id;
											}
                                            echo '<tr><td></td><td></td><td align="center"><b>'.$c.'</b></td></tr>';
										}
								?>
									</tbody>
									
								</table>


									
                            </div>
