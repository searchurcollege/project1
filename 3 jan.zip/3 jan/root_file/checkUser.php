<?php
    session_start();
    if($_SESSION['login']=='N')
    {
        echo '<script>';
        echo 'window.location.replace("https://www.searchurcollege.com/check.php")';
        echo '</script>';
        die();
    }
    include('connection/dbconnect.php');
   // include ('connection/header.php');

?>

<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="https:////cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"/>

<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<style>
    td {border: 1px dotted gray;}

    .checkbox label:after {
      content: '';
      display: table;
      clear: both;
    }
    
    .checkbox .cr {
      position: relative;
      display: inline-block;
      border: 1px solid #a9a9a9;
      border-radius: .25em;
      width: 1.3em;
      height: 1.3em;
      float: left;
      margin-right: .5em;
    }
    
    .checkbox .cr .cr-icon {
      position: absolute;
      font-size: .8em;
      line-height: 0;
      top: 50%;
      left: 15%;
    }
    
    .checkbox label input[type="checkbox"] {
      display: none;
    }
    
    .checkbox label input[type="checkbox"]+.cr>.cr-icon {
      opacity: 0;
    }
    
    .checkbox label input[type="checkbox"]:checked+.cr>.cr-icon {
      opacity: 1;
    }
    
    .checkbox label input[type="checkbox"]:disabled+.cr {
      opacity: .5;
    }

</style>
<head><title>USERS</title></head>
<body style="font-family: tahoma;">
<div class="text-right" style="margin-bottom: 20px;">
    <button class="btn btn-danger btn-sm" sstyle="position: absolute;" onclick="myFunction()">Delete</button>
    <a href="https://www.searchurcollege.com/check2.php"><button  class="btn btn-info btn-sm">Dashboard</button></a>
</div>
<form id="delform" action="deleteUser.php" method="POST">
<table id="example" style="margin-top: 40px;" class="table table-bordered table-striped table-hover" width="100%">
        <thead>
            <tr style="background: orange;">
                <th width="3%">Select Multi</th>
                <!-- <th width="13%">Registered on</th> -->
                <th>Name</th>
                <th>Email</th>
                <th>Premium</th>
                <th>Phone</th>
                <th>Course</th>
                <th>Current Location</th>
                <th>Preferred Location</th>
                <th>Reference</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $count=0;
            $sql="SELECT id,first_name, last_name, email, contact, course_interested, current_location, preferred_location, created_at,balance_amt ,token, reference ,reference_name FROM users ORDER BY id DESC";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
            {
                $id=$row["id"];
                $fname=$row["first_name"];
                $lname=$row["last_name"];
                $name=$fname.' '.$lname;
                $email=$row["email"];
                $contact=$row["contact"];
                $course=$row["course_interested"];
                $c_location=$row["current_location"];
                $p_location=$row["preferred_location"];
                $tkn=$row["token"];
                $date=$row["created_at"];
                $preimum=$row["balance_amt"];
                $ref=$row["reference"];
                $ref_name=$row["reference_name"];
                $sql2="SELECT COUNT(id) AS count FROM user_exam WHERE user_id='$email'";
                $result2=$conn->query($sql2);
                while($row2=$result2->fetch_assoc())
                    $count=$row2["count"];

                if($preimum>0){$p="";}
                else{$p="P (".$count.")"; }
                if($tkn!='')
                {
                    if($preimum>0)
                        echo '<tr style="background:#FAA597;">';
                    else
                        echo '<tr style="background:#60ff33;">';
                }
                else
                    echo '<tr>';

                echo '<td>
                        <div class="checkbox">
                			<label>
                                <input type="checkbox" name="chk[]" value='.$id.' class="checkbox">
                                <span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>
                			</label>
                        </div>			
                    </td>
                    
                    <td>'.$name.'</td>
                    <td>'.$email.'</td>
                    <td align="center">'.$p.'</td>
                    <td>'.$contact.'</td>
                    <td>'.$course.'</td>
                    <td>'.$c_location.'</td>
                    <td>'.$p_location.'</td>
                    <td>'.$ref.'<br><i style="color:blue;"> '.$ref_name.'</i></td>
                    <td align="center" valign="middle">';
                   if($preimum==0 && $count>0)
                   {
                        echo '<a href="detailUser.php?email='.$email.'&name='.$name.'&contact='.$contact.'" >
                        <label style="cursor: pointer; padding: 2px; " class=""><font color="blue"> View Detail </font> </label>
                    </a>';
                   } 
                echo '</td>
                </tr>';
            }
        
        ?>

        </tbody>

    </table>
    
    </form>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


<script type="text/javascript" src="jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="jquery-1.12.0.min.js"></script>
 
<script type="text/javascript" src="https://cdn.datatables.net/tabletools/2.2.4/js/dataTables.tableTools.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/tabletools/2.2.2/swf/copy_csv_xls_pdf.swf"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.print.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable({
            "pageLength": 50,
            dom: 'Bfrtip',
            buttons: ['copy','csv','excel','pdf','print'],
            "order": [[ 0, "desc" ]]
        });
    });
</script>  

<script>
function myFunction() {
    //alert(1);
    var r = confirm("Do you want to DELETE Record?");
    if (r == true)
     {
       $("#delform").submit();
    } 
    else
        alert("Record not deleted");
  //  window.location = 'checkUser.php';
    
}
</script>
