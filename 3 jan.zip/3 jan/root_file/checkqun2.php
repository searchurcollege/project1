<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
<head><title>QUESTIONS DETAIL</title></head>
<?php
    session_start();
    if($_SESSION['login']=='N')
    {
        echo '<script>';
        echo 'window.location.replace("https://www.searchurcollege.com/check.php")';
        echo '</script>';
        die();
    }
include('connection/dbconnect.php');

                                        $query11 = "SELECT DISTINCT COUNT(question_id) as total_question FROM questions";

                                        $result11 = mysqli_query($conn,$query11);

                                        $rows11 = mysqli_fetch_assoc($result11);

                                        echo "<h4 ><sstrong> Total Number of Questions=".$rows11['total_question']."</sstrong> </h4>";
                                        ?>

<a href="https://searchurcollege.com/checkqun.php">
     <button style="margin-top: 5px; padding: 5px 24px;;  popsition: absolute; transition: .5s ease;
     background-color: white;
    color: black;
    border: 2px solid #4CAF50;"  >Date wise</button>   </a>

 <a href="https://www.searchurcollege.com/check2.php"><button  style="margin-top: 5px; padding: 5px 24px;;  position: absolute; transition: .5s ease;
    top: 0%;
    right:0% ; background-color: white;
    color: black;
    border: 2px solid #555555" >Dashboard</button></a>                                    
<table id="example" class="table table-bordered table-striped table-hover" width="100%">
        <thead>
            <tr style="background: orange;">
               <th>Super cat name</th>
               <th>Main cat name</th>
               
               <th>exam name</th>
               <th>Number of questions</th>
                
                
                
            </tr>
        </thead>
<?php

    include('connection/dbconnect.php');
   // include ('connection/header.php');

    $mainSql="Select super_cat_id,main_cat_id,exam_cat_id,exam_exercise_id,exam_id, count(question_id) as c from questions GROUP by exam_id";
    $result=$conn->query($mainSql);
    while($row=$result->fetch_assoc())
            {
                $sid=$row["super_cat_id"];
                $mid=$row["main_cat_id"];
                $ecid=$row["exam_cat_id"];
                $eeid=$row["exam_exercise_id"];
                $eid=$row["exam_id"];
                $count=$row["c"];

                $lvl1sql="SELECT super_cat_name FROM cat00_super_category where super_cat_id=$sid";
                $result1=$conn->query($lvl1sql);
       
                while($row1=$result1->fetch_assoc())
                 $Sname=$row1["super_cat_name"];
                

                $lvl2sql="SELECT main_cat_name FROM cat01_main_category where main_cat_id=$mid";
                $result2=$conn->query($lvl2sql);
                while($row2=$result2->fetch_assoc())
                    $Mname=$row2["main_cat_name"];

               

                $lvl5sql="SELECT exam_name FROM exam where exam_id=$eid";
                $result5=$conn->query($lvl5sql);
                while($row5=$result5->fetch_assoc())
               
                    $Ename=$row5["exam_name"];

                ?>
               
        <tbody>
        <tr>
            <td><?php echo $Sname; ?></td>
            <td><?php echo $Mname; ?></td>
            
            <td><?php echo $Ename; ?></td>
             <td><?php echo $count; ?></td>

        </tr>
           

               

 <?php      } ?>

</tbody>
    </table>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DefaultView.Sort = "[id] ASC";
 
} );
</script> 