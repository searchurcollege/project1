
<!-- Quantcast Tag -->
<script type="text/javascript">
var _qevents = _qevents || [];

(function() {
var elem = document.createElement('script');
elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") + ".quantserve.com/quant.js";
elem.async = true;
elem.type = "text/javascript";
var scpt = document.getElementsByTagName('script')[0];
scpt.parentNode.insertBefore(elem, scpt);
})();

_qevents.push({
qacct:"p-s55hFpdVEF-hQ"
});
</script>

<noscript>
<div style="display:none;">
<img src="//pixel.quantserve.com/pixel/p-s55hFpdVEF-hQ.gif" border="0" height="1" width="1" alt="Quantcast"/>
</div>
</noscript>
<!-- End Quantcast tag -->


<script>
$(function() {
        $(this).bind("contextmenu", function(e) {
            e.preventDefault();
        });
    });
</script>

<style type="text/css">
    .footer-bottom {
    padding: 0px 0 0px;
    border-top: 1px solid #666;
    background: #1e1e1e;
   
}
.copyright-text p {
    color: #ccc;
    margin-top: 9px;
    margin-bottom: 0;
}
.social-link li {
    display: inline-block;
    margin: 0 5px;
}
.social-link li a {
    color: #ccc;
    border: 1px solid #ccc;
    width: 40px;
    height: 40px;
    line-height: 40px;
    border-radius: 50%;
    text-align: center;
    display: inline-block;
    font-size: 20px;
    transition: .5s;
    padding-top: 6px;
    padding-left: 6px;
    padding-right: 6px;
    padding-bottom: 6px;
}    

}
</style>
<link href="https://fonts.googleapis.com/css?family=Karla" rel="stylesheet"> 

<!--<link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro" rel="stylesheet"> 
 <link href="https://fonts.googleapis.com/css?family=Abel|PT+Sans+Narrow|Source+Sans+Pro" rel="stylesheet"> -->
<style> 
body{
  /*   font-family: 'Source Serif Pro', serif;
   font-family: 'PT Sans Narrow', sans-serif; */ 
   font-family: 'Karla', sans-serif;
}
</style>
<div class="clearfix" ></div>
        <div class="footer-bottom" style="margin-top: 0px;">
           <div class="container">
	      <div class="row">
		<div class="col-sm-9">							
			<p><ul class="list-inline form-control" style="background:transparent; border:#000000; padding-left: 5px; margin-top: 8px; ">
				<li><a href="https://www.searchurcollege.com/about/about-us.php"><font color="white">About Us</font></a></li>
                <li><a href="#"><font color="white">Add Colleges</font></a></li>
				<li><a href="#"><font color="white">Advertise With Us</font></a></li>
				<li><a href="#"><font color="white">College Login</font></a></li>
				<li><a href="https://www.searchurcollege.com/privacy_policy.php"><font color="white">Privacy Policy</font></a></li>
				<li><a href="https://www.searchurcollege.com/terms_conditions.php"><font color="white">Terms & Conditions</font></a></li>
				<!--<li><a href="#"><font color="white">Sitemap</font></a></li>-->
                <li><a href="https://www.searchurcollege.com/contact/contactus.php"><font color="white">Contact</font></a></li>
			   </ul></p>								
		</div>
                <div class="col-md-3 footer-ns animated fadeInRight" style="padding-top: 5px;">
                   <!--<p>
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Newsletter">
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="button"><span class="glyphicon glyphicon-envelope"></span></button>
                      </span>
                    </div><!-- /input-group -->
                 <!--</p>-->
            </div>                    
				<!-- End Col -->
		</div>
		</div>
                </div>		
<div class="footer-bottom">
<div class="container" style="padding: 0px 10px 0px 10px;">
		<div class="row" style="padding: 0px 10px 0px 10px;">
			<div class="col-sm-5">
				<div class="copyright-text" style="color: #fff!important;">
					Copyright &copy; 2018 - Searchurcollege - All Rights Reserved<br /><a href="https://www.searchurcollege.com/sitemap.xml" target="_blank">Sitemap</a>
				</div>
			</div>
							<!-- End Col -->
				<div class="col-sm-7 text-right">
                           <ul class="social-link">
				<li><font color="white">Connect with us</font></li>
				<li><a href="https://www.facebook.com/searchurcollege/" target="_blank"><font color="white"><i class="fab fa-facebook-f"></i></font></a></li>						
				<li><a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
				<!--<li><a href=""><span class="fa fa-twitter"></span></a></li>-->
			  </ul>							
				</div> <!-- End Col -->
					</div>
				</div>
</div>	
    <div class="clearfix"></div>
