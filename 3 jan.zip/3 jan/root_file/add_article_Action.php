<?php
include("connection/dbconnect.php");
$k="";
$v="";
foreach ($_POST as $key => $value) {
    //echo '$'.htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
  $k.=$key.", ";
  $v.="'".$value."', ";
}
 $k=rtrim($k,', ');
 $v=rtrim($v,', ');
$tbl_name="tbl_article";
$posted_on=$_REQUEST['posted_on'];
$fileName="";
if(!empty($_FILES['image']['name'])){
   // echo "1";
        
             $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
            if ($conn->query($sql) == TRUE) {
                 $last_id = $conn->insert_id;
              // echo "success";
            } else {
                 // "Error: " . $sql . "<br>" . $conn->error;
                echo "error";
            }
             $allowedExts = array("gif", "jpeg", "jpg", "png");
           // $extension = end(explode(".", $_FILES["facility_image_path"]["name"]));

            // $currentDir = '../'.getcwd().'/gallery/college/facility';
           // chdir('/uploads');
            $currentDir = getcwd()."/uploads";
            $uploadDirectory = "/";
            $errors = []; // Store all foreseen and unforseen errors here

            $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions
             $fileName = $_FILES['image']['name'];
            $fileSize = $_FILES['image']['size'];
            $fileTmpName  = $_FILES['image']['tmp_name'];
            $fileType = $_FILES['image']['type'];
            $fileExtension = strtolower(end(explode('.',$fileName)));
            $fn="ARTICLE".$posted_on.".".$fileExtension;
             $uploadPath =$currentDir. $uploadDirectory . $fn;

            if (! in_array($fileExtension,$fileExtensions)) {
                    $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
                }

                if ($fileSize > 5000000) {
                    $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
                }

                if (empty($errors)) {
                    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                   
                    if ($didUpload) {
                        //echo "The file " . basename($fileName) . " has been uploaded";
                         
                         //include('../../../connection/dbconnect.php');
                         $sql1="UPDATE $tbl_name SET image='$fn' WHERE id='$last_id'";
                          $result=$conn->query($sql1);
                        echo 1;
                    } else {
                        echo "An error occurred somewhere. Try again or contact the admin";
                    }
                } else {
                    foreach ($errors as $error) {
                        echo $error . "These are the errors" . "\n";
                    }
                }
                         
        
       //echo 1;
         
    }
    
?>
