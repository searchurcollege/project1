<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
@media screen and (min-width: 200px) and (max-width: 999px) {
    .srch{
        clear:both!important;
        min-width: 220px!important;
        margin-left: -160px!important;
        margin-top:0px!important;
        width: 90%!important;
        position: relative!important;
    }
    .srch2{
        background: black!important;
        padding: 0px!important;
    }
}
</style>
<div style="bbackground: red;">
    <div class="srch" style="position: absolute; margin-top: -25%;">
        <div class="srch2 col-md-12" style="padding: 20px; margin-left: 53%; bbackground: #4389C5; opacity: 0.9; width: 100%;">
            <div class="panel with-nav-tabs panel-primary">
                <div class="panel-body" style="background: white">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab1primary">
                            <?php include('search/index2.php');?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
</div>
