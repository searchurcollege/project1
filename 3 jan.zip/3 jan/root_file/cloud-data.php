<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
#row{
    margin-top: -15px;
    margin-left: 5px;
}
.list-group-item {
    
    border: 0px solid #fff!important;
}

.footer_links {
    border-top: 1px solid #000;
    padding: 5px 0 0px 20px;
}
h5{
    font-weight:bold;
    text-transform: uppercase;
    margin-left: 20px;
    
}

@media only screen and (max-width: 600px) {
    #row{
    margin-top: -5px;
    margin-left: 5px;
}
.list-group-item {
    
    border: 0px solid #fff!important;
}

.footer_links {
    border-top: 1px solid #000;
    padding: 5px 0 0px 20px;
}
}
ul {
  list-style-type: none;
}
.col-md-3
{
    padding:0px;    
}
</style>


      
<div class="clearfix"></div>
    <div class="container">
      <section class="education-advice">
        <div class="text-center free-text">
          <h3 style="margin-top: 35px; margin-bottom: 35px;font-size: 30px;"><b>POPULAR SEARCHES</b></h3>
          
        </div>
        <div class="row" id="row">
          <div class="col-md-3 col-xs-12 list-group">
                <h3><i class="fa fa-cogs"></i> <span>Engineering</span></h3>
                <hr class="footer_links" />
                  <h5>Entrance Exam</h5>
                  <?php
                    include('connection/dbconnect.php');
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Engineering' AND search_sub_category=2 LIMIT 5";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                    echo '</ul>';
                    echo'<h5>Searches</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Engineering' AND search_sub_category=1";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                        $s1=implode(' ', array_slice(explode(' ', $search_name), 0, 1))."\n";
                        $s2=implode(' ', array_slice(explode(' ', $search_name), 3, 10))."\n";
                        //echo '<li style="color:red;">N1= '.$s1.'</li>';
                        //echo '<li style="color:red;">N2= '.$s2.'</li>';
                        $mysql='SELECT DISTINCT(a.college_id) ,a.uni_id,a.college_name , a.college_image_path , a.college_desc, a.college_location_id ,a.college_type ,a.college_establishment_dt ,a.college_aicte_approved FROM suc_college a INNER JOIN suc_college_courses b ON a.college_id = b.college_id INNER JOIN suc_master_course c ON b.master_course_id = c.course_id INNER JOIN suc_master_course_category d ON d.course_cat_id = c.course_cat_id WHERE d.course_cat_name like \'%MBA/PGDM%\' and a.college_location_id IN ( 242) LIMIT 1, 5';
                        $sql2="UPDATE suc_popular_searches SET search_sql='".$mysql;//."' WHERE search_name='".$search_name."'";
                        //echo '<li>'.$sql2.'</li>';
                        $result2=$conn->query($sql2);
                    }
                    echo '</ul>';
                    echo '<h5>Colleges</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Engineering' AND search_sub_category=3";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'?sql=1">'.$search_name.'</a></li>';
                    }
                  ?>
            </div>
            <!-- end col -->
            <div class="col-md-3 col-xs-12 list-group">
                <h3><i class="fa fa-graduation-cap" aria-hidden="true"></i><span> MBA</span></h3>
                <hr class="footer_links" />
                  <h5>Entrance Exam</h5>
                  <?php
                    include('connection/dbconnect.php');
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='MBA' AND search_sub_category=2 LIMIT 5";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                    echo '</ul>';
                    echo'<h5>Searches</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='MBA' AND search_sub_category=1";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'?title='.$search_name.'">'.$search_name.'</a></li>';
                    }
                    echo '</ul>';
                    echo '<h5>Colleges</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='MBA' AND search_sub_category=3";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                  ?>
            </div>
            <!-- end col -->
            <div class="col-md-3 col-xs-12 list-group">
                <h3><i class="fa fa-stethoscope" aria-hidden="true" ></i> <span>Medical</span></h3>
                <hr class="footer_links" />
                  <h5>Entrance Exam</h5>
                  <?php
                    include('connection/dbconnect.php');
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Medical' AND search_sub_category=2 LIMIT 5";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                    echo '</ul>';
                    echo'<h5>Searches</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Medical' AND search_sub_category=1";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                    echo '</ul>';
                    echo '<h5>Colleges</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Medical' AND search_sub_category=3";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                  ?>
            </div>
            <!-- end col -->
            <div class="col-md-3 col-xs-12 list-group">
                <h3><i class="fa fa-gavel"></i> <span>LAW</span></h3>
                <hr class="footer_links" />
                  <h5>Entrance Exam</h5>
                  <?php
                    include('connection/dbconnect.php');
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Law' AND search_sub_category=2 LIMIT 5";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                    echo '</ul>';
                    echo'<h5>Searches</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Law' AND search_sub_category=1";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                    echo '</ul>';
                    echo '<h5>Colleges</h5>';
                    $sql="SELECT * FROM suc_popular_searches WHERE search_super_category='Law' AND search_sub_category=3";
                    $result=$conn->query($sql);
                    echo '<ul>';
                    while($row=$result->fetch_assoc())
                    {
                        $search_name=$row["search_name"];
                        $search_url=$row["search_url"];
                        if($search_url=='')
                            echo '<li>'.$search_name.'</li>';
                        else
                            echo '<li><a href="'.$search_url.'">'.$search_name.'</a></li>';
                    }
                  ?>
            </div>
            <!-- end col -->
            
          </div>
          
        </div>
        <!-- end row -->
        </div>
        </div>
      </section>