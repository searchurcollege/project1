<?php
include('connection/dbconnect.php');
$chk=$_REQUEST["chk"];
foreach ($chk as $v ) {
  //echo $v."<br>";
  $sql="DELETE from users where id=$v";
  $result=$conn->query($sql);
  echo '<script>
  alert("record deleted");
  </script>';
}
?>
<script>
    window.location = "checkUser.php";
</script>