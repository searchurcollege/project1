<?php
    session_start();
    if($_SESSION['login']=='N')
    {
        echo '<script>';
        echo 'window.location.replace("https://www.searchurcollege.com/check.php")';
        echo '</script>';
        die();
    }
    include('connection/dbconnect.php');
  ?>
 <html>
<head>
    <meta charset="UTF-8">
    <title>Searchurcollege</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <meta name="keywords" content="">
    <link rel="stylesheet" type="text/css" href="https://searchurcollege.com/exam/admin/assets/css/bootstrap.min.css">
    <alink rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/ionic/1.3.2/css/ionic.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://searchurcollege.com/exam/admin/assets/css/ionicons.min.css">
    <link rel="stylesheet" type="text/css" href="https://searchurcollege.com/exam/admin/assets/css/AdminLTE.css">
    <link rel="stylesheet" type="text/css" href="https://searchurcollege.com/exam/admin/assets/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <link rel="stylesheet" type="text/css" href="https://searchurcollege.com/exam/admin/assets/css/datatables/dataTables.bootstrap.css">
    <!-- include summernote css-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.1/summernote.css" rel="stylesheet">
    <!---*********************Error Dive CSS --->
        <style>
            #error {
                position:fixed; 
                bottom: 0px; 
                left: 0px; 
                width: 100%;
                z-index:9999; 
                border-radius:0px
            }
            #sucessDiv{
                position:fixed; 
                bottom: 0px; 
                left: 0px; 
                width: 100%;
                z-index:9999; 
                border-radius:0px
            }
            #successAlert {
                margin: 0 auto;
                float:right;
                background-color: #0ea564;
                color:#fff;
            }
            #danger{
                margin: 0 auto;
                float:right;
                background-color: #f44336;
                color:#fff;
            }
            #danger a{
                color:#fff;
            }           
            #danger a:hover{
                color:#fff;
            }
            .no-print{
                display:none;
            }
        </style>
<!---********************* End Error Dive CSS --->
</head>

<body class="skin-blue">
    <!-- Top header section. Contains the profile details -->
    
    <div class="wrapper row-offcanvas row-offcanvas-left">

        <!-- Left side column. Contains the navbar and content of the page -->

        <!-- Left side column. contains the logo and sidebar -->



<!-- jQuery 2.0.2 -->
<sscript src="https://www.searchurcollege.com/exam/admin/assets/js/jquery-2.1.1.js" type="text/javascript"></script>
<!-- Bootstrap -->
<sscript src="https://www.searchurcollege.com/exam/admin/assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<sscript src="https://www.searchurcollege.com/exam/admin/assets/js/AdminLTE/app.js" type="text/javascript"></script>


        <aside class="center-side">                

            <!-- Content Header (Page header) -->

            <section class="content-header">

                <h4>Dashboard <div class="pull-right"><a href="https://www.searchurcollege.com/logout.php">Logout</a></div></h4>

            </section>

            <!-- Main content -->

            <section class="content">

                <!-- Small boxes (Stat box) -->

                <div class="row">

                    
<!-- ./col -->

                    <div class="col-lg-3 col-xs-6">

                        <!-- small box -->

                        <div class="small-box bg-yellow">

                            <div class="inner">

                                <h3>

                                     <?php

                                        $query3 = "SELECT DISTINCT COUNT(user_id) as total_user FROM users";

                                        $result3 = mysqli_query($conn,$query3);

                                        $rows3 = mysqli_fetch_assoc($result3);

                                        echo $rows3['total_user'];

                                    ?>

                                </h3>

                                <p>

                                    User Registrations

                                </p>

                            </div>

                            <div class="icon">

                                <i class="ion ion-person-add" aria-hidden="true"></i>

                            </div>

                            <a href="https://searchurcollege.com/checkUser.php" class="small-box-footer">

                                More info <i class="fa fa-arrow-circle-right"></i>

                            </a>

                        </div>

                    </div><!-- ./col -->
<div class="col-lg-3 col-xs-6">

                        <!-- small box -->

                        <div class="small-box bg-aqua">

                            <div class="inner">

                                <h3>

                                    <?php

                                        $query1 = "SELECT DISTINCT COUNT(exam_id) as total_exam FROM exam";

                                        $result1 = mysqli_query($conn,$query1);

                                        $rows1 = mysqli_fetch_assoc($result1);

                                        echo $rows1['total_exam'];



                                    ?>

                                </h3>
                                <p>

                                    Total Exam

                                </p>

                                <p> 
                                    <?php

                                        $queryMbaExam = "SELECT DISTINCT COUNT(exam_id) as total_exam FROM exam where super_cat_id=1";

                                        $resultMbaExam = mysqli_query($conn,$queryMbaExam);

                                        $rowsMbaExam = mysqli_fetch_assoc($resultMbaExam);

                                        echo "MBA=".$rowsMbaExam['total_exam'];

                                        $queryErExam = "SELECT DISTINCT COUNT(exam_id) as total_exam FROM exam where super_cat_id=3";

                                        $resultErExam = mysqli_query($conn,$queryErExam);

                                        $rowsErExam = mysqli_fetch_assoc($resultErExam);

                                        echo "&nbsp  Engg=".$rowsErExam['total_exam'];

                                        $queryMedExam = "SELECT DISTINCT COUNT(exam_id) as total_exam FROM exam where super_cat_id=4";

                                        $resultMedExam = mysqli_query($conn,$queryMedExam);

                                        $rowsMedExam = mysqli_fetch_assoc($resultMedExam);

                                        echo "&nbsp  Med=".$rowsMedExam['total_exam'];

                                        $queryLawExam = "SELECT DISTINCT COUNT(exam_id) as total_exam FROM exam where super_cat_id=5";

                                        $resultLawExam = mysqli_query($conn,$queryLawExam);

                                        $rowsLawExam = mysqli_fetch_assoc($resultLawExam);

                                        echo "&nbsp  Law=".$rowsLawExam['total_exam'];

                                        $queryDesExam = "SELECT DISTINCT COUNT(exam_id) as total_exam FROM exam where super_cat_id=6";

                                        $resultDesExam = mysqli_query($conn,$queryDesExam);

                                        $rowsDesExam = mysqli_fetch_assoc($resultDesExam);

                                        //echo "&nbsp  Design=".$rowsDesExam['total_exam'];



                                    ?>

                                   

                                </p>

                            </div>

                            <div class="icon">

                                <i class="ion ion-bag" aria-hidden="true"></i>

                            </div>

                            <a href="" class="small-box-footer">

                                More info <i class="fa fa-arrow-circle-right" aria-hidden="true"></i>

                            </a>

                        </div>

                    </div><!-- ./col -->
                    <div class="col-lg-3 col-xs-6">

                        <!-- small box -->

                        <div class="small-box bg-red">

                            <div class="inner">

                                <h3>

                                    
                                    <?php

                                        $query4 = "SELECT DISTINCT COUNT(question_id) as total_question FROM questions";

                                        $result4 = mysqli_query($conn,$query4);

                                        $rows4 = mysqli_fetch_assoc($result4);

                                        echo $rows4['total_question'];



                                    ?>
                                </h3>
                                <p>

                                    Total Question

                                </p>

                                <p>
                                    <?php

                                        $querymba = "SELECT DISTINCT COUNT(question_id) as total_question1 FROM questions where super_cat_id=1";

                                        $resultmba = mysqli_query($conn,$querymba);

                                        $rowsmba = mysqli_fetch_assoc($resultmba);

                                        echo "MBA=".$rowsmba['total_question1'];

                                        $queryEr = "SELECT DISTINCT COUNT(question_id) as total_question2 FROM questions where super_cat_id=3";

                                        $resultEr = mysqli_query($conn,$queryEr);

                                        $rowsEr = mysqli_fetch_assoc($resultEr);

                                        echo "&nbsp Engg=".$rowsEr['total_question2'];

                                        $queryEr = "SELECT DISTINCT COUNT(question_id) as total_question3 FROM questions where super_cat_id=4";

                                        $resultMed = mysqli_query($conn,$queryMed);

                                        $rowsMed = mysqli_fetch_assoc($resultMed);

                                        if($rowsMed['total_question3']==Null)
                                            echo "&nbsp Med=0";
                                        else
                                            echo "&nbsp Med=".$rowsMed['total_question3'];




                                    ?>


                                </p>

                            </div>

                            <div class="icon">

                                <i class="ion ion-pie-graph"></i>

                            </div>

                            <a href="https://searchurcollege.com/checkqun2.php" class="small-box-footer">

                                More info <i class="fa fa-arrow-circle-right"></i>

                            </a>

                        </div>

                    </div><!-- ./col -->

                     <div class="col-lg-3 col-xs-6">

                        <!-- small box -->

                        <div class="small-box bg-yellow">

                            <div class="inner">

                                <h3>

                                     <?php

                                        $query3 = "SELECT DISTINCT COUNT(id) as total_user FROM tbl_article";

                                        $result3 = mysqli_query($conn,$query3);

                                        $rows3 = mysqli_fetch_assoc($result3);

                                        echo $rows3['total_user'];

                                    ?>

                                </h3>

                                <p>

                                    Total Article

                                </p>

                            </div>

                            <div class="icon">

                                <i class="ion ion-person-add" aria-hidden="true"></i>

                            </div>

                            <a href="https://searchurcollege.com/add_article.php" class="small-box-footer">

                                Add New <i class="fa fa-arrow-circle-right"></i>

                            </a>

                        </div>

                    </div><!-- ./col -->

                </div><!-- /.row -->

          <?php
           $countIIFT="SELECT link_count from link where exam_name='iift'";
            $resultiift = mysqli_query($conn,$countIIFT);
            $rowsiift = mysqli_fetch_assoc($resultiift);
            echo "<h3>IIFT =".$rowsiift['link_count'];
          ?>      
        <h3></h3>        

    <!--********************** Error Alert Div ******************************-->
        <div id="error" style="display:none;">
            <div class="alert fade in col-md-4" id="danger">
                <span class="glyphicon glyphicon-info-sign"></span>
                <strong>Error! </strong><span id="errorMessage"></span>
            </div>
        </div>
        <div id="sucessDiv" style="display:none;">
            <div class="alert fade in col-md-4" id="successAlert">
                <span class="glyphicon glyphicon-info-sign"></span>
                <strong>Success! </strong><span id="successMessage"></span>
            </div>
        </div>  
    <!--**********************End Error Alert Div ******************************-->
<div id="modal_content" class="modal fade"></div>

<!-- jQuery 2.0.2 -->
<script src="https://searchurcollege.com/exam/admin/assets/js/jquery-2.1.1.js" type="text/javascript"></script>
<!-- Bootstrap -->
<script src="https://searchurcollege.com/exam/admin/assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="https://searchurcollege.com/exam/admin/assets/js/AdminLTE/app.js" type="text/javascript"></script>
<!-- Jquery validate -->
<script src="https://searchurcollege.com/exam/admin/assets/js/jquery.validate.js" type="text/javascript"></script>
<script src="https://searchurcollege.com/exam/admin/assets/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
<!-- DATA TABES SCRIPT -->
<script src="https://searchurcollege.com/exam/admin/assets/js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="https://searchurcollege.com/exam/admin/assets/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
<!-- InputMask -->
<script src="https://searchurcollege.com/exam/admin/assets/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
<script src="https://searchurcollege.com/exam/admin/assets/js/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
<script src="https://searchurcollege.com/exam/admin/assets/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>

<!-- include summernote js-->    
    <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.1/summernote.js"></script>
    <script>
    $(document).ready(function() {
        $('.summernote').summernote({
        minHeight: 150,
          maxHeight: 450,
          toolbar: [
            ['style', ['bold', 'italic', 'underline']],
            ['font', ['strikethrough', 'superscript', 'subscript']],
            ['fontname', ['fontname']],
            ['fontsize', ['9']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'hr']],
          ],
        });
        // preselect the fontName 
        $(".note-editable").css("font-size","16px");            
        $(".note-editable").css("font-family","Arial");
    });
    </script>
<table id="example" style ="margin-top: 40px;"class="table table-bordered table-striped table-hover" width="100%">
    <thead>
            <tr style="background: skyblue;">
<?php 
$da=array();
$cremail=array();
$i=4;
$tblqury="SELECT DATE(updated_at) FROM `questions` GROUP BY DATE(updated_at) DESC LIMIT 5";
$rslt=$conn->query($tblqury);
    while($rw=$rslt->fetch_assoc())
    {
        $datee=$rw["DATE(updated_at)"];     
        
        $da[]=$datee;
        
                //$tblqury1="SELECT exam_id"
    }
    echo '<th class="text-center">NAME</th>';
    $da=array_reverse($da,true);
    foreach ($da as $aa ) {
       echo '<th class="text-center">'.$aa.'</th>';
    }

    echo "</tr> </thead> ";
    $ccrname=array();
$tblqury1="SELECT admin_first_name,email FROM admin_credential";
$rslt1=$conn->query($tblqury1);
    while($rw1=$rslt1->fetch_assoc())
    {
        $ccrname[]=$rw1["admin_first_name"];
         $cremail[]=$rw1["email"];
    }
echo "<tboday> <tr>";
$qn="-";
$i=0;
foreach ($cremail as $nemail) {
    echo '<td align="center">'.strtoupper($ccrname[$i]).'</td>'; $i++;
    foreach ($da as $aa ) {
       $fquerry="SELECT count(question_id) from questions where added_by='".$nemail."' and DATE(updated_at)='".$aa."'";
        $rsltf=$conn->query($fquerry);
        //echo "ss";
         while($rwf=$rsltf->fetch_assoc())
         {
        $qn=$rwf["count(question_id)"];
         
         }
            echo '<td align="center"> '.$qn .'</td>';
        }
    echo '</tr>';
}
    echo '</tbody> </table>';
 ?>

     <?php
            $n=array();
            $m=array();
     $sql="SELECT admin_first_name,email FROM admin_credential";
      $result=$conn->query($sql);
            while($row=$result->fetch_assoc()){
                $n[]="'".$row["admin_first_name"]."',";
                $email=$row["email"];
                $sql2="SELECT count(question_id) as c from questions where added_by='$email'  and DATE(updated_at)=CURDATE()";
                 $result2=$conn->query($sql2);

                 while($row1=$result2->fetch_assoc()){
                    $m[]=$row1["c"].",";
                 }
            }
            $a= implode($n);
            $a=rtrim($a,',');
             $b= implode($m);
             $b=rtrim($b,',');

            $a;
            //$sql1="SELECT count(question_id) from questions where added_by='admin@gmail.com'"
$abc=array();
$ab=array();
 $query="SELECT  exam_exercise_id from questions where DATE(updated_at)=CURDATE() GROUP by exam_exercise_id";
$result3=$conn->query($query);

                 while($row2=$result3->fetch_assoc()){

                    //$eid=$row2["exam_id"];

                    $eeid=$row2["exam_exercise_id"];
                  

                   $lvl5sql="SELECT exam_exercise_name FROM `cat03_exam_exercise` where exam_exercise_id=$eeid  ";
                    $result5=$conn->query($lvl5sql);

                    while($row5=$result5->fetch_assoc()){
                       $abc[]="'".$row5["exam_exercise_name"]."',"; 
                     }
                     $lvl3sql="SELECT count(question_id) as cc FROM questions where exam_exercise_id=$eeid  and DATE(updated_at)=CURDATE() ";
                    $result13=$conn->query($lvl3sql);
                    while($row13=$result13->fetch_assoc()){
                      $ab[]=$row13["cc"].","; 
                     }
                 }
                 $xyz= implode($abc);
                 $xyz=rtrim($xyz,',');
                   $xy= implode($ab);
                 $xy=rtrim($xy,',');


       


       ?>  

    <!--********************** Error Alert Div ******************************-->
  
    <!--**********************End Error Alert Div ******************************-->
<div id="modal_content" class="modal fade"></div>

<link rel="stylesheet" href="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
    <script src="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>

<div  class="col-md-6 text-center" style="padding-top: 0px; bbackground: lightblue;">
      <center>
        <div id="graphst" class="ct-chart ct-perfect-fourth" style="width: 600px; height: 400px; position: relative!!important;"></div>
    
    </center>
    </div>


    <div  class="col-md-6 text-center" style="padding-top: 0px; bbackground: lightblue;">
      <center>
        <div id="graphst1" class="ct-chart1 ct-perfect-fourth" style="width: 600px; height: 400px;"></div>
    
    </center>
    </div>
    
    <script>
    var data = {
  labels: [ <?php echo $a;?>  ],
  series: [
    [ ],
    [<?php echo $b; ?>]
  ]
};

var options = {
  seriesBarDistance: 10
};

var responsiveOptions = [
  ['screen and (max-width: 640px)', {
    seriesBarDistance: 5,
    axisX: {
      labelInterpolationFnc: function (value) {
        return value[0];
      }
    }
  }]
];

new Chartist.Bar('.ct-chart', data, options, responsiveOptions);

var data = {
  labels: [ <?php echo $xyz;?>  ],
  series: [
    [ ],
    [<?php echo $xy; ?>]
  ]
};
var options = {
  seriesBarDistance: 10
};

var responsiveOptions = [
  ['screen and (max-width: 640px)', {
    seriesBarDistance: 5,
    axisX: {
      labelInterpolationFnc: function (value) {
        return value[0];
      }
    }
  }]
];

new Chartist.Bar('.ct-chart1', data, options, responsiveOptions);


    </script>
</body>
</html>
<?php 
?>

