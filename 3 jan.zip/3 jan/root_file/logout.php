<?php
    session_start();
    $_SESSION['login']='N';
    echo '<script>';
    echo 'window.location.replace("https://www.searchurcollege.com/check.php")';
    echo '</script>';
?>