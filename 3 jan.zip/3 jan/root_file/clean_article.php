<?php
    include('connection/dbconnect.php');
    $sql="SELECT id, title FROM tbl_article" ;
    $result=$conn->query($sql);
    while($row=$result->fetch_assoc())
    {
        $id=$row['id'];
        $title=strip_tags($row['title']);
        $title=preg_replace("/&#?[a-z0-9]{2,8};/i"," ", $title);
        //html2text($title);
        echo '<br>'.$title;//$title=str_replace('&', '&amp;', $title);
        //$title=htmlentities($title, null, 'utf-8');
        //$title=str_replace("&nbsp;", " ", $title);
        //echo '<br>I='.$title;
        $sql2="UPDATE tbl_article SET title='$title' WHERE id=$id" ;
        $result2=$conn->query($sql2);
    }

function html2text($Document) {
    $Rules = array ('@<script[^>]*?>.*?</script>@si',
                    '@<[\/\!]*?[^<>]*?>@si',
                    '@([\r\n])[\s]+@',
                    '@&(quot|#34);@i',
                    '&amp;',
                    '@&(lt|#60);@i',
                    '@&(gt|#62);@i',
                    '@&(nbsp|#160);@i',
                    '@&(iexcl|#161);@i',
                    '@&(cent|#162);@i',
                    '@&(pound|#163);@i',
                    '@&(copy|#169);@i',
                    '@&(reg|#174);@i',
                    '@&#(d+);@e'
             );
    $Replace = array ('',
                      '',
                      '',
                      '',
                      '&',
                      '<',
                      '>',
                      ' ',
                      chr(161),
                      chr(162),
                      chr(163),
                      chr(169),
                      chr(174),
                      'chr()'
                );
  return preg_replace($Rules, $Replace, $Document);
}
?>