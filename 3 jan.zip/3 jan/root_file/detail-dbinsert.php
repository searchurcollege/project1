<?php
    include("../connection/dbconnect.php");
    
        if(isset($_POST['submit'])){
	
		$super_cat_id=$_POST['super_cat_id'];	
		$exam_exercise_id=$_POST['exam_exercise_id'];	
		$img=$_POST['img'];	
		$exam_id=$_POST['exam_id'];	
		$exam_full_name=$_POST['exam_full_name'];		
		$exam_level=$_POST['exam_level'];
		$exam_conducted=$_POST['exam_conducted'];
		$exam_admitcard=$_POST['exam_admitcard'];
		$exam_date=$_POST['exam_date'];
        $exam_result=$_POST['exam_result'];
		$exam_category=$_POST['exam_category'];
		$application_begin=$_POST['application_begin'];
		$application_fees=$_POST['application_fees'];
		$modeofexam=$_POST['modeofexam'];
        $exam_frequency=$_POST['exam_frequency'];
        $application_end=$_POST['application_end'];	
		$modeofpayment=$_POST['modeofpayment'];		
		$exam_format=$_POST['exam_format'];
		$exam_apply=$_POST['exam_apply'];
		$about_content=$_POST['about_content'];
		$test_content=$_POST['test_content'];
        $dates_content=$_POST['dates_content'];
		$pattern_content=$_POST['pattern_content'];
		$syllabus_content=$_POST['syllabus_content'];
		$admitcard_content=$_POST['admitcard_content'];
		$testcenter_content=$_POST['testcenter_content'];
        $result_content=$_POST['result_content'];
        $cutoff_content=$_POST['cutoff_content'];
		$applicationform_content=$_POST['applicationform_content'];
        $contact_content=$_POST['contact_content'];
        $status=$_POST['status'];
        $exam_remark=$_POST['exam_remark'];	
        
		
		//**************************** End Form field validation ****************************

		echo $stm="INSERT INTO exam_details (super_cat_id,exam_exercise_id,img,exam_id,exam_full_name,exam_level,exam_conducted,exam_admitcard,exam_date,exam_result,exam_category,application_begin,application_fees,modeofexam,exam_frequency,application_end,modeofpayment,exam_format,exam_apply,about_content,test_content,dates_content,pattern_content,syllabus_content,admitcard_content,testcenter_content,result_content,cutoff_content,applicationform_content,contact_content,status,exam_remark) VALUES ('".$super_cat_id."','".$exam_exercise_id."','".$img."','".$exam_id."','".$exam_full_name."','".$exam_level."','".$exam_conducted."','".$exam_admitcard."','".$exam_date."','".$exam_result."','".$exam_category."','".$application_begin."','".$application_fees."','".$modeofexam."','".$exam_frequency."','".$application_end."','".$modeofpayment."','".$exam_format."','".$exam_apply."','".$about_content."','".$test_content."','".$dates_content."','".$pattern_content."','".$syllabus_content."','".$admitcard_content."','".$testcenter_content."','".$result_content."','".$cutoff_content."','".$applicationform_content."', '".$contact_content."','".$status."','".$exam_remark."')";

if(mysqli_query($conn, $stm)){
    echo "<script type='text/javascript'>alert('Records inserted successfully!')</script>";
	echo "<script type='text/javascript'>window.location.href = 'detail-insert.php'</script>";
	
} else{
    echo "<script type='text/javascript'>alert('ERROR: Could not able to execute $sql!')</script>" . mysqli_error($conn);
	echo "<script type='text/javascript'>window.location.href = 'detail-insert.php'</script>";
}
}		

?>