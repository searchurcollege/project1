<head>
    <title>Searchurcollege is Online Educational Test Portal.</title>   
    <meta name="Description" content="Searchurcollege is an online educational information and practice test portal. It provide one stop solution for students that make online question banks & Test Series, course and college selection easy for students looking to pursue undergraduate (UG) and postgraduate (PG) courses in India. We are providing question banks and Test Series for entrance exam of all courses. Students seeking admission for courses like MBA, Engineering, Medical, LAW, Design, MCA etc,. "/>
    <meta name="Keywords" content="Searchurcollege, Model Question Paper, Chapterwise Set, Test Series, Education, Colleges, Universities, Institutes, Career, Career Options, Career Prospects, Engineering, MBA, MEDICAL, LAW, DESIGN, Courses, Higher Education, Forum, Community, Education Career Experts, Ask Experts, Admissions, Results, Events, Scholarships"/>
    <link href="css/bootstrap2.css" rel="stylesheet">
</head>
<html>
<head>
<?php
    include('connection/dbconnect.php');
    $useragent=$_SERVER['HTTP_USER_AGENT'];
    if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
        include('connection/header3.php');
    else
        include('connection/header1.php');
 ?>

  
  <!-- Global site tag (gtag.js) - Google Analytics -->
<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-118318912-1"></script> -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-118318912-1');
</script>
</head>
<body>
  	</script>
    
    <style media="screen">
    .scrollup {
        background: url("img/back-to-top.png") no-repeat scroll 0 0 transparent;
        position: fixed;
        cursor: pointer;
        bottom: 20px;
        display: none;
        height: 110px;
        width: 40px;
        right: 20px;
        text-indent: -9999px;
    }
    </style>

    <style>
    section.study-section {
    width: 100%;
    position: relative;
    background: #596F7C;
    height: auto;
    padding: 70px;
}

.thumbnail-section {
    display: block!important;
    width: 100%!important;
    background: #fff!important;
    margin-right: 15px!important;
    margin-left: 15px!important;
    height: auto!important;
    min-height: 245px!important;
    position: relative!important;
    padding: 0px!important;
    overflow: hidden!important;
    border: none!important;
}
@media only screen and (max-width: 600px) {
    
    #onestop{
        font-size: 18px!important;
    }
.prev1{
    margin-left: -40px!important;
 } 
  .next1{
    margin-right: -40px!important;
 }

}
.carousel-control {
    opacity: 1.5!important;
   }
 .prev1{
    margin-left: -100px;
 } 
  .next1{
    margin-right: -85px;
 }
 
 
    </style>
    
<section class="slideshow-container" style="bbackground: black">
        <div style="background: transparent; mmargin-top: 10px;">
            <h2 align="center" id="onestop" style="margin-top: 10px;">One Stop Solution for Students</h2>
        </div>

  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
  </ol>
  <div class="carousel-inner">

    <div class="carousel-item active">
      <a href="https://www.searchurcollege.com/test/test.php?id=1"><img class="d-block w-100" src="img/banner31.jpg" width="100%" alt="SearchUrCollege"></a>
      
    </div>
    <div class="carousel-item">
      <a href="https://www.searchurcollege.com/test/test.php?id=1"><img class="d-block w-100" src="img/banner11.jpg" width="100%" alt="SearchUrCollege"></a>
      
    </div>
    <div class="carousel-item">
      <a href="https://www.searchurcollege.com/test/test.php?id=1"><img class="d-block w-100" src="img/banner21.jpg" width="100%" alt="SearchUrCollege"></a>
    </div>
    <div class="carousel-item">
      <a href="https://www.searchurcollege.com/test/test.php?id=1"><img class="d-block w-100" src="img/banner3.jpg" width="100%" alt="SearchUrCollege"></a>
    </div>
    <div class="carousel-item">
      <a href="https://www.searchurcollege.com/test/test.php?id=3"><img class="d-block w-100" src="img/banner5.jpg" width="100%" alt="SearchUrCollege"></a>
    </div>
  </div>
  <?php include('mysearch2.php');?>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" onclick="event.preventDefault();" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true" style="height: 40px!important; width: 40px!important;position: absolute; left:0px;"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" onclick="event.preventDefault();" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true" style="height: 40px!important; width: 40px!important; position: absolute; right: 0px;"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
 <?php  include('ticker1.php');?> <!-- comment ticket bcoz ticker js oppos the select2 -->
	  
      <!-- end slide show banner -->
	 
	
	 
	 
	 
	 
     <div class="clearfix"></div>
    <section class="free-text">
        <div class="text-center free-text">
          <h3><i class="fas fa-edit" style="font-size: 20px;"></i> Tests</h3>
        </div>
        <div class="free-box">
          <ul class="list-unstyled list-inline">
            <li>
              <div class="inside-img">
                <div class="img text-center"></div>
                <h3>MBA</h3>
                <div class="link">
                  <ul class="list-inline list-unstyled">
                    <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=1">Question Banks</a>    
                     <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=1">Test Series/</a><a href="https://www.searchurcollege.com/test/test.php?id=1">Course</a>
                    <!--<a href="https://www.searchurcollege.com/index.php/test/stream/mocktest">Mock</a>-->
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <div class="inside-img">
                <div class="img text-center"></div>
                <h3>Engineering</h3>
                <div class="link">
                  <ul class="list-inline list-unstyled">
                   <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=3">Question Banks</a>    
                     <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=3">Practice Set/</a><a href="https://www.searchurcollege.com/test/test.php?id=3">Course</a>
                    <!--<a href="https://www.searchurcollege.com/index.php/test/stream/mocktest">Mock</a>-->
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <div class="inside-img">
                <div class="img text-center"></div>
                <h3>Law</h3>
                <div class="link">
                  <ul class="list-inline list-unstyled">
                    <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=5">Question Banks</a>    
                     <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=5">Practice Set/</a><a href="#">Course</a>
                    <!--<a href="https://www.searchurcollege.com/index.php/test/stream/mocktest">Mock</a>-->
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <div class="inside-img">
                <div class="img text-center"></div>
                <h3>Medical</h3>
                <div class="link">
                  <ul class="list-inline list-unstyled">
                    <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=4">Question Banks</a>    
                     <a class="drop" href="https://www.searchurcollege.com/test/test.php?id=4">Practice Set/</a><a href="https://www.searchurcollege.com/test/test.php?id=4">Course</a>
                    <!--<a href="https://www.searchurcollege.com/index.php/test/stream/mocktest">Mock</a>-->
                  </ul>
                </div>
              </div>
            </li>
            
          </ul>
          <div class="clearfix"></div>
        </div>
      </section>

<!------------------New Section------------------------------->

 <section class="free-text" style="background: #F4F4F4;">
        <div class="text-center free-text">
          <h3><i class="fas fa-file" style="font-size: 20px;"></i> Courses</h3>
        </div>
        <div class="free-box">
          <ul class="list-unstyled list-inline">
            <li>
              <a href="https://www.searchurcollege.com/colleges/mba-college-list-1.php"><div class="inside-img">
                <div><img alt="MBA" src="img/mba.jpg" style="width: 100%;"  /></div>
                <h3>MBA</h3>
                
              </div></a>
            </li>
            <li>
              <a href="https://www.searchurcollege.com/colleges/engineering-college-list-1.php"><div class="inside-img">
                <div><img alt="Engineering" src="img/engineering.jpg" style="width: 100%;"  /></div>
                <h3>Engineering</h3>
                
              </div></a>
            </li>
            <li>
              <a href="https://www.searchurcollege.com/colleges/law-college-list-1.php"><div class="inside-img">
                <div><img alt="LAW" src="img/law.jpg" style="width: 100%;"  /></div>
                <h3><a href="">LAW</h3>
                
              </div></a>
            </li>
            <li>
              <a href=""><div class="inside-img">
                <div><img alt="Design" src="img/design.jpg" style="width: 100%;"  /></div>
                <h3><a href="">Design</h3>
                
              </div></a>
            </li>
            <li>
              <a href="https://www.searchurcollege.com/colleges/medical-college-list-1.php"><div class="inside-img">
                <div><img alt="Medical" src="img/medical.jpg" style="width: 100%;"  /></div>
                <h3><a href="">Medical</h3>
                
              </div></a>
            </li>
            <li>
              <a href=""><div class="inside-img">
                <div><img alt="MCA" src="img/mca.jpg" style="width: 100%;"  /></div>
                <h3><a href="">MCA</h3>
                
              </div></a>
            </li>
            <li>
                <a href=""><div class="inside-img">
                
                <!--<div class="img text-center"></div>-->
                <div><img alt="Hotel Management" src="img/hotal-management.jpg" style="width: 100%;"  /></div>
                <h3><a href="">Hotel Management</h3>
                
              </div></a>
            </li>
            <li>
              <a href=""><div class="inside-img">
                <div><img alt="Media & Journalism" src="img/media.jpg" style="width: 100%;"  /></div>
                <h3><a href="">Media & Journalism</a></h3>
                
              </div>
            </li>
          </ul>
          <div class="clearfix"></div>
        </div>
      </section>

 
<!------------------------------------------------->
      <section class="exam-section">
        <div class="text-center free-text">
          <h3><i class="fas fa-file-text" style="font-size: 20px;"></i> EXAMS</h3>
        </div>
        <div class="exam-tab">
          <ul class="nav nav-pills">
            <li class="active"><a data-toggle="pill" href="#exam-one">MBA</a></li>
            <li><a data-toggle="pill" href="#exam-two">LAW</a></li>
            <li><a data-toggle="pill" href="#exam-three">Engineering</a></li>
			<li><a data-toggle="pill" href="#exam-four">Design</a></li>
			<li><a data-toggle="pill" href="#exam-five">Medical</a></li>
			<!--<li><a data-toggle="pill" href="#exam-six">Others</a></li>-->
          </ul>
          <div class="tab-content">
            <div id="exam-one" class="tab-pane fade in active"> 
              <div class="exam-circle">
                <ul class="list-unstyled list-inline">
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/cat-details.php">cat</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/mat-details.php">mat</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/cmat-details.php">cmat</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/xat-details.php">xat</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/atma-details.php">atma</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                </ul>
                <div class="clearfix"></div>
              </div>
			   <div class="view-more">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-center">
                  <a href="https://www.searchurcollege.com/exams/mba-exams.php"><button class="btn btn-primary">View More Details &nbsp; <i class="fa fa-caret-right" aria-hidden="true"></i></button></a>
                </div>
              </div>
            </div>
          </div>
              <!-- end exam circle -->
            </div>
            <div id="exam-two" class="tab-pane fade">
              <div class="exam-circle">
                <ul class="list-unstyled list-inline">
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/clat-details.php">clat</a></p>
                      </div>
                    </div>
                   <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/ailet-details.php">ailet</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/lsat-details.php">lsat</a></p>
                      </div>
                    </div>
                   <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/aclat-details.php">aclat</a></p>
                      </div>
                    </div>
                   <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/amuee-details.php">amuee</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                </ul>
                <div class="clearfix"></div>
              </div>
			   <div class="view-more">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-center">
                  <a href="https://www.searchurcollege.com/exams/law-exams.php"><button class="btn btn-primary">View More Details &nbsp; <i class="fa fa-caret-right" aria-hidden="true"></i></button></a>
                </div>
              </div>
            </div>
          </div>
              <!-- end exam circle -->
            </div>
            <div id="exam-three" class="tab-pane fade">
              <div class="exam-circle">
                <ul class="list-unstyled list-inline">
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p align="center"><a href="https://www.searchurcollege.com/exams/jeemain-details.php">jee <br>main</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p align="center"><a href="https://www.searchurcollege.com/exams/jeeadv-details.php">jee<br>Advance</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/bitsat-details.php">bitsat</a></p>
                      </div>
                    </div>
                   <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/viteee-details.php">viteee</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/srmjeee-details.php">srmjeee</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                </ul>
                <div class="clearfix"></div>
              </div>
			   <div class="view-more">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-center">
                  <a href="https://www.searchurcollege.com/exams/engineering-exams.php"><button class="btn btn-primary">View More Details &nbsp; <i class="fa fa-caret-right" aria-hidden="true"></i></button></a>
                </div>
              </div>
            </div>
          </div>
			 <!-- end exam circle -->
            </div>
            <div id="exam-four" class="tab-pane fade">
              <div class="exam-circle">
                <ul class="list-unstyled list-inline">
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/ceed-details.php">CEED</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/nidee-details.php">NIDEE</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/niftee-details.php">NIFTEE</a></p>
                      </div>
                    </div>
                   <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/uceed-details.php">UCEED</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/aicet-details.php">AICET</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                </ul>
                <div class="clearfix"></div>
              </div>
			   <div class="view-more">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-center">
                  <a href="https://www.searchurcollege.com/exams/design-exams.php"><button class="btn btn-primary">View More Details &nbsp; <i class="fa fa-caret-right" aria-hidden="true"></i></button></a>
                </div>
              </div>
            </div>
          </div>
			  
               <!-- end exam circle -->
            </div>
            <div id="exam-five" class="tab-pane fade">
              <div class="exam-circle">
                <ul class="list-unstyled list-inline">
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/aiims-details.php">AIIMS</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/neet-details.php">NEET</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/jipmer-details.php">JIPMER</a></p>
                      </div>
                    </div>
                   <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/niper-details.php">NIPER</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                  <li>
                    <div class="over-circle">
                      <div class="circle-img">
                        <p><a href="https://www.searchurcollege.com/exams/afmc-details.php">AFMC</a></p>
                      </div>
                    </div>
                    <!--<p>Exam Date</p>
                    <h3>26<span class="th">th</span>April</h3>-->
                  </li>
                </ul>
                <div class="clearfix"></div>
              </div>
			   <div class="view-more">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-center">
                  <a href="https://www.searchurcollege.com/exams/medical-exams.php"><button class="btn btn-primary">View More Details &nbsp; <i class="fa fa-caret-right" aria-hidden="true"></i></button></a>
                </div>
              </div>
            </div>
          </div>
			  
              <!-- end exam circle -->
            </div>
    
      </section>
      <!-- end exam section -->
      
      
      <div class="clearfix"></div>
      <section class="feature-collage">
        <div class="row">
          <div class="col-md-8 col-sm-8 col-xs-12">
            <div class="collage-slider">
              <div class="text-center free-text">
                <h3><i class="fas fa-info-circle" style="font-size: 20px;"></i> Important Info</h3>
              </div>
              <?php include('featured-colleges.php'); ?><!-- comment feature-colleges bcoz ticker js oppos the select2 -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="have-question">
              <div class="text-center free-text">
                <h3><i class="fas fa-question-circle" style="font-size: 20px;"></i> Have a Question ? </h3>
              </div>
              <div class="question-panel">
                <p>You have any Question <span class="color-red">*</span></p>
                <form>
                  <div class="form-group">
                    <textarea class="form-control" rows="4" id="have-question" placeholder="Need guidance on career and education?  Ask our experts" style="resize: none;"></textarea>
                  </div>
                   <a href="#" onclick="askNow();" class="btn btn-primary" style.display='block' data-toggle="modal" data-target="#id01" >Ask Now</a>
                </form>
                <img alt="Searchurcollege Ask your Question" src="img/askurquestion.png" style="max-width: 100%; heigth: 55vh;" >
              </div>
              <!-- end question panel -->
            </div>
            <!-- end have question -->
          </div>
        </div>
      </section>
      <!--start feature-college -->
      
<div class="clearfix"></div>
      <section class="education-advice">
        <div class="text-center free-text">
          <h3><i class="fas fa-hand-paper" style="font-size: 20px;"></i> Education Advice</h3>
        </div>
        <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="get-value">
              <div class="get-text">
                <p>Get proper advice for your career from experience industries professionals, faculties, alumni & exam toppers to help you make the right decision to choose your dream college.</p>
                <button class="btn btn-primary" style.display='block' data-toggle="modal" data-target="#id01" >Get Advice <i class="fa fa-caret-right" aria-hidden="true"></i></button>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="get-img">
              <div class="get-value">
                <img alt="get advice" src="img/edu-advice.png" class="img-reponsive">
              </div>
            </div>
          </div>
        </div>
        <!-- end row -->
      </section>
      <!-- end education-advice -->
<section class="collage-counter">
        <ul class="list-unstyled">
          <li>
            <div class="counter">
              <h2 class="ttimer count-title count-number" data-to="3000" data-speed="500">3000+</h2>
              <p class="count-text ">Tests</p>
            </div>
          </li> 
          <li>
            <div class="counter">
              <h2 class="ttimer count-title count-number" data-to="45000"  data-speed="500">45000+</h2>
              <p class="count-text ">Practice Question</p>
            </div>
          </li>
          <li>
            <div class="counter">
              <h2 class="ttimer count-title count-number" data-to="10000" data-speed="500">10000+</h2>
              <p class="count-text ">COlleges</p>
            </div>
          </li>
          <li>
            <div class="counter">
              <h2 class="ttimer count-title count-number" data-to="8000" data-speed="500">8000+</h2>
              <p class="count-text ">QUESTION ANSWERED</p>
            </div>
          </li>
        </ul>
      </section>
      <!-- end college counter -->
      
      <!-- start artical panel -->
      <div class="clearfix"></div>
      <section class="article-panel">
      <div class="text-center free-text">
          <h3><i class="fas fa-newspaper" style="font-size: 20px;"></i> Latest News & Articles </h3>
        </div>
        <div class="aricle-overlay">
          <div class="row">
      <?php
      $sql="SELECT id,title , image FROM `tbl_article` ORDER BY id DESC LIMIT 3" ;
      if($sql = $conn->prepare($sql)){
        $sql->execute();
        $sql->store_result();
        $sql->bind_result($id,$title,$img);
         while($sql->fetch()){
        ?>
        <div class="col-sm-4 col-md-4 col-xs-12">
              <div class="overlay-section">
                <div class="image-view">
                  <div class="news-img">
  				      <table width="100%" border="1">
                          <tr>
                            <td>
                                <img alt="searchurcollege" class="img-responsive" src="https://www.searchurcollege.com/uploads/<?php echo $img; ?>" style="min-height: 180px!important; max-height: 180px; width: 100%;" alt="articles" />
                            </td>
                          </tr>
                        </table>
                  </div>
                  <div class="news-content">
				    <font face="Arial, Helvetica, sans-serif" size="-1" color="#FF9900"><?php echo strip_tags($title)?></p>
                    <form action="article.php" method="post">  
                        <input type="hidden" name="Aid" value="<?php echo $id;?>" />
                        <button class="btn-block" type="submit" style="background: transparent; border: 0px;">
                        <h5 style="color: black;">Read More</h5></font></button>
                    </form>
                    <!--<h3>Engineering</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesettin </p>-->
                  </div>
                </div>
                <!--<div class="overlay">
                  <div class="text-bg"><button class="btn btn-primary">View Details</button></div>
                </div>-->
              </div>
            </div> 
            <?php 
      }}
      
      
       ?>
       
        
            
           
            
          </div>
        </div>
        <div class="view-more">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="text-center">
               <a href="allartical.php"><button class="btn btn-primary">Articles <i class="fa fa-caret-right" aria-hidden="true"></i></button></a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- end article panel -->
      <div class="clearfix"></div>
     
      
      
     
      
      
<style>
.ad {
   position: fixed;
   top: 50%;
   left: 50%;
   transform: translate(-50%, -50%);
   z-index :100000000;
   opacity: .9;
}
</style>
<div class="ad" onclick="hideAd(); z-index: 10;">
    <div style="right: 20px; top: 20px; position: absolute; cursor: pointer;" onclick="hideAd();">
        <!-- <img src="img/close.png" height="30" title="Close Offer"/> -->
    </div>
    <a href="#" data-toggle="modal" data-target="#register">
    <?php
        // if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
        //     echo '<img id="adimg" src="ad1.gif" width="350px" onclick="hideAd();"/>';

        // else
        //     echo '<img id="adimg" src="ad1.gif" width="900px" onclick="hideAd();"/>';
    ?>
    </a>
</div>

<?php
    include('footer.php');
?>
    <!-- <a class="scrollup">Scroll</a> -->


<script type="text/javascript"></script>
    




    <div class="clearfix"></div>
    <!-- end main section-->
    <!-- ...........custom js include here.............. -->
    <!--<script type="text/javascript" src="js/SideShow.js"></script> -->
    <!-- <script type="text/javascript" src="js/counter.js"></script> -->
    <script>
      $(document).ready(function() {
        $('#Carousel,#Carousel,#Carousel-two').carousel({
         interval: false
        });
      });
      

    //Ad Scroll after n Pixels
    $(document).scroll(function() {
      var y = $(this).scrollTop();
      if (y > 600) {
        $('.ad').fadeIn();
      } else {
        $('.ad').fadeOut();
      }
    });
    function hideAd()
    {
        $('.ad').css('z-index', '-1');
    }

    </script>
    
    
    	<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
	
	
<script>
function showUrlInDialog(url){
  var tag = $("<div></div>");
  $.ajax({
    url: url,
    success: function(data) {
      tag.html(data).dialog({modal: true}).dialog('open');
    }
  });
}

</script>



<style>
* {
  box-sizing: border-box;
}

body {
  background-color: #000000;
}

#regForm {
  background-color: #DDDDD3; 
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 40%;
  min-width: 100px;
 
 }

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

select {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
 }

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 10px 100px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}


button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}

@media only screen and (max-width: 600px) {
* {
  box-sizing: border-box;
}

body {
  background-color: #000000;
}

#regForm {
  background-color: #DDDDD3; 
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 90%;
  min-width: 100px;
 
 }

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 15px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

select {
  padding: 10px;
  width: 100%;
  font-size: 15px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
 }

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 10px 100px;
  font-size: 15px;
  font-family: Raleway;
  cursor: pointer;
}


button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
}

</style>
<div id="id01" class="modal" role="dialog">
  <div class="modal-dialog ">
    <div class="modal-content">
        <div class="modal-body">
            <div class="row row-eq-height">
        		
                
        		<div id="col2" class="col-md-12" style="background: white; padding: 0px 40px 20px 40px;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 style="color: #5D9BD0; text-align: center; margin-bottom: 10px;"><i class="fa fa-user fa-sm"></i> <b>Provide us some Basic Details</b></h3>
                    <form id="frmAsknow" action="thankyou.php"method="post">
                      <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <select id="L1" name="last_qualification" class="form-control" rrequired>
                                <option disabled selected>Last Qualification</option>
                                <?php
                                    include_once('connection/functions.php');
                                    $result=selectCourse();
                                    while($row=$result->fetch_assoc())
                                    {
                                        $id=$row['id'];
                                        echo '<option value="'.$id.'">'.$row["course_master_name"].'</option>';
                                    }
                                ?>
                            </select>
                            <textarea id="ta1" name="query"></textarea>
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <input list="course_interested" id="L2" name="course_interested" class="form-control" placeholder="Course Looking for" required />
                            <datalist id="course_interested">
                            </datalist>
                        </span>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control iinput-md" id="first_name" name="first_name" placeholder="First Name" required />
                          <span class="input-group-addon" style="width: 0px;"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control input-md" id="last_name" name="last_name" placeholder="Last Name" required />
                        </div>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input id="email" type="email" class="form-control" name="email" placeholder="Email" required />
                        </span>
                    </span>
                        <span class="input-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                <input type="text" class="form-control" id="phone" name="contact" placeholder="Contact No." required />
                            </div>
                        </span>
                        <div class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                            <input id="myInput1" class="autocomplete form-control" type="text" id="city" name="current_location" placeholder="Current Location" required />
                            <!--<input list="current_location" id="cl" name="current_location" class="form-control" placeholder="Current Location" rrequired />
                            <datalist id="current_location">
                                <?php
                                   $sql="SELECT * FROM location";
                                   $result=$conn->query($sql);
                                   while($row=$result->fetch_assoc())
                                   {
                                        $id=$row['id'];
                                        echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
                                   }
                                ?> 
                            </datalist>-->
                            
                       
                       
                            <span class="input-group-addon"><i class="fa fa-flag-checkered"></i></span>
                            <input id="myInput2" class="autocomplete form-control" type="text" name="preferred_location" placeholder="Preferred Location" required />
                        </div>
                        <center><div style="ppadding: 0px;" class="g-recaptcha pull-right" data-sitekey="6LdkqGsUAAAAAHaGJsKsrkrvewL8eWH2U_xGOttR"></div></center>
                        <div class="col-md-12" style="padding: 0px;">
                        <div class="col-md-5">
                           </b>
                            <br /><a href="#" data-toggle="modal" data-target="#login" data-dismiss="modal"><b></b></a>
                        </div>
                        <div class="col-md-7">
                            <div id="msg">
                                <span id="rsuccess" class="pull-right" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> <span id="m1"></span></span>
                                <span id="rerror" class="pull-right" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <span id="m2"></span></span>
                            </div>
                            <button id="sub" type="submit" class="btn btn-primary pull-right">SEND</button>
                        </div>
                        <div id="regButton" class="col-md-4" style="display: none; background: #DE4313;">
                        </div>
                        </div>
                        <br /><br />
                    </form>
        		</div>
        		<div id="col3" class="col-md-12" style="display: none; color: black; background: transparent; z-index: 1000; padding: 0px 40px 20px 40px;">
                    <h3 style="color: #5D9BD0; margin-top: 20px;"><b><i class="fas fa-info-circle fa-lg"></i> Thanks for Registering with us</b>
                    <button type="button" id="pclose" class="close">&times;</button>
        
                    <span class="pull-right" ><small><b style="color: #DE4313; font-size: 20px;">3000 <img alt="offer" src="../img/eb.png" height="50" style="position: inline;" /> OFFER</b><b style="color: black; font-size: 22px;"> @ <i class="fa fa-inr"></i> 199/-
                    <br /><small class="pull-right" style="color: green;"><i class="fa fa-bell faa-ring animated"></i> HURRY, <font color="red" size="4"> 2880</font> Premium Accounts are left</small></b></span>
                    <br />
                    </h4>
                    </h3>
                    <br /><h4>Avail more benifits by Upgrading to a <b style="color: #5D9BD0;">Premium Member</b></h4>
                    <br /><br />
                    <table class="table stable-striped">
                            <tr style="background: gray; color: white;"><td width="45%" style="background: #F2F2F2; color: black; border: 0px; text-align: left;"><b>Checkout the benifits</b></td><td><b>Standard</b></td><td style="background: green"><b>Premium</b></td></tr>
                            <tr><td class="first">Top Colleges & Universities</td><td class="second"><img alt="searchurcollege" src="../img/tick.png" height="20" /></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">Eligibility & Admission</td><td class="second"><img alt="searchurcollege" src="../img/tick.png" height="20" /></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">College Rankings</td><td class="second"><img alt="searchurcollege" src="../img/tick.png" height="20" /></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                            <tr><td class="first">College Brochures</td><td class="second"><img alt="searchurcollege" src="../img/tick.png" height="20" /><td class="third"><img alt="searchurcollege" alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                            <?php
                                $a=5;
                                $c=5;
                                for($i=0;$i<sizeof($a);$i++)
                                {
                                    echo '<tr><td class="first">'.$a[$i].'</td><td class="second"></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>';
                                }
                                //echo '<tr><td colspan="2" class="first">Covering '.$c.' and many more...</td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>';
                                echo '<tr><td class="first">Covering '.$c.' and many more...</td><td class="second"></td><td class="third"><img alt="saerchurcollege" src="../img/tick2.png" height="20" /></td></tr>';
                            ?>
                            <tr><td class="first">Last 10 years question banks & solution of CAT, XAT, CMAT & others MBA exams</td><td></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">More 15000 questions</td><td></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Minimum 10 sets of chapter wise practice test for each subject in MBA syllabus</td><td></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Unlimited full length practice test</td><td></td><td class="third"><img alt="searchurcollege" src="../img/tick2.png" height="20" /></td></tr>
                            <!--<tr><td class="first">365 Days Support</td><td></td><td><img alt="searchurcollege" src="../img/tick.png" height="20" /></td></tr>
                            <tr><td class="first">Career Guidance</td><td></td><td><img alt="searchurcollege" src="../img/tick.png" height="20" /></td></tr>-->
                    </table>
                    <center>
<script>
    $('.carousel').carousel({
      interval: 7000
    
    })
	window.onload = function() {
		var d = new Date().getTime();
		document.getElementById("tid").value = d;
		var e = new Date().getTime();
		document.getElementById("order_id").value = e;
	};
</script>
                	   <form method="POST" name="customerData" aaction="success.php" action="https://www.searchurcollege.com/connection/cca/ccavRequestHandler.php">
                            <!--<input type="hhidden" id="na" name="na" />
                            <input type="hhidden" id="ct" name="ct" />
                            <input type="hhidden" id="ph" name="ph" />
                            <input type="hhidden" id="em" name="em" />-->

                            <input type="hidden" name="tid" id="tid" readonly />
                            <input type="hidden" name="merchant_id" value="188437"/>
                            <input type="hidden" name="order_id" value="123654789"/>
                            <input type="hidden" name="amount" value="199"/>
                            <input type="hidden" name="currency" value="INR"/>
                            <input type="hidden" name="redirect_url" value="https://www.searchurcollege.com/cca/success.php" />
                            <input type="hidden" name="cancel_url" value="https://www.searchurcollege.com/cca/failure.php" />
                            <input type="hidden" name="language" value="EN"/>
                            <input type="hidden" id="na" name="billing_name" />
                            <input type="hidden" id="ct" name="billing_city" />
                            <input type="hidden" id="ph" name="billing_tel" />
        		        	<input type="hidden" id="em" name="billing_email" />

                            <button type="submit" class="btn btn-primary btn-lg">PAY NOW</button>
                        </form>
                    </center>
                </div>
            </div>
        </div>
      </div>
    </div>
</div>  



<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the crurrent tab


$('a').live("click", function(e) {
         return false; // prevent default click action from happening!
         e.preventDefault(); // same thing as above
    });

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    //document.getElementById("prevBtn").style.display = "none";
	$("#prevBtn").hide();
	$("#nextBtn").show();
	$("#submit1").hide();
  } else {
    document.getElementById("prevBtn").style.display = "inline";
	
  }
  if (n == (x.length - 1)) {
    //document.getElementById("nextBtn").innerHTML = "Submit";
	$("#nextBtn").hide();
	$("#submit1").show(); 
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function askNow()
{
    $('#ta1').val($('#have-question').val());
}
</script>

    <script type="text/javascript">
    $(document).ready(function() {

        var scrollbtn = false;

        //detect scroll
        $(window).scroll(function(){
            if(scrollbtn == false){
                var scrollTop = $(window).scrollTop();
                var docHeight = $(document).height();
                var winHeight = $(window).height();

                var scrollPercent = (scrollTop) / (docHeight - winHeight);
                var scrollPercentRounded = Math.round(scrollPercent*100);

                if (scrollPercentRounded > 50) {
                    $('.scrollup').css({'bottom': 20}).fadeIn();
                } else {
                    $('.scrollup').fadeOut();
                }
            }

        });

        //scroll-to-top
        $('.scrollup').click(function(){
            scrollbtn = true;
            var docheight = $(window).height();
            $('.scrollup').stop().animate({
                'bottom' : docheight
            }, 2000).fadeOut(function(){
                scrollbtn = false;
            });

            $("html, body").animate({ scrollTop: 0 }, 1200);

            return false;
        });
    });
    </script>

 
</body>
</html>