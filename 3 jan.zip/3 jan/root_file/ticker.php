<style>
@media screen and (min-width: 486px) and (max-width: 786px){
    #ticker {display: none;}
}
    

.holder {
	position:relative;
	top:0px;
	left:100px;
	width:200px;
	overflow:visible;
}

.holder.hide-overflow {
	overflow:hidden;
}

ul.list {
	position:relative;
	display:inline-block;
	list-style:none;
}

ul.list.cloned {
	position:absolute;
	top:0;
	left:0;
}

ul.list li {
	background-color:black;
    color: white;
	float: left;
	width: 200px;
    height: 23px;
	text-align: center;
	font-size: 18px;
    margin-top: 8px;
}
.list a
{color: white;}
.list a:hover
{text-decoration: none;}
</style>
    <div id="ticker" style="overflow-x: hidden;">
        <img id="id" src="img/id.png" alt="Important Dates" style="position: absolute; z-index: 100; left: 0px; margin-top: -1px;" />
        <div class="holder">
            <ul class="list">
                <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">MICA <i class="fa fa-calendar fa-xs"></i> 09-02-2019</a></li>
                <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">IIFT <i class="fa fa-calendar fa-xs"></i> 02-12-2018</a></li>
                <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">NMAT <i class="fa fa-calendar fa-xs"></i> 04 to 17-12-2018</a></li>
                <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">SNAP <i class="fa fa-calendar fa-xs"></i> 16-12-2018</a></li>
                <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">MAT <i class="fa fa-calendar fa-xs"></i> 09 & 15-12-2018</a></li>
                <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">XAT <i class="fa fa-calendar fa-xs"></i> 06-01-2019</a></li>
                <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">CMAT <i class="fa fa-calendar fa-xs"></i> 27-01-2019</a></li>
                <li><a href="https://www.searchurcollege.com/exams/jeemain-details.php">JEE MAIN <i class="fa fa-calendar fa-xs"></i> 06 to 20-1-19</a></a></li>
            </ul>
            </a>
        </div>
    </div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js'></script>
<script>
    var $holder = $(".holder");
    var $list = $holder.find("ul.list");
    var $clonedList = $list.clone();
    
    var listWidth = $list.find("li").length * 200;
    var endPos = $holder.width() - listWidth;
    
    $list.add($clonedList).css({
    	"width" : listWidth + "px"
    });
    
    $clonedList.addClass("cloned").appendTo($holder);
    
    //TimelineMax
    var infinite = new TimelineMax({repeat: -1, paused: false});
    var time = 20;
    
    infinite.fromTo($list, time, {left:0}, {left: -listWidth, ease: Linear.easeNone}, 0);
    infinite.fromTo($clonedList, time, {left:listWidth}, {left:0, ease: Linear.easeNone}, 0);
    infinite.set($list, {left: listWidth});
    infinite.to($clonedList, time, {left: -listWidth, ease: Linear.easeNone}, time);
    infinite.to($list, time, {left: 0, ease: Linear.easeNone}, time);
    
    //Pause/Play
    				
    $holder.on("mouseenter", function(){
    	infinite.pause();
    }).on("mouseleave", function(){
    	infinite.play();
    });
    
    //Show/Hide overflow
    $("#ov").on("click", function(){
    	$holder.removeClass("hide-overflow");
    });
    
    $("#oh").on("click", function(){
    	$holder.addClass("hide-overflow");
    });
</script>
    