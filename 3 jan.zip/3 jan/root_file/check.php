<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=0">

<?php
    if(isset($_REQUEST['user']))
    {
        if($_REQUEST['user']=='Ranjay' && $_REQUEST['password']=='qwerty@123@')
        {
            session_start();
            $_SESSION['login']='Y';
            echo '<script>';
            echo 'window.location.replace("check2.php/")';
            echo '</script>';
        }
    }
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<style>
    #mydiv {
        position:fixed;
        top: 50%;
        left: 58%;
        width:20em;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: -15em; /*set to a negative number 1/2 of your width*/
    }
</style>
<center>
<h4>SearchUrCollege</h4>
<h5>[ Super Admin ]</h5>
</center>
<div id="mydiv" class="text-center">
  <div id="formContent" style="background: orange; padding: 10px; border-radius: 20px;">
      <img src="https://www.searchurcollege.com/img/header-logo.png" iid="icon" alt="SearchUrCollege" style="padding: 10px;" />
    <form method="post" action="?">
      <input type="text" class="form-control" name="user" placeholder="User Name" required />
      <br />
      <input type="password" class="form-control" name="password" placeholder="Password" required />
      <br />
      <input type="submit" class="btn btn-success" value="Login">
    </form>
  </div>
</div>
