<script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>

<?php include('../connection/header.php'); ?>

<style>
body{
    
    line-height: 20px;
}
p{
    background: white!important;
    color: black!important;
}
table{
    background: white!important;
    color: black!important;
    width: 100%;
}
table tr td{
    algin: left;
}
h1,h2,h4,h5,h6{
    color: black!important;
}
.nav-tabs>li>a {
    margin-right: -1px!important;}
.tst-heading{
    text-align: justify!important;
}
</style>

      <!-- start ad panle section -->
  	<form id="submit" class="well" action="detail-dbinsert.php" method="POST">    
      <!-- End ad panle section -->
      <div class="clearfix"></div>
      <div class="bread-crumb">
        <ol class="breadcrumb">
          
          <li>
            <label>Super Category Name</label>
    		<select class="form-control sselect2" id="super_cat_id" name="super_cat_id" required>
    			<option>Select Super Category</option>
                 <?php 
                include("../connection/dbconnect.php");
                $sql="SELECT super_cat_id,super_cat_name from cat00_super_category";
    			$result=$conn->query($sql);
    			while($row=$result->fetch_assoc())
                {
                    $super_cat_id=$row["super_cat_id"];
                   $super_cat_name=$row["super_cat_name"];
                  echo ' <option  value="'.$super_cat_id.'">'.$super_cat_name.'</option> ';
                }
                 ?>								
    		</select>          
          </li>
          <li>
          <label>Exam Name</label>
          <select class="form-control sselect2" id="exam_exercise_id" name="exam_exercise_id" required>
    			<option>Select Exam Name</option>
                 <?php 
                include("../connection/dbconnect.php");
                $sql="SELECT exam_exercise_id,exam_exercise_name from cat03_exam_exercise";
    			$result=$conn->query($sql);
    			while($row=$result->fetch_assoc())
                {
                    $exam_exercise_id=$row["exam_exercise_id"];
                   $exam_exercise_name=$row["exam_exercise_name"];
                  echo ' <option  value="'.$exam_exercise_id.'">'.$exam_exercise_name.'</option> ';
                }
                 ?>								
    		</select> 
          
          </li>
          <li>
            <label>Exam Image</label>
			<input type="text" class="form-control" placeholder="Image Name" name="img" id="img" />
          </li>
          <li>
          <label class="col-md-4">Status</label>
            <div class="col-md-2">
               <div class="input-group"><input checked data-toggle="toggle" data-onstyle="warning" id="status" name="status" type="checkbox" value="1"></div>
            </div>
          </li>
        </ol>
      </div>
      <!-- start college list panel -->
      <section class="collage-list">
        <div class="ask-qst">
        <div class="xat-panel">
          <div class="row">
            <div class="cource-h3">
            <div class="col-md-12 col-sm-12 col-xs-7">
              <div class="pull-left col-md-4">
              <h3>
              <select class="form-control sselect2" id="exam_id" name="exam_id" required>
    			<option>Select Exam Name</option>
                 <?php 
                include("../connection/dbconnect.php");
                $sql="SELECT exam_id,exam_name from exam";
    			$result=$conn->query($sql);
    			while($row=$result->fetch_assoc())
                {
                    $exam_id=$row["exam_id"];
                   $exam_name=$row["exam_name"];
                  echo ' <option  value="'.$exam_id.'">'.$exam_name.'</option> ';
                }
                 ?>								
    		</select>
              </h3>
              <p><input class="form-control" type="text" placeholder="Exam Full Name" name="exam_full_name" id="exam_full_name" required/></p>
            </div>
            <div class="col-md-8 col-sm-8 col-xs-7">
                <label>Exam Remark</label>
                <input class="form-control" type="text" placeholder="Exam Remark" name="exam_remark" id="exam_remark"/></p>
           </div>
            </div>
           <div class="clearfix"></div>
            
          </div>
          </div>
          <div class="exam-lavel">
            <div class="row">
              <div class="col-md-4 col-xs-12">
                <div class="publication-section">
                  <div class="section-one">
                    <div class="list-unstyled list-inline">
                      <table class="table table-striped table-bordered">
                        <tbody>
                            <tr>
        						<td style="width: 50%;"><b>Exam Level</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Exam Level" name="exam_level" id="exam_level" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Conducted Body</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Exam Conducted Body" name="exam_conducted" id="exam_conducted" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Admit Card Download</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Admit Card Download" name="exam_admitcard" id="exam_admitcard" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Exam Date</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Exam Date" name="exam_date" id="exam_date" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Result Date</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Result Date" name="exam_result" id="exam_result" required/></td>
        					</tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <!-- end publication-sectio -->
              </div>
              <div class="col-md-4 col-xs-12">
                <div class="publication-section">
                  <div class="section-one">
                    <div class="list-unstyled list-inline">
                      <table class="table table-striped table-bordered">
                        <tbody>
                            <tr>
        						<td style="width: 50%;"><b>Exam Category</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Exam Category" name="exam_category" id="exam_category" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Application Date</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Application Date" name="application_begin" id="application_begin" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Application Fee</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Application Fee" name="application_fees" id="application_fees" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Mode Of Exam</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Mode Of Exam" name="modeofexam" id="modeofexam" required/></td>
        					</tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <!-- end publication-sectio -->
              </div>
              <div class="col-md-4 col-xs-12">
                <div class="publication-section">
                  <div class="section-one">
                    <div class="list-unstyled list-inline">
                      <table class="table table-striped table-bordered" style="width: 100%;">
                        <tbody>
                            <tr>
        						<td style="width: 50%;"><b>Frequency Of Exam</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Frequency Of Exam" name="exam_frequency" id="exam_frequency" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Last Date Of Application</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Last Date Of Application" name="application_end" id="application_end" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Mode Of Payment</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Mode Of Payment" name="modeofpayment" id="modeofpayment" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Exam Format</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="Exam Format" name="exam_format" id="exam_format" required/></td>
        					</tr>
                            <tr>
        						<td style="width: 50%;"><b>Apply Now</b></td>
        						<td style="width: 50%;"><input type="text" class="form-control" placeholder="URL" name="exam_apply" id="exam_apply" required/></td>
        					</tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <!-- end publication-sectio -->
              </div>
            </div>
          </div>
          <!-- exam lavel -->
          </div>
          <!-- exam lavel -->
        </div>
        <!-- end xat panel -->
         <div class="courses-tab">
          <ul id="tabs" class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#t1">About </a></li>
            <li><a data-toggle="tab" href="#t2">Test</a></li>
			<li><a data-toggle="tab" href="#t3">Dates</a></li>
            <li><a data-toggle="tab" href="#t4">Exam Pattern</a></li>
            <li><a data-toggle="tab" href="#t5">Syllabus</a></li>
            <li><a data-toggle="tab" href="#t6">Admit Card</a></li>
			<li><a data-toggle="tab" href="#t7">Test Centre</a></li>
            <li><a data-toggle="tab" href="#t8">Results</a></li>
			<li><a data-toggle="tab" href="#t9">Cut Off</a></li>
            <li><a data-toggle="tab" href="#t10">Application Form</a></li>
			<li><a data-toggle="tab" href="#t11">Contact</a></li>
          </ul>
          <div class="tab-content">
           
            <div id="t1" class="tab-pane fade in active">
               	<textarea class="form-control summernote" id="about_content" name="about_content"></textarea>
            </div>
            <!-- end tab-pane -->
			
            <div id="t2" class="tab-pane fade">
			   	<textarea class="form-control summernote" id="test_content" name="test_content"></textarea>
            </div>
           <!-- end tab-pane --> 
            <div id="t3" class="tab-pane fade">
		       	<textarea class="form-control summernote" id="dates_content" name="dates_content"></textarea>
            </div>
          <!-- end tab-pane --> 	
        
            <div id="t4" class="tab-pane fade">
		       	<textarea class="form-control summernote" id="pattern_content" name="pattern_content"></textarea>
             </div>
		
		<!-- end tab-pane --> 
            <div id="t5" class="tab-pane fade">
               	<textarea class="form-control summernote" id="syllabus_content" name="syllabus_content"></textarea>
            </div>
		<!-- end tab-pane --> 	
		    <div id="t6" class="tab-pane fade">
                	<textarea class="form-control summernote" id="admitcard_content" name="admitcard_content"></textarea>
            </div>
		<!-- end tab-pane --> 	
		      <div id="t7" class="tab-pane fade">
                   	<textarea class="form-control summernote" id="testcenter_content" name="testcenter_content"></textarea>
              </div>
		<!-- end tab-pane --> 		
		    <div id="t8" class="tab-pane fade">
                	<textarea class="form-control summernote" id="result_content" name="result_content"></textarea>
            </div>
		<!-- end tab-pane --> 	
		<div id="t9" class="tab-pane fade">
             	<textarea class="form-control summernote" id="cutoff_content" name="cutoff_content"></textarea>
        </div>
		<!-- end tab-pane --> 	
		<div id="t10" class="tab-pane fade">
           	<textarea class="form-control summernote" id="applicationform_content" name="applicationform_content"></textarea>
        </div>
		<!-- end tab-pane --> 
        <!-- end tab-pane --> 
        <div id="t11" class="tab-pane fade">
		   	<textarea class="form-control summernote" id="contact_content" name="contact_content"></textarea>
        </div>	
          </div>
          <!-- /Bootstrap Tabs -->
          <!-- Bootstrap Accordion -->
          <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true"></div>
          <!-- /Bootstrap Accordion -->
        </div>
        <!-- end courses-tab -->
      </section>
      <!-- End college list panel -->
      <div class="box-footer clearfix">	
		<div class="col-xs-12">	
			<div class="col-xs-12 pull-right">
				<button type="submit"  name="submit" id="submit" class="btn btn-primary  pull-right"> Submit</button>
			</div>
		</div>
	</div>
</form>
      
   <?php
   include('../footer.php');
   ?>
    <!-- ...........End js include here.............. -->
  <script>
	CKEDITOR.replace( 'about_content' );
    CKEDITOR.replace( 'test_content' );
    CKEDITOR.replace( 'dates_content' );
    CKEDITOR.replace( 'pattern_content' );
    CKEDITOR.replace( 'syllabus_content' );
    CKEDITOR.replace( 'admitcard_content' );
    CKEDITOR.replace( 'testcenter_content' );
    CKEDITOR.replace( 'result_content' );
    CKEDITOR.replace( 'cutoff_content' );
    CKEDITOR.replace( 'applicationform_content' );
    CKEDITOR.replace( 'contact_content' );
  </script>
  
  
  
  </body>
</html>