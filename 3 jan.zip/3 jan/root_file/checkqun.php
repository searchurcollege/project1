<?php
    session_start();
    if($_SESSION['login']=='N')
    {
        echo '<script>';
        echo 'window.location.replace("https://www.searchurcollege.com/check.php")';
        echo '</script>';
        die();
    }
    include('connection/dbconnect.php');
   // include ('connection/header.php');

?>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>
<head><title>QUESTIONS DETAIL</title></head>
<a href="https://searchurcollege.com/checkqun2.php"><button  style="margin-top: 5px; padding: 5px 24px;;  position: absolute; transition: .5s ease;
    top: 0%;
    right:10% ; background-color: white;
    color: black;
    border: 2px solid #555555" >back</button></a>
<a href="https://www.searchurcollege.com/check2.php"><button  style="margin-top: 5px; padding: 5px 24px;;  position: absolute; transition: .5s ease;
    top: 0%;
    right:0% ; background-color: white;
    color: black;
    border: 2px solid #555555" >Dashboard</button></a>

<table id="example" style="margin-top: 40px;"class="table table-bordered table-striped table-hover" width="100%">
        <thead>
            <tr style="background: orange;">
               <th>Date</th>
                <th>Question</th>
                
                
            </tr>
        </thead>
        <tbody>
        <?php
            
            $sql="SELECT count(question_id) as x,DATE(updated_at) as y FROM `questions` GROUP BY DATE(updated_at) order by DATE(updated_at) DESC";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
            {
            
                $count=$row["x"];
                $date=$row["y"];

                
                echo '<tr>
                <td>'.$date.'</td>
                    <td>'.$count.'</td>
                    
                   
                </tr>';
            }
        ?>
        </tbody>
    </table>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DefaultView.Sort = "[id] ASC";
 
} );
</script>    