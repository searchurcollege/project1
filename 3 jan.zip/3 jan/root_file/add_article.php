<!-- <script src="https://www.searchurcollege.com/exam/admin/ckeditor/ckeditor.js"></script> -->
<script src="https://www.searchurcollege.com/assets/ckeditorfull/ckeditor.js"></script>
<script src="https://www.searchurcollege.com/assets/ckeditor/ckeditor.js"></script>
<script src="https://www.searchurcollege.com/assets/ckeditor/samples/js/sample.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
 <script
  src="https://code.jquery.com/jquery-1.12.4.js"
  integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU="
  crossorigin="anonymous"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/assets/css/ionicons.min.css">
	<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/assets/css/AdminLTE.css">
	<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/assets/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
	<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/assets/css/datatables/dataTables.bootstrap.css">
	<!-- <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script> -->
<?php // include("connection/header.php"); ?>
<section class="content">

<div class="row" style="margin-top: 30px;">
<!-- left column -->
<div class="col-md-2"></div>
<div class="col-md-8">
	<!-- general form elements -->
	<form id="frmSubmi" class="well" method="POST" aaction="https://www.searchurcollege.com/exam/admin/search/college-facility/college_facility_Action.php?table_name=suc_college_facilities" >
		<div class="box-body">
			
				<div class="col-xs-12">
					<input id="username" name="username"  value="admin" type="hidden" />
                    <input type="hidden" name="posted_on" value="<?php echo  $date = date('Y-m-d H:i:s');  ?>" />
<div class="form-group col-xs-12">
 <label for="catName">Title</label>
						<input type="text" placeholder="Title" class="form-control" name="title" id="title" value="" required />
					</div>
 <div class="form-group col-xs-6">
						<label for="catName">Article Image</label>
						<input type="file"  class="form-control" name="image" id="image" />
					</div>

					 <div class="form-group col-xs-12">
											<label for="cat_Description">Fees Slab Description</label>
											<textarea class="form-control summernote" placeholder="" id="discription" name="discription"></textarea>
										</div>

				</div>
			 
		</div>
		<div class="box-footer clearfix">	
			<div class="col-xs-12">	
				<div class="col-xs-12 pull-right">
<center> <img id ="loadingImage" style="max-height: 140px; margin-left: -70px; position: absolute; ffloat:left; display: none;" cclass="pull-right" src="https://searchurcollege.com/exam/admin/search/loading.gif"></center>
					<button type="submit" nname="btnCategory" iid="btnCategory" class="btn btn-primary  pull-right">Submit</button>
				</div>
			</div>
		</div>
	</form>

</div>
<div class="col-md-2"></div>	
</div>

</section>
<div class="col-md-12" id ="success"style="display: none; height: 40px; margin-top:-40px; "><center><h4 align="center" style="bbackground: green; width: 100%;font-size: 20px; color: green;">--New RECORD INSERTED--</h4></center></div>


 <script>
	CKEDITOR.replace( 'discription' );
    //CKEDITOR.replace( 'cc_fee_notes' );
  </script>

 <script>
    $(document).ready(function(){
      $("#frmSubmi").submit(function(e){
         //$("#loadingImage").show();
       e.preventDefault();
      for (instance in CKEDITOR.instances)
      {
        CKEDITOR.instances[instance].updateElement();
      } 
      // var file_data = $("#facility_image_path").prop("files")[0];   // Getting the properties of file from file field
      // var form_data = new FormData();                  // Creating object of FormData class
      // form_data.append("file", file_data)        
      $.ajax({
        url:"add_article_Action.php",
        method:"POST",
        //data: $('#frmSubmi').serialize(),
          data: new FormData(this),
          contentType: false,       // The content type used when sending data to the server.
          cache: false,             // To unable request pages to be cached
          processData:false, 
        success:function(data)
        {
          alert(data);
          if(data==1){
           // $('#loadingImage').hide();
            $('#success').fadeIn().delay(1000).fadeOut();
            setTimeout("location.href = 'add_article.php'",2000);
        }
        else
        {
         // $('#loadingImage').hide();
          alert("Erorr");
        }
        
        }
      });
      
      
    });
  });
</script>