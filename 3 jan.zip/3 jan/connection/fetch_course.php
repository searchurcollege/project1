<?php
    include("functions.php");
    include("dbconnect.php");
    $course_id = ($_REQUEST["course_id"] <> "") ? trim($_REQUEST["course_id"]) : "";
    $result=selectCategory($course_id);
    echo '<span class="input-group">';
    echo '<span class="input-group-addon"><i class="fa fa-book"></i></span>';
    echo '<select id="L2" name="course_interested" class="form-control">';
    echo '<option disabled selected>Select Course</option>';
    while($row=$result->fetch_assoc())
    {
        $id=$row['id'];
        echo '<option value="'.$id.'">'.$row["category"].'</option>';
    }
    echo '</select>';
?>