<?php
	include('dbconnect.php');
    session_start();
    $email=$_SESSION['email'];
    if($email=='')
        $email=$_REQUEST['email'];
    $sqll="update users set token='' where email='$email'";
    $result1=$conn->query($sqll);
    session_destroy();
    header("Location: https://www.searchurcollege.com/");

?>