<?php include('header.php');?>
<style>
    #referral
    { 
        position:fixed;
        top: 50%;
        left: 52%;
        width: 300px;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: -15em; /*set to a negative number 1/2 of your width*/
        border: 1px double orange;
        border-radius: 10px;
        background: #FCEEE0;
        padding: 30px;
    }
</style>
<div id="referral" style="padding: 15px; z-index: 10000; color: black; box-shadow: 5px 5px lightgrey;">
    <center>
    <form id="frmReferral">
        <h4>Having <b>Referral</b> Code?</h4>
        <br />
        <div class="col-md-6" style="padding: 0px;">
            <div class="input-group" id="ref2" style="display: none;">
                <input type="text" class="form-control" style="width: 68%;" name="ref2" placeholder="Your Code" required />
                <button type="submit" class="btn btn-success">Go</button>
            </div>
            <button class="btn btn-success" id="ref1">YES</button>
        </div>
        <div class="col-md-6" style="padding: 0px;">
            <a href="pay_now.php"><button class="btn btn-danger">NO</button></a>
        </div>
</form>
    </center>
</div>

<?php include('../footer.php');?>


<script>
    //Referral Choice
    $('#ref1').click(function(event) {
      $('#ref1').hide();
      $('#ref2').show();
      return false;
    });

    //Has Referral
    $('#frmReferral').submit(function(event) {
      referral=$('#ref2').val();
      $.post(
       'https://www.searchurcollege.com/connection/referral_save.php?referral='+referral,
        $(this).serialize(),
        function(data){
            alert(data);
        }
      );
      return false;   
    });   
</script>


