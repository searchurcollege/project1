<?php
    include('functions.php');
    $id=$_REQUEST['id'];
    $data='';
    $result=selectCategory($id);
    while($row=$result->fetch_assoc())
    {
        $id=$row['id'];
        $data.='<option value="'.$row["category"].'">'.$row["category"].'</option>';
    }
    echo $data;
?>
