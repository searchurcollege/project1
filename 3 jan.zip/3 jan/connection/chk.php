<?php
    $id=$_REQUEST['id'];
    $sid=1;
    //$sid=$_SESSION['id'];
    $eid=102;
    session_start();
    $_SESSION['eid']=$eid;
    //if(isset($_SESSION['email']))
    {
        $email=$_SESSION['email'];
        include('dbconnect.php');
        //echo $sql="SELECT super_cat_id FROM cat00_super_category WHERE super_cat_id=".$sid;
        //$result=$conn->query($sql);
        //while($row=$result->fetch_assoc())
            //$super_cat_id=$row['super_cat_id'];
        if($id==$sid)
        {
            $sql="SELECT balance_amt FROM users WHERE email='$email'";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
                $balance_amt=$row['balance_amt'];
            if($balance_amt==0)
                $url='1';//https://searchurcollege.com/exam/start-exam/'.$eid;
            else
                $url='2';//"https://searchurcollege.com/connection/pay_now.php";
        }
        else
            $url='3';
    }
   
    echo $url;
?>
