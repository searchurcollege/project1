      <link href="https://fonts.googleapis.com/css?family=Noto+Serif+KR" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
      <link rel="shortcut icon" type="image/x-icon" href="https://www.searchurcollege.com/img/favicon.ico">
      <llink rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/style.css">
      <sscript type="text/javascript" src="https://www.searchurcollege.com/js/jquery.min.js"></script>
      <sscript type="text/javascript" src="https://www.searchurcollege.com/js/bootstrap.min.js"></script>
      <sscript src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.1.1/css/bootstrap.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<style>
    .sub
    {
        background: transparent; border: 0px;
    }
    .sub:hover
    {
        background: black; color: white; border: 0px;
    }
</style>
<?php
if(!isset($_SESSION)) 
 session_start();
 
?>

 
<!---------Microdata Schema----------->
<script type=�application/ld+json�>
{
"@context": "http://www.schema.org",
"@type": "Online Test Portal",
"url": "https://www.searchurcollege.com",
"name": "SearchurCollege",
"image": "https://www.searchurcollege.com/img/header-logo.png",
"description": "Searchurcollege is online educational information classified and  practice test portal. This platform will empower students with making  the most important decision of their life."
}
</script>
<!------------------------------------->  


<!-------------Alexa------------------------->
<a href="https://www.alexa.com/siteinfo/searchurcollege.com"><script type="text/javascript" src="https://xslt.alexa.com/site_stats/js/t/a?url=searchurcollege.com"></script></a>
<!-----------------End----------------------->

<!-- google file verification-->
<meta name="google-site-verification" content="6EfYIRGsOHzIp52jxpan0ecb5yZdo5KjoPnFuG0GjSI" />
<!--end-->

 <!--Bing site tag-->
<meta name="msvalidate.01" content="F04770FCC8B31FAD4D0BACE0D2DBECE2" />
<!--Bing End--> 

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-118318912-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-118318912-1');
</script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '438116786600943');
  fbq('track', 'PageView');
</script>
<noscript><img alt="searchurcollege facebook" height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=438116786600943&ev=PageView&noscript=1"
></noscript>
<!-- End Facebook Pixel Code -->
   <style> 

    .glow {
          background-color: yellow;
          -webkit-border-radius: 10px;
          bborder-radius: 10px;
          border: none;
          color: yellow;
          cursor: pointer;
          display: inline-block;
          font-family: Arial;
          font-size: 20px;
          ppadding: 5px 10px;
          text-align: left;
          text-decoration: none;
      -webkit-animation: glowing 1500ms infinite;
      -moz-animation: glowing 1500ms infinite;
      -o-animation: glowing 1500ms infinite;
      animation: glowing 1500ms infinite;
    }
    @-webkit-keyframes glowing {
      0% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
      50% { background-color: #FF0000; -webkit-box-shadow: 0 0 40px #FF0000; }
      100% { background-color: #B20000; -webkit-box-shadow: 0 0 3px #B20000; }
    }
    
    @-moz-keyframes glowing {
      0% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
      50% { background-color: #FF0000; -moz-box-shadow: 0 0 40px #FF0000; }
      100% { background-color: #B20000; -moz-box-shadow: 0 0 3px #B20000; }
    }
    
    @-o-keyframes glowing {
      0% { background-color: orange; box-shadow: 0 0 3px #B20000; }
      50% { background-color: orange; box-shadow: 0 0 40px #FF0000; }
      100% { background-color: orange; box-shadow: 0 0 3px #B20000; }
    }
    
    @keyframes glowing {
      0% { background-color: orange; box-shadow: 0 0 3px red; }
      50% { background-color: orange; box-shadow: 0 0 40px red; }
      100% { background-color: orange; box-shadow: 0 0 3px red; }
    }
    .box {
       width:200px;height:300px;
       position:relative;
       border:1px solid #BBB;
       background:#eee;
       float:left;
       margin:20px
    }
    .ribbon {
       position: absolute;
       right: -5px; top: -5px;
       z-index: 1;
       overflow: hidden;
       width: 75px; height: 75px; 
       text-align: right;
    }
    .ribbon span {
       font-size: 10px;
       color: #fff; 
       text-transform: uppercase; 
       text-align: center;
       font-weight: bold; line-height: 20px;
       transform: rotate(45deg);
       width: 100px; display: block;
       background: #79A70A;
       background: linear-gradient(#9BC90D 0%, #79A70A 100%);
       box-shadow: 0 3px 10px -5px rgba(0, 0, 0, 1);
       position: absolute;
       top: 19px; right: -21px;
    }
    .ribbon span::before {
       content: '';
       position: absolute; 
       left: 0px; top: 100%;
       z-index: -1;
       border-left: 3px solid #79A70A;
       border-right: 3px solid transparent;
       border-bottom: 3px solid transparent;
       border-top: 3px solid #79A70A;
    }
    .ribbon span::after {
       content: '';
       position: absolute; 
       right: 0%; top: 100%;
       z-index: -1;
       border-right: 3px solid #79A70A;
       border-left: 3px solid transparent;
       border-bottom: 3px solid transparent;
       border-top: 3px solid #79A70A;
    }
    .red span {background: linear-gradient(#F70505 0%, #8F0808 100%);}
    .red span::before {border-left-color: #8F0808; border-top-color: #8F0808;}
    .red span::after {border-right-color: #8F0808; border-top-color: #8F0808;}
    
    .blue span {background: linear-gradient(#2989d8 0%, #1e5799 100%);}
    .blue span::before {border-left-color: #1e5799; border-top-color: #1e5799;}
    .blue span::after {border-right-color: #1e5799; border-top-color: #1e5799;}
    
    .nav li {font-weight: bold;}
</style>

<style type="text/css">
    .dropdown-submenu {
    position: relative;
}

#dropsec{

}
.dropdown-submenu>.dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -6px;
    margin-left: -1px;
    -webkit-border-radius: 0 6px 6px 6px;
    -moz-border-radius: 0 6px 6px;
    border-radius: 0 6px 6px 6px;
}
.dropdown-menu li a:hover {
    background: black!important;
    color: white!important;
}
.dropdown-submenu:hover>.dropdown-menu {
    display: block;
    color: white!important;
}
.dropdown-submenu li a:hover{
    background: black!important;
    color: white!important;
}
.dropdown-submenu>a:after {
    display: block;
    content: " ";
    float: right;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
    border-width: 5px 0 5px 5px;
    border-left-color: #ccc;
    margin-top: 5px;
    margin-right: -10px;
}
.dropdown-submenu:hover>a:after {
    border-left-color: #fff;
}
.dropdown-submenu.pull-left {
    float: none;
}
.dropdown-submenu.pull-left>.dropdown-menu {
    left: -100%;
    margin-left: 10px;
    -webkit-border-radius: 6px 0 6px 6px;
    -moz-border-radius: 6px 0 6px 6px;
    border-radius: 6px 0 6px 6px;
}    
.navbar-inverse .navbar-nav>.open>a, .navbar-inverse .navbar-nav>.open>a:focus, .navbar-inverse .navbar-nav>.open>a:hover {
    color: #000000!important;
    background-color: #fffdfd!important;
}
.dropdown-menu {
    background-color: #ffffff!important;
}
.dropdown-menu>li>a {
    color: #000000!important;
  }
 
section .main-section { height: 20px; }
.input1{
    text-align: left!important;
    font-family: Arial;
    font-size: 14px;
    padding: 8px 0px 0px 15px;
    display: block;
    clear: both;
    font-weight: normal;
    line-height: 1.42857143;
    color: #333;
    white-space: nowrap
    
}
.input1:hover {
    background: black!important;
    color: white!important;
    width:100%!important;
}
</style>
  </head>


<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P9BJF7F"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->



<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" sstyle="margin-top: 60px;">
    <section class="main-section"><section class="nav-section">
    <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container-fluid" style="height: 5px;">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
              </button>
              <a class="navbar-brand" href="https://www.searchurcollege.com"><img alt="searchuecollege.com" src="https://www.searchurcollege.com/img/header-logo.png"></a>
            </div>
            <div class="nav-rt">
              <ul class="nav navbar-nav navbar-right right-nav">
                <li>
                 <?php
                 
                 if(isset($_SESSION['photo']))
                
                    echo'<a href="#" class="dropdown-toggle" data-toggle="dropdown"><img alt="searchurcollege_user" src="https://www.searchurcollege.com/exam/profile/profileImage/'.$_SESSION['photo'].'" width="40px" height="40px"></a>';
                 else
                    echo'<a href="#" class="dropdown-toggle" data-toggle="dropdown"><img alt="searchurcollege_user" src="https://www.searchurcollege.com/img/user.png"></a>';
                  ?>
                  <ul id="dropsec" class="dropdown-menu multi-level">
                        <?php
                           // if(session_status()==PHP_SESSION_NONE)
                            // if(!isset($_SESSION))
                             //   session_start();
                            $sid=""; 
                            if(isset($_SESSION['email']))
                            {
                              if(isset($_SESSION['email']))
                              {
                                $sid=$_SESSION['sid'];
                                if($_SESSION['ba'])
                                {
                                    if($_SESSION['ba']==0)
                                       echo '<li style="color: #FF9934; padding:10px"><h5 style="color: #FF9934;"><strong> Welcome '.$_SESSION['user_name'].' <i class="fa fa-star ffa-spin" title="Premium Member" style="color: #F2FB05; margin-top: -25px;margin-left:100px;"></i></strong></h5></li>';
                                    else
                                      echo '<li style="color: #FF9934;"><h5>Welcome '.$_SESSION['user_name'].'</h5></li>';
                                }
                                else
                                    echo '<li style="color: #FF9934;"><h5>Welcome '.$_SESSION['user_name'].'</h5></li>';
                              }
                                  echo '<li><a href="https://www.searchurcollege.com/exam/home?id='.$sid.'">Dashboard</a></li>';
                                  echo '<li><a href="https://www.searchurcollege.com/connection/logout.php">Logout</a></li>';
                            }
                            else
                            {
                                echo '<li><a href="#" id="log" data-toggle="modal" data-target="#login">Login</a></li>';
                                echo '<li style="display: none;"><a href="#" id="log2" data-toggle="modal" data-target="#login2">Login</a></li>';
                                echo '<li><a href="#" data-toggle="modal" data-target="#register">Register</a></li>';
                            }
                        ?>
                    </ul>
                </li>
              </ul>
            </div>
            <!-- end nav rt -->
            <div class="collapse navbar-collapse" id="myNavbar" style="margin-left: -10px!important;">
               <ul class="nav navbar-nav" >
               <?php
              
                //if(!isset($_SESSION['email']))
                {
                    echo '<li style="background: #ff9934;" cclass="glow"><a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: white; font-size: 18px; font-weight: bold;">TEST SERIES <div style="font-size: 12px; background: yellow; color: green; padding: 8px 5px 8px 5px; position: absolute; right: 10px; margin-top: -35px;" class="blink"><b>NEW</b></div><span class="caret" style="color: gray;"></span></a>
                        <ul class="dropdown-menu multi-level">';
					include_once('functions.php');
                    $result=selectStream();
                    while($row=$result->fetch_assoc())
                    {
                        $id=$row['super_cat_id'];
                        if($id<6){
                        echo '<li><a href="https://www.searchurcollege.com/test/test.php?id='.$id.'">'.$row["super_cat_name"].'</a></li>';
                    }
                       // echo '<li><a href="https://www.searchurcollege.com/test/test.php?id='.$id.'">'.$row["super_cat_name"].'</a></li>';
                    }
                    echo '</ul></li>';
                }
               ?>
              <!--
 <?php
              
                //if(!isset($_SESSION['email']))
                {
                    echo '<li style="background: #ff9934;" cclass="glow"><a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: white; font-size: 18px; font-weight: bold;">TEST SERIES<div style="font-size: 12px; background: yellow; color: green; padding: 8px 5px 8px 5px; position: absolute; right: 10px; margin-top: -35px;" class="blink"><b>NEW</b></div><span class="caret" style="color: gray;"></span></a>
                        <ul class="dropdown-menu multi-level">';
					include_once('functions.php');
                    $result=selectStream();
                    while($row=$result->fetch_assoc())
                    {
                        $id=$row['super_cat_id'];
                        echo '<li><form method="POST" action="https://www.searchurcollege.com/test/test.php"><input type="hidden" name="id" value="'.$id.'"><input type="submit" class="sub input1" value="'.$row["super_cat_name"].'"  /></form></li>';
                    }
                    echo '</ul></li>';
                }
               ?>
-->
               
               <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">MBA <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu ">
                                <li>
                                    <form action="https://www.searchurcollege.com/search/listC.php" method="POST" id="mbaPost">
                                    <input type="hidden" name="country1" value="MBA/PGDM">
                                    </form>
                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=MBA/PGDM" id="mbaClick" style="text-decoration:none;">MBA/PGDM</a>
                                    <a href="https://www.searchurcollege.com/colleges/distance-mba/college-list-1.php">Distance MBA</a>
                                   
                                <!--<a href="#">Executive MBA/PGDM</a>
                                    <a href="#">Online MBA</a>
                                    <a href="#">Part Time MBA</a>-->
                                </li>
                            </ul>
                        </li>
                        <li><a href="https://www.searchurcollege.com/exams/mba-exams.php" >MBA Exam Details</a></li>
                    <!--<li><a href="#" >Location of college</a></li>
                        <li><a href="#" >Reviews of college</a></li>
                        <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/management-2018.php">2018</a>
                                    <a href="https://www.searchurcollege.com/ranking/management-2017.php">2017</a>
                                    <a href="https://www.topuniversities.com/university-rankings/rankings-by-location/india/2019" target="_blank">QS Ranking</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">ENGINEERING <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=B.E / B.Tech">B.E./B.Tech.</a>
                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=M.Tech">M.E./M.Tech.</a>
                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=Diploma">Diploma Courses</a>
                                <!--<a href="#">Distance Diploma Courses</a>
                                    <a href="#">Distance B.Tech</a>-->
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/engineering-exams.php" >Engineering Exam Details</a></li>
                    <!--<li><a href="#" >Location of college</a></li>
                        <li><a href="#" >Reviews of college</a></li>
                        <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/engineering-2018.php">2018</a>
                                    <a href="https://www.searchurcollege.com/ranking/engineering-2017.php">2017</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">LAW <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=B.A. LL.B">BA LLB</a>

                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=BBA LL.B">BBA LLB</a>
                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=LL.B">LLB</a>
                                    <a href="https://www.searchurcollege.com/search/listC.php?country1=LL.M">LLM</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/law-exams.php" >LAW Exam Details</a></li>
                     <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                         <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/law-2018.php">2018</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->       
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">DESIGN <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#">Communication Design</a>
                                    <a href="#">Fashion Design</a>
                                    <a href="#">Industrial/Product Design</a>
                                    <a href="#">Interior Design</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/design-exams.php" >Design Exam Details</a></li>
                        <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <!--<li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#" >2018</a>
                                    <a href="#" >2017</a>
                                </li>
                            </ul>
                        </li>-->
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">MEDICAL <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/colleges/medical-college-list-1.php">MBBS</a>
                                    <a href="#">Pharmacy</a>
                                    <a href="#">Nursing</a>
                                    <a href="#">Dental Science</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="https://www.searchurcollege.com/exams/medical-exams.php" >Medical Exam Details</a></li>
                     <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="https://www.searchurcollege.com/ranking/medical-2018.php">2018</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">MORE<b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#">BCA</a>
                                    <a href="#">MCA</a>
                                    <a href="#">BSc. IT</a>
                                    <a href="#">MSc. IT</a>
                                    <a href="#">BBA</a>
                                    <a href="#">BBM</a>
                                    <a href="#">Hotal Management</a>
                                    <a href="#">Media & Journalism</a>
                                    <a href="#">Engineerng Diploma (Polytechnic)</a>
                                    <a href="#">Animation</a>
                                    <a href="#">Finance & Accounts</a>
                                    <a href="#">Degree Courses (Arts, Commerce & Science)</a>
                                    <a href="#">Others (Diploma etc.)</a>
                                </li>
                            </ul>
                        </li>
                         <li><a href="#">Other Exam Details</a></li>
                     <!--<li><a href="#" >Location of college</a></li>
                         <li><a href="#" >Reviews of college</a></li>
                         <li><a href="#" >Colleges excepting Scores Exam</a></li>-->
                        <!--<li class="dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking of College</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#" >2018</a>
                                    <a href="#" >2017</a>
                                </li>
                            </ul>
                        </li>-->
                    </ul>
                </li>
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">SCHOLARSHIP <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a >Central Govt.</a></li>
                        <li><a >State Govt.</a></li>
                    	<li><a >CSR Funding</a></li>
                   		<li><a >Minority</a></li>
                        <li><a >Loan</a></li>
                    </ul>
                </li>
            <!--<li><a href="#" >Specialization courses</a></li>-->
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">EXAMS <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a href="https://www.searchurcollege.com/exams/mba-exams.php">MBA</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/engineering-exams.php">Engineering</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/medical-exams.php" >Medical</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/law-exams.php" >LAW</a></li>
                        <li><a href="https://www.searchurcollege.com/exams/design-exams.php" >Design</a></li>
                   <!--<li><a href="#" >Others Exam </a></li>-->
                    </ul>
                </li>
                <!-- <?php
                   // if(isset($_SESSION['email']))
                    {
                      //  if($_SESSION['ba']==0)
                        //    echo '<li style="color: #F2FB05; font-weight: bold; margin-top: 10px; position: absolute; right: 100px;"><h4>Welcome '.$_SESSION['user_name'].' <i class="fa fa-star ffa-spin" title="Premium Member" style="color: #F2FB05; margin-top: -15px;"></i></h4></li>';
                        //else
                          //  echo '<li style="color: #F2FB05; font-weight: bold; margin-top: 10px; position: absolute; right: 100px;"><h4>Welcome '.$_SESSION['user_name'].'</h4></li>';
                    }
                ?> -->
            </ul>
            </div>
          </div>
        </nav>
      </section>
      <!-- end nav bar section -->
    </section>
    <div class="clearfix"></div>
 
<style>
@-webkit-keyframes blink {  
  from { opacity: 1.0; }
  to { opacity: 0.0; }
}

.blink {
  -webkit-animation-name: blink;  
  -webkit-animation-iteration-count: infinite;  
  -webkit-animation-timing-function: cubic-bezier(1.0,0,0,1.0);
  -webkit-animation-duration: 1s; 
}
</style>
    
<?php
    include('login.php');
    include('register.php');
?> 

 <script >
   window.onload=function() {
   document.getElementById("mbaClick").onclick=function() {
     //alert("ss");
     document.getElementById("mbaPost").submit();
     // return false; // cancel the actual link
   }
   document.getElementById("enggClick").onclick=function() {
     //alert("ss");
     document.getElementById("enggPost").submit();
     // return false; // cancel the actual link
   }
 }
 </script>