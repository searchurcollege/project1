<?php
    //include('header.php');
?>
<style>
.input-group
{
    margin-bottom: 10px;
}
.mydiv {
    position:fixed;
    top: 50%;
    lleft: 50%;
    width: 100%;
    margin-top: -9em; /*set to a negative number 1/2 of your height*/
    mmargin-left: -15em; /*set to a negative number 1/2 of your width*/
    border: 1px solid #ccc;
    background-color: #f3f3f3;
}
 @media screen and (min-width: 200px) and (max-width: 999px){
   .modal-content{
   padding-bottom: 45px!important; }
    
}

</style>

<?php 
    $protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"],0,strpos( $_SERVER["SERVER_PROTOCOL"],'/'))).'://';
    //echo '<br>'.$protocol.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
?>
<div id="login" class="modal fade" role="dialog" style="margin-top: 100px;">
  <div class="modal-dialog">
    <div class="modal-content">
            <div class="col-md-12 col-xs-12" style="background: white; padding: 10px;">
                <button type="button" style="position: absolute; right: 20px; color: black;" class="close" data-dismiss="modal" title="Close">&times;</button>
                <h4 class="modal-title"><b><i class="fa fa-user-o"></i> User Login</b><br /><br /></h4>
                <form id="frmLogin" action="user_login.php">
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="text" class="form-control" name="email"id="email" placeholder="Email" required />
                    </div>
                    <div class="col-md-12">
                        <span class="input-group"><span class="input-group-addon">
                            <i class="fa fa-book"></i>
                        </span>
                        <input type="password" class="form-control" name="password" placeholder="Password" required />
                    </div>
                    <div class="col-md-12 text-right" style="margin-top: 10px;">
                        <button type="submit" class="btn btn-success pull-left">Login</button>
                        <button id="fp" class="btn btn-warning pull-left" style="margin-left: 10px;">Forgot Password</button>
                        <span class="pull-right" style="margin-top: 7px; font-weight: bold;">
                            New user ? <a><span data-toggle="modal" data-target="#register" data-dismiss="modal" style="margin-right: 10px; cursor: pointer; color: #5D9BD0;">Register Here</span></a>
                        </span>
                        <div class="row"></div>
                        <span id="success" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Login Succeeded.</span>
                        <span id="success1" class="pull-left" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Password send to Email.</span>
                        <span id="error" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Invalid Credentials</span>
                         <span id="error1" class="pull-left" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Something Wrong, Please click on Forget Password</span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
        //Login User
        $('#frmLogin').submit(function(event) {
          $.post('https://www.searchurcollege.com/connection/user_login.php',
            $(this).serialize(),
            function(data)
            {
                if(data=='1')
                {
                    $("#success").show();
                    eid=$('#eid').val();
                    setTimeout(function() { $("#success").hide(); }, 3000);
                    if(eid>0)
                        window.location.href = "https://www.searchurcollege.com/exam/start-exam/"+eid;
                    else
                    {
                        location.reload();
                    }
                }
                else
                if(data=='2')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                if(data==0)
                {
                    $("#error").show();
                    setTimeout(function() { $("#error").hide(); }, 3000);
                }
                else
                {
                    window.location.href = "https://www.searchurcollege.com/connection/alert.php?email="+data;
                }
            }
          );
          //alert("11");
          return false; 

        }); 
</script>

<script type="text/javascript">
        //Login User
        $('#fp').click(function(event) {
            email=$('#email').val();
         // alert("window.location.pathname");
          $.post(
           'https://www.searchurcollege.com/connection/forget_pass.php?email='+email,
            
            function(data)
            {
                console.log(data);
                if(data=='1')
                {
                    $("#success1").show();
                    setTimeout(function() { $("#success1").hide(); }, 3000);
                }
                else
                if(data=='2')
                {
                    window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                }
                else
                if(data=='3') 
                {
                    window.location.href = "https://www.searchurcollege.com/connection/alert.php";
                }
                else
                {
                    $("#error1").show();
                    setTimeout(function() { $("#error1").hide(); }, 4000);
                }
            }
          );

          return false;   
        }); 
</script>

