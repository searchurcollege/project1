<?php
    include('dbconnect.php');
    $email=strtolower($_REQUEST['email']);
    $password1=$_REQUEST['password1'];
    $password2=$_REQUEST['password2'];
    $phone=$_REQUEST['phone'];
    $first_name=ucwords(strtolower($_REQUEST['first_name']));
    $last_name=ucwords(strtolower($_REQUEST['last_name']));
    $user_name=ucwords(strtolower($first_name)).' '.ucwords(strtolower($last_name));
    $last_qualification=$_REQUEST['last_qualification'];
    $course_interested=$_REQUEST['course_interested'];
    $reference=$_REQUEST['reference'];
    $reference_name=$_REQUEST['reference_name'];
    $sql="SELECT super_cat_id FROM tbl_course_category WHERE category= '$course_interested'";
    $result=$conn->query($sql);
    while($row=$result->fetch_assoc())
    {
        $super_cat_id=$row['super_cat_id'];
    }
    $current_location=$_REQUEST['current_location'];
    $preferred_location=$_REQUEST['preferred_location'];
    $otp=(rand(1000,9999));
    $activation_code=substr(md5(uniqid(rand(), true)), 16, 16);
    $phone_verification=0;
    $email_verification=0;
    $date=date('Y-m-d H:i:s', time());
    $created_on=$date;
    $ip_address=getenv('REMOTE_ADDR');
    $status=1;
 
    $m=0;
    $mno=10;
    $message=array();
    $message[0]='Last Qualification, not Selected';
    $message[1]='Course Intereseted, not Selected';
    $message[2]='First Name could not be emply';
    $message[3]='Last Name could not be emply';
    $message[4]='Email is not valid';
    $message[5]='Password is not valid';
    $message[6]='Password & Confirm Password do not match';
    $message[7]='Contact Number is not valid';
    $message[8]='Current Location is not given';
    $message[9]='Preferred Location is not given';
    $message[10]=1;
    if(strlen($last_qualification)==0)
        {$m++; $mno=0;}
    else
    if(strlen($course_interested)==0)
        {$m++; $mno=1;}
    else
    if(strlen($first_name)==0)
        {$m++; $mno=2;}
    else
    if(strlen($last_name)==0)
        ;//{$m++; $mno=3;}
    else
    if(strlen($email)==0)
        {$m++; $mno=4;}
    else
    if(strlen($password1)==0)
        {$m++; $mno=5;}
    else
    if($password1!=$password2)
        {$m++; $mno=6;}
    else
    if(strlen($phone)<10)
        {$m++; $mno=7;}
    else
    if(strlen($current_location)==0)
        {$m++; $mno=8;}
    else
    if(strlen($preferred_location)==0)
        {$m++; $mno=9;}

    $x=0;
    if($m==0)
    {
        $url = 'http://nimbusit.co.in/api/swsendSingle.asp';
        $msg=$otp.' is your One-Time-Password for mobile verfication. www.searchurcollege.com';
        $url='http://nimbusit.co.in/api/swsendSingle.asp?username=t1searchurcollege&password=ranjay786&sender=SEARCH&sendto='.$phone.'&message='.$msg;
        $sql="SELECT contact FROM users WHERE contact='$phone'";
        $result=$conn->query($sql);
        if($result->num_rows>0)
        {
            $message[10]='Phone number already registered';
            $x++;
        }

        $sql="SELECT email FROM users WHERE email='$email'";
        $result=$conn->query($sql);
        if($result->num_rows>0)
        {
            $message[10]='Email already registered';
            $x++;
        }
    
        if($x==0)
        {
            $premium_amt=$balance_amt=199; 
            //$premium_amt=$balance_amt=0; 
            $sql="INSERT INTO users (user_id, user_name, email, password, contact, first_name, last_name, last_qualification, super_cat_id, course_interested, current_location, preferred_location, reference, reference_name, otp, activation_code, contact_verification, email_verification, premium_amt, balance_amt, ip_address, status) VALUES('$email', '$user_name', '$email', '$password1', '$phone', '$first_name', '$last_name', '$last_qualification', '$super_cat_id', '$course_interested', '$current_location', '$preferred_location', '$reference', '$reference_name', '$otp', '$activation_code', $phone_verification, $email_verification, $premium_amt, $balance_amt, '$ip_address', $status)";
            $result=$conn->query($sql);
            $msg=$otp.' is your One-Time-Password for mobile verfication. www.searchurcollege.com';
            $url='http://nimbusit.co.in/api/swsendSingle.asp?username=t1searchurcollege&password=ranjay786&sender=SEARCH&sendto='.$phone.'&message='.$msg;
            $url=str_replace(" ", '%20', $url);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);

            session_start();
            $_SESSION['user_name']=$first_name;
            $_SESSION['email']=$email;
            $_SESSION['contact']=$contact;
    		$_SESSION['regUsrId']=$email;
    		$_SESSION['stream']=$stream;
            $_SESSION['sid']=$super_cat_id;

            //include('mail_registration.php');
        }
        //$last_id=$conn->insert_id;
        if(isset($_SESSION['partner_id']))
        {
            $partner_id=$_SESSION['partner_id'];
            $chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXY";
            $pass="";
            for($i=0;$i<6;$i++)
                $pass.=$chars[mt_rand(0, strlen($chars)-1)];
            $sql="SELECT partner_referral_code FROM suc_partner_referral_code WHERE partner_id=$partner_id";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
                $partner_referral_code=$row['partner_referral_code'];

            $pass=$phone;
            $sql="UPDATE users SET password='$pass', amt_paid=199, balance_amt=0, reference='Coaching/Tuition', partner_id=$partner_id, referral_code='$partner_referral_code' WHERE email='$email'";
            $result=$conn->query($sql);
            $sql="INSERT INTO suc_partner_users (partner_id, user_id, user_status) VALUES ($partner_id,'$email',1)";
            $result=$conn->query($sql);
            
            //Registration Acknowledgement mail to student
            $signature='Administrator<br />
                <b>SearchUrCollege</b><br />'.$img.'<br />
                B-41, 2nd Floor, Sector-2<br />
                Noida, Uttar Pradesh <small>(INDIA)</small><br />
                <small><i class="fa fa-envelope"></i> <a href="mailto:'.$from.'">'.$from.'</a>
                <i class="fa fa-phone"></i> <a href="tel:+911204750214">+91-120-475 0214</a>
                <i class="fa fa-globe"></i> <a target="_blank" href="https://www.searchurcollege.com">www.searchurcollege.com</a></small><br />';
            $message='Dear '.$first_name.'<br /><br />Your account is registered with us. Thanks for being part of <b>SearchUrCollege</b> community.<br />
                Your login credentials are as follows: <br /><br />
                User: '.$email.'<br />
                Password: '.$pass.'<br /><br />';
            $to=$email;
            $from='admin@searchurcollege.com';
            $from_name='SearchUrCollege';
            $subject='SUC - Login Details';
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'To: '.$to.' <'.$to.'>' . "\r\n";
            $headers .= 'From: '.$from_name.' <'.$from.'>' . "\r\n";
            $headers .= 'Cc: '.$cc . "\r\n";
            
            echo $message;
            // Mail to User
            if(mail($to, $subject, $message.$signature, $headers))
                echo 'Mail Send';
            else
                echo 'Mail Not Send';
        }
    }
    echo $message[$mno];
?>



