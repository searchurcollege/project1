<?php
    $id=$_REQUEST['id'];
    $eid=$_REQUEST['eid'];
    session_start();
    $_SESSION['eid']=$eid;
    if(isset($_SESSION['email']))
    {
        $email=$_SESSION['email'];
        include('dbconnect.php');
        if($id==$_SESSION['sid'])
        {
            $sql="SELECT balance_amt FROM users WHERE email='$email'";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
                $balance_amt=$row['balance_amt'];
            if($balance_amt==0)
            {
                $dt=date('Y-m-d');
                $sql="SELECT COUNT(id) AS count FROM user_exam WHERE user_id='$email' AND SUBSTR(created_at,1,10)='$dt'";
                $result=$conn->query($sql);
                while($row=$result->fetch_assoc())
                    $count=$row['count'];
                if($count>15)
                    $url='4';
                else
                    $url='1';//https://www.searchurcollege.com/exam/start-exam/'.$eid;
            }
            else
                $url='2';//"https://www.searchurcollege.com/connection/pay_now.php";
        }
        else
            $url='3';
    }
    else
        $url='0';///https://www.searchurcollege.com/connection/login.php?eid='.$eid;
    echo $url;
?>
