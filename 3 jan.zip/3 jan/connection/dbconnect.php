<?php
    $servername="localhost";
    $username="searchurcollege";
    $password="Newme7503415202";
    $dbname="searchurcollege_main";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error)
        die("Connection failed: " . $conn->connect_error);
?>
