<?php
    include('header.php');
    include('left.php');
    $email=$_REQUEST["email"];
    $name=$_REQUEST["name"];
    $contact=$_REQUEST["contact"];
    session_start();
    $partner_business_name=$_SESSION['partner_business_name'];
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Student Details
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">  
              <?php echo $name.' ('.$contact.')';?>
          </h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
            <div class="col-md-12">
            <div class="box-body">
              <div class="table-responsive">
              <table id="example1" class="table table-bordered table-striped">
        <thead>
            <tr style="background: orange;">
				<th style="width: 25%;"><center>Last Test given on</center></th>	
				<th style="width: 20%;"><center>Exam Title</center></th>
				<th style="width: 20%;"><center>Test Name</center></th>
				<th style="width: 12%;" ><center>Attemptes</center></th>
				<th style="width: 12%;"><center>Highest Score</center></th>
            </tr>
        </thead>
        <tbody>
								<?php
									//*********************************************************************************************
									// 	#: Get Recent Exam Status
									//*********************************************************************************************

       	                                
										
                                        //$userExm="SELECT count(ue.id),  ue.user_exam_id, ue.total_no_of_ques, ue.time_duration, ue .total_marks, ue.pass_marks, ue.total_attempt, ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,e.exam_exercise_id, e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id='$email' ORDER BY ue.created_at DESC";
                                        $userExm="SELECT count(ue.id),  ue.user_exam_id,e.exam_exercise_id,max(ue.correct_answer),ue.total_no_of_ques, e.exam_name, e.exam_id, max(ue.created_at), ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id='$email'  GROUP BY user_exam_id ORDER BY ue.created_at DESC";
                                        
                                        if ($userExm = $conn->prepare($userExm)) 
										{
										 # echo "jscj";
											$c=0;
                                            $userExm->execute();
											$userExm->store_result();
											$userExm->bind_result($id,$user_exam_id, $exam_exercise_id , $correct_answer,$total_marks,$exam_name, $exam_id, $date, $code);
											while($userExm->fetch()){
												$sql="select q.marks as marks from questions q , user_exam ue where ue.user_exam_id=q.exam_id and ue.user_id='$email' and q.exam_id=$exam_id group by user_exam_id ORDER BY ue.created_at DESC";
									            $result=$conn->query($sql);
									            while($row=$result->fetch_assoc())
									            	$marks=$row['marks'];
									        										
                                                $date=date('d-M-Y H:i',strtotime($date));
												if(empty($exam_name)){
												echo '<tr>
														<td colspan="10">	
															<div class="callout callout-info">
																<h4>No exams have been taken at the moment !</h4>
															</div>
														</td>
													</tr>';
												}
												else{
												   
								?>

								<?php
															$query="select exam_exercise_name , exam_cat_id from cat03_exam_exercise where exam_exercise_id='$exam_exercise_id'";
																$result2=$conn->query($query);
												                while($row2=$result2->fetch_assoc()){
												                	$exercise_name=$row2["exam_exercise_name"];
												                    $cat_id=$row2["exam_cat_id"];
												                }

												                $query="select exam_cat_name   from cat02_exam_category where exam_cat_id='$cat_id'";
																$result2=$conn->query($query);
												                while($row2=$result2->fetch_assoc()){
												                	$cat_name=$row2["exam_cat_name"];
												                	
												                     if(substr($cat_name, 0, 4)=="Othe")
												                     	$cat_name="-";
												                     else
												                     	 $cat_name;
												                    // echo $row2["exam_cat_name"];

												                }
															?>
													<tr class="border_bottom">
														<td align="center"><?php echo $date;?></td>
														
														<td align="center">
															<?php
															
															echo $cat_name;
															?>
														</td>

														<td align="center">
															<?
															echo $exercise_name.'('.$exam_name.")"; 
															?>
														</td>

														

														<?
														$c_ans=$correct_answer*$marks;
														$t_marks=$total_marks*$marks;
														?>
														<td align="center"><?php echo $id;?></td>
														<td align="center"><?php echo $c_ans.' / '.$t_marks ; ?></td>
														
													
														
														
													</tr>
								<?php
												}
                                                $c=$c+$id;
											}
                                            echo '<tr class="border_bottom"><td></td><td></td><td></td><td align="center"><b>'.$c.'</b></td><td></td></tr>';
										}
								?>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>

<script>
$('.chk').on('click', function (e) {
    var id=$(this).attr('id');
    if($(this).prop("checked") == true)
        status=1;
    else
        status=0;
    $.ajax({
        type:'post',
        url:'update_status.php',
        data:'table=md_vendormaster&field=vendor_id&&id= ' + id + '&status='+status
    });
 });
</script>

