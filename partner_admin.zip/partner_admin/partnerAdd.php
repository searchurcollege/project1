<?php
    include('header.php');
    include('left.php');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Vendor
        <span id="success" class="label label-success pull-right" style="display: none; font-size: 70%;">Record Added</span>
        <span id="error1" class="label label-warning pull-right" style="display: none; font-size: 70%;">Record Exists</span>
        <span id="error2" class="label label-warning pull-right" style="display: none; font-size: 70%;">Something went wrong with content/image)</span>
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Add New</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
            <div class="col-md-12">
                <form id="frmvendorAdd" enctype="multipart/form-data" method="POST" class="form-horizontal">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Business Name <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="business_name" placeholder="Business Name" required />
                        </div>
                        <label class="col-sm-2 control-label">Business Category <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <select class="form-control select2" name="cat_id">
                            <?php
                                $result=selectCategories();
                                foreach($result as $row)
                                {
                                    $cat_id=$row['cat_id'];
                                    $cat_name=$row['cat_name'];
                                    echo '<option value='.$cat_id.'>'.$cat_name.'</option>';
                                }
                            ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Address <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="address" placeholder="Address" required />
                        </div>
                        <label class="col-sm-2 control-label">City / Pincode <span class="req">*</span></label>
                        <div class="col-sm-2">
                            <select class="form-control select2" name="city">
                            <?php
                                $result=selectLocation();
                                foreach($result as $row)
                                {
                                    $location_name=$row['location_name'];
                                    if($location_name=='Kaithal')
                                        echo '<option selected value='.$location_name.'>'.$location_name.'</option>';
                                    else
                                        echo '<option value='.$location_name.'>'.$location_name.'</option>';
                                }
                            ?>
                            </select>
                        </div>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" name="pincode" placeholder="Pincode" rrequired />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Contact Person <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="contact_person" placeholder="Contact Person" required />
                        </div>
                        <label class="col-sm-2 control-label">Website </label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="website" placeholder="Website" rrequired />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Email </label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="email" placeholder="Email" rrequired />
                        </div>
                        <label class="col-sm-2 control-label">Phone <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="phone" placeholder="Phone" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label"><a target="_blank" href="https://www.google.com/maps">Google Map</a> Link </label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="google_map_link" placeholder="Google Map Link" />
                        </div>
                        <label class="col-sm-2 control-label"><a target="_blank" href="http://www.mapcoordinates.net/en">Longitude / Latitude</a> </label>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" name="longitude" placeholder="Longitude" rrequired />
                        </div>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" name="latitude" placeholder="Latitude" rrequired />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Vendor Photo <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <div class="imageupload">
                                <div class="file-tab">
                                    <label class="btn btn-default btn-file">
                                        <span>Browse</span>
                                        <input type="file" name="vendor_image" required />
                                    </label>
                                    <button id="remove" type="button" class="btn btn-default">Remove</button>
                                </div>
                            </div>
                        </div>
                        <label class="col-sm-2 control-label">Business Logo <span class="req">*</span></label>
                        <div class="col-sm-4">
                            <div class="imageupload">
                                <div class="file-tab">
                                    <label class="btn btn-default btn-file">
                                        <span>Browse</span>
                                        <input type="file" name="business_logo" required />
                                    </label>
                                    <button id="remove2" type="button" class="btn btn-default">Remove</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-info pull-right">Add Record</button>
                    </div>
                </form>
            </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>

<script type="text/javascript">
    $("#frmvendorAdd").submit(function(e) {
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: "vendorProcess.php?action=add",
            type: "POST",
            data: formData,
            success: function(data) {
                if(data==0)
                {
                    $("#frmvendorAdd").trigger("reset");
                    $("#remove").click();
                    $("#remove2").click();
                    $("#success").show();
                    setTimeout(function() { $("#success").hide(); }, 3000);
                }
                else
                if(data==1)
                {
                    $("#error1").show();
                    setTimeout(function() { $("#error1").hide(); }, 3000);
                }
                else
                {
                    $("#error2").show();
                    setTimeout(function() { $("#error2").hide(); }, 3000);
                }
            },
            cache: false,
            contentType: false,
            processData: false
        });
        e.preventDefault();
    });
</script>



