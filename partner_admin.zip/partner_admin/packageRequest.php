<?php
    include('header.php');
    include('left.php');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Package
        <span id="success" class="label label-success pull-right" style="display: none; font-size: 70%;">Record Added</span>
        <span id="error1" class="label label-warning pull-right" style="display: none; font-size: 70%;">Record Exists</span>
        <span id="error2" class="label label-warning pull-right" style="display: none; font-size: 70%;">Something went wrong with content/image)</span>
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Packages</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <br /><br />
        <?php
            if($_SESSION['partner_email']!='searchurcollege@gmail.com')
            {
                echo '<div class="box-body" id="raise1" style="background: lightgrey;">
                    <div class="col-md-12">
                        <center>
                        <form id="frmPackageAdd" method="POST">
                        <div class="form-group">
                            <label class="col-sm-2 control-label text-right">Request for a new Package</label>
                            <div class="col-sm-2">
                                <input type="number" class="form-control" id="nou" name="nou" min="5" value="20" placeholder="Number of Students" required />
                            </div>
                            <div class="col-sm-2">
                                <button type="submit" class="btn btn-success">Raise Request</button>
                            </div>
                        </div>
                        </form>
                        </center>
                    </div>
                </div>';
            }
        ?>
        <div class="box-body">
            <div class="col-md-12">
            <center>
                <button class="btn btn-danger" style="display: none;" id="raise2" onclick='window.location.reload();' title="Reload"><i class="fa fa-refresh"></i></button>
            </center>
            <div class="box-body">
              <div class="table-responsive">
              <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr style="background: orange;">
                    <th width="3%">Sr</th>
                    <th><center>Request Date</center></th>
                <?php
                    if($_SESSION['partner_email']=='searchurcollege@gmail.com')
                        echo '<th>Partner Name</th>';
                ?>
                    <th><center>Referral Code</center></th>
                    <th><center>Usage Limit</center></th>
                    <th><center>Consumed</center></th>
                    <th><center>Valid Till</center></th>
                    <th><center>Status</center></th>
                </tr>
              </thead>
              <tbody>
              <?php
                if($_SESSION['partner_email']!='searchurcollege@gmail.com')
                {
                    $partner_id=$_SESSION['partner_id'];
                    $sql="SELECT id, created_dt, partner_id, partner_referral_code, partner_no_of_users, referral_code_status FROM suc_partner_referral_code WHERE partner_id=$partner_id ORDER BY created_by DESC";
                }
                else
                    $sql="SELECT id, created_dt, partner_id, partner_referral_code, partner_no_of_users, referral_code_status FROM suc_partner_referral_code ORDER BY created_by DESC";
                $result=$conn->query($sql);
                $i=1;
                while($row=$result->fetch_assoc())
                {
                    $id=$row['id'];
                    $created_date=date('d-M-Y H:m:i',strtotime($row['created_dt']));
                    $partner_id=$row['partner_id'];
                    $partner_referral_code=$row['partner_referral_code'];
                    $partner_no_of_users=$row['partner_no_of_users'];
                    $referral_code_status=$row['referral_code_status'];
                    $date=strtotime($row['created_dt']);
                    $valid_till=date('d-M-Y',strtotime("+364 days",$date));
                    $sql2="SELECT COUNT(partner_id) AS count FROM users WHERE partner_id=$partner_id AND referral_code='$partner_referral_code'";
                    $result2=$conn->query($sql2);
                    while($row2=$result2->fetch_assoc())
                        $count=$row2["count"];
                    if($_SESSION['partner_email']=='searchurcollege@gmail.com')
                    {
                        $sql2="SELECT partner_business_name FROM suc_partners WHERE partner_id=$partner_id";
                        $result2=$conn->query($sql2);
                        while($row2=$result2->fetch_assoc())
                            $partner_business_name=$row2["partner_business_name"];
                    }
                    echo '<tr>
                    <td>'.$i.'</th>
                    <td><center>'.$created_date.'</center></td>';
                    if($_SESSION['partner_email']=='searchurcollege@gmail.com')
                        echo '<td>'.$partner_business_name.'</td>';
                    echo '<td><center>'.$partner_referral_code.'</center></td>
                    <td><center>'.$partner_no_of_users.'</center></td>
                    <td><center>'.$count.'</center></td>
                    <td><center>'.$valid_till.'</center></td>';
                    if($_SESSION['partner_email']=='searchurcollege@gmail.com')
                    {
                        if($referral_code_status==1)
                        {
                            $referral_code_status='<label class="switch">
                                    <input  type="checkbox" class="chk" checked name="status" id="'.$id.'">
                                    <span title="Status On/OFF" class="slider round"></span>
                                  </label>';
                        }
                        else
                        {
                            $referral_code_status='<label class="switch">
                                    <input type="checkbox" class="chk" name="status" id="'.$id.'">
                                    <span title="Status On/OFF" class="slider round"></span>
                                  </label>';
                        }
                        echo '<td><center>'.$referral_code_status.'</center></td>';
                    }
                    else
                    {
                        if($referral_code_status==0)
                            echo '<td><center style="color: red;">Inactive</center></td>';
                        else
                            echo '<td><center>Active</center></td>';
                    }
                    echo '</tr>';
                    $i++;
                }
               ?>  
               </tbody>
               </table>
              </div>
            </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>
<script>
$('.chk').on('click', function (e) {
    var id=$(this).attr('id');
    if($(this).prop("checked") == true)
        status=1;
    else
        status=0;
    $.ajax({
        type:'post',
        url:'update_status.php',
        data:'table=suc_partner_referral_code&field=id&id= ' + id + '&status='+status
    });
 });
</script>
<script type="text/javascript">
    $("#frmPackageAdd").submit(function(e) {
        var formData = new FormData($(this)[0]);
        var nou=$('#nou').val();
        $.ajax({
            url: "https://www.searchurcollege.com/admin/packageProcess.php?nou="+nou,
            type: "POST",
            success: function(data) {
                if(data==0)
                {
                    alert('Request Forwarded');
                    $("#frmpackageAdd").trigger("reset");
                    $('#nou').val('');
                    $('#raise1').hide();
                    $('#raise2').show();
                    $("#remove").click();
                    $("#remove2").click();
                    $("#success").show();
                    setTimeout(function() { $("#success").hide(); }, 3000);
                }
                else
                if(data==1)
                {
                    $("#error1").show();
                    setTimeout(function() { $("#error1").hide(); }, 3000);
                }
                else
                {
                    $("#error2").show();
                    setTimeout(function() { $("#error2").hide(); }, 3000);
                }
            },
            cache: false,
            contentType: false,
            processData: false
        });
        e.preventDefault();
    });
</script>






