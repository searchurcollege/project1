<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SearchUrCollege.com | Admin Panel</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <!-- Background Animation -->
  <link rel="stylesheet" href="dist/css/style.css" />
  <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
  <script type='text/javascript' src='dist/js/jquery.particleground.js'></script>
  <script type='text/javascript' src='dist/js/demo2.js'></script>
</head>


<body id="particles">
  <div id="intro">
<?php
    session_start();
    if(isset($_SESSION['email']))
    {
        echo '<script>';
        echo 'window.location.replace("dashboard.php");';
        echo '</script>';
    }
?>
<div class="login-box" style="background: white; opacity: 1; border-radius: 10px;">
  <div class="login-logo">
    <img src="images/logo.png" alt="SearchUrCollege_Logo" height="80" /><br />
    <font size="4" color="black"><b>[Admin Area]</font></b>
  </div>
  <div class="login-box-body" style="margin-top: -40px; border-radius: 10px;">
    <p class="login-box-msg" style="font-size: 16px; font-weight: bold;">Login to start the session</p>
    <form id="login" aaction="login_process.php" method="post">
      <div class="form-group has-feedback">
        <input type="email" class="form-control" name="email" placeholder="Email" value="">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" name="password" placeholder="Password" value="">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-12">
            <span id="success" class="pull-left" style="display: none; color: green;"><i class="fa fa-smile-o" style="font-size:20px; margin-top: 8px;"></i> Login Succeeded.</span>
            <span id="error" class="pull-left" style="display: none; color: red; margin-top: 8px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Invalid Credentials</span>
        </div>
        <div class="col-xs-12">
          <button type="submit" class="btn btn-primary btn-block bbtn-flat">Login</button>
        </div>
      </div>
    </form>
  </div>
</div>
  </div>
</div>

<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
<script type="text/javascript">
        $('#login').submit(function(event) {
          $.post(
           'loginProcess.php',
            $(this).serialize(),
            function(data)
            {
                if(data==1)
                {
                    $("#success").show();
                    setTimeout(function() { $("#success").hide(); }, 3000);
                    window.location.replace("dashboard.php");
                }
                else
                {
                    $("#error").show();
                    setTimeout(function() { $("#error").hide(); }, 3000);
                }
            }
          );
          return false;   
        }); 
</script>
  <script type='text/javascript' src='dist/jquery.particleground.js'></script>
  <script type='text/javascript' src='dist/js/demo2.js'></script>

</body>
</html>

