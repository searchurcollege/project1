<?php
    include('dbconnect.php');
    $table=$_REQUEST['table'];
    $field=$_REQUEST['field'];
    $id=$_REQUEST['id'];
    $featured=$_REQUEST['featured'];
    echo $sql="UPDATE $table SET featured=$featured WHERE $field=$id";
    $result=$conn->query($sql);
?>
