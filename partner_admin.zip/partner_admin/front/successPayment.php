<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5;url=https://www.mamretail.com/md/front" />
<title>Meri Deal - Success</title>
<div style="margin-top: 10%; text-align: center;">
    Payment Succeeded, please wait...
    <img src="images/loading.gif" />
</div>

