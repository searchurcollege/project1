<?php include('header.php');?>
<br />
<center><a href="https://www.mamretail.com/md/front"><img src="../images/logo.png" height="50" /></a></center>
<br />
<div class="container">
    <div class="text-center"><h3><b>Forgot Password</b></h3></div>
    <form id="register-form" action="https://www.mamretail.com/md/front/successForgot.php" method="post" role="form" autocomplete="off">
        <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email Address" value="" autocomplete="off" required />
        </div>
        <div class="form-group">
        <div class="row">
        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
        <input type="submit" name="recover-submit" id="recover-submit" tabindex="2" class="form-control btn btn-success" value="Recover Account" />
        </form>
    </div>
</div>

    
    