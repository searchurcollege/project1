<?php include('header.php');?>
<br />
<center><a href="https://www.mamretail.com/md/front"><img src="../images/logo.png" height="50" /></a></center>
<br /><br />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.2/css/star-rating.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.2/js/star-rating.min.js"></script>
<div class="container">
    <form id="rating" action="https://www.mamretail.com/md/front/successRating.php" method="post">
        <center>
            <h4>Rate us:</h4>
            <input id="input-1" name="input-1" class="rating rating-loading" value="5" data-min="0" data-max="5" data-step="0.5" data-size="lg">
            <input type="submit" name="submit" id="submit" tabindex="2" class="btn btn-success" value="Submit" />
        </center>
    </form>
</div>


<script>
//$("#input-id").rating();
</script>


</body>
</html>