<?php include('header.php');?>
<style>
.weekDays-selector input {
  display: none!important;
}

.weekDays-selector input[type=checkbox] + label {
  display: inline-block;
  border-radius: 6px;
  background: #dddddd;
  height: 40px;
  width: 30px;
  margin-right: 3px;
  line-height: 40px;
  text-align: center;
  cursor: pointer;
}

.weekDays-selector input[type=checkbox]:checked + label {
  background: #2AD705;
  color: #ffffff;
}
</style>
<br /><br /><br />
<form action="b.php">
    <div class="weekDays-selector">
        <input type="checkbox" id="weekday-mon" name="weekday[]" value="Mon" class="weekday" />
        <label for="weekday-mon">M</label>
        <input type="checkbox" id="weekday-tue" name="weekday[]" value="Tue" class="weekday" />
        <label for="weekday-tue">T</label>
        <input type="checkbox" id="weekday-wed" name="weekday[]" value="Wed" class="weekday" />
        <label for="weekday-wed">W</label>
        <input type="checkbox" id="weekday-thu" name="weekday[]" value="Thu" class="weekday" />
        <label for="weekday-thu">T</label>
        <input type="checkbox" id="weekday-fri" name="weekday[]" value="Fri" class="weekday" />
        <label for="weekday-fri">F</label>
        <input type="checkbox" id="weekday-sat" name="weekday[]" value="Sat" class="weekday" />
        <label for="weekday-sat">S</label>
        <input type="checkbox" id="weekday-sun" name="weekday[]" value="Sun" class="weekday" />
        <label for="weekday-sun">S</label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
