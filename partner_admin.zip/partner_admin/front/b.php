<?php

    $weekday=$_REQUEST['weekday'];
    foreach($weekday as $w)
    {
        echo '<br />Day= '.$w;
    }

?>