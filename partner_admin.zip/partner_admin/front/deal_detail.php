<?php include('header.php');?>
<?php include('footer.php');?>
<?php
    $deal_id=$_REQUEST['deal_id'];
    $deal_image=$_REQUEST['deal_image'];
?>
<style>
    body { overflow-x: hidden; }
    #confirm
    { 
        position:fixed;
        top: 50%;
        left: 50%;
        width: 300px;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: -15em; /*set to a negative number 1/2 of your width*/
        border: 5px double #5d9bd0;
        background-color: #f3f3f3;
        padding: 30px;
    }
</style>
<div class="jjumbotron text-center" id="about">
  <div id="myCarousel" class="carousel slide text-center" data-ride="carousel" style="margin-top: -5px;">
    <!-- Indicators -->
    <br /><br />
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="<?php echo $deal_image;?>" style="width: 100%; height: 150px; padding: 10px;" />
      </div>
      <div class="item">
        <img src="images/deals_banner1.png" style="width: 100%; height: 150px; padding: 10px;" />
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<!-- Container (About Section) -->
<div class="content" style="padding: 10px;">
<div class="content ccontainer-fluid" style="width: 100%; padding: 10px; border: 1px solid gray; border-radius: 20px;">
    <?php
        $result=selectDeal($deal_id);
        foreach($result as $row)
        {
            $vendor_id=$row['vendor_id'];
            $deal_title=$row['deal_title'];
            $deal_title2=$row['deal_title'];
            $image=$row['image'];
            $coupon_code=$row['coupon_code'];
            $start_date=$row['start_date'];
            $end_date=$row['end_date'];
            $start_date=date('d-M-Y', strtotime($start_date));
            $end_date=date('d-M-Y', strtotime($end_date));
            $actual_price=round($row['actual_price'],0);
            $discount_percent=$row['discount_percent'];
            $discount_amount=$row['discount_amount'];
            $tags=$row['tags'];
            $featured=$row['featured'];
            $tags=$row['tags'];
            $status=$row['status'];
            $deal_description=$row['deal_description'];
            $coupon_instruction=$row['coupon_instruction'];
            $business_name=$row['business_name'];
            $city=$row['city'];
            $business_logo=$row['business_logo'];
            if($discount_percent>0)
                $amount=$actual_price-($actual_price*$discount_percent)/100;
            else
                $amount=$actual_price-$discount_amount;
            $amount_payable=$amount;
            $amount='<i class="fa fa-inr"></i> <span style="color: black;"><strike>'.$actual_price.'</strike></span> <font color="blue">'.$amount.' </font>';
        }
        echo '<h4><img src="../images/vendor/business_logo/'.$business_logo.'" style="float: left; height: 50px; width: 50px; border: 1px dotted gray; border-radius: 50%; margin-right: 10px; margin-top: -10px;" /><span style="color: blue; font-weight: bold;" class="pull-right">'.$amount.'</span><small>'.$business_name.'<br />'.$city.'</small></span></h3>';
        echo '<h3><b style="color: purple">'.$deal_title.'</b></h3>';
        echo '<h4>Decription <i class="fa fa-tag"></i><span class="pull-right"><small>Expiring on: '.$end_date.'</small></span></b></h4><br />';
        echo '<p align="justify">'.$deal_description;
        echo '<br /><br /><small><b>Instructions: </b>'.$coupon_instruction.'</small></p>';
        echo '<span class="pull-right" style="margin-top: -15px; margin-right: 5px;">Share 
          <a class="social-icon facebook" target="blank" data-tooltip="Facebook" href="http://www.facebook.com">
            <i class="fa fa-facebook"></i></a>
          <a class="social-icon twitter" target="blank" data-tooltip="Twitter" href="https://www.twitter.com">
            <i class="fa fa-twitter"></i></a>
          <a class="social-icon google-plus" target="blank" data-tooltip="Google +" href="https://plus.google.com">
            <i class="fa fa-google-plus"></i></a></span>';
    ?>
  
    </div>
    <br /><br />
    <div style="position: fixed; bottom: 10px; width: 95%;">
        <button id="buy" class="btn btn-block" data-toggle="modal" data-target="#myModal" style="background: purple; color: white;"><span class="pull-left">BUY NOW</span><span class="pull-right"><i class="fa fa-inr"></i> <?php echo $amount_payable;?></span></button>
    </div>
    <?php
        echo "<h5><b>More DEALS from this Vendor:</b></h5>";
        $result=selectVendorDealOther($deal_id, $vendor_id);
        $i=0;
        foreach($result as $row)
        {
            $deal_title=$row['deal_title'];
            $image=$row['image'];
            $coupon_code=$row['coupon_code'];
            $start_date=$row['start_date'];
            $end_date=$row['end_date'];
            $start_date=date('d-M-Y', strtotime($start_date));
            $end_date=date('d-M-Y', strtotime($end_date));
            echo '<form action="deal_detail.php" method="post"><div style="background: #FBE8FB; border: 1px dashed black; margin-bottom: 10px; padding: 10px;">';
            echo '<img src="../images/deals/'.$image.'" style="width: 100%; height: 150px; padding: 0px;" />';
                 //<br />
               //<b><center>'.$deal_title.'</b><br /><span style="color: blue; font-weight: bold;">';//.$business_name.'</span><br />'.$amount.'</center>';
            echo '<input type="hidden" name="deal_id" value="'.$deal_id.'">';
            echo '<input type="hidden" name="deal_image" value="../images/deals/'.$image.'">';
            echo '<div sstyle="background: red; pposition: absolute; right: 10px; bottom: 20px; mmargin-top: -10px; ppadding: 5px; wwidth: 30px;">
            </div>';
            echo '</div></form>';

            $i++;
        }
        echo '<br /><br />';
    ?>
</div>
</div>


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog" style="margin-top: 20%;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><b><?php echo $deal_title2;?></b></h4>
        </div>
        <div class="modal-body">
            <?php
                echo '<br /><b><img src="../images/vendor/business_logo/'.$business_logo.'" style="float: left; height: 50px; width: 50px; border: 1px dotted gray; border-radius: 50%; margin-right: 10px; margin-top: -10px;" />';
                echo $business_name.'</b><span class="pull-right">'.$amount.'</span><br /><br /><br />';
            ?>
        </div>
        <div class="modal-footer">
          <a href="https://www.mamretail.com/md/front/payment.php"><button type="button" class="btn btn-default" style="background: purple; color: white;">Confirm Order</button></a>
        </div>
      </div>
      
    </div>
  </div>
  
</div>


<script>
    $('#buy').on('click', function (e) {
        $('#confirm').toggle('slow', function() {
        });
    });
</script>
<script src="http://www.geoplugin.net/javascript.gp"></script>
<script>
    jQuery(document).ready(function($) {
        var city=geoplugin_city();
        $("#address").html("<span style='bbackground: yellow; left: 10px; position: absolute; width: 400px; letter-spacing: 1px;'><i class='material-icons' style='font-size: 18px; margin-top: 7px;'>place</i><span style='position: absolute; margin-top: 10px;'>" + city + "</span></span>");
    });
    //$.get("http://ipinfo.io", function (response) {
    //$("#address").html("<span style='position: absolute; width: 400px;'><i class='material-icons'>place</i>" + response.city + ", " + response.region+"</span>");
    //}, "jsonp");
</script>
</body>
</html>
