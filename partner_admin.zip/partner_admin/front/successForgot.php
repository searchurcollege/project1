<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="3;url=https://www.mamretail.com/md/front" />
<title>Meri Deal - Success</title>
<div style="margin-top: 10%; text-align: center;">
    An Email is sent to your registered email address.
    <br /><br />Please follow the instructions.
    <img src="images/loading.gif" />
</div>

