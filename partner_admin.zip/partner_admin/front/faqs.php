<?php include('header.php');?>
<?php include('footer.php');?>
<br />
<center><a href="https://www.mamretail.com/md/front"><img src="../images/logo.png" height="50" /></a></center>
<h3>FAQs</h3>
<div class="container" style="padding-right: 20px;">
<ol>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0in; line-height: 150%">

                    <b>What is MeriDeal?</b>
                    <br>
                    MeriDeals are incredibly beneficial promotional offers issued by merchants through
                    the website. One deal will be offered each day. This is a limited time, and often
                    limited inventory offer. The first ones to buy get the deal.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>How do I buy a MeriDeal?</b>
                    <br>
                    Its simple. You can view each day's deal on the website and click the buy button.
                    You will be taken to the payment page. Once your deal tips, you will be sent an
                    e-voucher. You can present this to the merchant to claim your offer.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>When is a deal considered as tipped?</b>
                    <br>
                    Every deal has a minimum buyer requirement, once this is met the deal is tipped..

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>
                        How will I get my voucher after I buy a deal and it is
                        tipped?
                    </b>
                    <br>
                    You will get it on your email as well a verified mobile number. You can present
                    this to the merchant along with the identity proof that you entered during the deal
                    purchase process to claim your deal.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>What is the identity proof that I am required to enter?</b>
                    <br>
                    We request you to enter an identity proof along with your purchase so as to ensure
                    maximum security. Your voucher will be valid only with the identity proof, almost
                    all accepted identity proof is accepted on the site.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Can I change the identity proof after I have bought a deal?</b>
                    <br>
                    Unfortunately no. The identity proof has been requested so as to ensure maximum
                    security for your deal. So you will need to produce the same to claim your deal.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Can I use MeriDeal with other offers?</b>
                    <br>
                    Please refer to the details of each deal on the deal page. Unless specified otherwise,
                    MeriDeals can't be clubbed with other promotion.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>What happens if the minimum number of buyers do not buy?</b>
                    <br>
                    If the minimum number of buyers do not buy the deal, the deal will not be tipped
                    and this will be notified to buyers who had bought the deal.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Will I get a refund if the deal does not get closed?</b>
                    <br>
                    Refund for full-payment made will be processed immediately. There might occur a
                    delay of 5 to 7 working days for the payment to be credited to your credit/debit
                    card.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Can I return a MeriDeal?</b>
                    <br>
                    The entire success of MeriDeal is the power of collective buying. Many merchants
                    offer the deal only on a specific number of buys, or have limited merchandise available.
                    As the deal count is important, you can't cancel a bought deal. But if you are
                    not happy with the service or product, you can enter it in the returns page of your
                    my account space. We shall look into it.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>What if the merchant refuses to honour my MeriDeal?</b>
                    <br>
                    Please get in touch with us immediately. We will either help you redeem the voucher
                    as stated in the Deal Terms or give you refund.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>What happens if I can't use the MeriDeal on time?</b>
                    <br>
                    Each MeriDeal has a validity period. Please use this within the time frame. Please
                    get in touch with us if this has happened in spite of your best efforts.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>What are the Deal Terms?</b>
                    <br>
                    Please read the deal terms and fine print thoroughly before you buy any deal. Each
                    merchant has a separate set of rules and policies, deal expiry window, deal terms
                    etc, so please ensure that you have gone through them before you buy any deal.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Is there any charge for joining MeriDeal?</b>
                    <br>
                    No, its absolutely free!

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Is it safe to use credit/debit card for payment on MeriDeal?</b>
                    <br>
                    Yes. We assure safe and secure payment method on MeriDeal. All the data are encoded
                    to protect it from third party access.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Can I gift a voucher to a friend?</b>
                    <br>
                    Oh yes! We do encourage gifts and surprises to friends, unless mentioned 'no
                    gifting' in the conditions. You could still buy the voucher in your name and
                    gift it too.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>Can I exchange my voucher for cash or other items?</b>
                    <br>
                    We are sorry, you cannot exchange your voucher unless the deal 'Terms &amp;
                    Conditions' state otherwise.

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>I like today's deal - how do I get it?</b>
                    <br>
                    Click "BUY" before the offer ends. If the minimum number of people sign
                    up and buy, we'll charge you. If not enough people join, no one gets it (and
                    you won't be charged), so make sure you inform your friends to get the deal!

            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>
                        What happens if a deal doesn't reach its required minimum
                        number of purchasers?
                    </b>
                    <br>
                    If not enough people buy the deal, it gets canceled, and you won't be charged.
                    So if you really want the deal, be sure to inform your friends and make them buy
                    it too.
            </p>
        </li>
        <li>
            <p align="JUSTIFY" style="margin-bottom: 0.14in; line-height: 22px;">

                    <b>I bought a deal- how do I use it?</b>
                    <br>
                    Once you make a payment, you'll receive an email with the e-voucher which can
                    be printed to claim the deal.
            </p>
        </li>
    </ol>
</div>
