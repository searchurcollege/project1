<div style="position: fixed; bottom: 10%; z-index: 10000;">
      <button id="back" class="btn btn-info btn-sm pull-right">
        <i class="fa fa-chevron-circle-left"></i> B a c k
      </button>  
</div>

<script>
    $("#back").click(function(event) {
        event.preventDefault();
        history.back(1);
    });
</script>