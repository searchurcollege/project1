<?php include('header.php');?>
<?php include('footer.php');?>
<br />
<center><a href="https://www.mamretail.com/md/front"><img src="../images/logo.png" height="50" /></a></center>
<br />
<div class="content ccontainer-fluid" style="width: 100%; padding: 10px;">
    <?php
        $result=myTopDeals();
        foreach($result as $row)
        {
            $deal_id=$row['deal_id'];
            $deal_title=$row['deal_title'];
            $image=$row['image'];
            $coupon_code=$row['coupon_code'];
            $start_date=$row['start_date'];
            $end_date=$row['end_date'];
            $start_date=date('d-M-Y', strtotime($start_date));
            $end_date=date('d-M-Y', strtotime($end_date));
            $actual_price=round($row['actual_price'],0);
            $discount_percent=$row['discount_percent'];
            $discount_amount=$row['discount_amount'];
            $tags=$row['tags'];
            $featured=$row['featured'];
            $tags=$row['tags'];
            $status=$row['status'];
            $deal_description=$row['deal_description'];
            $coupon_instruction=$row['coupon_instruction'];
            $business_name=$row['business_name'];
            $city=$row['city'];
            if($discount_percent>0)
                $amount=$actual_price-($actual_price*$discount_percent)/100;
            else
                $amount=$actual_price-$discount_amount;
            $amount_payable_text='<i class="fa fa-inr"></i> <strike>'.$actual_price.'</strike> <font size="4">'.$amount.'/-</font>';
            $amount=substr($deal_description,0,11).'...<br /><i class="fa fa-inr"></i> <strike>'.$actual_price.'</strike> <font color="blue">'.$amount.' </font>';
            echo '<form action="deal_detail.php" method="post"><div style="background: #FBE8FB; border: 1px dashed black; margin-bottom: 10px; padding: 10px;">';
            echo '<img src="../images/deals/'.$image.'" style="width: 100%; height: 150px; padding: 0px;" />';
                 //<br />
               //<b><center>'.$deal_title.'</b><br /><span style="color: blue; font-weight: bold;">';//.$business_name.'</span><br />'.$amount.'</center>';
            echo '<input type="hidden" name="deal_id" value="'.$deal_id.'">';
            echo '<input type="hidden" name="deal_image" value="../images/deals/'.$image.'">';
            echo '<div sstyle="background: red; pposition: absolute; right: 10px; bottom: 20px; mmargin-top: -10px; ppadding: 5px; wwidth: 30px;">
            <button class="btn btn-block btn-sm" style="background: purple; color: white; margin: 0px 10px 0px 0px;">'.$deal_title.' <span style="background: #FBE8FB; color: purple; padding: 8px 5px 5px 5px; border-radius: 10px;">'.$amount_payable_text.'</span></button></div>';
            echo '</div></form>';
        }
    ?>
</div>

<script src="http://www.geoplugin.net/javascript.gp"></script>
<script>
    jQuery(document).ready(function($) {
        var city=geoplugin_city();
        $("#address").html("<span style='bbackground: yellow; left: 10px; position: absolute; width: 400px; letter-spacing: 1px;'><i class='material-icons' style='font-size: 18px; margin-top: 7px;'>place</i><span style='position: absolute; margin-top: 10px;'>" + city + "</span></span>");
    });
    //$.get("http://ipinfo.io", function (response) {
    //$("#address").html("<span style='position: absolute; width: 400px;'><i class='material-icons'>place</i>" + response.city + ", " + response.region+"</span>");
    //}, "jsonp");
    $(".bg").show().delay(3000).fadeOut();
    $("#main").delay(3000).fadeIn(100);
</script>
</body>
</html>
