<?php include('header.php');?>
   <style type="text/css">
        html, body {
            height: 100%;
            margin: 0;
            overflow-x: hidden;
        }
    </style>
<style>
    .bg { 
        background-image: url("images/deals_banner2.png");
        height: 100%;
        width: 110%;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
</style>
<div class="bg">
    <img src="images/loading2.gif" style="position: absolute; margin-top: 50%; margin-left: 20%;" />;
</div>

<div id="main" style="display: none;">
<div class="jjumbotron text-center" id="about">
  <div id="myCarousel" class="carousel slide text-center" data-ride="carousel" style="margin-top: -5px;">
    <!-- Indicators -->
    <br /><br />
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="../images/deals/deal1.jpg" />
      </div>
      <div class="item">
        <img src="../images/deals/deal2.jpg" />
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<!-- Container (About Section) -->
<div class="content ccontainer-fluid" style="width: 100%; padding: 10px;">
    <?php
        $result=selectDeals();
        foreach($result as $row)
        {
            $deal_id=$row['deal_id'];
            $deal_title=$row['deal_title'];
            $image=$row['image'];
            $coupon_code=$row['coupon_code'];
            $start_date=$row['start_date'];
            $end_date=$row['end_date'];
            $start_date=date('d-M-Y', strtotime($start_date));
            $end_date=date('d-M-Y', strtotime($end_date));
            $actual_price=round($row['actual_price'],0);
            $discount_percent=$row['discount_percent'];
            $discount_amount=$row['discount_amount'];
            $tags=$row['tags'];
            $featured=$row['featured'];
            $tags=$row['tags'];
            $status=$row['status'];
            $deal_description=$row['deal_description'];
            $coupon_instruction=$row['coupon_instruction'];
            $business_name=$row['business_name'];
            $city=$row['city'];
            if($discount_percent>0)
                $amount=$actual_price-($actual_price*$discount_percent)/100;
            else
                $amount=$actual_price-$discount_amount;
            $amount_payable_text='<i class="fa fa-inr"></i> <strike>'.$actual_price.'</strike> <font size="4">'.$amount.'/-</font>';
            $amount=substr($deal_description,0,11).'...<br /><i class="fa fa-inr"></i> <strike>'.$actual_price.'</strike> <font color="blue">'.$amount.' </font>';
            echo '<form action="https://www.mamretail.com/md/front/deal_detail.php" method="post"><div style="background: #FBE8FB; border: 1px dashed black; margin-bottom: 10px; padding: 10px;">';
            echo '<img src="../images/deals/'.$image.'" style="width: 100%; height: 150px; padding: 0px;" />';
            echo '<input type="hidden" name="deal_id" value="'.$deal_id.'">';
            echo '<input type="hidden" name="deal_image" value="../images/deals/'.$image.'">';
            echo '<div sstyle="background: red; pposition: absolute; right: 10px; bottom: 20px; mmargin-top: -10px; ppadding: 5px; wwidth: 30px;">
            <button class="btn btn-block btn-sm" style="background: purple; color: white; margin: 0px 10px 0px 0px;">'.$deal_title.' <span style="background: #FBE8FB; color: purple; padding: 8px 5px 5px 5px; border-radius: 10px;">'.$amount_payable_text.'</span></button></div>';
            echo '</div></form>';
        }
    ?>
    <br />
    <button class="btn btn-success btn-sm pull-right">M o r e...</button>
    </div>

<div class="container-fluid bbg-grey">
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-globe logo"></span>
    </div>
    <div class="col-sm-8">
        <div class="col-sm-5" style="text-align: center;">
            <p>Contact us and we'll get back to you.</p>
            <p><span class="glyphicon glyphicon-phone"></span> +91 180010203838</p>
            <p><span class="glyphicon glyphicon-envelope"></span> contact@merideal.com</p>
        </div>
    <div class="col-sm-7">
      <div class="row">
        <form action="https://www.mamretail.com/md/front/successContact.php" method="post">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit">Send</button>
        </div>
      </div>
    </div>
    </form>
  </div>
</div>
</div>
</div>

<script src="http://www.geoplugin.net/javascript.gp"></script>
<script>
    jQuery(document).ready(function($) {
        var city=geoplugin_city();
        $("#address").html("<span style='bbackground: yellow; left: 10px; position: absolute; width: 400px; letter-spacing: 1px;'><i class='material-icons' style='font-size: 18px; margin-top: 7px;'>place</i><span style='position: absolute; margin-top: 10px;'>" + city + "</span></span>");
    });
    //$.get("http://ipinfo.io", function (response) {
    //$("#address").html("<span style='position: absolute; width: 400px;'><i class='material-icons'>place</i>" + response.city + ", " + response.region+"</span>");
    //}, "jsonp");
    $(".bg").show().delay(3000).fadeOut();
    $("#main").delay(3000).fadeIn(100);
</script>
</body>
</html>
