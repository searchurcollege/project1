<?php include('header.php');?>
<?php include('footer.php');?>
<br />
<center><a href="https://www.mamretail.com/md/front"><img src="../images/logo.png" height="50" /></a></center>
<h3>About Us</h3>
<div class="whitebg outer-border col-md-12">
    <p>
        Welcome to <a href="https://www.merideal.com/" style=color:Blue; target="_blank">MeriDeal</a> presenting incredible value in daily deals. Each deal offers great value and savings to the customer.
    </p>
    <h3 width="100%">
    What makes us special?
</h3>
    <p width="100%">
    Each deal from us is specially curated to ensure that it remains unique and
    interesting to the members. Something special, at a really special price. We are
    constantly on the look out for different products or services that can make your
    life more easy, more beautiful. And we use the power of collective buying to get
    the best price possible.
</p>
    <h3 width="100%">
    How does it work?
</h3>
    <p width="100%">
    Its simple, you check out the daily deal on the app, buy the deal, and then spread
    the word to your friends and contact so that the deal can reach its desired number
    to tip.
</p>
    <h3 width="100%">
    How can you reach us?
</h3>
    <p width="100%">
    To know more, reach us at <a href="MailTo:support@merideal.com" style=color:Blue;>support@merideal.com</a>
</p>
</div>
