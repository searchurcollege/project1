<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="3;url=https://www.mamretail.com/md/front" />
<title>Meri Deal - Success</title>
<div style="margin-top: 10%; text-align: center;">
    Thanks for your concern.
    <br /><br />We will get back to you soon.
    <img src="images/loading.gif" />
</div>

