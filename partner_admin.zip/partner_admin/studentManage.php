<?php
    include('header.php');
    include('left.php');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Manage Students
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Manage Students</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
            <div class="col-md-12">
            <div class="box-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered table-striped">
        <thead>
            <tr style="background: orange;">
                <th width="13%">Registered on</th>
                <th><center>Name</center></th>
                <th><center>Email</center></th>
                <th><center>Phone</center></th>
                <th><center>Course</center></th>
                <th><center>Action</center></th>
            </tr>
        </thead>
        <tbody>
        <?php
        $ij=1;
            $count=0;
            if($_SESSION['partner_email']!='searchurcollege@gmail.com')
            {
                $partner_id=$_SESSION['partner_id'];
                $sql="SELECT id, first_name, last_name, email, contact, course_interested, current_location, preferred_location, created_at,balance_amt, token, reference, reference_name, status FROM users where partner_id=$partner_id ORDER BY id DESC";
            }
            else
                $sql="SELECT id, first_name, last_name, email, contact, course_interested, current_location, preferred_location, created_at,balance_amt, token, reference, reference_name, status FROM users ORDER BY id DESC";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
            {
                $id=$row["id"];
                $fname=$row["first_name"];
                $lname=$row["last_name"];
                $name=$fname.' '.$lname;
                $email=$row["email"];
                $contact=$row["contact"];
                $course=$row["course_interested"];
                $c_location=$row["current_location"];
                $p_location=$row["preferred_location"];
                $tkn=$row["token"];
                $date=$row["created_at"];
                $preimum=$row["balance_amt"];
                $ref=$row["reference"];
                $ref_name=$row["reference_name"];
                $status=$row["status"];
                echo '
                    <td aalign="center">'.$date.'</td>
                    <td aalign="center">'.ucwords(strtolower($name)).'</td>
                    <td aalign="center">'.$email.'</td>
                    <td aalign="center">'.$contact.'</td>
                    <td aalign="center">'.$course.'</td>
                    <td align="center" valign="middle">';
                   $ij++;
                if($status==1)
                {
                    $status='<label class="switch">
                            <input  type="checkbox" class="chk" checked name="status" id="'.$id.'">
                            <span title="Status On/OFF" class="slider round"></span>
                          </label>';
                }
                else
                {
                    $status='<label class="switch">
                            <input type="checkbox" class="chk" name="status" id="'.$id.'">
                            <span title="Status On/OFF" class="slider round"></span>
                          </label>';
                }
                echo $status.'</td>
                </tr>';
            }
        
        ?>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>

<script>
$('.chk').on('click', function (e) {
    var id=$(this).attr('id');
    if($(this).prop("checked") == true)
        status=1;
    else
        status=0;
    $.ajax({
        type:'post',
        url:'update_status.php',
        data:'table=users&field=id&id= ' + id + '&status='+status
    });
 });
</script>
<script>
$(document).ready(function() {
    $('#example').DataTable( {
    aaSorting: [0, 'desc'],
    });
});
</script>


