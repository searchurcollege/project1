  <style>
    .info-box-text {font-weight: bold;}
  </style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Admin Dashboard
      </h1>
    </section>

    <!-- Main content -->
    <section class="content start">
        <div class="row">
        <div class="col-md-4 col-sm-12 col-xs-12">
          <a href="studentManage.php"><div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-users"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Total Students</span>
              <?php
                $partner_id=$_SESSION['partner_id'];
                $sql="SELECT COUNT(partner_id) AS count FROM suc_partner_users WHERE partner_id=$partner_id";
                $result=$conn->query($sql);
                while($row=$result->fetch_assoc())
                    $count1=$row["count"];
              ?>
              <span class="info-box-number"><?php echo $count1;?></span>
              <div class="text-right"><a href="studentAdd.php">Register New</a></div>
            </div>
          </div></a>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <a href="#"><div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-qrcode"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Total Packages</span>
              <?php
                $sql="SELECT COUNT(partner_id) AS count FROM suc_partner_referral_code WHERE partner_id=$partner_id";
                $result=$conn->query($sql);
                while($row=$result->fetch_assoc())
                    $count2=$row["count"];
              ?>
              <span class="info-box-number"><?php echo $count2;?></span>
              <div class="text-right"><a href="packageRequest.php">Request New</a></div>
            </div>
          </div></a>
        </div>
        <div class="clearfix visible-sm-block"></div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <a href="#"><div class="info-box">
            <span class="info-box-icon bg-blue"><i class="fa fa-code-fork"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Total Partners</span>
              <?php
                    $sql="SELECT partner_no_of_users FROM suc_partners WHERE partner_id=$partner_id";
                    $result=$conn->query($sql);
                    while($row=$result->fetch_assoc())
                    {
                        $partner_no_of_users=$row['partner_no_of_users'];
                    }
              ?>
              <span class="info-box-number">--<!--3 / <?php echo $partner_no_of_users;?>--></span>
              <div class="text-right"><a href="#">View</a></div>
            </div></a>
          </div>
        </div>
      </div>

        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Registrations <small>(Past 3 months) <font color="red">*dummy data</font></small></h3>
                        <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div id="chart1" style="height: 250px;"></div>
            </div>
        </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Test Attempts <small>(Past 3 months) <font color="red">*dummy data</a></small></h3>
                        <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div id="chart2" style="height: 250px;"></div>
            </div>
        </div>
    </div>

      <!-- RECENT REGISTRATIONS -->
      <div class="row">
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Recent Registrations <small><font color="green">* real-time data</font></small></h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <ul class="products-list product-list-in-box">
                <?php
                    $sql="SELECT id,first_name, last_name, email, contact, course_interested, current_location, preferred_location, created_at,balance_amt ,token, reference, reference_name FROM users ORDER BY id DESC LIMIT 2";
                    $result=$conn->query($sql);
                    while($row=$result->fetch_assoc())
                    {
                        $id=$row["id"];
                        $fname=$row["first_name"];
                        $lname=$row["last_name"];
                        $name=$fname.' '.$lname;
                        $contact=$row["contact"];
                        $course=$row["course_interested"];
                        $c_location=$row["current_location"];
                        $date=$row["created_at"];
                        $date=date('d-M-Y',strtotime($date));
                        echo '<li class="item">
                            <div class="product-img">
                                <img src="images/user.png" style="height: 50px; width: 50px; border-radius: 50%; margin-right: 10px;" />
                            </div>
                            <div class="product-info">
                                <a href="" class="product-title"><b>'.$name.' ('.$course.')</b></a><span class="pull-right" style="color: gray;">Joined: '.$date.'</span>
                                <div style="color: gray; position: absolute;" class="text-left"><i class="fa fa-phone"></i> <font color="black">'.$contact.'</u></div>
                                <div style="color: gray" class="text-right"><i class="fa fa-map-marker"></i> <font color="black">'.$c_location.'</u></div>
                            </div>
                        </li>';
                    }
                ?>
              </ul>
            </div>
            <!-- /.box-body -->
            <div class="box-footer text-center">
              <a href="studentList.php" class="uppercase">View All</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div> 
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Top Performers <small><font color="red">*dummy data</font></small></h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <ul class="products-list product-list-in-box">
                <li class="item">
                    <div class="product-img">
                        <img src="images/user.png" style="height: 50px; width: 50px; border-radius: 50%; margin-right: 10px;" />
                    </div>
                    <div class="product-info">
                        <a href="" class="product-title"><b>Anurag Jain</b></a><span class="pull-right" style="color: gray;">CAT-2018</span>
                        <div style="color: gray; position: absolute;" class="text-left"><i class="fa fa-phone"></i> <font color="black">9810290233</u></div>
                        <div style="color: gray" class="text-right"><i class="fa fa-pencil"></i> <font color="black">Scored: 62 / 100</u></div>
                    </div>
                </li>
                <li class="item">
                    <div class="product-img">
                        <img src="images/user.png" style="height: 50px; width: 50px; border-radius: 50%; margin-right: 10px;" />
                    </div>
                    <div class="product-info">
                        <a href="" class="product-title"><b>Divya</b></a><span class="pull-right" style="color: gray;">CAT-2018</span>
                        <div style="color: gray; position: absolute;" class="text-left"><i class="fa fa-phone"></i> <font color="black">9910050392</u></div>
                        <div style="color: gray" class="text-right"><i class="fa fa-pencil"></i> <font color="black">Scored: 56 / 100</u></div>
                    </div>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
            <br />
            <div class="box-footer text-center">
              <a href="#" class="uppercase">View All</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
      </div>


    </section>
    <!-- /.Main content -->
  </div>
  <!-- /.content-wrapper -->

<?php include('footer.php');?>


<script>
    new Morris.Line({
      // ID of the element in which to draw the chart.
      element: 'chart1',
      // Chart data records -- each entry in this array corresponds to a point on
      // the chart.
      data: [
        { year: '2018', value: 20 },
        { year: '2017', value: 10 },
      ],
      // The name of the data record attribute that contains x-values.
      xkey: 'year',
      // A list of names of data record attributes that contain y-values.
      ykeys: ['value'],
      // Labels for the ykeys -- will be displayed when you hover over the
      // chart.
      labels: ['Value']
    });

    new Morris.Line({
      // ID of the element in which to draw the chart.
      element: 'chart2',
      // Chart data records -- each entry in this array corresponds to a point on
      // the chart.
      data: [
        { year: '2018-07', value: 1 },
        { year: '2018-08', value: 12 },
        { year: '2018-09', value: 17 },
        { year: '2018-10', value: 19 },
        { year: '2018-11', value: 25 },
        { year: '2018-12', value: 45 },
      ],
      // The name of the data record attribute that contains x-values.
      xkey: 'year',
      // A list of names of data record attributes that contain y-values.
      ykeys: ['value'],
      // Labels for the ykeys -- will be displayed when you hover over the
      // chart.
      labels: ['Value']
    });
</script>