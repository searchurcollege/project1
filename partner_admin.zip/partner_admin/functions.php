<?php
    include('dbconnect.php');
    global $created_by;
    function authentication($email,$password)
    {
        global $conn;
        $sql="SELECT partner_id, partner_business_name, partner_email, partner_phone, partner_banner, partner_address, partner_location FROM suc_partners WHERE partner_email='$email' AND partner_login_password='$password'";
        $result=$conn->query($sql);
        if($result->num_rows>0)
        {
            echo "1";
            while($row=$result->fetch_assoc())
            {
                $partner_id=$row["partner_id"];
                $partner_business_name=$row["partner_business_name"];
                $partner_location=$row["partner_location"];
                session_start();
                $_SESSION['partner_id']=$partner_id;
                $_SESSION['partner_email']=$email;
                $_SESSION['partner_business_name']=$partner_business_name;
                $_SESSION['partner_location']=$partner_location;
            }
        }
        else
            echo "0";
    }
    function selectCity()
    {
        include('dbconnect.php');
        $sql="SELECT * FROM location";
        $result=$conn->query($sql);
        if($result->num_rows>0)
            return($result);
        else
            return(0);
    }
	function selectLocation()
    {
        global $conn;
        $sql="SELECT location_id, location_name, state, longitude, latitude FROM md_locationmaster GROUP BY location_name";
		$result=$conn->query($sql);
		return($result);
    }
	function selectState()
    {
        global $conn;
        $sql="SELECT state FROM md_locationmaster GROUP BY state";
		$result=$conn->query($sql);
		return($result);
    }
    function selectCourse()
    {
        global $conn;
        $sql="SELECT id, course_master_name FROM tbl_course_master";
        $result=$conn->query($sql);
        if($result->num_rows>0)
            return($result);
        else
            return(0);
    }


	function selectCategories()
    {
        global $conn;
        $sql="SELECT cat_id, cat_name, created_on, image, status FROM md_categorymaster";
		$result=$conn->query($sql);
		return($result);
    }
	function selectCategory($id)
    {
        global $conn;
        $sql="SELECT cat_id, cat_name, created_on, image, status FROM md_categorymaster WHERE cat_id=$id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectsubCategories()
    {
        global $conn;
        $sql="SELECT a.cat_id, a.cat_name, b.subcat_id, b.subcat_name, b.image, b.created_on, b.status FROM md_categorymaster a JOIN md_subcategorymaster b ON a.cat_id=b.cat_id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectsubCategory($id)
    {
        global $conn;
        $sql="SELECT a.cat_id, a.cat_name, b.subcat_id, b.subcat_name, b.image, b.created_on, b.status FROM md_categorymaster a JOIN md_subcategorymaster b ON a.cat_id=b.cat_id WHERE subcat_id=$id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectDeals()
    {
        global $conn;
        $sql="SELECT a.deal_id, a.deal_title, a.image, a.coupon_code, a.start_date, a.end_date, a.actual_price, a.discount_percent, a.discount_amount, a.featured, a.tags, a.created_on, a.status, a.deal_description, a.coupon_instruction, a.vendor_id, b.business_name, b.city FROM md_dealmaster a JOIN md_vendormaster b ON a.vendor_id=b.vendor_id ORDER BY a.featured DESC";
		$result=$conn->query($sql);
		return($result);
    }
	function selectDeal($id)
    {
        global $conn;
        $sql="SELECT a.deal_id, a.deal_title, a.image, a.coupon_code, a.start_date, a.end_date, a.actual_price, a.discount_percent, a.discount_amount, a.featured, a.tags, a.created_on, a.status, a.deal_description, a.coupon_instruction, a.vendor_id, b.business_name, b.city, b.business_logo FROM md_dealmaster a JOIN md_vendormaster b ON a.vendor_id=b.vendor_id WHERE a.deal_id=$id";
		$result=$conn->query($sql);
		return($result);
    }
	function myTopDeals()
    {
        global $conn;
        $sql="SELECT a.deal_id, a.deal_title, a.image, a.coupon_code, a.start_date, a.end_date, a.actual_price, a.discount_percent, a.discount_amount, a.featured, a.tags, a.created_on, a.status, a.deal_description, a.coupon_instruction, a.vendor_id, b.business_name, b.city FROM md_dealmaster a JOIN md_vendormaster b ON a.vendor_id=b.vendor_id WHERE a.featured=1 ORDER BY a.featured DESC";
		$result=$conn->query($sql);
		return($result);
    }
	function selectVendorDealOther($deal_id, $vendor_id)
    {
        global $conn;
        $sql="SELECT a.deal_id, a.deal_title, a.image, a.coupon_code, a.start_date, a.end_date, a.actual_price, a.discount_percent, a.discount_amount, a.featured, a.tags, a.created_on, a.status, a.deal_description, a.coupon_instruction, b.business_name, b.city, b.business_logo FROM md_dealmaster a JOIN md_vendormaster b ON a.vendor_id=b.vendor_id WHERE b.vendor_id=$vendor_id AND a.deal_id!=$deal_id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectAds()
    {
        global $conn;
        $sql="SELECT a.ad_id, a.ad_title, a.ad_image, a.start_date, a.end_date, a.link_with, a.sort_order, a.status, b.business_name FROM md_admaster a JOIN md_vendormaster b ON a.vendor_id=b.vendor_id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectAd($id)
    {
        global $conn;
        $sql="SELECT a.ad_id, a.ad_title, a.ad_image, a.start_date, a.end_date, a.link_with, a.sort_order, a.status, b.business_name FROM md_admaster a JOIN md_vendormaster b ON a.vendor_id=b.vendor_id WHERE a.ad_id=$id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectVendors()
    {
        global $conn;
        $sql="SELECT a.vendor_id, a.cat_id, b.cat_name, a.business_name, a.contact_person, a.city, a.phone, a.vendor_image, a.business_logo, a.status FROM md_vendormaster a JOIN md_categorymaster b ON b.cat_id=a.cat_id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectVendor($id)
    {
        global $conn;
        $sql="SELECT a.vendor_id, a.cat_id, b.cat_name, a.business_name, a.contact_person, a.city, a.phone, a.vendor_image, a.business_logo, a.status FROM md_vendormaster a JOIN md_categorymaster b ON b.cat_id=a.cat_id WHERE a.vendor_id=$id";
		$result=$conn->query($sql);
		return($result);
    }
	function selectCustomers()
    {
        global $conn;
        $sql="SELECT customer_id, customer_name, address, city, email, phone, customer_image, created_on, status FROM md_customermaster";
		$result=$conn->query($sql);
		return($result);
    }
	function selectCustomer($id)
    {
        global $conn;
        $sql="SELECT customer_id, customer_name, address, city, email, phone, customer_image, created_on, status FROM md_customermaster WHERE customer_id=$id";
		$result=$conn->query($sql);
		return($result);
    }

    //Count Deals
	function countDeals()
    {
        global $conn;
        $sql="SELECT COUNT(deal_id) AS deals FROM md_dealmaster";
		$result=$conn->query($sql);
		return($result);
    }
    //Count Ads
	function countAds()
    {
        global $conn;
        $sql="SELECT COUNT(ad_id) AS ads FROM md_admaster";
		$result=$conn->query($sql);
		return($result);
    }
    //Count Vendors
	function countVendors()
    {
        global $conn;
        $sql="SELECT COUNT(vendor_id) AS vendors FROM md_vendormaster";
		$result=$conn->query($sql);
		return($result);
    }
    //Count Customers
	function countCustomers()
    {
        global $conn;
        $sql="SELECT COUNT(customer_id) AS customers FROM md_customermaster";
		$result=$conn->query($sql);
		return($result);
    }
    //Count Locations
	function countLocations()
    {
        global $conn;
        $sql="SELECT COUNT(location_id) AS locations FROM md_locationmaster";
		$result=$conn->query($sql);
		return($result);
    }
    //Count Categories
	function countCategories()
    {
        global $conn;
        $sql="SELECT COUNT(cat_id) AS categories FROM md_categorymaster";
		$result=$conn->query($sql);
		return($result);
    }
    //Count Sub-Categories
	function countsubCategories()
    {
        global $conn;
        $sql="SELECT COUNT(subcat_id) AS subcategories FROM md_subcategorymaster";
		$result=$conn->query($sql);
		return($result);
    }

	function topDeals()
    {
        global $conn;
        $sql="SELECT deal_id, deal_title, image, coupon_code, start_date, end_date FROM md_dealmaster ORDER BY deal_title LIMIT 3";
		$result=$conn->query($sql);
		return($result);
    }
	function topVendors()
    {
        global $conn;
        $sql="SELECT vendor_id, contact_person, vendor_image, business_name, business_logo, city, phone FROM md_vendormaster ORDER BY vendor_id DESC LIMIT 3";
		$result=$conn->query($sql);
		return($result);
    }
	function topCustomers()
    {
        global $conn;
        $sql="SELECT customer_id, customer_name, customer_image, phone, city, created_on FROM md_customermaster ORDER BY customer_id DESC LIMIT 3";
		$result=$conn->query($sql);
		return($result);
    }

    function getIP()
    {
        if(!empty($_SERVER['HTTP_CLIENT_IP']))
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else
            $ip = $_SERVER['REMOTE_ADDR'];
        return $ip;
    }
?>
