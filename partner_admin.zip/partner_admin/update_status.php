<?php
    include('dbconnect.php');
    $table=$_REQUEST['table'];
    $field=$_REQUEST['field'];
    $id=$_REQUEST['id'];
    $status=$_REQUEST['status'];
    echo $sql="UPDATE $table SET status=$status WHERE $field=$id";
    $result=$conn->query($sql);
?>
