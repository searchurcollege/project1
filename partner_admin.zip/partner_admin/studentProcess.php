<?php
    session_start();
    $created_by=$_SESSION['partner_email'];
    if(isset($_REQUEST['action']))
    {
        $action=$_REQUEST['action'];
        if($action=='add')
        {
            /*$k="";
            $v="";
            foreach ($_POST as $key => $value)
            {
              $k.=$key.", ";
              $v.="'".$value."', ";
            }
            $k=rtrim($k,', ');
            $v=rtrim($v,', ');
            $tbl_name='users';//$_REQUEST["table_name"];
            $sql ="INSERT INTO $tbl_name(".$k.") VALUES (".$v.")" ;
            if($conn->query($sql) == TRUE)
               echo 1;
            else
            echo 0;*/
        }
    }
?>