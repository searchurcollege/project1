	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header.php'); 
	?>
		<style>
			#border-bottom{
				border-bottom:1px solid #ff6300;
				margin-bottom:10px;
			}		
		</style>

		<div class="row row-eq-height">
			
			<div class="col-md-2 col-xs-12 left-sidebar"> 
		
				<?php require_once(__ROOT__.'/includes/sidebar.php'); ?>
				
			</div>
			
		
			<div class="col-md-10 col-xs-12  div-content"> 
			
				<!-- Content Header (Page header) -->
				<div id="contentHeader">
				
					<h4><i class="fa fa-file"></i> <b style="color: skyblue;">My Exam</b></h4>
				</div>					
                <style>
                    .box2
                    {
                        padding: 10px!important;
                        margin: 10px!important;
                    }
                </style>
				<div class="col-md-12 col-xs-12">
                    <?php
                        if(isset($_REQUEST['tn']))
                        {
                            $tn=$_REQUEST['tn'];
                        	$stm5="SELECT exam_id, exam_name, description FROM exam WHERE status=1 AND exam_name='$tn'";
                            if ($stm5 = $myconn->prepare($stm5)) 
                        	{
                        		$stm5->execute();
                        		$stm5->store_result();
                        		$stm5->bind_result($exam_id, $exam_name, $description);
                                $i=0;
                        		while($stm5->fetch()>0)
                                {
                                    echo '<a href="'.BASE_URL.'start-exam/'.$exam_id.'" style="color: white;"><button class="btn btn-primary btn-md box2">'.$exam_name.'</button></a>';
                                    $i++;
                                }
                                if($i>0)
                                {
                                	$stm1="SELECT super_cat_id, super_cat_name, super_cat_description FROM cat00_super_category WHERE super_cat_status=1 ORDER by super_cat_id asc limit 100";
                                	if ($stm1 = $myconn->prepare($stm1)) 
                                	{
                                		$stm1->execute();
                                		$stm1->store_result();
                                		$stm1->bind_result($super_cat_id, $super_cat_name, $super_cat_description);
                                		while($stm1->fetch()>0)
                                        {
                                            echo '<a href="'.BASE_URL.'exam/l2.php?scid='.$super_cat_id.'&n1='.$super_cat_name.'" style="color: white;"><button class="btn btn-primary btn-md box2">'.$super_cat_name.'</button></a>';
                                            ?>
                                                <script>window.location="<?php echo BASE_URL.'start-exam/'.$exam_id;?>"</script>
                                            <?php
                                        }
                                    }
                                }
                                else
                                ?>
                                    <script>
                                        alert('Test not found');
                                        history.go(-1);
                                    </script>
                                <?php
                            }
                        }
                        else
                        {
                        	$stm1="SELECT super_cat_id, super_cat_name, super_cat_description FROM cat00_super_category WHERE super_cat_status=1 ORDER by super_cat_id asc limit 100";
                        	if ($stm1 = $myconn->prepare($stm1)) 
                        	{
                        		$stm1->execute();
                        		$stm1->store_result();
                        		$stm1->bind_result($super_cat_id, $super_cat_name, $super_cat_description);
                        		while($stm1->fetch()>0)
                                {
                                    echo '<a href="'.BASE_URL.'exam/l2.php?scid='.$super_cat_id.'&n1='.$super_cat_name.'" style="color: white;"><button class="btn btn-primary btn-md box2">'.$super_cat_name.'</button></a>';
                                    ?>
                                        <script>window.location="<?php echo BASE_URL.'start-exam/'.$exam_id;?>"</script>
                                    <?php
                                }
                            }
                        }
                        echo '</ul></li>';
                    ?>
				</div>
			</div>				

		</div>

		<?php require_once(__ROOT__.'/includes/footer.php');?>