	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/header.php'); 
	?>
	<div class="container middlecontent" style="background:#fff">

		<div class="col-xs-12">		
						
			<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
				<!--**********************************************************************************************
				// 		#1: Geet Exam Exercise Name 
				  --********************************************************************************************** -->
					<?php
						$exam_cat_id=$_REQUEST['examCatID'];
						$stm1="SELECT ex.exam_exercise_id,ex.exam_exercise_name, e.exam_cat_name, e.exam_cat_description
								FROM cat03_exam_exercise ex, cat02_exam_category e  WHERE e.exam_cat_id=ex.exam_cat_id AND e.exam_cat_id=?";
						if ($stm1 = $myconn->prepare($stm1)) 
						{
							$stm1->bind_param('i', $exam_cat_id);
							$stm1->execute();
							$stm1->store_result();
							$stm1->bind_result($exam_exercise_id,$exam_exercise_name,$exam_cat_name,$exam_cat_description);
							$flag=1;
							while($stm1->fetch()>0){
								if(!empty($flag)){
					?>
							<h4><strong><?php echo $exam_cat_name; ?><strong></h4>
							<p><?php echo $exam_cat_description; ?></p>
					<?php
								$flag=0;
								}
					?>
							<div class="panel panel-default">
							
								<div class="panel-heading" role="tab" id="heading<?php echo $exam_exercise_id;?>" style="background:#ffa066; color:#fff;">
									<h4 class="panel-title">
										<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $exam_exercise_id;?>" aria-expanded="true" aria-controls="collapse<?php echo $exam_exercise_id;?>">
											<i class="more-less glyphicon glyphicon-plus pull-right"></i>
											<?php echo $exam_exercise_name;?>
										</a>
									</h4>
								</div>
								
								<div id="collapse<?php echo $exam_exercise_id;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo $exam_exercise_id;?>">
									<div class="panel-body">
										<?php
											$stm2="SELECT exam_id, no_of_question,type,price,available_from,available_to,exam_name,description FROM exam WHERE exam_exercise_id=?";
											if ($stm2 = $myconn->prepare($stm2)) 
											{
												$stm2->bind_param('i', $exam_exercise_id);
												$stm2->execute();
												$stm2->store_result();
												$stm2->bind_result($exam_id,$no_of_question,$type,$price,$available_from,$available_to,$exam_name,$description);
												while($stm2->fetch()>0){
											?>
											        <div class="promoDiv">
														<label>
															<p><?php echo $exam_name;?></p>
															 No Of Quest : <?php echo $no_of_question;?> | 
															Sart Form :<?php echo $available_from;?>  To: <?php echo $available_to;?> | 
															<?php if(empty($price)){echo 'FREE';}else{echo $price;}?>
															
														<?php
															if(empty($_SESSION['regUserID'])){
														?>

																<a href="#" id="login_link" class="btn toggle-modal" data-toggle="modal" data-target="#myModal"><span class="btn-with-zomm">Start Exam</span></a>
														<?php
															}
															else{
														?>
																<a href="#" id="login_link" class="btn toggle-modal" data-toggle="modal" data-target="#myModal"><span class="btn-with-zomm">Start Exam</span></a>								
														<?php
															}
														?>
														</label>
													</div>
											<?php
												}
											}
										?>
									</div>
								</div>
								
							</div>	
					<?php
							}
						}
						?>
			</div><!-- panel-group -->	
			
		</div><!-- container -->

	</div>
	
	<?php require_once(__ROOT__.'/includes/login_footer.php');?>
	<script>
	function toggleIcon(e) {
    $(e.target)
        .prev('.panel-heading')
        .find(".more-less")
        .toggleClass('glyphicon-plus glyphicon-minus');
	}
	$('.panel-group').on('hidden.bs.collapse', toggleIcon);
	$('.panel-group').on('shown.bs.collapse', toggleIcon);
	</script>