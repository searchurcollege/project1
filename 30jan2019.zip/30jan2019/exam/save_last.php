<?php
    include_once '../includes/global.php';
	$stmIns="INSERT INTO user_answer (exam_id,user_id,question_id,answer,mark,time_left)VALUES(?,?,?,?,?,?)";
	$stmsIns = $myconn->prepare($stmIns);
	$stmsIns->bind_param('isisis', $examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
	$stmsIns->execute();
?>