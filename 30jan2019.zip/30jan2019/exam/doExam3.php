
<meta http-equiv="cache-control" content="private, max-age=0, no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
    include_once '../includes/global.php';
    include_once '../includes/authentication.php';
	define('__ROOT__', dirname(dirname(__FILE__))); 
	$examID = $_REQUEST['examid'];
    $userID = $_SESSION['regUsrId'];
    $sql="SELECT user_name FROM users WHERE user_id=?";
    $sql = $myconn->prepare($sql);
	$sql->bind_param('s', $userID);
	$sql->execute();
	$sql->store_result();
	$sql->bind_result($user_name);
	$sql->fetch();
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/start_exam.css">	
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/start_exam.css">	
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/do_exam.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<style>
.radioBtn
{
    padding-right: 20px!important;
    display: inline-block!important;
}
body
{
    overflow: hidden;
}
iframe
{
    width: 100%;
    height: 90%;
    
}
header
{
	font-family: 'Lobster', cursive;
	text-align: center;
	font-size: 25px;	
}

#info
{
	font-size: 18px;
	color: #555;
	text-align: center;
	margin-bottom: 25px;
}

a{
	color: #074E8C;
}

.scrollbar
{
	mmargin-left: 30px;
	float: le0t;
	height: 400px;
	width: 100%;
	background: #F5F5F5;
	overflow-y: scroll;
	margin-bottom: 25px;
}

.force-overflow
{
	min-height: 450px;
}

.style-4::-webkit-scrollbar-track
{
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar
{
	width: 10px;
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar-thumb
{
	background-color: #000000;
	border: 2px solid #555555;
}
</style>
<body style="overflow: hidden;">
    <?php
        if(isset($_POST['submit'])){
            header('Location: '.$_SERVER['REQUEST_URI']);
        }
        if(isset($_REQUEST['fq']))
            unset($_SESSION['timeLeft']);

        $exmName="SELECT exam_name, exam_duration, no_of_question, total_mark, pass_marks FROM exam where exam_id=? LIMIT 1";
        $exmName = $myconn->prepare($exmName);
    	$exmName->bind_param('i', $examID);
    	$exmName->execute();
    	$exmName->store_result();
    	$exmName->bind_result($exam_name,$exam_duration,$no_of_question,$total_mark,$pass_marks);
    	$exmName->fetch();
    	$_SESSION['no_of_question']=$no_of_question;
    
        //Fetch exam in Answer table
    	$tquestn="SELECT sno, question_id, time_left FROM user_answer WHERE user_id=? AND exam_id=? ORDER BY time_left";
        $tquestn = $myconn->prepare($tquestn);
        $tquestn->bind_param('si',$userID,$examID);
    	$tquestn->execute();
    	$tquestn->store_result();
    	$tquestn->bind_result($sno,$qid,$timeLeft);
    	$tquestn->fetch();

        if(isset($_SESSION['timeLeft']))
            ;
        else
        {
        	if(empty($timeLeft))
                $timeLeft=convertToHoursMins($exam_duration, '%02d:%02d:00');
            $_SESSION['timeLeft']=$timeLeft;
        }

    ?>
    <div class="row" style="background: #FF9934; margin: 0px;">
        <div class="col-md-9 text-center">
    		<h4 style="color: white;">SearchUrCollege Test Series (<?php echo $exam_name;?>) </h4>
        </div>
        <div class="col-md-3 pull-right" style="margin-top: 10px;">
    		<a href="https://www.searchurcollege.com/exam" style="margin-right: 10px; color: black;"><i class="fa fa-home"></i> HOME</a>
    		<a href="#DemoModal1" data-toggle="modal" style="margin-right: 10px; color: black;"><i class="fa fa-book"></i> Questions</a>
    		<a href="#DemoModal2" data-toggle="modal" style="margin-right: 10px; color: black;"><i class="fa fa-info-circle"></i> Instruction</a>
        </div>
    </div>
    <div class="row btn-primary" style="padding: 0px 15px 0px 15px;">
        <div class="col-md-3" style="margin-top: 8px;">
            <?php
                        $quesIdStm="SELECT question_id FROM questions WHERE exam_id=$examID";
                        $quesID = $myconn->prepare($quesIdStm);
                    	$quesID->execute();
                    	$quesID->store_result();
            			$quesID->bind_result($question_id);
                        $i=1;
                        $sno=array();
                        $qno=array();
            			while($quesID->fetch()>0)
                        {
                            $sno[$i-1]=$i;
                            $qno[$i-1]=$question_id;
                            $i++;
                        }
                        $one=$qno[0];
                        if($one=='')
                        {
                            echo 'Questions are not uploaded yet';
                            exit;
                        }
                        if(isset($_REQUEST['sn']))
                        {
                            if(isset($_REQUEST['prev']))
                            {
                                $sn=$_REQUEST['sn']-2;
                                if($sn<=1)
                                    $sn=0;
                            }
                            else
                            {
                                $sn=$_REQUEST['sn'];
                                if($sn==$_REQUEST['noq'])
                                    $sn=$sn-1;
                            }
                            $nqno=$qno[$sn];
                        }
                        else
                        {
                            $sn=1;
                            $nqno=$qno[0];
                        }
            ?>
            <b style="font-size: 15px;">Question : 
            <?php
                if(isset($_REQUEST['fq']))
                    echo $sn;
                else
                    echo $sn+1;
            ?>
            </b>
        </div>
        <div class="col-md-6" style="margin-top: 8px; text-align: right;">
            Language: 
            <select class="text-right" disabled="disabled" style="color: black;">
                <option>English</option>
                <option>Hindi</option>
            </select>
        </div>
        <div cclass="col-md-3">
            <div class="btn-group pull-right">
                <button type="button" class="btn btn-primary"><b style="font-size: 15px;">Time Left: </b></button>
                <input type="hidden" name="start_value" id="start_value" style="color: black;" value="<?php echo $_SESSION['timeLeft'];?>" />
                <input type="hidden" name="pause_value" id="pause_value" value="2" />
                <input type="hidden" name="timeLeft" style="color: black;" id="timeLeft" />
                <input type="hidden" name="loadData" id="loadData" />

                <button type="button" class="btn btn-primary" id="clock"><b style="font-size: 15px;"><span class="divCounter" id="divCounter"></span></b></button>
                <button type="button" class="btn btn-danger" id="pause"><i class="fa fa-pause"></i> Pause Test</button>
            </div>
        </div>
    </div>
    <iframe id="qFrame" name="qFrame" frameborder="0" src="https://www.searchurcollege.com/exam/exam/fetch_question3.php?examid=<?php echo $examID;?>&fq=0"></iframe>
</body>


	<!--***********************************************************************************
	//	#: Instruction Modal 
	***************************************************************************************-->
	<div class="DemoModal2">
		<!-- Modal Contents -->
		<div id="DemoModal2" class="modal fade"> <!-- class modal and fade -->
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header"> <!-- modal header -->
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
						<h4 class="modal-title"><p> <b><u>Instruction : </u></b></p></h4>
					</div>
					<div class="modal-body" style="min-height:550px; max-height:550px; overflow-y: scroll"> <!-- modal body -->
							<ol style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
								<li>Total duration of examination is <span class="text-danger"><b><?php echo $exam_duration; ?> minutes. </b></span></li>  
								<li>The clock will be set at the server. The countdown timer in the top right corner of screen will display the remaining time available for you to complete the examination. When the timer reaches zero, the examination will end by itself. You will not be required to end or submit your examination.</li>  
								<li>The Question Palette displayed on the right side of screen will show the status of each question using one of the following symbols:<br>  
									<table class="instruction_area" style="FONT-SIZE: 100%">  
										<tbody>  
											<tr>  
												<td><span class="not_visited" title="Not Visited">A</span></td>  
												<td>You have not visited the question yet.</td>  
											</tr>  
											<tr>  
												<td><span class="not_answered" title="Not Answered">B</span></td>  
												<td>You have not answered the question.</td>  
											</tr>  
											<tr>  
												<td><span class="answered" title="Answered">C</span></td>  
												<td>You have answered the question.</td>  
											</tr>  
											<tr>  
												<td><span class="review" title="Not Answered &amp; Mark for Review">D</span></td>  
												<td>You have NOT answered the question, but have marked the question for review.</td>  
											</tr>  
											<tr>  
												<td><span class="review_answered" title="Answered &amp; Mark for Review" style="background-position: -6px -82px; line-height: 34px;">E</span></td>  
												<td>You have answered the question, but marked it for review.</td>  
											</tr>  
										</tbody>  
									</table>  
								</li> 
								<li style="LIST-STYLE-TYPE: none">The Marked for Review status for a question simply indicates that you would like to look at that question again. 
									<font color="red">
										<i>If a question is answered and Marked for Review, your answer for that question will be considered in the evaluation. </i>
									</font>
								</li> 
							</ol>
							<br>
							<p> <b><u>Navigating to a Question : </u></b></p>
							<br>
							<ol start="4" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
								<li>To answer a question, do the following:  
									<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a"> 
										<li>Click on the question number in the Question Palette to go to that numbered question directly.</li>  
										<li>Click on <strong>Save &amp;Next</strong> to save your answer for the current question and then go to the next question.</li>  
										<li>Click on <strong>Mark for Review &amp; Next</strong> to save your answer for the current question, mark it for review, and then go to the next question.<br>  
											<span style="color:#ff0000;">Caution: Note that your answer for the current question will not be saved, if you navigate to another question directly by clicking on its question number.</span>
										</li> 
									</ol> 
								</li><br> 
								<li>You can view all the questions by clicking on the Question Paper button. Note that the options for multiple choice type questions will not be shown.</li> 
							</ol><br>	
						<p> <b><u>Answering a Question : </u></b></p>
						<br>						
						<ol start="6" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
							<li>Procedure for answering a multiple choice type question:  
								<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a">  
									<li>To select your answer, click on the button of one of the options.</li> 
									<li>To deselect your chosen answer, click on the button of the chosen option again or click on the <b>Clear Response</b> button.</li>  
									<li>To change your chosen answer, click on the button of another option.</li>  
									<li>To save your answer, you MUST click on the <b>Save &amp; Next</b> button.</li>  
									<li>To mark the question for review, click on the <b>Mark for Review &amp; Next</b> button.<br>  
										<em><span style="color:#ff0000;">If an answer is selected for a question that is 'Marked for Review', that answer will be considered in the evaluation even if it is not marked as 'Save &amp; Next', at the time of final submission</span>.</em>
									</li>  
								</ol>  
							</li>  
							<li>To change your answer to a question that has already been answered, first select that question for answering and then follow the procedure for answering that type of question.</li> 
							<li>Note that questions for which option has been chosen and answers are saved or marked for review will be considered for evaluation.</li> 
							<li><em><span style="color:#ff0000;">� (one fourth) marks i.e. one mark will be deducted for indicating incorrect response of each question. No deduction from the total score will be made if no response is indicated for a question</span></em>.</li> 
						</ol><br>
						<div class="cusInstText1" style="height: 91%; width: 100%; overflow: auto; display: block;">
							<p style="text-align: center;">
								<u><strong>Exam specific Instructions</strong></u>
							</p> <br> <br> 
							<ol> 
								<li>This is a Mock test. The Question paper displayed is for practice purposes only. Under no circumstances should this be presumed as a sample paper.</li> 
								<li>Each question is allocated 4 (four) marks for each correct.</li> 
								<li>One fourth marks will be deducted for incorrect response of each question. No deduction from the total score will be made if no answer is given.</li> 
								<li>There is only one correct answer for each question.</li> 
							</ol> <br> <br> 
						</div>														
					</div>
				</div> <!-- / .modal-content -->
			</div> <!-- / .modal-dialog -->
		</div><!-- / .modal -->
	</div>
	<!--***********************************************************************************
	//	#: Instruction Modal 
	***************************************************************************************-->
	<div class="DemoModal1">
		<!-- Modal Contents -->
		<div id="DemoModal1" class="modal fade"> <!-- class modal and fade -->
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header"> <!-- modal header -->
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
						<h4 class="modal-title text-primary"><p> <b>All Questions :</b></p></h4>
					</div>
					<div class="modal-body" style="min-height:550px; max-height:550px; overflow-y: scroll"> <!-- modal body -->
						<?php             
							$QuesList="SELECT question FROM questions where exam_id=?";
							$QuesList = $myconn->prepare($QuesList);
							$QuesList->bind_param('i', $examID);
							$QuesList->execute();
							$QuesList->store_result();
							$QuesList->bind_result($ViewQuestion);
                            $QNo=1;
							while($QuesList->fetch()>0){
						?>	
						<div class="well well-sm text-center">
						    <span class="text-danger pull-left"><?php echo 'Question '.$QNo;?></span>
						    <hr style="border-top: 1px solid #0a540d;">
							<?php echo $ViewQuestion;?>
						</div>						
						<?php
					    	$QNo++;
							}
						?>
					</div>
				</div> <!-- / .modal-content -->
			</div> <!-- / .modal-dialog -->
		</div><!-- / .modal -->
	</div>

<?php
function convertToHoursMins($time, $format = '%02d:%02d')
{
    if ($time < 1)
        return;
    $hours = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}
?>
