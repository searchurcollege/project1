<?php
include('../../connection/header.php');
include('../../connection/dbconnect.php');

$email=$_SESSION['email'];
$stream=$_SESSION['stream'];
?>
<title>Search ur College-Model Question Paper</title>
  <!-- <meta name="description" content="Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test">
  <meta name="keywords" content="MAT,CAT,XAT,CMAT, Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test"> -->
  <style>
  body
{
  color: #4d4d4d!important;
  /*font-weight: normal!important;*/
}


  	#left-slider{
  height: 100vh;
  background: #1e1e1e ;
  
}
 	
.panel-default{
    text-align:center;
    cursor:pointer;
    font-family: 'Raleway',sans-serif;
    background: #fcfcfc;
}
.panel-default > .panel-footer {
    color: #fff;
    font-size: 14px; 
    background-color: #47c8ed;    
    /*display:none;*/
    text-shadow: 1px 1px 1px rgba(150, 150, 150, 1);
}
.panel-default i{
    font-size: 5em;
    }
   .badge
   {
   	font-size: 20px;
    margin-top: 5px;
   }
   .blinking {
  -webkit-animation-name: blink;  
  -webkit-animation-iteration-count: infinite;  
  -webkit-animation-timing-function: cubic-bezier(1.0,0.0,0,1.0);
  -webkit-animation-duration: 1.5s; 
}
.tip_info {
    text-decoration: none
}
.tip_info:hover {
    
    position: relative
}
.tip_info span {
    display: none
}

.tip_info:hover span {
    
    padding: 5px 10px 5px 10px;
    display: block;
    z-index: 100;
    background:  #f0f0f0 ;
    left: 0px;
    mmargin: 10px;
    margin-top:20px; 
    text-align: left;
    margin-left: -60px;
    width: 300px;
    height: auto;
    position: absolute;
    top: 10px;
    right:0px;
    border-radius: 6px;
    font-size:16px; 
    box-shadow: 0px 3px lightgray;

    
}
@media screen and (min-width: 200px) and (max-width: 499px){
	#left-slider{  
  height: 14vh!important; 
  background: #1e1e1e ;
  mmargin-top:  -10px!important;
  padding: 0px!important;
  z-index: 10;  
}
.tip_info:hover span {
    
    padding: 5px 10px 5px 10px;
    display: block;
    z-index: 100;
    background:  #f0f0f0 ;
    left: 0px;
    mmargin: 10px;
    margin-top:20px; 
    text-align: left;
    margin-left: -250px;
    width: 300px;
    height: auto;
    position: absolute;
    top: 10px;
    right:0px;
    border-radius: 6px;
    font-size:16px; 
    box-shadow: 0px 3px lightgray;

    
}

}

  </style>
   <div class="col-md-2" id="left-slider">
    <?php include('../home/left1.php'); ?>
        </div>
    <div class="col-md-10">
      <div class="text-center free-text" style="margin-top: 12px; margin-bottom: 10px;">
         <span style="font-size: 30px; color: #4d4d4d;"><b>Reward Your Friends - Reward Yourself 
</b><i class="fa fa-info-circle tip_info" aria-hidden="true" style="cursor: pointer;"><span><p style="padding: 0px;"> <ul>
  <li>Refer your friends all about Searchurcollege and get rewarded for each registration your referrals make. Refer as many new members to make the most of this exclusive offer</li> <br>
  <li>You earn 10 bonus points for each registration your referrals make. You can redeem the rewards as cash after 50 bonus points</li>
</ul></span></i></p></span><br />
        </div>
    	<?
    	$sql="SELECT user_referral_code from suc_user_referrals where user_id='$email'";
    	$result=$conn->query($sql);
    	while($row=$result->fetch_assoc())
    		$ref_code=$row["user_referral_code"];
    	$sql="SELECT  count(id) as count FROM `users` WHERE referral_code='$ref_code'";
    	$result=$conn->query($sql);
    	while($row=$result->fetch_assoc())
      {
    		
        $count=$row["count"];
      }

    	?>
    	
<div cclass="container" style="margin-top: 20px;">
	<div cclass="row">
    <?if($count>=3 && $count<5){?>
<div class="col-md-8 col-xs-12 col-md-12"> 
<h4 class="blinking"><b>Invite <? echo bcsub("5",$count) ?> more members and enjoy valuable prize</b></h4>
</div> 
         <!-- Blinking div end -->
<!-- <?}?>
<?if($count>5){?>
<div class="col-md-8 col-xs-12 col-md-12"> 
<h4 class="blinking">Now you can Redeem your points</h4>
</div> 

<?}?> -->
<div class="col-md-4 col-xs-12 col-md-12 pull-right">
  <h4>My Referral Code : <b><?php echo $ref_code; ?></b></h4>
</div>   
	</div>
</div>
<div class="container col-md-12">
                                                                                       
  <div class="table-responsive col-md-12"> 
  <h4> Referral Details</h4>         
  <table class="table">
    <thead>
      <tr>
        <th style="width: 10px;">Registered Date</th>
        <th style="width: 10px;">Ref. Name <sup><span class="badge" style="font-size: 14px!important;"><?php echo $count; ?></span></sup></th>
       
      </tr>
    </thead>
    <tbody>
<?
$sql="SELECT  first_name , created_at FROM `users` WHERE referral_code='$ref_code'";
      $result=$conn->query($sql);
while($row=$result->fetch_assoc())
{
  $name_ap_code=$row["first_name"];
  $newDate = date("d-m-Y", strtotime($row["created_at"]));
 // $count++;
  echo '<tr>
        <td>'.$newDate.'</td>
        <td>'.$name_ap_code.'</td>
       
      </tr>';
}
?>

      
    </tbody>
  </table>
  </div>
  <div class="col-md-12"  style="background:#5bc0de; height: 50px; vertical-align: middle;line-height: 50px; ">
    <div class="col-md-8">
<span style="color: white; font-size: 22px;text-align: left;vertical-align: middle;line-height: 50px; font-weight: 600;"> Earned Bonus Points : <? echo $count*10; ?> </span> 
</div>
<?

if($count>=5){
  echo '<div class="pull-right"><button class="btn btn-primary">Redeem my points</button></div>';
}
else{
  echo '<div class="pull-right"><button disabled class="btn btn-primary">Redeem my points</button></div>';
}
?>
  </div>
</div>

</div>
<? include("../../footer.php"); ?>
<!-- <script>
	$(function(){
$('.panel').hover(function(){
        $(this).find('.panel-footer').slideDown(250);
    },function(){
        $(this).find('.panel-footer').slideUp(250); //.fadeOut(205)
    });
})

</script> -->