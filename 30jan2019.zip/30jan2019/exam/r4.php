	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/login_header.php'); 
	?>
		<style>
			#border-bottom{
				border-bottom:1px solid #ff6300;
				margin-bottom:10px;
			}		
		</style>

		<div class="row row-eq-height">
			
			<div class="col-md-2 col-xs-12 left-sidebar"> 
		
				<?php require_once(__ROOT__.'/includes/sidebar.php'); ?>
				
			</div>
			
		
			<div class="col-md-10 col-xs-12  div-content"> 
			
				<!-- Content Header (Page header) -->
				<div id="contentHeader">
				
					<h4><i class="fa fa-file"></i> <a style="color: white;" href="r1.php">My Result</a>
                    <?php
                     $n1=$_REQUEST['n1'];
                     $n2=$_REQUEST['n2'];
                     $n3=$_REQUEST['n3'];
                     $scid=$_REQUEST['scid'];
                     $mcid=$_REQUEST['mcid'];
                     $ecid=$_REQUEST['ecid'];
                     echo '&nbsp;&nbsp;<i class="fa fa-caret-right"></i>&nbsp;&nbsp;<a style="color: white;" href="r1.php?n1='.$n1.'&scid='.$scid.'">'.$n1.'</a>';
                     echo '&nbsp;&nbsp;<i class="fa fa-caret-right"></i>&nbsp;&nbsp;<a style="color: white;" href="r2.php?n1='.$n1.'&n2='.$n2.'&scid='.$scid.'&mcid='.$mcid.'">'.$n2.'</a>';
                     echo '&nbsp;&nbsp;<i class="fa fa-caret-right"></i>&nbsp;&nbsp;<a style="color: white;" hhref="r3.php?n1='.$n1.'&n2='.$n2.'&n3='.$n3.'&scid='.$scid.'&mcid='.$mcid.'&ecid='.$ecid.'"><b style="color: skyblue;">'.$n3.'</b></a>';
                    ?>
                    </h4>
				</div>					
                <style>
                    .box2
                    {
                        padding: 10px!important;
                        margin: 10px!important;
                    }
                </style>
				<div class="col-md-12 col-xs-12">
                    <?php
                        //echo '<h4><b>'.$n3.'</b></h4>';
                    	$stm4="SELECT exam_exercise_id, exam_exercise_name, exam_exercise_description FROM cat03_exam_exercise WHERE exam_exercise_status=1 AND exam_cat_id=$ecid ORDER by exam_exercise_id asc limit 100";
                        if ($stm4 = $myconn->prepare($stm4)) 
                    	{
                    		$stm4->execute();
                    		$stm4->store_result();
                    		$stm4->bind_result($exam_exercise_id, $exam_exercise_name, $exam_exercise_description);
                			while($stm4->fetch()>0)
                            {
                                echo '<a href="'.BASE_URL.'exam/r5.php?eeid='.$exam_exercise_id.'&scid='.$scid.'&mcid='.$mcid.'&ecid='.$ecid.'&n1='.$n1.'&n2='.$n2.'&n3='.$n3.'&n4='.$exam_exercise_name.'" style="color: white;"><button class="btn btn-primary btn-md box2">'.$exam_exercise_name.'</button></a>';
                            }
                        }
                        echo '</ul></li>';
                    ?>
				</div>
			</div>				

		</div>

		<?php require_once(__ROOT__.'/includes/footer.php');?>