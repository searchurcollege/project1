<?php

	//************************** Include Requied File ***************************
	define('__ROOT__', dirname(dirname(__FILE__))); 
	require_once(__ROOT__.'/includes/global.php'); 
	require_once(__ROOT__.'/includes/authentication.php');
	
	error_reporting(0);

	$exam_id=$_POST['hfExamId'];
	$question_id=$_POST['hQquestionId'];
	$mark=1;
	
		// Chech previous question is inserted
		$stm="SELECT question_id FROM user_answer where question_id=?";
		$stms = $myconn->prepare($stm);
		$stms->bind_param('i', $question_id);
		$stms->execute();
		$stms->store_result();
		$stms->bind_result($questionID);
		$stms->fetch();
		if(!empty($questionID)){
			// Update if question is already answered 
			$stmUpdt="UPDATE user_answer SET  mark='$mark' WHERE question_id=?";
			$stmsUdt = $myconn->prepare($stmUpdt);
			$stmsUdt->bind_param('i', $question_id);
			$stmsUdt->execute();
			echo 'R';		
		}
		else{
			$stmIns="INSERT INTO user_answer (exam_id,question_id,mark)VALUES(?,?,?)";
			$stmsIns = $myconn->prepare($stmIns);
			$stmsIns->bind_param('iis', $exam_id,$question_id,$mark);
			$stmsIns->execute();
			echo 'R';
		}
?>