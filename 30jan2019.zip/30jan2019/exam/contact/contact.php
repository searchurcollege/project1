	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/header.php'); 
	?>

	<div class="container middlecontent">

		<div class="row">

			<div class="col-lg-8">

				<h4>  <strong>Just Get In Touch!</strong></h4>

				<hr/>

					<p>We will be glad to hear from you</p>

					<!--<div class="alert alert-success alert-dismissable">

						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

						<b>Success! </b>

					</div>

					<div class="alert alert-danger alert-dismissable">

						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

					</div>-->

					

					<form role="form" method="POST" action="#">

						<div class="form-group">

							<label for="name">Your Name</label>

							<input type="text" class="form-control required" id="name" name="name" value=""/>

						</div>

						<div class="form-group">

							<label for="email">Email address</label>

							<input type="text" class="form-control" id="email" name="email"  value=""/>

						</div>

						<div class="form-group">

						<label for="subject">Subject</label>

							<input type="text" class="form-control" id="subject" name="subject"  value=""/>

						</div>

						<div class="form-group">

							<label for="message">Message</label>

							<textarea class="form-control" id="message" rows="10" style="resize: none" name="message"></textarea>

						</div>

						<button type="submit" class="btn btn-info">Submit</button>

					</form>

			</div><!--/col-lg-8 -->

			

			<div class="col-lg-4">

				<h4><strong>Our Address</strong></h4>

				<hr>

					<p><?php echo $address;?></p>
					<p><?php echo $city.', '.$state;?></p>

					<p><i class="fa fa-envelope"></i>&nbsp; <?php echo $email;?></p>

					<p><i class="fa fa-phone"></i>&nbsp; +91-<?php echo $phone;?> </p>

					<p>To know more contact at info@gksingh.com </p>

			</div>

		</div><!--/row -->

	</div><!--/container -->

	<?php require_once(__ROOT__.'/includes/login_footer.php');?>