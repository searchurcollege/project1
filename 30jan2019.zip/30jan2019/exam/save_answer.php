<?php
    include_once '../includes/global.php';
	$sno = $_REQUEST['sno'];
	$userID = $_REQUEST['uid'];
	$examID = $_REQUEST['eid'];
	$crQues = $_REQUEST['qno'];
	$timeLeft = $_REQUEST['tl'];
	$quesNo = $_REQUEST['quesNo'];
	$UsrAns = $_REQUEST['correctAns'];
    if($UsrAns=='')
        $color='#DB4007';   //Red
    else
        $color='#88C824';   //Green
    $UsrAns = str_replace("undefined","",$UsrAns);



session_start();
$_SESSION['timeLeft']=$timeLeft;
//$time1 = $_SESSION['st'];
//$time2 = date("H:i:s");

//echo "<br>TD=".get_time_difference($time1, $time2);
//$timeLeft=get_time_difference($time1, $time2);

//$duration=$_SESSION['timeLeft'];
//$timeLeft=get_time_difference($timeLeft, $duration);

function get_time_difference($time1, $time2)
{
    $time1 = strtotime("1980-01-01 $time1");
    $time2 = strtotime("1980-01-01 $time2");
    if ($time2 < $time1)
        $time2 += 86400;
    return date("H:i:s", strtotime("1980-01-01 00:00:00") + ($time2 - $time1));
}

	$mark = 0;
    if(isset($_REQUEST['review']))
        ;
    else
    {
    	// Chech previous question is inserted
    	$Ques="SELECT question_id FROM user_answer WHERE question_id=$crQues AND user_id='$userID' AND exam_id=$examID AND status!='submited'";
        $Ques = $myconn->prepare($Ques);
    	$Ques->execute();
    	$Ques->store_result();
    	$Ques->bind_result($crQuesID);
    	$Ques->fetch();
        if(!empty($crQuesID))
        {
    		// Update if question is already answered 
    		$stmUpdt="UPDATE user_answer SET color='$color', sno=$sno, answer='$UsrAns', mark=$mark, time_left='$timeLeft' WHERE question_id=? AND user_id=? AND status!='submited'";
            $stmsUdt = $myconn->prepare($stmUpdt);
    		$stmsUdt->bind_param('ii', $crQues,$userID);
    		$stmsUdt->execute();
    		++$quesNo;
    	}
    	else{
    		$stmIns="INSERT INTO user_answer (color,sno,exam_id,user_id,question_id,answer,mark,time_left)VALUES(?,?,?,?,?,?,?,?)";
            $stmsIns = $myconn->prepare($stmIns);
    		$stmsIns->bind_param('siisisis',$color,$sno,$examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
    		$stmsIns->execute();							
    	}
    }
    exit;    
?>            
            
   