
      	
<?php

include('../../connection/header3.php');



?>
<!DOCTYPE html>
  <link rel="stylesheet" type="text/css" href="css/slick.css">
  <link rel="stylesheet" type="text/css" href="css/slick-theme.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  
  <title>Search ur College-Model Question Paper</title>
  <meta name="description" content="Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test">
  <meta name="keywords" content="MAT,CAT,XAT,CMAT, Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css'>

 


<?php
define( "BASE_URL", "https://searchurcollege.com/exam/");
?>
<style class="cp-pen-styles">


*, *:before, *:after {
  box-sizing: border-box;
}

td
{
    color: black;    
}

.load-more-container {
  background: transparent;
  width: 100%!important;
  min-height: 500px;
  margin: 20px auto;
  position: relative;
}
.load-more-container ul {
  list-style-type: none;
  padding: 0;
}
.load-more-container ul:after {
  content: "";
  display: table;
  clear: both;
}
.load-more-container ul li {
  width: calc(20% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 5px;
}
.load-more-container ul li:nth-child(1n + 7) {
  max-height: 0;
  opacity: 0;
  transition: 0.1s ease-in;
}
.load-more-container .load-more-btn {
  width: 150px;
  line-height: 40px;
  border-radius: 2px;
  margin: 0 auto;
  display: block;
  background: #219150;
  color: #fff;
  cursor: pointer;
  text-align: center;
}
.load-more-container .load-more-btn:hover {
  background: green;
}
.load-more-container .load-more-btn .loaded {
  display: none;
}
.load-more-container #load-more {
  display: none;
}
.load-more-container #load-more:checked ~ ul li:nth-child(1n + 5) {
  max-height: 999px;
  opacity: 1;
  transition: 0.2s ease-in;
}
.load-more-container #load-more:checked ~ .load-more-btn .loaded {
  display: block; 
}
.load-more-container #load-more:checked ~ .load-more-btn .unloaded {
  display: none;
  
}

@media (max-width: 500px) {
 .load-more-container ul li {
  width: calc(100% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 2px;
}

}
@media screen and (min-width: 200px) and (max-width: 786px){
    
 .exam-tab .nav>li>a {
    position: relative;
    display: block;
    padding: 0px 30px;
    padding-bottom: 3px;
    font-size: 16px!important;
    border-radius: 0px;
    color: #596F7C;
    margin-left: 15px;
}   
 .btn-group-lg>.btn, .btn-lg {
    padding: 05px 16px!important;
    font-size: 15px!important;
    line-height: 1.3333333;
    border-radius: 6px;
} 
#title{
    
    font-size:20px!important;
}
#banner{
  display: none;

}  
#left-slider{
  height: 55vh!important;
  background: #1e1e1e ;
  margin-top:  0px!important;
  padding: 5px!important;  
}

#desk{
    display: none!important;
}
#mob{
    display: block!important;
}
  
} 

@media screen and (min-width: 200px) and (max-width: 499px){
    #dv{display: none;}
    #mv{display: inline;}
    #banner{
      display: none;
    }
    #left-slider{
  height: 25vh!important;
  background: #1e1e1e ;
  margin-top:  0px!important;
  padding: 5px!important;  
}


}
section.study-section .nav-tabs {
    border-bottom: 2px solid transparent!important;
}


.scrollbar
{
mmargin-left: 30px;
float: le0t;
height: 400px;
width: 100%;
background: #ffffff;
overflow-y: scroll;
margin-bottom: 25px;
}
.force-overflow
{
min-height: 450px;
}
.style-4::-webkit-scrollbar-track
{
-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
background-color: #596f7c;
}
.style-4::-webkit-scrollbar
{
width: 10px;
background-color: #F5F5F5;
}
.style-4::-webkit-scrollbar-thumb
{
background-color: #000000;
border: 2px solid #555555;
}

</style>
  
  
  <style type="text/css">
    .blocks
    {
        background: white;
        display: inline-flexbox!important;
        padding: 5px;
        border-radius: 5px;
        text-align: center;
        width: 100px;
        min-width: 70px!important;
        margin-right: 15px!important;
    }
    .bB1
    {
        margin-left: -10px;
        margin-top: 28px;
    }
    .B2
    {
        margin-left: -30px;
        mmargin-top: -40px;
    }
    .nav-pills>li.active>a, .nav-pills>li.active>a:hover, .nav-pills>li.active>a:focus
    {
        background: #596f7c!important;
    }
    .slick-prev:before, .slick-next:before
    {
        color: white!important;   
    }
    * {
      box-sizing: border-box;
    }

    .slider {
        width: 100%;
        margin-top: 10px;
    }

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 100%;
    }

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }
    .slick-prev
    {
          margin-left: 15px;
    }
    .slick-next
    {
          margin-right: 15px;
    }


    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: 1;
    }
    
    .slick-active {
      opacity: 1;
    }

    .slick-current {
      opacity: 1;
    }


.tabs-content {
       @include clearfix;
       margin-bottom: $tabs-content-margin-bottom;
       width: 100%;
       > .content {

          // Replacement for display: none;, a fix for carousel in tabs
         overflow-y: hidden;
         height: 0;

         float: $default-float;
         padding: $tabs-content-padding 0;
         width: 100%;
         &.active { display: block; float: none;  height: auto;}  // height: auto; added. Also part of the display: none; replacement, a fix for carousel in tabs
         &.contained { padding: $tabs-content-padding; }
       }
       &.vertical {
         display: block;
         > .content { padding: 0 $tabs-content-padding; }
      }
        
        section.study-section .tab-content {
        margin-top: 40px!important;
}
    }
    
   body{
    background: white!important;
   }
   
.exam-tab .nav>li>a {
    position: relative;
    display: block;
    padding: 0px 60px;
    padding-bottom: 3px;
    font-size: 22px!important;
    border-radius: 0px;
    color: #596F7C;
    margin-left: 17px;
}   

.btn-group-lg>.btn, .btn-lg {
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.3333333;
    border-radius: 6px;
}

#left-slider{
  height: 120vh;
  background: #1e1e1e ;
  margin-right: -15px;  
} 
  
      </style>
<div id="banner" class="col-md-12" style="background: url('https://searchurcollege.com/frontassets/images/k.png');height: 150px; opacity: 0.3;"></div>

        
        <div class="col-md-12" style="bbackground: orange; padding: 0px;">
       <div class="col-md-2" id="left-slider"> 
		<?php include('../home/left.php'); 
       
        ?>
        </div>
        
        <div class="col-md-10" style="widsth: 90%; margin: 0px; padding: 0px; bbackground: red; margin-left: 15px; height: 100px;">
        <div class="text-center free-text" style="margin-top: 2px; margin-bottom: 10px;">
         <span style="font-size: 30px;"><b>My Results</b></span><br />
        </div>

<!------------------------------desk---------------------------------->			   
            <div class="col-md-12 col-xs-12" id="desk">

		<sscript type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example').DataTable()
                
			} );
          
                        
		</script>
<style>
th
{
    padding: 5px;
    text-align: center;
}
</style>							
                                 <table id="example" class="display table-hover" cellspacing="0" width="100%">
									<thead class="bg-red">
										<th width="20%">Dated</th>										
										<th width="20%">Exam Name</th>										
										<th>Questions</th>
									<!--	<th>Total Time</th>
										<th>Total Marks</th>  
 										<th>Passing Marks</th> -->
										<th>Attempted</th>
										<th>Correct</th>
										<th>Incorrect</th>
									<!--	<th>Marks</th>
										<th>Result</th> -->
                                        <th>Action</th>
									</thead>
									<tbody>
								<?php
									//*********************************************************************************************
									// 	#: Get Recent Exam Status
									//*********************************************************************************************
                                            
         	                              $user_id = $_SESSION['regUsrId'] ;
										include('../../connection/dbconnect.php');
                                        $userExm="SELECT ue.id, ue.user_exam_id, ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,
													ue.total_attempt,ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,
													e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id='$user_id' ORDER BY ue.created_at DESC";
                                        
                                        if ($userExm = $conn->prepare($userExm)) 
										{
										 # echo "jscj";
											$userExm->execute();
											$userExm->store_result();
											$userExm->bind_result($id,$user_exam_id,$total_no_of_ques,$time_duration,$total_marks,$pass_marks,
											$total_attempt,$correct_answer, $wrong_answer, $user_get_marks, $result_status, $exam_name, $exam_id, $date, $code);
											while($userExm->fetch()){
        										$userExm2="SELECT COUNT(answer_id) AS tot_attempts FROM user_answer WHERE code='$code'";
                                                $userExm2=$conn->prepare($userExm2); 
    											$userExm2->execute();
    											$userExm2->store_result();
    											$userExm2->bind_result($tot_attempts);
    											while($userExm2->fetch())
                                                    $tot_attempts=$tot_attempts;
                                                $date=date('d-M-Y H:i',strtotime($date));
												if(empty($exam_name)){
												echo '<tr>
														<td colspan="10">	
															<div class="callout callout-info">
																<h4>No exams have been taken at the moment !</h4>
															</div>
														</td>
													</tr>';
												}
												else{
												   $total_attempt=$tot_attempts;
                                                   $wrong_answer=$total_attempt-$correct_answer;
            									   if($wrong_answer<0)
                                                        $wrong_answer=0-$wrong_answer;
                                                    if($total_no_of_ques==0)
                                                        $total_no_of_ques=1;
    												$mpq=$total_marks/$total_no_of_ques;
                                                    $user_get_marks=round($correct_answer*$mpq);
                                                    $a=$total_marks/$total_no_of_ques;
                                                    if($user_get_marks>=$pass_marks)
                                                        $result_status='PASS';
                                                    else
                                                        $result_status='FAILED';
								?>
													<tr>
														<td align="center"><?php echo $date;?></td>
														<td align="center"><?php echo $exam_name;?></td>
														<td align="center"><?php echo $total_no_of_ques;?></td>
													<!--	<td align="center"><?php //echo $time_duration.' <em>min</em>';?></td>   
														<td align="center"><?php // echo $total_marks;?></td> 
														<td align="center"><?php //echo $pass_marks;?></td>    -->
 														<td align="center"><?php echo $total_attempt;?></td>
														<td align="center"><?php echo $correct_answer;?></td>
														<td align="center"><?php echo $wrong_answer;?></td>
													<!--	<td align="center"><?php echo $user_get_marks;?></td>   -->
														<td align="center" valign="middle">
															<a href="my_result2.php?exmID=<?php echo $code;?>" title="View Questions"> 
                                                             <label style="mmargin-top: 15px; padding: 2px; " class="btn btn-block btn-xs label-primary"><font color="white"> View Solution </font> </label>
															</a>
														</td>
														
													</tr>
								<?php
												}
											}
										}
								?>
									</tbody>
									
								</table>


									
                            </div>
<!----------------------------desk End------------------------------>
<!-------------------------------Mob--------------------------------->
 <div class="col-md-12 col-xs-12" id="mob" style="display: none;">

		<sscript type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
		<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example').DataTable()
                
			} );
          
                        
		</script>
<style>
th
{
    padding: 5px;
    text-align: center;
}
</style>							
                                 <table id="example" class="display table-hover" cellspacing="0" width="100%">
									<thead class="bg-red">
										<th width="30%">Dated</th>										
										<th width="30%">Exam Name</th>										
										<th>Action</th>
									</thead>
									<tbody>
								<?php
									//*********************************************************************************************
									// 	#: Get Recent Exam Status
									//*********************************************************************************************
                                            
         	                              $user_id = $_SESSION['regUsrId'] ;
										include('../../connection/dbconnect.php');
                                        $userExm="SELECT ue.id, ue.user_exam_id, ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,
													ue.total_attempt,ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,
													e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.user_id='$user_id' ORDER BY ue.created_at DESC";
                                        
                                        if ($userExm = $conn->prepare($userExm)) 
										{
										 # echo "jscj";
											$userExm->execute();
											$userExm->store_result();
											$userExm->bind_result($id,$user_exam_id,$total_no_of_ques,$time_duration,$total_marks,$pass_marks,
											$total_attempt,$correct_answer, $wrong_answer, $user_get_marks, $result_status, $exam_name, $exam_id, $date, $code);
											while($userExm->fetch()){
        										$userExm2="SELECT COUNT(answer_id) AS tot_attempts FROM user_answer WHERE code='$code'";
                                                $userExm2=$conn->prepare($userExm2); 
    											$userExm2->execute();
    											$userExm2->store_result();
    											$userExm2->bind_result($tot_attempts);
    											while($userExm2->fetch())
                                                    $tot_attempts=$tot_attempts;
                                                $date=date('d-M-Y H:i',strtotime($date));
												if(empty($exam_name)){
												echo '<tr>
														<td colspan="10">	
															<div class="callout callout-info">
																<h4>No exams have been taken at the moment !</h4>
															</div>
														</td>
													</tr>';
												}
												else{
												   $total_attempt=$tot_attempts;
                                                   $wrong_answer=$total_attempt-$correct_answer;
            									   if($wrong_answer<0)
                                                        $wrong_answer=0-$wrong_answer;
                                                    if($total_no_of_ques==0)
                                                        $total_no_of_ques=1;
    												$mpq=$total_marks/$total_no_of_ques;
                                                    $user_get_marks=round($correct_answer*$mpq);
                                                    $a=$total_marks/$total_no_of_ques;
                                                    if($user_get_marks>=$pass_marks)
                                                        $result_status='PASS';
                                                    else
                                                        $result_status='FAILED';
								?>
													<tr>
														<td align="center"><?php echo $date;?></td>
														<td align="center"><?php echo $exam_name;?></td>
														<td align="center" valign="middle">
															<a href="my_result2.php?exmID=<?php echo $code;?>" title="View Questions"> 
                                                             <label style="mmargin-top: 15px; padding: 2px; " class="btn btn-block btn-xs label-primary"><font color="white"> View Solution </font> </label>
															</a>
														</td>
														
													</tr>
								<?php
												}
											}
										}
								?>
									</tbody>
									
								</table>


									
                            </div>
<!-----------------------------Mob End------------------------------->
           
            
        </div>
        </div>

<section>
<?php
    include('../../footer.php');
?>

</section>




   
