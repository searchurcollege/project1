	<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=0">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/bootstrap.min.css">
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<style>
a:focus {
  color: white!important;
}
.scrollbar
{
	mmargin-left: 30px;
	float: le0t;
	height: 370px;
	width: 100%;
	background: #F5F5F5;
	overflow-y: scroll;
	margin-bottom: 25px;
}

#question_body1
{
	min-height: 100%;
}
.style-4::-webkit-scrollbar-track
{
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar
{
	width: 10px;
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar-thumb
{
	background-color: #000000;
	border: 2px solid #555555;
}
</style>
	<?php 
        session_start();
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/global.php'); 
		require_once(__ROOT__.'/includes/authentication.php'); 
		//require_once(__ROOT__.'/includes/login_header.php'); 
		$examID = $_REQUEST['examid'];
		$_SESSION['examID'] = $examID;
		$userID = $_SESSION['regUsrId'];
		$exmName="SELECT exam_name, exam_duration, no_of_question, total_mark, pass_marks FROM exam where exam_id=$examID";
		$exmName = $myconn->prepare($exmName);
		$exmName->execute();
		$exmName->store_result();
		$exmName->bind_result($exam_name,$exam_duration,$no_of_question,$total_mark,$pass_marks);
		$exmName->fetch();
    	$_SESSION['no_of_question']=$no_of_question;
        //Fetch exam in Answer table
    	$tquestn="SELECT time_left FROM user_answer WHERE user_id=? AND exam_id=? ORDER BY created_at DESC";
    	$tquestn = $myconn->prepare($tquestn);
        $tquestn->bind_param('si',$userID,$examID);
    	$tquestn->execute();
    	$tquestn->store_result();
    	$tquestn->bind_result($timeLeft);
    	$tquestn->fetch();
		if(empty($timeLeft))
        {
            //$answer='';
            $timeLeft=$exam_duration;
            $timeLeft=convertToHoursMins($timeLeft, '%02d:%02d:00');
        }
        $_SESSION['timeLeft']=$timeLeft;
        //echo "A=".$answer;
	?>
		<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/exam/assets/css/start_exam.css">	
		<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/exam/assets/css/do_exam.css">

		<div class="row">
          <style>
            #footerwrap{
                display:none;
                padding:0!important;
                margin:0!important;
            }
@media screen and (min-width: 787){
    #pause_time2 {display: none!important;}
}
@media screen and (min-width: 200px) and (max-width: 786px){
    #testname{
        font-size: 12px!important;
    }
    #proimg, #quepalette,#questionshow{
        display: none;
    }
    #pause_time2 {display: block!important;}
    #main-content{
        mmin-height: 1200px; 
        mmax-height:4000px; 
        overflow-y: scroll; 
        padding-bottom: 0!important;
    }
    #submittest{
        display: block!important;
    }
    .scrollbar{
        min-height: 400px!important;
    }
    .scrollbar2{
        min-height: 650px!important;
    }
    #7 {max-height: 400px!important;}
    #ansChecked {margin-top: -20px;}

    #submitbtn{
   		display: flex;
  		align-items: center;
  		justify-content: center;
 		margin-top:20px; 

    }
}

        </style>
        <body style="overflow-y: scroll; height: 100%;">
			<div class="col-md-12 sscrollbar2" id="main-content" ">

			<!-- Main content -->
				<div class="panel panel-danger">

					<div class="panel-heading text-center" style="background: #FF9934;" id="testname">
						<h3 class="panel-title ttext-primary"><font size="5px" color="white"><b>SearchUrCollege Test Series (<?php echo $exam_name;?>)</b></font></h3>
						<div id="instruction"><a id="questionshow" href="#DemoModal1" class="pull-right" data-toggle="modal" style="margin-top:-20px;float:left; margin-right:120px; color: black;"><i class="fa fa-book"></i> Questions</a>
						<a href="#DemoModal2" class="pull-" data-toggle="modal" style="margin-top:-20px; margin-right:20px; float:right; color: black;"><i class="fa fa-info-circle"></i> Instruction</a>
					</div></div>
					<div class="panel-body scrollbar2" style="min-height: 70%; padding: 0px; overflow: hidden;">
					
						<div class="col-md-3 col-xs-12 pull-right">
							<div class="row" style="border:2px solid #ebccd1; margin-right:15px; margin-left:15px;" id="proimg">
								<div class="col-md-6 col-xs-12">
									<img id="conditage_image" style="border: 0px; padding: 5px;" src="<?php echo 'https://www.searchurcollege.com/exam/profile/profileImage/'.$_SESSION['photo'];?>" width="150px" height="150px;">
									<h3 id="user-name" class="text-left"><?php echo strtoupper($user_name); ?> </h3>
								</div>

								<div class="col-md-6 col-xs-12 text-right" id="pause_time">
                                    <input type="hidden" name="time_saved" id="time_saved" value="" />
									<h3 id="remain-time" style="margin-left: -20px;" class="text-danger"><b style="font-size: 18px;">TIME LEFT</b>
                                    
                                    <button type="button" class="btn btn-success" style="background: black!important; color: white!important;" id="clock"><b style="font-size: 15px;"><span class="divCounter" id="divCounter" style="font-size: 18px;"></span></b></button></h3>
                                    <input type="hidden" name="start_value" id="start_value" value="<?php echo $_SESSION['timeLeft'];?>" />
                                    <input type="hidden" name="pause_value" id="pause_value" value="2" />
                                    <input type="hidden" name="timeLeft" id="timeLeft" />
                                    <input type="hidden" name="loadData" id="loadData" />
                                    <br /><input type="button" style="margin-left: -20px;" class="btn btn-default" style="background: white!important;" id="pause" value="Pause Test" />
								</div>
							</div>
							
							<div class="col-md-12 col-xs-12" style="margin-top:15px;">
							
								<div class="panel panel-danger" style="max-height: 65%;" id="quepalette">

									<div class="panel-heading text-center">

										<h4 class="panel-title">Question Palette</h4>

									</div>

									<div class="panel-body" id="quetionList" style="min-height:400px; max-height:400px!important;">
									<div class="panel-body" id="quetionList2" style="min-height:400px; background: gray; display: none;">
                                    </div>
										<ul id="quetionList1" class="nav nav-tabs" style="min-height:200px; max-height:200px!important; overflow-y: scroll">
											<?php
												$quesIdStm="SELECT question_id FROM questions where exam_id=?";
												$quesID = $myconn->prepare($quesIdStm);
												$quesID->bind_param('i', $examID);
												$quesID->execute();
												$quesID->store_result();
												$quesID->bind_result($question_id);
                                                $NofQues=1;
                                                while($quesID->fetch()>0){
											?>	
												
												<li class="<?php echo $NofQues;?>" style="width: 30px;"><center><a data-toggle="tab" index="<?php echo $NofQues;?>" onclick="tabActive();" id="tabID" class="not_visited" href="<?php echo $question_id;?>" style="padding-left: 5px!important; padding-right: 5px!important;"><?php echo $NofQues;?></a></center></li>
													
											<?php
												$NofQues++;
												}
												
											?>			
										</ul>
										<div class="col-md-12">
										<table class="instruction_area" style="margin-top:2px;">  
											<tbody>  
												<tr>  
													<td><span class="not_visited" title="Not Visited">A</span></td>  
													<td>Not Visited</td>  
												</tr>  
												<tr>  
													<td><span class="not_answered" title="Not Answered">B</span></td>  
													<td>Not Answered</td>  
												</tr>  
												<tr>  
													<td><span class="answered" title="Answered">C</span></td>  
													<td>Answered</td>  
												</tr>  
												<tr>  
													<td><span class="review" title="Not Answered &amp; Mark for Review">D</span></td>  
													<td>Marked for Review</td>  
												</tr>   
											</tbody>  
										</table> 
										</div>

									</div>
									 <div class="col-md-12 text-center"style="margin-top: -10px;">
										<form id="formSubmitExam" name="formSubmitExam">
											<input type="hidden" name="hfUserId" id="hfUserId" value="<?php echo $_SESSION['regUsrId'];?>">
											<input type="hidden" name="hfExamId" id="hfExamId" value="<?php echo $examID;?>">
											<input type="hidden" name="hfTotalNoQues" id="hfTotalNoQues" value="<?php echo $no_of_question;?>">
											<input type="hidden" name="hfTimeDuration" id="hfTimeDuration" value="<?php echo $exam_duration;?>">
											<input type="hidden" name="hfTotalMarks" id="hfTotalMarks" value="<?php echo $total_mark;?>">
											<input type="hidden" name="hfPassMarks" id="hfPassMarks" value="<?php echo $pass_marks;?>">
											
											<a href="https://www.searchurcollege.com/exam/end-exam" type="button" id="btnSubmitExam" name="btnSubmitExam" class="btn btn-success" style="display: none;">SUBMIT EXAM</a>
										</form>
									</div> 
									
								</div>

							</div>

						</div>	
						
						<div class="col-lg-9 col-md-9">

							<div class="panel panel-primary" style="max-height: 87%; bbackground: red;">

								<div class="panel-heading">
								
									<h4 class="panel-title">
									
										<span id="Qno"></span>
										<span class="pull-right"><a href="https://www.searchurcollege.com/exam/home/?id=1"><button class="btn btn-primary btn-xs" style="margin-top: -2px;">Home</button></a></span>

									<!-- 	<span id="chooseLanguage" class="pull-right">

											View In:<select disabled="disabled" style="line-height:12px;margin-left:5px;"><option>English</option><option>Hindi</option></select>

										</span> -->
									</h4>

								</div>
								<div class="col-md-6 col-xs-12 pull-right text-right;" id="pause_time2" style="display: none; margin-top: -40px; right: 0px; background: transparent; width: 100%; text-align: right;">
                                    <button type="button" class="btn btn-success btn-xs" style="background: black!important; color: white!important; margin-top: 5px;" id="clock2"><b style="font-size: 15px;"><span class="divCounter2" id="divCounter2" style="font-size: 18px;"></span></b></button></h3>
                                    <input type="button" class="btn btn-default btn-xs" style="background: white!important; margin-top: 5px;" id="pause2" value="Pause Test" />
								</div>

								<div class="panel-body" id="question_body2" style="min-height: 65%; background: gray;">
                                    <h3 style="margin-top: 10%px; color: white;"><center>The Exam is Paused.</center></h3>
                                </div>
								<div class="panel-body scrollbar" id="question_body1" sstyle="min-height: 65%">
								

									<input type="hidden" id="no_of_question" value="<?php echo $_SESSION['no_of_question'];?>">
									
									<div class="tab-content" >

										<div class="tab-pane fade in active">
											
											<form method="post" action="" id="formAnsw" name="formAnsw" style="min-height: 500px!important;">
											
												<div id="questionID">
												 
												</div>
								
                                                <?php
                                                    if($question_id>0)
                                                    {
                                                    ?>
        												<div class="col-md-12 col-xs-12 text-center" style="margin-top: -10px;">
        													<a  id="btnClrResp" class="btn btn-info btnClrResp" style="margin-top: 10px; margin-right: 5px">CLEAR RESPONSE</a>
        													<a type="button" id="btnRev" class="btn btn-primary btnRev"style="margin-top: 10px;margin-right: 5px;">REVIEW</a>
        													<a type="button" id="btnPrev" class="btn btn-warning btnPrevious"style="margin-top: 10px;margin-right: 5px;" ><i class="fa fa-chevron-left"></i>  PREV</a>
        													<a type="button" id="btnSave" class="btn btn-danger btnSave" style="display: none;" style="margin-top: 10px;margin-right: 5px;">SAVE & NEXT  <i class="fa fa-chevron-right"></i></a>
        													<a type="button" id="btnNext" class="btn btn-danger btnNext" style="margin-top: 10px;margin-right: 5px;">SAVE & NEXT  <i class="fa fa-chevron-right"></i></a>
        													
        													<form id="formSubmitExamm" name="formSubmitExam" >
											<input type="hidden" name="hfUserId" id="hfUserId" value="<?php echo $_SESSION['regUsrId'];?>">
											<input type="hidden" name="hfExamId" id="hfExamId" value="<?php echo $examID;?>">
											<input type="hidden" name="hfTotalNoQues" id="hfTotalNoQues" value="<?php echo $no_of_question;?>">
											<input type="hidden" name="hfTimeDuration" id="hfTimeDuration" value="<?php echo $exam_duration;?>">
											<input type="hidden" name="hfTotalMarks" id="hfTotalMarks" value="<?php echo $total_mark;?>">
											<input type="hidden" name="hfPassMarks" id="hfPassMarks" value="<?php echo $pass_marks;?>">
											<a href="https://www.searchurcollege.com/exam/end-exam" type="button" id="btnSubmitExamm" name="btnSubmitExam" class="btn btn-success" style="margin-top: 10px;margin-right: 5px;">SUBMIT EXAM</a>
										</form>

        												
        													
															</form>
                                                            
        												</div>
        												
                                                    <?php    
                                                    }
                                                    else
                                                        echo '<h4>There is no Question available for this test.<h4>';
                                                ?>
												
											</form>	
											
										</div>
										
									</div>
									
								</div>

							</div>

							<!----->

						</div>	

					</div>

<script type="text/javascript">
	$("#S").click(function(){
    $("#btnSubmitExam").click();
    //alert("The paragraph was clicked.");
});
</script>
				</div>							
					
				
			</div>

			
		</div>

		<script>
			var QuesNo=1;
			$.ajax({
			type: "POST",
			url: "https://www.searchurcollege.com/exam/exam/getquestion.php?action=FQ",
			data:'quesNo='+QuesNo,
			success: function(data){
				$("#questionID").html(data);
				}
			});
            $('#Qno').html('<b>Question '+QuesNo+'</b>');
			$('li:first-child').find('a').addClass('not_answered').removeClass('not_visited');
		</script>
		
		<script>
			//*********************** Pause Button ******************************
			$('#pause, #pause2').click(function(){
    			//$('#pause').hide();
                v=parseInt($('#pause_value').val())+1;
                $('#pause_value').val(v);
                $('#pause').val('Start Test');
                $('#question_body1').hide();
                $('#question_body2').show();
                $('#quetionList1').hide();
                $('#quetionList2').show();
            });
             
			$('.btnNext').click(function(){
                $('#start_value').val($('#timeLeft').val());
				QuesNo=$('#hfQuesNo').val();
				noq=$('#noq').val();
                // if(QuesNo>=noq-1)
                // {
                	
                //     $('.btnNext').hide();
                //     $('.btnSave').show();

                // }
                // else
                
                	
                    if($('#qt').val()=='Single')
        				var UsrAns = $(".redioBtn:checked").val();
                    else
        				var UsrAns = $("#correctAns").val();
        			//alert(UsrAns);
    				var crQues = $('#hfCrQuesID').val();				
    				var timeLeft = $('#timeLeft').val();
    				$.ajax({
    				type: "POST",
    				url: 'https://www.searchurcollege.com/exam/exam/getquestion.php?action=NEXT',
    				data:'crQues='+crQues+'&quesNo='+QuesNo+'&UsrAns='+UsrAns+'&timeLeft='+timeLeft,
    				success: function(data){
    					// alert(data);
    					if(UsrAns>0){
    						$('.'+QuesNo).find('a').addClass('answered').removeClass("not_answered not_visited review");
    					}
    					else {
    						//alert('not_answered');
    						$('.'+QuesNo).find('a').addClass('not_answered').removeClass("answered not_visited review");
    					}

    					

    					if(!$.trim(data)){
    						alert('You have reached last question');
    						return false;
    					}					
    					$("#questionID").html(data);
    					var QuesNoNew=$('#hfQuesNo').val();
            			if(isNaN(QuesNoNew))
                            QuesNoNew=1;
    					$('#Qno').html('<b>Question '+QuesNoNew+'</b>');
    					$('.'+QuesNoNew).find('a').addClass('not_answered').removeClass("not_visited answered review");
    					}
    				});
                
			});

			$('.btnSave').click(function(){
                $('#start_value').val($('#timeLeft').val());
				QuesNo=$('#hfQuesNo').val();
				noq=$('#noq').val();
               // $('.btnNext').show();
               // $('.btnSave').hide();
                {
                	//alert(11);
                    if($('#qt').val()=='Single')
        				var UsrAns = $(".redioBtn:checked").val();
                    else
        				var UsrAns = $("#correctAns").val();
        			alert(UsrAns);
    				var crQues = $('#hfCrQuesID').val();				
    				var timeLeft = $('#timeLeft').val();
    				$.ajax({
    				type: "POST",
    				url: 'https://www.searchurcollege.com/exam/exam/getquestion.php?action=TAB2',
    				data:'crQues='+crQues+'&quesNo='+QuesNo+'&UsrAns='+UsrAns+'&timeLeft='+timeLeft,
    				success: function(data){
    					//alert(UsrAns);

    					if(UsrAns>0 || UsrAns!=''){
    						$('.'+QuesNo).find('a').addClass('answered').removeClass("not_answered not_visited review");
    					}else {
    						$('.'+QuesNo).find('a').addClass('not_answered').removeClass("answered not_visited review");
    					}
    					if(!$.trim(data)){
    						alert('You have reached last question');
    						return false;
    					}					
    					$("#questionID").html(data);
    					var QuesNoNew=$('#hfQuesNo').val();
            			if(isNaN(QuesNoNew))
                            QuesNoNew=1;
    					$('#Qno').text('Question '+QuesNoNew);
    					$('.'+QuesNoNew).find('a').addClass('not_answered').removeClass("not_visited answered review");
    					}
    				});
                }
			});
		</script>	
		
		<script>
			$('.btnPrevious').click(function(){
                $('.btnNext').show();
                $('.btnRev').show();
                $('.btnSave').hide();
				QuesNo=$('#hfQuesNo').val();
				$('#btnNext').attr("disabled", false);
                if($('#qt').val()=='Single')
    				var UsrAns = $(".redioBtn:checked").val();
                else
    				var UsrAns = $("#correctAns").val();
				var crQuesPrv = $('#hfCrQuesID').val();				
				$.ajax({
				type: "POST",
				url: 'https://www.searchurcollege.com/exam/exam/getquestion.php?action=PREV',
				data:'crQues='+crQuesPrv+'&quesNo='+QuesNo,
				success: function(data){
					if(UsrAns>0){
						$('.'+QuesNo).find('a').addClass('answered').removeClass("not_answered not_visited review");
					}
					if(!$.trim(data)){
						alert('You have reached at first question');
						return false;
					}					
					$("#questionID").html(data);
					QuesNo=$('#hfQuesNo').val();
        			if(isNaN(QuesNo))
                        QuesNo=1;
					$('#Qno').text('Question '+QuesNo);
					$('.'+QuesNo).find('a').addClass('zoom');
					$('.'+QuesNo).find('a').addClass('not_answered').removeClass("not_visited answered review");
					}
				});				
			});
		</script>
		
		<script>
			//*********************** Clear Response Button ******************************			
			$('.btnClrResp').click(function(){
				$('#ansChecked').find('input[type=radio]:checked').removeAttr('checked');
				$('#ansChecked').find('input[type=checkbox]:checked').removeAttr('checked');
			});
		</script>	
		
		<script>	
			//*********************** Review Question Button ******************************	
			$('.btnRev').click(function(){
				QuesNo=$('#hfQuesNo').val();
				noq=$('#noq').val();
                if(QuesNo>=noq-1)
                {
                    $('.btnRev').hide();
					$('.'+QuesNo).find('a').addClass('review').removeClass("not_answered not_visited answered");
                }
                else
                {
    				var RevQues = $('#hfCrQuesID').val();				
    				$.ajax({
    				type: "POST",
    				url: 'https://www.searchurcollege.com/exam/exam/getquestion.php?action=MARK',
    				data:'crQues='+RevQues+'&quesNo='+QuesNo,
    				success: function(data){
    					$('.'+QuesNo).find('a').addClass('review').removeClass("not_answered not_visited answered");
    					if(!$.trim(data)){
    						alert('You have reached last question');
    						return false;
    					}
    					$("#questionID").html(data);
    					QuesNo=$('#hfQuesNo').val();
            			if(isNaN(QuesNo))
                            QuesNo=1;
    					$('#Qno').text('Question '+QuesNo);	
    					$('.'+QuesNo).find('a').addClass('not_answered').removeClass("not_visited answered review");
    					}
    				});
                }
			});	
		</script>
		
		<script>
			//*********************** Submit Exam ****************************	
			$('#btnSubmitExamm').click(function(){
			 if (confirm('Are you sure you want to Submit?'))
             {

				$.ajax({
					type: "POST",
					url: "https://www.searchurcollege.com/exam/exam/submit_exam.php",
					data: $('#formSubmitExam').serialize(this),
					success: function(response) {
						
						if(response=="submited"){
							window.location.replace("https://www.searchurcollege.com/exam/end-exam");

							// window.open( this.href,'DoExam',"location=no,status=no,menubar=no,toolbar=no,resizable=no,scrollbars=no," + wihe),
							// window.close(this)
							// alert(11);
							// return false;
						}
					}
				});
            }
            else
            	alert(100000);
				return false;
			});		
		</script>
		
		<?php require_once(__ROOT__.'/includes/footer.php');?>
		
		<script>
			var hoursleft = 0;
            var minutesleft = 0;
            var secondsleft = 0;
			var hoursleft = parseInt($('#start_value').val().substring(0,2)); //give minutes you wish
			var minutesleft = parseInt($('#start_value').val().substring(3,5)); //give minutes you wish
            var secondsleft = parseInt($('#start_value').val().substring(6,8)); // give seconds you wish
    
			var sec = secondsleft;
			var mins = minutesleft;
			var hours = hoursleft;
			var finishedtext = "Time Up!";
			var end1;
			//if(localStorage.getItem("end1")) {
			//	end1 = new Date(localStorage.getItem("end1"));
			//}  else
             {
				end1 = new Date();
				end1.setHours(end1.getHours()+hoursleft);
				end1.setMinutes(end1.getMinutes()+minutesleft);
				end1.setSeconds(end1.getSeconds()+secondsleft);
			}
			    var counter = function () {
				var now = new Date();
			    var diff = end1 - now;

				diff = new Date(diff);

				var milliseconds = parseInt((diff%1000)/100)
				var sec = parseInt((diff/1000)%60)
				var mins = parseInt((diff/(1000*60))%60)
				var hours = parseInt((diff/(1000*60*60))%24);
				if (hours < 10) {
					hours = "0" + hours;
				}
				if (mins < 10) {
					mins = "0" + mins;
				}
				if (sec < 10) { 
					sec = "0" + sec;
				}
				if(now >= end1) {
					clearTimeout(interval);
				   // localStorage.setItem("end", null);
					localStorage.removeItem("end1");
					localStorage.clear();
					document.getElementById('divCounter').innerHTML = finishedtext;
					document.getElementById('divCounter2').innerHTML = finishedtext;
					$('#btnPrev').attr("disabled", true);
					$('#btnNext').attr("disabled", true);
					// Submit Exam 
					$.ajax({
						type: "POST",
						url: "https://www.searchurcollege.com/exam/exam/submit_exam.php",
						data: $('#formSubmitExam').serialize(this),
						success: function(response) {
							if(response=="submited"){
								wihe = 'width='+screen.availWidth+',height='+screen.availHeight;
								window.open( 'https://www.searchurcollege.com/exam/exam/end_exam.php','EndExam',"screenX=1,screenY=1,left=1,top=1," + wihe),
								window.close('DoExam')
								return false;
							}
						}
					});
				} else {
	                if(($('#pause_value').val()%2)==0)
                    {
    					var value =hours + ":" + mins + ":" + sec;
                        $('#pause').val('Pause Test');
                        $('#pause2').val('Pause Test');
                        $('#timeLeft').val(value);
                        $('#question_body1').show();
                        $('#question_body2').hide();
                        $('#quetionList1').show();
                        $('#quetionList2').hide();
    					localStorage.setItem("end1", end1);
    					document.getElementById('divCounter').innerHTML = value;
    					document.getElementById('divCounter2').innerHTML = value;
                    }
                    else
                    {
                        $('#start_value').val($('#timeLeft').val());
            			hoursleft = parseInt($('#start_value').val().substring(0,2)); //give minutes you wish
            			minutesleft = parseInt($('#start_value').val().substring(3,5)); //give minutes you wish
                        secondsleft = parseInt($('#start_value').val().substring(6,8)); // give seconds you wish

        				end1 = new Date();
        				end1.setHours(end1.getHours()+hoursleft);
        				end1.setMinutes(end1.getMinutes()+minutesleft);
        				end1.setSeconds(end1.getSeconds()+secondsleft);
        			    counter = function () {
        				now = new Date();
        			    diff = end1 - now;
           				diff = new Date(diff);
        				milliseconds = parseInt((diff%1000)/100)
        				sec = parseInt((diff/1000)%60)
        				mins = parseInt((diff/(1000*60))%60)
        				hours = parseInt((diff/(1000*60*60))%24);
        				if (hours < 10)
        					hours = "0" + hours;
        				if (mins < 10)
        					mins = "0" + mins;
        				if (sec < 10)
        					sec = "0" + sec;
                        }
                    }
				}
			}
			var interval = setInterval(counter, 0);
    </script>
	
	<script>
	function tabActive(){
		var activeTab = null;
		$('a[data-toggle="tab"]').on('show.bs.tab', function (event) {
			activeTab = $(event.target).attr("href");
			quesNo = $(event.target).attr("index");
			$.ajax({
			type: "POST",
			url: 'https://www.searchurcollege.com/exam/exam/getquestion.php?action=TAB',
			data:'crQues='+activeTab+'&quesNo='+quesNo,
			success: function(data){
				$("#questionID").html(data);
    			if(isNaN(QuesNo))
                    QuesNo=1;
				QuesNo=$('#hfQuesNo').val();
				$('#Qno').text('Question '+QuesNo);
				}
			});
		});
	}
	</script>
	
	<!--***********************************************************************************
	//	#: Instruction Modal 
	***************************************************************************************-->
	
	<div class="DemoModal2">
	
		<!-- Modal Contents -->
		<div id="DemoModal2" class="modal fade"> <!-- class modal and fade -->
		  
			<div class="modal-dialog modal-lg">
			
				<div class="modal-content">
				  
					<div class="modal-header"> <!-- modal header -->
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close" style="color: black; font-weight: bold;"></i></button>
						<h4 class="modal-title"><p> <b><u>Instruction : </u></b></p></h4>
					</div>
				 
					<div class="modal-body" style="min-height:550px; max-height:550px; overflow-y: scroll"> <!-- modal body -->
						<ol style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
									<li>Total duration of examination is <span class="text-danger"><b><?php echo $exam_duration; ?> minutes. </b></span></li>  
								<!--	<li>The clock will be set at the server. The countdown timer in the top right corner of screen will display the remaining time available for you to complete the examination. When the timer reaches zero, the examination will end by itself. You will not be required to end or submit your examination.</li>   -->
									<li>Following symbols:  
										<table width="100%" class="instruction_area" style="FONT-SIZE: 100%">  
											<tbody>  
												<tr>  
													<td><span class="not_visited" title="Not Visited">1</span></td>  
													<td>You have not visited the question yet.</td>  
                                                <!-- <td rowspan="5">
                                                    <?php
                                                    
                                                        $banner='';
                                                        if($banner=='')
                                                            $banner='no_image.jpg';
                                                      //  echo '<img style="max-with: 600px; max-height: 200px; border: 3px double gray;" src="../admin/exam/uploads/'.$banner.'" />';
                                                    ?>
                                                </td> -->
												</tr>  
												<tr>  
													<td><span class="not_answered" title="Not Answered">2</span></td>  
													<td>You have not answered the question.</td>  
												</tr>  
												<tr>  
													<td><span class="answered" title="Answered">3</span></td>  
													<td>You have answered the question.</td>  
												</tr>  
												<tr>  
													<td><span class="review" title="Not Answered &amp; Mark for Review">4</span></td>  
													<td>You have NOT answered the question, but have marked the question for review.</td>  
												</tr>  
												<tr>  
													<td><span class="review_answered" title="Answered &amp; Mark for Review" style="background-position: -6px -82px; line-height: 34px;">5</span></td>  
													<td>You have answered the question, but marked it for review.</td>  
												</tr>  
											</tbody>  
										</table>  
									</li> 
									
									<lii style="LIST-STYLE-TYPE: none">The Marked for Review status for a question simply indicates that you would like to look at that question again. 
										
									</lii> 
								</ol>
								
								
							<!-- 	 <b><u>Navigating to a Question : </u></b> -->


								 <ol start="3" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">   
									<li>Procedure for answering a multiple choice type question:  
										<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a">  
											<li>To select your answer, click on the button of one of the options.</li> 
											<li>To deselect your chosen answer, click on the button of the chosen option again or click on the <b>Clear Response</b> button.</li>  
											<li>To change your chosen answer, click on the button of another option.</li>  
											<li>To save your answer, you MUST click on the <b>Save &amp; Next</b> button.</li>  
											<li>To mark the question for review, click on the <b>Mark for Review &amp; Next</b> button.<br>  
												<em><span style="color:#ff0000;">If an answer is selected for a question that is 'Marked for Review', that answer will be considered in the evaluation even if it is not marked as 'Save &amp; Next', at the time of final submission</span>.</em>
											</li>  
										</ol>  
									</li>  
									
								</ol>
							<br>	
						<!-- 	<ol style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
								<li>Total duration of examination is <span class="text-danger"><b><?php echo $exam_duration; ?> minutes. </b></span></li>  
								<li>The clock will be set at the server. The countdown timer in the top right corner of screen will display the remaining time available for you to complete the examination. When the timer reaches zero, the examination will end by itself. You will not be required to end or submit your examination.</li>  
								<li>The Question Palette displayed on the right side of screen will show the status of each question using one of the following symbols:<br>  
									<table class="instruction_area" style="FONT-SIZE: 100%">  
										<tbody>  
											<tr>  
												<td><span class="not_visited" title="Not Visited">1</span></td>  
												<td>You have not visited the question yet.</td>  
											</tr>  
											<tr>  
												<td><span class="not_answered" title="Not Answered">2</span></td>  
												<td>You have not answered the question.</td>  
											</tr>  
											<tr>  
												<td><span class="answered" title="Answered">3</span></td>  
												<td>You have answered the question.</td>  
											</tr>  
											<tr>  
												<td><span class="review" title="Not Answered &amp; Mark for Review">4</span></td>  
												<td>You have NOT answered the question, but have marked the question for review.</td>  
											</tr>  
											<tr>  
												<td><span class="review_answered" title="Answered &amp; Mark for Review" style="background-position: -6px -82px; line-height: 34px;">5</span></td>  
												<td>You have answered the question, but marked it for review.</td>  
											</tr>  
										</tbody>  
									</table>  
								</li> 
								
								<li style="LIST-STYLE-TYPE: none">The Marked for Review status for a question simply indicates that you would like to look at that question again. 
									<font color="red">
										<i>If a question is answered and Marked for Review, your answer for that question will be considered in the evaluation. </i>
									</font>
								</li> 
							</ol>
							
							<br>
							
							<p> <b><u>Navigating to a Question : </u></b></p>
							
							<br>
							
							<ol start="4" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
								<li>To answer a question, do the following:  
									<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a"> 
										<li>Click on the question number in the Question Palette to go to that numbered question directly.</li>  
										<li>Click on <strong>Save &amp;Next</strong> to save your answer for the current question and then go to the next question.</li>  
										<li>Click on <strong>Mark for Review &amp; Next</strong> to save your answer for the current question, mark it for review, and then go to the next question.<br>  
											<span style="color:#ff0000;">Caution: Note that your answer for the current question will not be saved, if you navigate to another question directly by clicking on its question number.</span>
										</li> 
									</ol> 
								</li><br> 
								<li>You can view all the questions by clicking on the Question Paper button. Note that the options for multiple choice type questions will not be shown.</li> 
							</ol><br>	

						<p> <b><u>Answering a Question : </u></b></p>
						<br>						
						<ol start="6" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
							<li>Procedure for answering a multiple choice type question:  
								<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a">  
									<li>To select your answer, click on the button of one of the options.</li> 
									<li>To deselect your chosen answer, click on the button of the chosen option again or click on the <b>Clear Response</b> button.</li>  
									<li>To change your chosen answer, click on the button of another option.</li>  
									<li>To save your answer, you MUST click on the <b>Save &amp; Next</b> button.</li>  
									<li>To mark the question for review, click on the <b>Mark for Review &amp; Next</b> button.<br>  
										<em><span style="color:#ff0000;">If an answer is selected for a question that is 'Marked for Review', that answer will be considered in the evaluation even if it is not marked as 'Save &amp; Next', at the time of final submission</span>.</em>
									</li>  
								</ol>  
							</li>  
							<li>To change your answer to a question that has already been answered, first select that question for answering and then follow the procedure for answering that type of question.</li> 
							<li>Note that questions for which option has been chosen and answers are saved or marked for review will be considered for evaluation.</li> 
							<li><em><span style="color:#ff0000;">Ã‚Â¼ (one fourth) marks i.e. one mark will be deducted for indicating incorrect response of each question. No deduction from the total score will be made if no response is indicated for a question</span></em>.</li> 
						</ol><br>

						<div class="cusInstText1" style="height: 91%; width: 100%; overflow: auto; display: block;">
							<p style="text-align: center;">
								<u><strong>Exam specific Instructions</strong></u>
							</p> <br> <br> 
							<ol> 
								<li>This is a Mock test. The Question paper displayed is for practice purposes only. Under no circumstances should this be presumed as a sample paper.</li> 
								 
								 
								<li>Each question is allocated 4 (four) marks for each correct.</li> 
								<li>One fourth marks will be deducted for incorrect response of each question. No deduction from the total score will be made if no answer is given.</li> 
								<li>There is only one correct answer for each question.</li> 
							</ol> <br> <br>  -->
							
						</div>														
						
					</div>
						
				</div> <!-- / .modal-content -->
			  
			</div> <!-- / .modal-dialog -->
		  
		</div><!-- / .modal -->
	
	</div>
		<!--***********************************************************************************
	//	#: Instruction Modal 
	***************************************************************************************-->
	
	<div class="DemoModal1">
	
		<!-- Modal Contents -->
		<div id="DemoModal1" class="modal fade"> <!-- class modal and fade -->
		  
			<div class="modal-dialog modal-lg">
			
				<div class="modal-content">
				  
					<div class="modal-header"> <!-- modal header -->
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close" style="color: black; font-weight: bold;"></i></button>
						<h4 class="modal-title text-primary"><p> <b>All Questions :</b></p></h4>
					</div>
				 
					<div class="modal-body" style="min-height:550px; max-height:550px; overflow-y: scroll"> <!-- modal body -->
						<?php
							$QuesList="SELECT question FROM questions where exam_id=?";
							$QuesList = $myconn->prepare($QuesList);
							$QuesList->bind_param('i', $examID);
							$QuesList->execute();
							$QuesList->store_result();
							$QuesList->bind_result($ViewQuestion);
                            $QNo=1;
							while($QuesList->fetch()>0){
						?>	

						<div class="well well-sm text-center">
						    <span class="text-danger pull-left"><?php echo 'Question '.$QNo;?></span>
						    <hr style="border-top: 1px solid #0a540d;">
							<?php echo $ViewQuestion;?>
						</div>						

						<?php
					    	$QNo++;
							}
						?>
					</div>
						
				</div> <!-- / .modal-content -->
			  
			</div> <!-- / .modal-dialog -->
		  
		</div><!-- / .modal -->
	
	</div>
    
<?php
function convertToHoursMins($time, $format = '%02d:%02d')
{
    if ($time < 1)
        return;
    $hours = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}
?>

<script>
$(function() {
        $(this).bind("contextmenu", function(e) {
            e.preventDefault();
        });
    });
</script> 