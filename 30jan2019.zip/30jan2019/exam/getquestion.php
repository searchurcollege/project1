<style>
body {overflow: hidden;}
</style>
<?php 
    session_start();
    $code=$_SESSION['code'];
    if($code=='')
        $code='None';
	//************************** Include Requied File ***************************
    	define('__ROOT__', dirname(dirname(__FILE__))); 
    	require_once(__ROOT__.'/includes/global.php'); 
    	require_once(__ROOT__.'/includes/authentication.php');
    	session_start();
        $examID = $_SESSION['examID'];
    	$userID = $_SESSION['regUsrId'];
    	$timeLeft = $_REQUEST['timeLeft'];
    	$no_of_question = $_SESSION['no_of_question']+1;
    	$action = $_REQUEST['action'];
    	$quesNo = $_REQUEST['quesNo'];
        if($quesNo<2)
            $quesNo=1;
    	$q=$quesNo;
        //echo 'Q='.$q.' Qno='.$quesNo.' NOQ='.$no_of_question;
        //if($q>=$no_of_question)
        //    echo 'That was the last Question';
        if($action!='FQ')
        {
            if($q>=$no_of_question)
            {
                echo "<script>
                    $('#btnPrev').hide();
                    $('#btnNext').hide();
                    $('#btnClrResp').hide();
                    $('#btnRev').hide();
                    </script>";
                $quesNo=1;
                //echo '<h4><font color=maroon>You have reached at the End.</font></h4>';
            }
            //else
            {
                echo "<script>
                    $('#btnPrev').show();
                    $('#btnNext').show();
                    $('#btnClrResp').show();
                    $('#btnRev').show();
                    </script>";
            }
        }
	// Get Total No of Questions
		$tquestn="SELECT max(question_id) as maxID FROM questions WHERE exam_id=?";
		$tquestn = $myconn->prepare($tquestn);
		$tquestn->bind_param('i',$examID);
		$tquestn->execute();
		$tquestn->store_result();
		$tquestn->bind_result($maxID);
		$tquestn->fetch();


    /*echo "<script>
	 if ($('#loadData').val()!='yes')
     {
        $('input[type=radio]').prop('checked',false);
        $('input[type=checkbox]').prop('checked',false);
     }   
    </script>";*/
	// Load First
		if($action == "FQ"){
            echo "<script>
             $('#btnPrev').hide();";
             /*if (confirm('Load saved answers..?'))
             {
                $('#btnPrev').hide();
                $('#loadData').val('yes');
             }*/
            echo "</script>";
			$quesAnswrd="SELECT question_id FROM user_answer WHERE user_id=? AND exam_id=? AND status!='submited'";
            $quesAnswrd = $myconn->prepare($quesAnswrd);
			$quesAnswrd->bind_param('si',$userID,$examID);
			$quesAnswrd->execute();
			$quesAnswrd->store_result();
			$quesAnswrd->bind_result($questionID);
			$quesAnswrd->fetch();
			if(empty($questionID))
            {
    			$Ques="SELECT exam_duration FROM exam WHERE exam_id=?";
				$Ques = $myconn->prepare($Ques);
				$Ques->bind_param('i',$examID);
				$Ques->execute();
				$Ques->store_result();
				$Ques->bind_result($examDuration);
				$Ques->fetch();
                session_start();
                $_SESSION['timeStart']='00:'.$examDuration.':00';

    			//$Ques="SELECT question_id, question FROM questions WHERE question_id=? AND exam_id=? ORDER BY question_id asc LIMIT 1";
    			$Ques="SELECT question_id, question FROM questions WHERE exam_id=? ORDER BY question_id asc LIMIT 1";
				$Ques = $myconn->prepare($Ques);
				$Ques->bind_param('i',$examID);
				$Ques->execute();
				$Ques->store_result();
				$Ques->bind_result($crQuesID,$ViewQuestion);
				$Ques->fetch();
			}
			else
            {
				$Ques="SELECT e.question_id, e.question, ue.answer, ue.status FROM questions e, user_answer ue 
						WHERE e.exam_id=? AND ue.user_id=? AND e.question_id=ue.question_id AND ue.status!='submited'
						ORDER BY e.question_id asc LIMIT 1";
				$Ques = $myconn->prepare($Ques);
				$Ques->bind_param('is', $examID,$userID);
				$Ques->execute();
				$Ques->store_result();
				$Ques->bind_result($crQuesID,$ViewQuestion,$answer,$status);
				$Ques->fetch();
                if($status=='submited')
                    $answer='';
			}
            $_SESSION['fq']=$crQuesID;
		}
		else if($action == "NEXT"){  
            //alert("12");
            $crQues = $_POST['crQues'];
			$quesNo = $_REQUEST['quesNo'];
			$UsrAns = $_REQUEST['UsrAns'];
            $_POST['crQues'] = "";
			if($UsrAns=='undefined'){
				$UsrAns='';
			}
			$mark = 0;
			// Chech previous question is inserted
			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id=$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
            $Ques = $myconn->prepare($Ques);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($question_id,$answer_id,$answer);
			$Ques->fetch();
			if(!empty($answer_id))
            {
                $crQues=$question_id;
				//$UsrAns=$answer;
                $stmUpdt="UPDATE user_answer SET code='$code', answer='$UsrAns', mark='$mark', time_left='$timeLeft' WHERE answer_id=$answer_id";
                $stmsUdt = $myconn->prepare($stmUpdt);
				$stmsUdt->execute();
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id>$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
                $Ques = $myconn->prepare($Ques);
    			$Ques->execute();
    			$Ques->store_result();
    			$Ques->bind_result($question_id,$answer_id,$answer);
    			$Ques->fetch();
    			if(empty($answer_id))
                {
        			$_REQUEST['UsrAns']='';
                    echo "<script> 
                    //    $('#correctAns').val('');
                        </script>";
                }
			}
			else
            {
				$stmIns="INSERT INTO user_answer (code,exam_id,user_id,question_id,answer,mark,time_left) VALUES(?,?,?,?,?,?,?)";
				$stmsIns = $myconn->prepare($stmIns);
				$stmsIns->bind_param('sisisis', $code, $examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
				$stmsIns->execute();							
            }
            if($crQues==$maxID)
            {
                echo "<script> 
					alert('You have reached at last question');
                    </script>";
    			$Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id=$crQues ORDER BY question_id asc LIMIT 1";
                $action == "LAST";
    			$quesNo = $_REQUEST['quesNo'];
            }
            else
            {
                $answer='';
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id>$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
                $Ques = $myconn->prepare($Ques);
    			$Ques->execute();
    			$Ques->store_result();
    			$Ques->bind_result($question_id,$answer_id,$answer);
    			$Ques->fetch();
                ?>
                <script>
                $('.btnNext').html('SAVE & NEXT  <i class="fa fa-chevron-right"></i>');
                </script>
                <?php
    			$Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id>$crQues ORDER BY question_id asc LIMIT 1";
                echo "<script> 
    				//$('#ansChecked').find('input[type=radio]:checked').removeAttr('checked');
    				//$('#ansChecked').find('input[type=checkbox]:checked').removeAttr('checked');
                    //$('#correctAns').val('');
                    </script>";
			}
			++$quesNo;
            $Ques = $myconn->prepare($Ques);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($crQuesID,$ViewQuestion);
			$Ques->fetch();
		}
		else if($action == "LAST"){  
		  //echo "LAST";
            $crQues = $_POST['crQues'];
			$quesNo = $_REQUEST['quesNo'];
			$UsrAns = $_REQUEST['UsrAns'];
			$_POST['crQues'] = "";
			if($UsrAns=='undefined'){
				$UsrAns='';
			}			
			$mark = 0;
			// Chech previous question is inserted
			$Ques="SELECT question_id FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id=$maxID AND status!='submited'";
            $Ques = $myconn->prepare($Ques);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($question_id);
			$Ques->fetch();
            if(!empty($question_id)){
				// Update if question is already answered 
				$stmUpdt="UPDATE user_answer SET code='$code', answer='$UsrAns', mark=$mark, time_left='$timeLeft' WHERE question_id=$maxID AND user_id='$userID' AND status!='submited'";
                $stmsUdt = $myconn->prepare($stmUpdt);
				$stmsUdt->execute();
			}
			else {
				$stmIns="INSERT INTO user_answer (code,exam_id,user_id,question_id,answer,mark,time_left)VALUES(?,?,?,?,?,?,?)";
				$stmsIns = $myconn->prepare($stmIns);
				$stmsIns->bind_param('sisisis', $code, $examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
				$stmsIns->execute();							
			}
			$Ques="SELECT question_id, question FROM questions WHERE exam_id=? AND question_id = $maxID ORDER BY question_id asc LIMIT 1";
			$Ques = $myconn->prepare($Ques);
			$Ques->bind_param('i',$examID);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($crQuesID,$ViewQuestion);
			$Ques->fetch();
			$quesNo=$no_of_question-1;
		}
		else if($action == "PAUSE")
        {
			$stmChkQnt="SELECT question_id FROM user_answer WHERE question_id=? AND user_id=? and exam_id=? AND ue.status!='submited'";
			$stmChkQnt = $myconn->prepare($stmChkQnt);
			$stmChkQnt->bind_param('isi', $crQues,$userID,$examID);
			$stmChkQnt->execute();
			$stmChkQnt->store_result();
			$stmChkQnt->bind_result($QuesID);
			$stmChkQnt->fetch();
			//if(!empty($QuesID)){
				// Update if question is already answered 
				$stmUpdt="UPDATE user_answer SET code='$code', answer='$UsrAns', mark='$mark', time_left='$timeLeft' WHERE question_id=? AND user_id=? AND exam_id=? AND status!='submited'";
				$stmsUdt = $myconn->prepare($stmUpdt);
				$stmsUdt->bind_param('isi', $crQues,$userID,$examID);
				$stmsUdt->execute();
                echo '<script>//window.close();</script>';
			//}
			//else{
			//	$stmIns="INSERT INTO user_answer (exam_id,user_id,question_id,answer,mark,time_left)VALUES(?,?,?,?,?,?)";
			//	$stmsIns = $myconn->prepare($stmIns);
			//	$stmsIns->bind_param('isisis', $examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
			//	$stmsIns->execute();							
			//}	
        }
        else if($action == "MARK"){
            $crQues = $_POST['crQues'];
			//echo "<br>QID=".$crQues;
            $quesNo = $_REQUEST['quesNo'];
			$UsrAns = $_REQUEST['UsrAns'];
            $_POST['crQues'] = "";
			if($UsrAns=='undefined'){
				$UsrAns='';
			}
			$mark = 0;
			// Chech previous question is inserted
			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id=$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
            $Ques = $myconn->prepare($Ques);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($question_id,$answer_id,$answer);
			$Ques->fetch();
			if(!empty($answer_id))
            {
                $crQues=$question_id;
				//$UsrAns=$answer;
                //$stmUpdt="UPDATE user_answer SET code='$code', answer='$UsrAns', mark='$mark', time_left='$timeLeft' WHERE answer_id=$answer_id";
                //$stmsUdt = $myconn->prepare($stmUpdt);
				//$stmsUdt->execute();
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id>$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
                $Ques = $myconn->prepare($Ques);
    			$Ques->execute();
    			$Ques->store_result();
    			$Ques->bind_result($question_id,$answer_id,$answer);
    			$Ques->fetch();
    			if(empty($answer_id))
                {
        			$_REQUEST['UsrAns']='';
                    echo "<script> 
                    //    $('#correctAns').val('');
                        </script>";
                }
			}
			else
            {
				//$stmIns="INSERT INTO user_answer (code,exam_id,user_id,question_id,answer,mark,time_left) VALUES(?,?,?,?,?,?,?)";
				//$stmsIns = $myconn->prepare($stmIns);
				//$stmsIns->bind_param('sisisis', $code, $examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
				//$stmsIns->execute();							
            }
            if($crQues==$maxID)
            {
                echo "<script> 
                    $('.btnNext').text('Save');
					alert('You have reached at last question');
                    </script>";
    			$Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id=$crQues ORDER BY question_id asc LIMIT 1";
                $action == "LAST";
    			$quesNo = $_REQUEST['quesNo'];
            }
            else
            {
                $answer='';
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id>$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
                $Ques = $myconn->prepare($Ques);
    			$Ques->execute();
    			$Ques->store_result();
    			$Ques->bind_result($question_id,$answer_id,$answer);
    			$Ques->fetch();
                ?>
                <script>
                $('.btnNext').html('SAVE & NEXT  <i class="fa fa-chevron-right"></i>');
                </script>
                <?php
    			$Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id>$crQues ORDER BY question_id asc LIMIT 1";
                echo "<script> 
    				//$('#ansChecked').find('input[type=radio]:checked').removeAttr('checked');
    				//$('#ansChecked').find('input[type=checkbox]:checked').removeAttr('checked');
                    //$('#correctAns').val('');
                    </script>";
			}
			++$quesNo;
            $Ques = $myconn->prepare($Ques);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($crQuesID,$ViewQuestion);
			$Ques->fetch();
		}
		else if($action == "PREV"){
            $crQues = ($_POST['crQues']);
			//echo "<br>Q=".$crQues;
            //--$crQues;
			//echo "<br>QID2=".$crQues;
			$quesNo = $_REQUEST['quesNo'];
            if($quesNo<=2)
                $quesNo=1;
            $UsrAns = $_REQUEST['UsrAns'];
            $_POST['crQues'] = "";
			if($UsrAns=='undefined'){
				$UsrAns='';
			}
            $answer='';
			$mark = 0;
			// Chech previous question is inserted
            if($crQues==$_SESSION['fq'])
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id=$crQues AND status!='submited' ORDER BY question_id desc LIMIT 1";
            else
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id=($crQues-1) AND status!='submited' ORDER BY question_id desc LIMIT 1";
            //echo $Ques;
            $Ques = $myconn->prepare($Ques);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($question_id,$answer_id,$answer);
			$Ques->fetch();
            //echo 'A='.$answer;
			if(!empty($answer_id))
            {
                //--$crQues;//=$question_id;
				//$UsrAns=$answer;
                //$stmUpdt="UPDATE user_answer SET code='$code', answer='$UsrAns', mark='$mark', time_left='$timeLeft' WHERE answer_id=$answer_id";
                //$stmsUdt = $myconn->prepare($stmUpdt);
				//$stmsUdt->execute();
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id=$crQues AND status!='submited' ORDER BY question_id desc LIMIT 1";
                $Ques = $myconn->prepare($Ques);
    			$Ques->execute();
    			$Ques->store_result();
    			$Ques->bind_result($question_id,$answer_id,$answer);
    			$Ques->fetch();
    			if(empty($answer_id))
                {
                    $_REQUEST['UsrAns']='';
                    //echo "<script> 
                    //    $('#correctAns').val('');
                    //    </script>";
                }
			}
			else
            {
                $answer='';
                echo "<script> 
    				$('#ansChecked').find('input[type=radio]:checked').removeAttr('checked');
    				$('#ansChecked').find('input[type=checkbox]:checked').removeAttr('checked');
                    $('#correctAns').val('');
                    </script>";
				//$stmIns="INSERT INTO user_answer (code,exam_id,user_id,question_id,answer,mark,time_left) VALUES(?,?,?,?,?,?,?)";
				//$stmsIns = $myconn->prepare($stmIns);
				//$stmsIns->bind_param('sisisis', $code, $examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
				//$stmsIns->execute();							
            }
            if($crQues==$_SESSION['fq'])
            {
                echo "<script> 
                    $('#btnPrev').hide();
                    </script>";
    			$Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id=$crQues ORDER BY question_id desc LIMIT 1";
                $action == "LAST";
    			$quesNo = 1;
            }
            else
            {
                $answer='';
    			$Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id<$crQues AND status!='submited' ORDER BY question_id desc LIMIT 1";
                $Ques = $myconn->prepare($Ques);
    			$Ques->execute();
    			$Ques->store_result();
    			$Ques->bind_result($question_id,$answer_id,$answer);
    			$Ques->fetch();
                ?>
                <script>
                    $('#btnPrev').show();
                </script>
                <?php
    			$Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id<$crQues ORDER BY question_id desc LIMIT 1";
                //echo "<script> 
    				//$('#ansChecked').find('input[type=radio]:checked').removeAttr('checked');
    				//$('#ansChecked').find('input[type=checkbox]:checked').removeAttr('checked');
                    //$('#correctAns').val('');
                    //</script>";
			}
            if($crQues>$_SESSION['fq'])
    			;//++$quesNo;
			--$quesNo;
            $Ques = $myconn->prepare($Ques);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($crQuesID,$ViewQuestion);
			$Ques->fetch();
		}
        else if($action == "TAB2"){
             $crQues = $_POST['crQues'];
            $quesNo = $_REQUEST['quesNo'];
            $UsrAns = $_REQUEST['UsrAns'];
            $_POST['crQues'] = "";
            if($UsrAns=='undefined'){
                $UsrAns='';
            }
            $mark = 0;
            // Chech previous question is inserted
            $Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id=$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
            $Ques = $myconn->prepare($Ques);
            $Ques->execute();
            $Ques->store_result();
            $Ques->bind_result($question_id,$answer_id,$answer);
            $Ques->fetch();
            if(!empty($answer_id))
            {
                $crQues=$question_id;
                //$UsrAns=$answer;
                $stmUpdt="UPDATE user_answer SET code='$code', answer='$UsrAns', mark='$mark', time_left='$timeLeft' WHERE answer_id=$answer_id";
                $stmsUdt = $myconn->prepare($stmUpdt);
                $stmsUdt->execute();
                $Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id>$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
                $Ques = $myconn->prepare($Ques);
                $Ques->execute();
                $Ques->store_result();
                $Ques->bind_result($question_id,$answer_id,$answer);
                $Ques->fetch();
                if(empty($answer_id))
                {
                    $_REQUEST['UsrAns']='';
                    echo "<script> 
                    //    $('#correctAns').val('');
                        </script>";
                }
            }
            else
            {
                $stmIns="INSERT INTO user_answer (code,exam_id,user_id,question_id,answer,mark,time_left) VALUES(?,?,?,?,?,?,?)";
                $stmsIns = $myconn->prepare($stmIns);
                $stmsIns->bind_param('sisisis', $code, $examID,$userID,$crQues,$UsrAns,$mark,$timeLeft);
                $stmsIns->execute();                            
            }
            if($crQues==$maxID)
            {
                echo "<script> 
                    $('.btnNext').text('Save');
                    alert('You have reached at last question');
                    </script>";
                $Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id=$crQues ORDER BY question_id asc LIMIT 1";
                $action == "LAST";
                $quesNo = $_REQUEST['quesNo'];
            }
            else
            {
                $answer='';
                $Ques="SELECT question_id, answer_id, answer FROM user_answer WHERE exam_id=$examID AND user_id='$userID' AND question_id>$crQues AND status!='submited' ORDER BY question_id LIMIT 1";
                $Ques = $myconn->prepare($Ques);
                $Ques->execute();
                $Ques->store_result();
                $Ques->bind_result($question_id,$answer_id,$answer);
                $Ques->fetch();
                ?>
                <script>
                $('.btnNext').html('SAVE & NEXT  <i class="fa fa-chevron-right"></i>');
                </script>
                <?php
                $Ques="SELECT question_id, question FROM questions WHERE exam_id=$examID AND question_id>$crQues ORDER BY question_id asc LIMIT 1";
                echo "<script> 
                    //$('#ansChecked').find('input[type=radio]:checked').removeAttr('checked');
                    //$('#ansChecked').find('input[type=checkbox]:checked').removeAttr('checked');
                    //$('#correctAns').val('');
                    </script>";
            }
            ++$quesNo;
            $Ques = $myconn->prepare($Ques);
            $Ques->execute();
            $Ques->store_result();
            $Ques->bind_result($crQuesID,$ViewQuestion);
            $Ques->fetch();
        }
		else if($action == "TAB"){
			$crQues = $_POST['crQues'];
			$quesNo = $_REQUEST['quesNo'];
			$_POST['crQues'] = "";
			$Ques="SELECT e.question_id, e.question, ue.answer, ue.status FROM questions e, user_answer ue 
			WHERE e.exam_id=? AND e.question_id='$crQues' AND e.question_id=ue.question_id AND ue.user_id=? AND ue.status!='submited'
			ORDER BY e.question_id desc LIMIT 1";
			$Ques = $myconn->prepare($Ques);
			$Ques->bind_param('is', $examID,$userID);
			$Ques->execute();
			$Ques->store_result();
			$Ques->bind_result($crQuesID,$ViewQuestion,$answer,$status);
			$Ques->fetch();
            if($status=='submited')
                $answer='';
			if(empty($crQuesID)){
				$Ques="SELECT question_id, question FROM questions  WHERE exam_id=? AND question_id='$crQues' ORDER BY question_id asc LIMIT 1";
				$Ques = $myconn->prepare($Ques);
				$Ques->bind_param('i',$examID);
				$Ques->execute();
				$Ques->store_result();
				$Ques->bind_result($crQuesID,$ViewQuestion);
				$Ques->fetch();	
			}
		}		
		if(!empty($crQuesID)){
        // Question Type
        $QID=$crQuesID-1;
		$Ques="SELECT question_type FROM questions WHERE exam_id=? AND question_id > '$QID' ORDER BY question_id asc LIMIT 1";
		$Ques = $myconn->prepare($Ques);
		$Ques->bind_param('i',$examID);
		$Ques->execute();
		$Ques->store_result();
		$Ques->bind_result($questionType);
		$Ques->fetch();
        echo '<input type="hidden" id="qt" name="qt" value="'.$questionType.'" />';
        if($crQuesID>=$maxID)
        {
            $userID=$_SESSION['regUsrId'];
    		$tquestn="SELECT answer FROM user_answer WHERE user_id='$userID' AND question_id=$maxID AND status!='submited'";
    		$tquestn = $myconn->prepare($tquestn);
    		$tquestn->execute();
    		$tquestn->store_result();
    		$tquestn->bind_result($maxAns);
    		$tquestn->fetch();
            $answer=$maxAns;
        }
    ?>
        	<input type="hidden" id="option1" />
        	<input type="hidden" id="option2" />
        	<input type="hidden" id="option3" />
        	<input type="hidden" id="option4" />
            <?php
                $answer=str_replace(' ', '', $answer);
                if($quesNo<2)
                    $quesNo=1;
                ?>
        	<input type="hidden" id="correctAns" name="correctAns" value="<?php echo $answer;?>"/>
        	<input type="hidden" id="hfCrQuesID" name="hfCrQuesID" value="<?php echo $crQuesID; $crQuesID="";?>">
			<input type="hidden" id="hfQuesNo" name="hfQuesNo" value="<?php echo $quesNo; $quesNo="";?>">
			<input type="hidden" id="noq" name="noq" value="<?php echo ($no_of_question-1);?>">
			<div class="divQues scrollbar style-4" style="mmin-height:60%!important; height: 400px!importantimportant; mmax-height:330px; overflow-y: scroll;">
				<p><?php echo $ViewQuestion;?></p>
			</div>
			<div class="col-md-12 col-xs-12 text-center" id="ansChecked" style="margin-bottom: 0px;">
				<h4><b style="margin-right: 20px;" id="sa">Select answer:</b>
    <?php
        if($questionType=='Single')
        {
 ?>
				<label for="rd1" style="margin-right: 20px; cursor: pointer;"><input class="redioBtn" <?php if($answer==1){echo 'checked=checked';}?>  type="radio" onclick="collectRadio(1);" name="correctAns" id="rd1" value="1"/>
				A </label>
				<label for="rd2" style="margin-right: 20px; cursor: pointer;"><input class="redioBtn" type="radio" <?php if($answer==2){echo 'checked=checked';}?> onclick="collectRadio(2);" name="correctAns" id="rd2" value="2"/>
				B </label>
				<label for="rd3" style="margin-right: 20px; cursor: pointer;"><input class="redioBtn" type="radio" <?php if($answer==3){echo 'checked=checked';}?> onclick="collectRadio(3);" name="correctAns" id="rd3" value="3"/>
				C </label>
				<label for="rd4" style="margin-right: 20px; cursor: pointer;"><input class="redioBtn" type="radio" <?php if($answer==4){echo 'checked=checked';}?> onclick="collectRadio(4);" name="correctAns" id="rd4" value="4"/>
				D </label>										
        <?php
        }
        else
        {
        ?>
				<input class="redioBtn" <?php if(strpos($answer, '1') !== false){echo 'checked=checked';}?>  type="checkbox" onchange="collect(1,'rd1');" nname="correctAns" id="rd1" value="1"/>
				<label for="rd1" style="margin-right: 20px; cursor: pointer;">A</label>
				<input class="redioBtn" type="checkbox" <?php if(strpos($answer, '2') !== false){echo 'checked=checked';}?> onchange="collect(2,'rd2');" nname="correctAns" id="rd2" value="2"/>
				<label for="rd2" style="margin-right: 20px; cursor: pointer;">B</label>
				<input class="redioBtn" type="checkbox" <?php if(strpos($answer, '3') !== false){echo 'checked=checked';}?> onchange="collect(3,'rd3');" nname="correctAns" id="rd3" value="3"/>
				<label for="rd3" style="margin-right: 20px; cursor: pointer;">C</label>
				<input class="redioBtn" type="checkbox" <?php if(strpos($answer, '4') !== false){echo 'checked=checked';}?> onchange="collect(4,'rd4');" nname="correctAns" id="rd4" value="4"/>
				<label for="rd3" style="margin-right: 20px; cursor: pointer;">D</label>	
        <?php
        }
		}
        ?>
            </h4>
			</div>
<script>
    if($('#hfQuesNo').val()=='undefinee')
		$('#hfQuesNo').val(1);
        
    function collect(x,y)
    {
        if($("#"+y).is(':checked'))
        {
            if(y=='rd1')
                $('#option1').val(1);
            if(y=='rd2')
                $('#option2').val(2);
            if(y=='rd3')
                $('#option3').val(3);
            if(y=='rd4')
                $('#option4').val(4);
            a=$('#option1').val();
            b=$('#option2').val();
            c=$('#option3').val();
            d=$('#option4').val();
            if(a.length>0)
                a=a+',';
            if(b.length>0)
                b=b+',';
            if(c.length>0)
                c=c+',';
            if(d.length>0)
                d=d+',';
            e=a+b+c+d;
            e=e.slice(0,-1);
            $('#correctAns').val(e);
        }
        else
        {
            if(y=='rd1')
                $('#option1').val('');
            if(y=='rd2')
                $('#option2').val('');
            if(y=='rd3')
                $('#option3').val('');
            if(y=='rd4')
                $('#option4').val(''); 
            a=$('#option1').val();
            b=$('#option2').val();
            c=$('#option3').val();
            d=$('#option4').val();
            if(a.length>0)
                a=a+',';
            if(b.length>0)
                b=b+',';
            if(c.length>0)
                c=c+',';
            if(d.length>0)
                d=d+',';
            e=a+b+c+d;
            e=e.slice(0,-1);
            $('#correctAns').val(e);
        }
    }

    function collectRadio(x)
    {
        $('#correctAns').val(x);
    }

</script>