<?php
    include_once '../includes/global.php';
    include_once '../includes/authentication.php';
	define('__ROOT__', dirname(dirname(__FILE__))); 
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<sscript src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>

<llink rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/start_exam.css">	
<llink rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/do_exam.css">
<style>
.radioBtn
{
    padding-right: 20px!important;
    display: inline-block!important;
}
.scrollbar
{
	mmargin-left: 30px;
	float: left;
	height: 380px;
	width: 100%;
	background: #F5F5F5;
	overflow-y: scroll;
	margin-bottom: 25px;
}

.force-overflow
{
	min-height: 450px;
}

.style-4::-webkit-scrollbar-track
{
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar
{
	width: 10px;
	background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar-thumb
{
	background-color: #000000;
	border: 2px solid #555555;
}
</style>
<body onload="first();">
        <form id="ifrm">
            <div class="row panel panel-primary" style="background: #428BCA; padding: 10px;">
                <table width="100%">
                    <tr><td style="padding-left: 20px; color: white;">Question
                            <?php
                                if(isset($_REQUEST['num']))
                                    echo $_REQUEST['num'];
                                else
                                {
                                    if(isset($_SESSION['sno']))
                                        echo $_SESSION['sno'];
                                    else
                                    {
                                        $_REQUEST['sno2']=$_REQUEST['sno2']+1;
                                        $sno=0;
                                        echo $_REQUEST['sno2'];
                                    }
                                }
                                //echo '<br />NUM='.$_REQUEST['num'].' SNO2='.$_REQUEST['sno2'].' Next='.$_REQUEST['next'];
                            ?>
                        </td>
                        <td align="right" style="padding-right: 10px;"><span style="color: white;">View in</span>&nbsp;&nbsp;<select class="text-right" disabled="disabled" sstyle="line-height:12px;margin-left:5px; color: black;"><option>English</option><option>Hindi</option></select></td>
                    </tr>
                </table>
            </div>
            <div id="Qdata" class="panel-body" style="background: white;">
                <div class="scrollbar style-4" style="background: white;">
                    <div class="force-overflow text-left">
                        <?php
                            //if($_REQUEST['sno2']!=$_REQUEST['noq'])
                            {
                                $examID=$_REQUEST['eid'];
                                session_start();
                                $userID=$_SESSION['regUsrId'];
                                echo '<input type="hidden" id="uid" value="'.$userID.'" />';                                                                
                                $quesIdStm="SELECT question_id FROM questions WHERE exam_id=$examID";
                                $quesID = $myconn->prepare($quesIdStm);
                            	$quesID->execute();
                            	$quesID->store_result();
    							$quesID->bind_result($question_id);
                                $i=1;
                                $sno=array();
                                $qno=array();
    							while($quesID->fetch()>0)
                                {
                                    $sno[$i-1]=$i;
                                    $qno[$i-1]=$question_id;
                                    $i++;
                                }
                                $one=$qno[0];
                                if($one=='')
                                {
                                    echo 'Questions are not uploaded yet';
                                    exit;
                                }
                                $noq=$i-1;
                                if(isset($_REQUEST['sno2']))
                                {
                                    if($_REQUEST['next']=='Y')
                                    {
                                        $sno=$_REQUEST['sno2']-1;
                                        $qno=$qno[$sno];
                                    }
                                    else
                                    {
                                        $sno=$_REQUEST['num']-1;
                                        $qno=$_REQUEST['sno2'];
                                    }
                                    $sno++;
                                }
                                else
                                {
                                    $sno=$sno[0];
                                    $qno=$qno[0];
                                }
                                if($_REQUEST['sno2']==1)
                                {
                                    $qno=$one;
                                    $sno++;
                                }

                                if(isset($_SESSION['sno']))
                                {
                                    $qno=$_SESSION['qid'];
                                    $sno=$_SESSION['sno'];
                                    unset($_SESSION['qid']);
                                    unset($_SESSION['sno']);
                                }

                                $quesIdStm="SELECT question, question_type FROM questions where question_id=$qno";
                                $quesID = $myconn->prepare($quesIdStm);
                            	$quesID->execute();
                            	$quesID->store_result();
                            	$quesID->bind_result($question, $question_type);
        						while($quesID->fetch()>0)
                                {
                                    $question=$question;
                                    $question_type=$question_type;
                                }
                                echo $question;
                             }
                             //$_REQUEST['sno2']=$_REQUEST['sno2']+1;
                        ?>
                    </div>
                </div>
                <div id="ansChecked" style="background: white;">
                    <h4><b>Select Answer: 
                    <?php
                    	$quesIdStm="SELECT answer FROM user_answer
                            WHERE exam_id=$examID AND user_id='$userID' AND question_id=$qno";
                        $quesID = $myconn->prepare($quesIdStm);
                    	$quesID->execute();
                    	$quesID->store_result();
						$quesID->bind_result($answer);
						while($quesID->fetch()>0)
                            $answer=$answer;
                        if($question_type=='Single')
                        {
                        ?>
            				<label for="rd1" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" <?php if($answer==1){echo 'checked=checked';}?>  type="radio" nname="correctAns" onclick="collectRadio(1);" id="rd1" value="1"/> A </label>
            				<label for="rd2" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="radio" <?php if($answer==2){echo 'checked=checked';}?>  nname="correctAns" onclick="collectRadio(2);" id="rd2" value="2"/> B </label>
            				<label for="rd3" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="radio" <?php if($answer==3){echo 'checked=checked';}?>  nname="correctAns" onclick="collectRadio(3);" id="rd3" value="3"/> C </label>
            				<label for="rd4" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="radio" <?php if($answer==4){echo 'checked=checked';}?>  nname="correctAns" onclick="collectRadio(4);" id="rd4" value="4"/> D </label>										
                        <?php
                        }
                        else
                        {
                        ?>
            				<label for="rd1" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" <?php if(strpos($answer, '1') !== false){echo 'checked=checked';}?> type="checkbox" onchange="collect(1,'rd1');" id="rd1" value="1"/> A </label>
               				<label for="rd2" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="checkbox" <?php if(strpos($answer, '2') !== false){echo 'checked=checked';}?> onchange="collect(2,'rd2');" id="rd2" value="2"/> B </label>
            				<label for="rd3" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="checkbox" <?php if(strpos($answer, '3') !== false){echo 'checked=checked';}?> onchange="collect(3,'rd3');" id="rd3" value="3"/> C </label>
            				<label for="rd4" style="margin-left: 20px; cursor: pointer;"><input class="radioBtn" type="checkbox" <?php if(strpos($answer, '4') !== false){echo 'checked=checked';}?> onchange="collect(4,'rd4');" id="rd4" value="4"/> D </label>
                        <?php
                		}
                    ?>
                	<input type="hidden" id="correctAns" name="correctAns" value="<?php echo $answer;?>"/>
                    </b></h4>
                </div>
            </div>
        </div>
        <center>
            <input type="hidden" id="sno2" name="sno2" value="<?php echo $sno;?>" />
            <input type="hidden" id="qno" name="qno" value="<?php echo $qno;?>" />
            <input type="hidden" id="eid" name="eid" value="<?php echo $examID;?>" />
            <input type="hidden" id="noq" name="noq" value="<?php echo $noq;?>" />
        	<input type="hidden" id="next" name="next" />
            <div class="col-md-12" style="text-align: center;">
            	<button id="btnClrResp" class="btn btn-info btnClrResp"><b>CLEAR RESPONSE</b></button>
            	<button type="button" id="btnRev" class="btn btn-primary btnRev"><b>REVIEW</b></button>
                <?php
                    if($sno>1)
                    	echo '<button type="button" onclick=history.go(-1); id="btnPrev" style="background: #FF9934;" class="btn btn-danger btnPrevious" ><b><i class="fa fa-chevron-left"></i> PREV</b></button>';
                ?>
                <?php
                    if($sno<$noq)
                        echo '<button type="submit" id="btnNext" style="background: #FF9934;"class="btn btn-danger btnNext"><b>SAVE & NEXT  <i class="fa fa-chevron-right"></i></b></button>';
                    if($sno==$noq)
                        echo '<button type="button" id="btnNext" style="background: #FF9934;"class="btn btn-danger btnNext"><b>SAVE</b></button>';
                ?>
            	<button type="button" id="btnStart" class="btn btn-danger btnNext" style="display: none;"><b>Restart  <i class="fa fa-undo"></i></b></button>
            </div>
        </center>
        	<input type="hidden" id="option1" />
        	<input type="hidden" id="option2" />
        	<input type="hidden" id="option3" />
        	<input type="hidden" id="option4" />
    </form>

<script>
	//******************************************* Clear Response Button
	$('.btnClrResp').click(function(){
		$('#ansChecked').find('input[type=radio]:checked').removeAttr('checked');
		$('#ansChecked').find('input[type=checkbox]:checked').removeAttr('checked');
        $('#correctAns').val('');
        return false;
	});

	//******************************************* Next Button
	$('.btnNext').click(function(){
        var sno=$('#sno2').val();
        var uid=$('#uid').val();
        var qno=$('#qno').val();
        var eid=$('#eid').val();
        $('#next').val('Y');
        var correctAns=$('#correctAns').val();
        var param='?sno='+sno+'&uid='+uid+'&qno='+qno+'&eid='+eid+'&correctAns='+correctAns;
		$.ajax({
		type: "POST",
		url: 'save_answer.php'+param,
		data: param,
		success: function(data){
			alert($('.'+qno).find('a').html());
            $('.'+qno).find('a').addClass('answered').removeClass("not_answered not_visited review");

			$("#questionID").html(data);
			var QuesNoNew=$('#hfQuesNo').val();
			if(isNaN(QuesNoNew))
                QuesNoNew=1;
			$('#Qno').text('Question '+QuesNoNew);
			$('.'+QuesNoNew).find('a').addClass('not_answered').removeClass("not_visited answered review");
			}
		});
        url=document.getElementById("qFrame1").contentWindow.location.href;
        //window.location.reload();
        //window.parent.location.reload();
        //window.top.location.reload();
        window.parent.parent.window.location = url;
        //$("#qFrame").trigger("click");
	});

	//******************************************* Review Button
	$('#btnRev').click(function(){
        var uid='project1973@gmail.com';
        var qno=$('#qno').val();
        var eid=$('#eid').val();
        var a=$('#noq').val();
        var b=$('#sno2').val();
        if(a==b)
            ;
        else
        {
            $('#next').val('Y');
            var correctAns=$('#correctAns').val();
            var param='?uid='+uid+'&qno='+qno+'&eid='+eid+'&correctAns='+correctAns;
            $('#ifrm').submit();
        }
	});
    
    function first()
    {
        //alert(1);
        //parent.location.reload();
        //$("#qFrame").trigger("click");
    }
</script>
        
<script>
    function collectRadio(x)
    {
        //alert(2);
        $('#correctAns').val(x);l
    }
    function collect(x,y)
    {
        if($("#"+y).is(':checked'))
        {
            if(y=='rd1')
                $('#option1').val(1);
            if(y=='rd2')
                $('#option2').val(2);
            if(y=='rd3')
                $('#option3').val(3);
            if(y=='rd4')
                $('#option4').val(4);
            a=$('#option1').val();
            b=$('#option2').val();
            c=$('#option3').val();
            d=$('#option4').val();
            if(a.length>0)
                a=a+', ';
            if(b.length>0)
                b=b+', ';
            if(c.length>0)
                c=c+', ';
            if(d.length>0)
                d=d+', ';
            e=a+b+c+d;
            e=e.slice(0,-2);
            $('#correctAns').val(e);
        }
        else
        {
            if(y=='rd1')
                $('#option1').val('');
            if(y=='rd2')
                $('#option2').val('');
            if(y=='rd3')
                $('#option3').val('');
            if(y=='rd4')
                $('#option4').val(''); 
            a=$('#option1').val();
            b=$('#option2').val();
            c=$('#option3').val();
            d=$('#option4').val();
            if(a.length>0)
                a=a+', ';
            if(b.length>0)
                b=b+', ';
            if(c.length>0)
                c=c+', ';
            if(d.length>0)
                d=d+', ';
            e=a+b+c+d;
            e=e.slice(0,-2);
            $('#correctAns').val(e);
        }
    }
</script>
