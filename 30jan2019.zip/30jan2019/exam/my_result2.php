
<?php

include('../../connection/header.php');
 $userID=$_SESSION['email'];

$url = $_SERVER['REQUEST_URI']; 
    $url = explode('/', $url);
    $param_count=sizeof($url);
    $data=array();
    $i=0;
    foreach($url as $element)
    {
        if($i==4)
            $userResulID=$element;
        $i++;
    }
   //$userResulID;
?>
<!DOCTYPE html>
  <link rel="stylesheet" type="text/css" href="css/slick.css">
  <link rel="stylesheet" type="text/css" href="css/slick-theme.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  
  <title>Search ur College-Model Question Paper</title>
  <meta name="description" content="Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test">
  <meta name="keywords" content="MAT,CAT,XAT,CMAT, Model Question Paper, Model Paper,Practice Set,Coursewise test, chapterwise test, education, colleges, universities, institutes, career,career options, career prospects, engineering, mba,technical education, higher education,cat, cat exam, cat 2018, cat exam 2018, college admission, online MBA application, Online MBA application form, online application,apply online, MBA admission, online admission form, Test, CAT Test, MBA Test">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css'>

 


<?php
define( "BASE_URL", "https://www.searchurcollege.com/exam/");
?>
<style class="cp-pen-styles">


.panel{
    border:2px solid #f56954 ;
    color:#fff;
  }
  .panel-heading{
    background:#f56954 ;
  }

*, *:before, *:after {
  box-sizing: border-box;
}

td
{
    color: black;    
}

.load-more-container {
  background: transparent;
  width: 100%!important;
  min-height: 500px;
  margin: 20px auto;
  position: relative;
}
.load-more-container ul {
  list-style-type: none;
  padding: 0;
}
.load-more-container ul:after {
  content: "";
  display: table;
  clear: both;
}
.load-more-container ul li {
  width: calc(20% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 5px;
}
.load-more-container ul li:nth-child(1n + 7) {
  max-height: 0;
  opacity: 0;
  transition: 0.1s ease-in;
}
.load-more-container .load-more-btn {
  width: 150px;
  line-height: 40px;
  border-radius: 2px;
  margin: 0 auto;
  display: block;
  background: #219150;
  color: #fff;
  cursor: pointer;
  text-align: center;
}
.load-more-container .load-more-btn:hover {
  background: green;
}
.load-more-container .load-more-btn .loaded {
  display: none;
}
.load-more-container #load-more {
  display: none;
}
.load-more-container #load-more:checked ~ ul li:nth-child(1n + 5) {
  max-height: 999px;
  opacity: 1;
  transition: 0.2s ease-in;
}
.load-more-container #load-more:checked ~ .load-more-btn .loaded {
  display: block; 
}
.load-more-container #load-more:checked ~ .load-more-btn .unloaded {
  display: none;
  
}

@media (max-width: 500px) {
 .load-more-container ul li {
  width: calc(100% - 10px);
  margin: 10px 5px 0;
  height: 68px;
  background: #fff;
  color: #fff;
  float: left;
  border-radius: 2px;
}

}

@media screen and (min-width: 200px) and (max-width: 499px){

    #dv{display: none;}
    #mv{display: inline;}
    
    
}
section.study-section .nav-tabs {
    border-bottom: 2px solid transparent!important;
}



.scrollbar
{
mmargin-left: 30px;
float: le0t;
height: 400px;
width: 100%;
background: #ffffff;
overflow-y: scroll;
margin-bottom: 25px;
}
.force-overflow
{
min-height: 450px;
}
.style-4::-webkit-scrollbar-track
{
-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
background-color: #596f7c;
}
.style-4::-webkit-scrollbar
{
width: 10px;
background-color: #F5F5F5;
}
.style-4::-webkit-scrollbar-thumb
{
background-color: #000000;
border: 2px solid #555555;
}
@media screen and (min-width: 500px) and (max-width: 786px){
    #left-slider{
  height: 18vh!important;
  background: #1e1e1e ;
  margin-top:  0px!important;
  padding: 5px!important; 
  z-index: 10;   
}
}
</style>
  
  
  <style type="text/css">
    .blocks
    {
        background: white;
        display: inline-flexbox!important;
        padding: 5px;
        border-radius: 5px;
        text-align: center;
        width: 100px;
        min-width: 70px!important;
        margin-right: 15px!important;
    }
    .scrollbar
{
  mmargin-left: 30px;
  float: le0t;
  height: 400px;
  width: 100%;
  background: #F5F5F5;
  overflow-y: scroll;
  margin-bottom: 25px;
}

.force-overflow
{
  min-height: 450px;
}

.style-4::-webkit-scrollbar-track
{
  -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
  background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar
{
  width: 10px;
  background-color: #F5F5F5;
}

.style-4::-webkit-scrollbar-thumb
{
  background-color: #000000;
  border: 2px solid #555555;
}
    .bB1
    {
        margin-left: -10px;
        margin-top: 28px;
    }
    .B2
    {
        margin-left: -30px;
        mmargin-top: -40px;
    }
    .nav-pills>li.active>a, .nav-pills>li.active>a:hover, .nav-pills>li.active>a:focus
    {
        background: #596f7c!important;
    }
    .slick-prev:before, .slick-next:before
    {
        color: white!important;   
    }
    * {
      box-sizing: border-box;
    }

    .slider {
        width: 100%;
        margin-top: 10px;
    }

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 100%;
    }

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }
    .slick-prev
    {
          margin-left: 15px;
    }
    .slick-next
    {
          margin-right: 15px;
    }


    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: 1;
    }
    
    .slick-active {
      opacity: 1;
    }

    .slick-current {
      opacity: 1;
    }


.tabs-content {
       @include clearfix;
       margin-bottom: $tabs-content-margin-bottom;
       width: 100%;
       > .content {

          // Replacement for display: none;, a fix for carousel in tabs
         overflow-y: hidden;
         height: 0;

         float: $default-float;
         padding: $tabs-content-padding 0;
         width: 100%;
         &.active { display: block; float: none;  height: auto;}  // height: auto; added. Also part of the display: none; replacement, a fix for carousel in tabs
         &.contained { padding: $tabs-content-padding; }
       }
       &.vertical {
         display: block;
         > .content { padding: 0 $tabs-content-padding; }
      }
        
        section.study-section .tab-content {
        margin-top: 40px!important;
}
    }
    
   body{
    background: white!important;
   }
   
.exam-tab .nav>li>a {
    position: relative;
    display: block;
    padding: 0px 60px;
    padding-bottom: 3px;
    font-size: 22px!important;
    border-radius: 0px;
    color: #596F7C;
    margin-left: 17px;
}   
@media screen and (min-width: 200px) and (max-width: 499px){
    
 .exam-tab .nav>li>a {
    position: relative;
    display: block;
    padding: 0px 30px;
    padding-bottom: 3px;
    font-size: 16px!important;
    border-radius: 0px;
    color: #596F7C;
    margin-left: 15px;
}   
 .btn-group-lg>.btn, .btn-lg {
    padding: 05px 16px!important;
    font-size: 15px!important;
    line-height: 1.3333333;
    border-radius: 6px;
} 
#title{
    
    font-size:20px!important;
}
#solutionsec{
      margin: 0px;
      height: 200vh;
    }
    #qunans{
      height:110vh;
      weigth :100%;
    }
    #barchart{
        margin-left:-40px!important;
        background:red;
        display: none;
    }
    #graphst{
      width: 300px;
      height: 200px!important;
      margin-left: -20px;
      margin-top: 20px; 

    }
    .colourstyle{
      width: 30px!important;
    }
    .textStyle{
      height: 10px!important;

    }
    .textStyle1{
    padding-left: 20px!important; 
    font-size: 16px!important; 
  }
    #dd{
      bbackground: yellow;
      width: 100%!important;
      overflow: auto;
    }
    #chartContainer{
      height: 150px!important;
    }
    #cont {
      margin-left:0px!important; 
    }

#left-slider{  
  height: 9vh!important; 
  background: #1e1e1e ;
  margin-top:  -10px!important;
  padding: 5px!important;
  z-index: 10;   
}  
} 
.colourstyle{
      width: 40px;
    }
.textStyle{
      height: 30px;

    }
    .textStyle1{
    padding-left: 20px; 
    font-size: 20px; 
  }
#graphst{
      width: 300px;
      height: 300px;

    }
.btn-group-lg>.btn, .btn-lg {
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.3333333;
    border-radius: 6px;
}
#cont {
      margin-top:10px;
      margin-left: 15px; 
      height: 500px;
    }

#left-slider{
  height: 175vh;
  background: #1e1e1e ;
  margin-right: -15px; 
  margin-top: -10px; 
} 
  
      </style>
        <script src="<?php echo BASE_URL;?>assets/js/chart-loader.js" type="text/javascript"></script>
<!--<div class="col-md-12" style="background: url('https://www.searchurcollege.com/frontassets/images/k.png');height: 150px; opacity: 0.3;"></div>-->

        
        <div class="col-md-12" style="bbackground: orange; padding: 0px;">
        <div class="col-md-2" id="left-slider"> 
		<?php include('../home/left1.php'); 
       
        ?>
        </div>
        <?php
         $servername="localhost";
    $username="searchurcollege";
    $password="Newme7503415202";
    $dbname="searchurcollege_main";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error)
        die("Connection failed: " . $conn->connect_error);

                                $alpha=array('A','B','C','D','E');                   
							               	//$userResulID=$_REQUEST['exmID'];
                            	$tquestn="SELECT user_exam_id FROM user_exam WHERE code='$userResulID'";
                              $tquestn = $conn->prepare($tquestn);
                            	$tquestn->execute();
                            	$tquestn->store_result();
                            	$tquestn->bind_result($user_exam_id);
                            	$tquestn->fetch();
                              $tquestn="SELECT exam_name FROM exam WHERE exam_id=$user_exam_id";
                                 $tquestn = $conn->prepare($tquestn);
                            	$tquestn->execute();
                            	$tquestn->store_result();
                            	$tquestn->bind_result($exam_name);
                            	$tquestn->fetch();
                        ?>
        <div id="solutionsec" class="col-md-10" style="widsth: 90%; margin: 0px; padding: 0px!important; bbackground: red; margin-left: 0px; hheight: 1000px;">
        <div class="text-center free-text" style="margin-top: 12px; margin-bottom: 10px;">
         <span style="font-size: 30px; color: black;"><b>Solution-<?php echo $exam_name; ?></b></span><br />
        </div>

			   
            <div id="cont" class="col-md-12 col-xs-12" style="margin-top:10px;margin-left: 15px; height: 500px;">
				
					<!-- Main content -->

					<div class="panel">
						
						<div class="panel-body"style="z-index: 1000000;">
    <?php
								//$stm3="SELECT ue.id, ue.user_exam_id,ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,ue.total_attempt,
								//		ue.correct_answer,ue.wrong_answer,ue.user_get_marks,ue.result_status,e.exam_name
								//		FROM user_exam ue, exam e WHERE ue.user_exam_id = e.exam_id AND ue.code = '$userResulID'";


										 $stm3="SELECT ue.id, ue.user_exam_id, ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,
													ue.total_attempt,ue.correct_answer, ue.wrong_answer, ue.user_get_marks, ue.result_status,
													e.exam_name, e.exam_id, ue.created_at, ue.code FROM user_exam ue, exam e WHERE ue.user_exam_id=e.exam_id AND ue.code = '$userResulID'";


                                ?>
							<?php
								/*$stm3="SELECT ue.user_exam_id,ue.total_no_of_ques,ue.time_duration,ue.total_marks,ue.pass_marks,ue.total_attempt,
										ue.correct_answer,ue.wrong_answer,ue.user_get_marks,ue.result_status,e.exam_name
										FROM user_exam ue, exam e WHERE ue.user_exam_id = e.exam_id AND ue.user_id=? ORDER by ue.user_exam_id desc";*/
       
								if ($stm3 = $conn->prepare($stm3))
								{
								    //$stm3->bind_param('s',$userID);
									$stm3->execute();
									$stm3->store_result();
									$stm3->bind_result($id,$user_exam_id,$total_no_of_ques,$time_duration,$total_marks,$pass_marks,
									$total_attempt,$correct_answer, $wrong_answer, $user_get_marks, $result_status, $exam_name, $exam_id, $date, $code);

                            ?>
                            <?php
									while($stm3->fetch()>0){
										 $userExm2="SELECT COUNT(answer_id) AS tot_attempts FROM user_answer WHERE code='$code'";
                                        $userExm2=$conn->prepare($userExm2); 
										$userExm2->execute();
										$userExm2->store_result();
										$userExm2->bind_result($tot_attempts);
										while($userExm2->fetch())
                    // echo $correct_answer;
                    //  echo $wrong_answer;

                                           $total_attempt=$tot_attempts;
                                         $not_attempt=$total_no_of_ques-$tot_attempts;
                                       $wrong_answer=$tot_attempts-$correct_answer;
                                      
								?>
<!-- <div class="col-md-12">
                        <div class="col-md-6 col-md-offset-3 col-xs-12" style="margin-left: -20px; margin-top: 40px;">
                                                    <h4><?php echo "<font color=black>".$exam_name;?></font></h4>
                          <script type="text/javascript">
                            google.charts.load("current", {packages:["corechart"]});
                            google.charts.setOnLoadCallback(drawChart);
                              function drawChart() {
                                var data = google.visualization.arrayToDataTable([
                                  ['Task', 'Question Details',{ role: "style" }],
                                  ['No Attempt ', <?php //echo $not_attempt;?>,"#FF8C00"],
                                  ['Wrong', <?php //echo $wrong_answer;?>,"#CD5C5C"],
                                  //['Total Attempt', <?php// echo $total_attempt;?>],
                                  ['Correct',  <?php //echo $correct_answer;?>,"#228B22"],                                  
                                ]);

                                var options = {
                                  title: 'QUESTION DETAILS',
                                  //is3D: true,
                                  pieHole :0.4,
                                };

                                var chart = new google.visualization.PieChart(document.getElementById('piechart_3d<?php// echo $exam_id;?>'));
                                chart.draw(data, options);
                              }
                          </script>
                          <br>
                           <div id="piechart_3d<?php// echo $exam_id;?>" style="margin-bottom:5px;"></div>
                        </div>

                        <div id="barchart" class="col-md-6   " style="mmargin-bottom: -25px; mmargin-top: 0px; margin-left: -30px;">
                                                    
                                                   
                                                             <script type="text/javascript">
                                                                google.charts.load("current", {packages:['corechart']});
                                                                google.charts.setOnLoadCallback(drawChart);
                                                                function drawChart() {
                                                                  var data = google.visualization.arrayToDataTable([
                                                                   ['Task', 'Question Details',{ role: "style" }],
                                                                   ['Wrong', <?php //echo $wrong_answer;?>,"#CD5C5C"],
                                                                   ['Correct',  <?php //echo $correct_answer;?>,"#228B22"],
                                                                   ['Total Attempt', <?php //echo $total_attempt;?>,"#FF8C00"],
                                               //  ['Total Quesion', <?php //echo $total_no_of_ques;?>,"#0000CD"],
                                                                   ]);
                                                            
                                                                   var view = new google.visualization.DataView(data);
                                                                  
                                                                            
                                                                                 var options = {
                                                                                    title: "Total Quesion",
                                                                                    width: 600,
                                                                                    height: 400,
                                                                                    bar: {groupWidth: "95%"},
                                                                                    legend: { position: "none" },
                                                                                  };
                                                                                  var chart = new google.visualization.ColumnChart(document.getElementById('barchart_3d<?php //echo $exam_id;?>'));
                                                                                  chart.draw(view, options);
                                                                              }
                                                                              </script>
                                                                              


                                                    <div id="barchart_3d<?php //echo $exam_id;?>" class="graph2" style="margin-bottom:0px; bbackground: red; "></div> 
                            <div id="piechart_3d<?php //echo $exam_id;?>" style="margin-bottom:5px; background: red;"></div>
                           <?php  ?>
                        </div>
                        </div>
 -->


    <link rel="stylesheet" href="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
    <script src="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
    <div id="graphtext" class="col-md-6 text-center" style="color: black; font-size: 18px;"><center>
        <table border=1 style="margin-top: 20%">
            <tr class="textStyle" ><td class="colourstyle" style="background: #FF9934; "></td><td class="textStyle1" align="left">Correct (<?php echo $correct_answer;?>)</td></tr>
            <tr class="textStyle" ><td style="background: #CD4B28; "></td><td class="textStyle1"  align="left">Incorrect (<?php echo $wrong_answer;?>)</td></tr>
            
            <tr class="textStyle" ><td style="background: lightgrey; "></td><td class="textStyle1"  align="left">Not-Attempted (<?php echo $not_attempt;?>)</td></tr>
        </table>
        </center>
    </div>
    <div  class="col-md-6 text-center" style="padding-top: 0px;">
      <center>
        <div id="graphst" class="ct-chart ct-perfect-fourth" style="width: 300px; height: 300px;"></div>
    
    </center>
    </div>
    <style>
    .ct-slice-donut {stroke-width: 40px!important;}
    .ct-series-a .ct-bar, .ct-series-a .ct-line, .ct-series-a .ct-point, .ct-series-a .ct-slice-donut {
        stroke: #FF9934;
    }
    .ct-series-b .ct-bar, .ct-series-b .ct-line, .ct-series-b .ct-point, .ct-series-b .ct-slice-donut {
        stroke: #CD4B28;
    }
    .ct-series-c .ct-bar, .ct-series-c .ct-line, .ct-series-c .ct-point, .ct-series-c .ct-slice-donut {
        stroke: lightgrey;
    }
    .ct-label {
        font-size: 14px;
        font-weight: bold;
        color: black;
    }
    </style>
    <script>
    var chart = new Chartist.Pie('.ct-chart', {
      series: [<?php echo $correct_answer;?>, <?php echo $wrong_answer;?>,  <?php echo $not_attempt;?>],
      labels: [ <?php echo $correct_answer;?>, <?php echo $wrong_answer;?>, <?php echo $not_attempt;?>]
    }, {    
      donut: true,
      showLabel: true,
      chartPadding: 15
    });
    </script>
  
<br />
<br />

 
                        <div id="qunans" class="col-md-12 scrollbar style-4 bottom-align-text" style="color:#000;bbackground: red; height:100vh; width: 100%; font-weight: normal; font-size: 18px;">

													<?php
                         $chk="SELECT q.question_id_OLD, q.question, a.correct_answer,a.solution, u.code, u.answer 
                                    FROM questions q JOIN answer a ON a.exam_id = q.exam_id 
                                    AND a.question_id = q.question_id_OLD AND q.exam_id=$exam_id 
                                    LEFT JOIN user_answer u ON u.exam_id = q.exam_id 
                                    AND u.question_id = q.question_id AND u.user_id = '$userID' AND u.code='$userResulID' ORDER BY q.question_id";
                          // $chk="SELECT question_id_OLD from questions";
                           $rslt=$conn->query($chk);
                           while($row11=$rslt->fetch_assoc())
                            {
                                $n=$row11["question_id_OLD"];
                            }
                           
                          if($n>0){
														$stm1="SELECT q.question_id, q.question, a.correct_answer,a.solution, u.code, u.answer 
														        FROM questions q JOIN answer a ON a.exam_id = q.exam_id 
														        AND a.question_id = q.question_id_OLD AND q.exam_id=$exam_id 
														        LEFT JOIN user_answer u ON u.exam_id = q.exam_id 
														        AND u.question_id = q.question_id AND u.user_id = '$userID' AND u.code='$userResulID' ORDER BY q.question_id";
                                  }
                              else {
                                $stm1="SELECT q.question_id, q.question, a.correct_answer,a.solution, u.code, u.answer 
                                    FROM questions q JOIN answer a ON a.exam_id = q.exam_id 
                                    AND a.question_id = q.question_id AND q.exam_id=$exam_id 
                                    LEFT JOIN user_answer u ON u.exam_id = q.exam_id 
                                    AND u.question_id = q.question_id AND u.user_id = '$userID' AND u.code='$userResulID' ORDER BY q.question_id";
                              }
                              														$stms1 = $conn->prepare($stm1);
														//$stms1->bind_param('is', $exam_id,$userID);
														$stms1->execute();
														$stms1->store_result();
														$stms1->bind_result($question_id,$question,$correct_answer,$solution,$code,$urAnswer);
														$sn=1;
														while($stms1->fetch()>0)
                                                        {
                                                        ?>
                                                            <div id="dd"class="well well-sm" style="color:#000; width: 100%">
                                                                <p>
                                                                    <h4 title="<?php echo $question_id;?>" class="text-danger pull-left"> <?php echo '<b>Question:</b> '.$sn;?></h4> 
                                                                    <br />  
                                                                    <hr style="border-top: 1px solid #0a540d;"><?php echo $question;?>
                                                                </p>
                                                                <br />
                                                                <p class="text-left"><b>Your Answer: <?php echo $alpha[$urAnswer-1];?>
                                                                    <?php 
                                                                    $urAnswer=str_replace(' ', '', $urAnswer);
                                                                    if($correct_answer==$urAnswer)
                                                                        echo '<i class="fa fa-check text-success"></i>';
                                                                    else
                                                                    {
                                                                        if(!empty($urAnswer))
                                                                            echo '<i class="fa fa-times text-danger" aria-hidden="true"></i>';
                                                                        else
                                                                            echo 'Not Attempted';
                                                                    }
                                                                    ?></b>
                                                                </p>
                                                                <br />
                                                                <p class="text-left"><b>Correct Answer: <?php echo $alpha[$correct_answer-1];?> <i class="fa fa-check text-success"></i></b></p>
                                                                <br />
                                                                <h4 cclass="text-success" ddata-toggle="collapse" ddata-target="#solution<?php echo $sn;?>"><b>Solution:</b> <i class="fa fa-arrow-down" aria-hidden="true"></i> </h4>
                                                                
                                                                <div style="background: lightgrey; margin-left: 0px; width: 100%" id="solution<?php echo $sn;?>" cclass="collapse">
                                                                    <div class="well well-sm" style="background: #EAEDED  ">
                                                                        <?php //echo strip_tags($solution); ?>
                                                                        <?php 
                                                                            echo $solution;
                                                                         ?>
                                                                    </div>
                                                                </div>
                                                            <?php
                                                                $sn++;
                                                            echo '</div>';
                                                        }
                                                        ?>
												
											</div>
										</div>
										
									</div>
									
							<?php
                                }
                                }
								?>
								
						</div>	<!-- panel-group -->

						<?php
                        ?>
						</div>
					</div>
           
            
        </div>

<div>
<?php
    include('../../footer.php');
?>

</div>




   
