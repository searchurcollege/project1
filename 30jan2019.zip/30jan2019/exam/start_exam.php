<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=0">
<link rel="stylesheet" type="text/css" href="https://www.searchurcollege.com/css/bootstrap.min.css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
		<?php 
        session_start();
        $_SESSION['code']=generateCode();
		define('__ROOT__', dirname(dirname(__FILE__))); 
		require_once(__ROOT__.'/includes/global.php'); 
		require_once(__ROOT__.'/includes/authentication.php'); 
		$examID=$_GET['examID'];
        if($examID=='')
            $examID=$_SESSION['eid'];
		$exmName="SELECT no_of_question, exam_exercise_id, total_mark, exam_name, exam_duration, banner FROM exam where exam_id=?";
		$exmName = $myconn->prepare($exmName);
		$exmName->bind_param('i', $examID);
		$exmName->execute();
		$exmName->store_result();
		$exmName->bind_result($no_of_question, $exam_exercise_id, $total_mark, $exam_name,$exam_duration, $banner);
		$exmName->fetch();
        $markPerQuestion=$total_mark/$no_of_question;

    	$stm4="SELECT exam_exercise_name FROM cat03_exam_exercise WHERE exam_exercise_status=1 AND exam_exercise_id=$exam_exercise_id";
        if ($stm4 = $myconn->prepare($stm4)) 
    	{
    		$stm4->execute();
    		$stm4->store_result();
    		$stm4->bind_result($exam_exercise_name);
    		$stm4->fetch();
        }

        //Fetch for Question Types
    	$stm5="SELECT question_id FROM questions WHERE exam_id=$examID GROUP BY question_type";
        if ($stm5 = $myconn->prepare($stm5)) 
    	{
    		$stm5->execute();
    		$stm5->store_result();
    		$stm5->bind_result($question_id);
            $i=0;
    		while($stm5->fetch()>0)
                $i++;
            $qt="is only <b>one correct answer</b>";
            if($i==2)
                $qt="are both, <b>Single & Multiple Choice</b> answers";
        }

	?>
	<llink rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/css/start_exam.css">	
    <?php //include('../../connection/header.php');?>
	<div class="row">
        <style>
            body {overflow-x: hidden;}
            #footerwrap{
                display:none;
                padding:0!important;
                margin:0!important;
            }
            #fixedheight {
                table-layout: fixed;
            }
            
            #fixedheight tr {
                height: 150px;
                overflow: hidden;
            }

            @media screen and (min-width: 200px) and (max-width: 499px){
            	#homebtn{
            		top:-22px!important;
            	}
            }

        </style>
		<div class="col-md-12 col-xs-12" id="main-content" style="padding-bottom: 0!important; text-align:justify;">

			<div class="ppanel panel-primary" style="bborder:5px solid #428bca; margin-bottom:0!important;">

				<div class="panel-heading col-md-12" >
					<div class="col-md-6">
					<h2 class="panel-title">Welcome to SearchUrCollege</h2>
						</div>		
						<div class="col-md-6 ">
							<a id=homebtn type="button" style="position: absolute; top: -10px; right: 0px;"  class="btn btn-success pull-right"  style="margin-right: 10px; z-index: 100000" oonclick="history.go(-1);" href="https://www.searchurcollege.com/exam/home/home.php?id=1">Home</a>
							
						</div>

				</div>

				<div class="content panel-body2" style="display: none; height: 100%; background: #F5F5F5;">
    				<div class="col-md-4" style="background: lightgrey; height: 100%; vertical-align: top;  ">
                        Space reserved for Ads.
                    </div>
    				<div class="col-md-4" style="ppadding-top: 10%;">
                        <table id="fixedheight" border="0" width="100%">
                            <tr><td>Space reserved for Ads.</td></tr>
                            <tr>
                                <td>
                                    <a href="https://www.searchurcollege.com/exam/home"><button class="btn btn-warning btn-block" style="height: 80px;">Goto Dashboard / Check Result</button></a>
                                    <br />
                                    <!--<a href="https://www.searchurcollege.com/demo"><button class="btn btn-success btn-block" style="height: 80px;">Give Another Test</button></a>-->
                                </td>
                            </tr>
                            <tr><td>Space reserved for Ads.</td></tr>
                        </table>
                    </div>
    				<div class="col-md-4" style="background: lightgrey; height: 100%; vertical-align: top;  ">
                        Space reserved for Ads.
                    </div>
                </div>
				<div class="panel-body" style="padding: 0px;">

					<div class="col-md-12 col-xs-12">
							
						<div class="col-md-12 text-center">
						
							<h4>INSTRUCTIONS FOR EXAM(<b> <?php echo $exam_name;?></b> )</h4>
						
						</div>
								<!-- <a type="button" style="position: absolute; top: 10px; right: 10px;" id="btnNext" name="btnNext" onclick="NextPage();" class="btn btn-primary pull-right">NEXT</a>	 -->
								<p class="text-center" style="position: fixed; bottom: 30px; right: 20px; z-index: 100000">
												<!--<a type="button" id="btnSatratExam" name="btnSatratExam" class="btn btn-primary" href="<?php echo BASE_URL;?>do-exam/<?php echo $examID;?>">I am ready to Begin</a>-->
												<!--<a type="button" id="btnSatratExam" name="btnSatratExam" class="btn btn-primary" href="<?php echo BASE_URL;?>do-exam/<?php echo $examID;?>">Start Test</a>-->
												<a type="button" id="btnSatratExam" name="btnSatratExam" class="btn btn-primary" href="https://www.searchurcollege.com/exam/exam/do_exam.php?examid=<?php echo $examID;?>">Start Test</a>

											</p>
								<a style="position: absolute; display: none; top: 10px; right: 10px;" type="button" style="position: absolute; top: 10px; right: 10px;"  id="btnPrev" name="btnPrev" onclick="PrevPage();"  class="btn btn-primary pull-left">Previous</a>
								<!--<a type="button" style="position: absolute; top: 10px; right: 100px;"  class="btn btn-success pull-right"  style="margin-right: 10px;" href="https://searchurcollege.com/exam/home">Home</a>-->
								<!-- <a type="button" style="position: absolute; top: 0px; right: 10px;"  class="btn btn-success pull-right"  style="margin-right: 10px; z-index: 100000" oonclick="history.go(-1);" href="https://searchurcollege.com/exam/home/home.php?id=1">Home</a> -->
						<div class="col-md-12">

							<div id="divContPart1">
								<p style="color:#f70025">Please read the Instructions carefully before starting the test.</p>
								
								<ol style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
									<li>Total duration of examination is <span class="text-danger"><b><?php echo $exam_duration; ?> minutes. </b></span></li>  
								<!--	<li>The clock will be set at the server. The countdown timer in the top right corner of screen will display the remaining time available for you to complete the examination. When the timer reaches zero, the examination will end by itself. You will not be required to end or submit your examination.</li>   -->
									<li>Following symbols:  
										<table width="100%" class="instruction_area" style="FONT-SIZE: 100%">  
											<tbody>  
												<tr>  
													<td><span class="not_visited" title="Not Visited">1</span></td>  
													<td>You have not visited the question yet.</td>  
                                                <!-- <td rowspan="5">
                                                    <?php
                                                        if($banner=='')
                                                            $banner='no_image.jpg';
                                                      //  echo '<img style="max-with: 600px; max-height: 200px; border: 3px double gray;" src="../admin/exam/uploads/'.$banner.'" />';
                                                    ?>
                                                </td> -->
												</tr>  
												<tr>  
													<td><span class="not_answered" title="Not Answered">2</span></td>  
													<td>You have not answered the question.</td>  
												</tr>  
												<tr>  
													<td><span class="answered" title="Answered">3</span></td>  
													<td>You have answered the question.</td>  
												</tr>  
												<tr>  
													<td><span class="review" title="Not Answered &amp; Mark for Review">4</span></td>  
													<td>You have NOT answered the question, but have marked the question for review.</td>  
												</tr>  
												<tr>  
													<td><span class="review_answered" title="Answered &amp; Mark for Review" style="background-position: -6px -82px; line-height: 34px;">5</span></td>  
													<td>You have answered the question, but marked it for review.</td>  
												</tr>  
											</tbody>  
										</table>  
									</li> 
									
									<lii style="LIST-STYLE-TYPE: none">The Marked for Review status for a question simply indicates that you would like to look at that question again. 
										
									</lii> 
								</ol>
								
								
							<!-- 	 <b><u>Navigating to a Question : </u></b> -->


								 <ol start="3" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">   
									<li>Procedure for answering a multiple choice type question:  
										<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a">  
											<li>To select your answer, click on the button of one of the options.</li> 
											<li>To deselect your chosen answer, click on the button of the chosen option again or click on the <b>Clear Response</b> button.</li>  
											<li>To change your chosen answer, click on the button of another option.</li>  
											<li>To save your answer, you MUST click on the <b>Save &amp; Next</b> button.</li>  
											<li>To mark the question for review, click on the <b>Mark for Review &amp; Next</b> button.<br>  
												<em><span style="color:#ff0000;">If an answer is selected for a question that is 'Marked for Review', that answer will be considered in the evaluation even if it is not marked as 'Save &amp; Next', at the time of final submission</span>.</em>
											</li>  
										</ol>  
									</li>  
									
								</ol><br>
								<!-- <ol start="3" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
									<li>To answer a question, do the following:  
										<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a"> 
											<li>Click on the question number in the Question Palette to go to that numbered question directly.</li>  
											<li>Click on <strong>Save &amp;Next</strong> to save your answer for the current question and then go to the next question.</li>  
											<li>Click on <strong>Mark for Review &amp; Next</strong> to save your answer for the current question, mark it for review, and then go to the next question.<br>  
												<span style="color:#ff0000;">Caution: Note that your answer for the current question will not be saved, if you navigate to another question directly by clicking on its question number.</span>
											</li> 
										</ol> 
									</li> 
									<li>You can view all the questions by clicking on the Question Paper button. Note that the options for multiple choice type questions will not be shown.</li> 
								</ol> -->

								
							</div>
							<center><img src="../../img/IIBS3.gif" width="250"/></center>
                            <br />
							<div id="divContPart2" style="display:none;">
								<p> <b><u>Answering a Question : </u></b></p>
								<!-- <ol start="6" style="TEXT-ALIGN: left; LIST-STYLE-TYPE: decimal; PADDING-LEFT: 4%; PADDING-TOP: 3px">  
									<li>Procedure for answering a multiple choice type question:  
										<ol style="TEXT-ALIGN: left; PADDING-LEFT: 4%; PADDING-TOP: 3px" type="a">  
											<li>To select your answer, click on the button of one of the options.</li> 
											<li>To deselect your chosen answer, click on the button of the chosen option again or click on the <b>Clear Response</b> button.</li>  
											<li>To change your chosen answer, click on the button of another option.</li>  
											<li>To save your answer, you MUST click on the <b>Save &amp; Next</b> button.</li>  
											<li>To mark the question for review, click on the <b>Mark for Review &amp; Next</b> button.<br>  
												<em><span style="color:#ff0000;">If an answer is selected for a question that is 'Marked for Review', that answer will be considered in the evaluation even if it is not marked as 'Save &amp; Next', at the time of final submission</span>.</em>
											</li>  
										</ol>  
									</li>  
									<li>To change your answer to a question that has already been answered, first select that question for answering and then follow the procedure for answering that type of question.</li> 
									<li>Note that questions for which option has been chosen and answers are saved or marked for review will be considered for evaluation.</li> 
									<li><em><span style="color:#ff0000;">¼ (one fourth) marks i.e. one mark will be deducted for indicating incorrect response of each question. No deduction from the total score will be made if no response is indicated for a question</span></em>.</li> 
								</ol><br> -->

								<div class="cusInstText1" style="height: 91%; width: 100%; overflow: auto; display: block;">
									<p style="text-align: left;">
										<u><strong>Exam specific Instructions</strong></u>
									</p> 
									<ol> 
										<li>This is <b><?php echo $exam_exercise_name;?></b> Test. The Question paper displayed is for practice purposes only. Under no circumstances should this be presumed as a sample paper.</li>
										<li>Each question is allocated <b><?php echo $markPerQuestion;?> mark</b> for each correct.</li> 
										<li>One fourth marks will be deducted for incorrect response of each question. No deduction from the total score will be made if no answer is given.</li> 
										<li>There <?php echo $qt;?> for each question.</li> 
									</ol> 
									
								<div class="col-lg-12 mt-10">

									<div class="col-md-12">

										<div id="chooseLanguage">

											<p><b>Choose you default language </b></p>

											<select id="cboPlatform" disabled="true" name="cboPlatform">

												<option>English</option>

												<option>Hindi</option>

											</select>

										</div>

										<span style="color:#fc192c"><em><b>Please note all question will appear in your default language. This language can be changed for a particular question later on.</b></em></span>

									</div>
                                    <?php
                                        if(isset($_SESSION['timeLeft']))
                                            unset($_SESSION['timeLeft']);
                                    ?>

									<div class="col-md-12">

										<form method="post" action="" id="formStartExam" name="formStartExam">
										
											<p>

												<input type="checkbox" id="chkConfirm" checked name="chkConfirm"/>

												<b>I have read and understood the instuctions. I agree that in case of not
												adhering to the instructions, I shall be liable to be debarred from this Test and / or to discipinay action, which
												may include ban from future Test / Examinations.</b>

											</p>

											<!-- <p class="text-center" style="position: fixed; bottom: 10px; right: 20px;">
												 <a type="button" id="btnSatratExam" name="btnSatratExam" class="btn btn-primary" href="<?php //echo BASE_URL;?>do-exam/<?php //echo $examID;?>">I am ready to Begin</a> 
												<a type="button" id="btnSatratExam" name="btnSatratExam" class="btn btn-primary" href="<?php// echo BASE_URL;?>do-exam/<?php //echo $examID;?>">I am ready to Begin</a>

											</p> -->
										</form>
										
									</div>	

								</div>
								
							</div>
						
						</div>

					</div>						

				</div>
				<div class="panel-footer">

					<h2 class="panel-title"> SearchUrCollege - Test Series</h2>

				</div>
			</div>	

		</div>

	</div>

<?php
function generateCode($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return($randomString);
}
?>

	<?php require_once(__ROOT__.'/includes/footer.php');?>
	
	<!-- ******************* Reset LocalSorage Time ************-->
	<script>
		localStorage.removeItem("end1");
		localStorage.clear();
	</script>
	
	<!-- ******************* Open a page in new windows ************-->
	<script>
		  $('#btnSatratExam').click(function(){
			 if($('#chkConfirm').is(':checked')==true){
				wihe = 'width='+screen.availWidth+',height='+screen.availHeight;
				loaction.href('DoExam',"")
				$('.panel-body').hide();
				$('.panel-body2').show();
				//window.open( this.href);
				window.close('Start-exam');
				return false;
			 }
			 else{
				$("#errorMessage").text('Please Agree To Proceed The Exam...');
				$('#divError').show();
				$("#divError").delay(3200).fadeOut(300);
			 }
			//window.open(this.href);
			return false;
		  });
	</script>
	
	<!-- ******************* Next And Previous ************-->
	<script>
		function NextPage(){
		    $('#btnPrev').show();
		    $('#btnNext').hide();
			$('#divContPart1').hide();			
			$('#divContPart2').show();
		}
		function PrevPage(){
		    $('#btnPrev').hide();
		    $('#btnNext').show();
			$('#divContPart2').hide();
			$('#divContPart1').show();
		}
        function ready()
        {
            //alert(1);
        }
	</script>