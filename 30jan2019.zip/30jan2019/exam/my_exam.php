	<?php 
		define('__ROOT__', dirname(dirname(__FILE__))); 
		//require_once(__ROOT__.'/includes/login_header.php');		
	?>
	<style>
		#border-bottom{
			border-bottom:1px solid #f56954 ;
			margin-bottom:10px;
		}
		.searchTerm {
		  float: left;
		  width: 100%;
		  border: 3px solid #f56954 ;
		  padding: 5px;
		  border-radius: 5px;
		  outline: none;
		  color: #9DBFAF;
		}
		.searchTerm:focus{
		  color: #ff6300;
		}
		.panel{
			border:1px solid #f56954 ;
			color:#fff;
		}
		.panel-heading{
			background:#f56954 ;
		}
		.inner-panel{
          border:1px solid #000 ;
          margin-top:2px;
		}
	</style>
		<div class="row row-eq-height">
			<div class="col-md-2 col-xs-12 left-sidebar"> 
				<?php //require_once(__ROOT__.'/includes/sidebar.php'); ?>
			</div>
			<div class="col-md-10 col-xs-12 div-content">
			<!-- Content Header (Page header) -->
				<div id="contentHeader">
					<h4> <i class="fa fa-dashboard"></i> <strong>Dashboard </strong><i class="fa fa-chevron-right"></i>  Exam List</h4>
				</div>
				<div class="control-group" style="margin-top:10px;">
					<div class="col-md-10 col-md-offset-1">
						<form id="live-search" action="" class="styled searchTerm" method="post">
							<input type="text" class="form-control" id="filter" placeholder="Type to seach exam" />
							<span id="filter-count"></span>
						</form> 					
					</div>
				</div>
				<div class="col-md-12 col-xs-12" style="margin-top:10px;">
					<!-- Main content -->
					<div class="panel">
						<div class="panel-heading"> RECENTLY ADDED EXAM </div>
<?php
    $a=1;
    $b=1;
    $c=1;
    $d=1;
    $e=1;
	$super_cat_status=1;
	$stm1="SELECT super_cat_id, super_cat_name, super_cat_description FROM cat00_super_category WHERE super_cat_status=? ORDER by super_cat_id asc limit 100";
	if ($stm1 = $myconn->prepare($stm1)) 
	{
		$stm1->bind_param('i', $super_cat_status);
		$stm1->execute();
		$stm1->store_result();
		$stm1->bind_result($super_cat_id, $super_cat_name, $super_cat_description);
		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
		while($stm1->fetch()>0){
        ?>
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingTwo">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#One<?php echo $super_cat_id.$a;?>" aria-expanded="false" aria-controls="collapseTwo">
                        <i class="more-less glyphicon glyphicon-plus"></i>
                        <?php echo $super_cat_name;?>
                    </a>
                </h4>
            </div>
            <div id="One<?php echo $super_cat_id.$a;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                <div class="panel-body">
                    <?php
                    	$main_cat_status=1;
                    	$stm2="SELECT main_cat_id, main_cat_name, main_cat_description FROM cat01_main_category WHERE main_cat_status=? AND super_cat_id=? ORDER by main_cat_id asc limit 100";
                    	if ($stm2 = $myconn->prepare($stm2)) 
                    	{
                    		$stm2->bind_param('ii', $main_cat_status, $super_cat_id);
                    		$stm2->execute();
                    		$stm2->store_result();
                    		$stm2->bind_result($main_cat_id, $main_cat_name, $main_cat_description);
                    		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                    		while($stm2->fetch()>0){
                    		  echo '$main_cat='.$main_cat_id;
                            ?>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingTwo">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#Two<?php echo $main_cat_id.$b;?>" aria-expanded="false" aria-controls="collapseTwo">
                                            <i class="more-less glyphicon glyphicon-plus"></i>
                                            <?php echo $main_cat_name;?>
                                        </a>
                                    </h4>
                                </div>
                                <div id="Two<?php echo $main_cat_id.$b;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                    <div class="panel-body">
                                        <?php
                                        	$exam_cat_status=1;
                                        	$stm3="SELECT exam_cat_id, exam_cat_name, exam_cat_description FROM cat02_exam_category WHERE exam_cat_status=? AND main_cat_id=? ORDER by exam_cat_id asc limit 100";
                                        	if ($stm3 = $myconn->prepare($stm3)) 
                                        	{
                                        		$stm3->bind_param('ii', $exam_cat_status, $main_cat_id);
                                        		$stm3->execute();
                                        		$stm3->store_result();
                                        		$stm3->bind_result($exam_cat_id, $exam_cat_name, $exam_cat_description);
                                        		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                                        		while($stm3->fetch()>0){
                                        		  echo '$exam_cat='.$exam_cat_id;
                                                ?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading" role="tab" id="headingTwo">
                                                        <h4 class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#Three<?php echo $exam_cat_id.$c;?>" aria-expanded="false" aria-controls="collapseTwo">
                                                                <i class="more-less glyphicon glyphicon-plus"></i>
                                                                <?php echo $exam_cat_name;?>
                                                            </a>
                                                        </h4>
                                                    </div>
                                                    <div id="Three<?php echo $exam_cat_id.$c;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                        <div class="panel-body">
                                                            <?php
                                                            	$exam_exercise_status=1;
                                                            	$stm4="SELECT exam_exercise_id, exam_exercise_name, exam_exercise_description FROM cat03_exam_exercise WHERE exam_exercise_status=? AND exam_cat_id=? ORDER by exam_exercise_id asc limit 100";
                                                            	if ($stm4 = $myconn->prepare($stm4)) 
                                                            	{
                                                            		$stm4->bind_param('ii', $exam_exercise_status, $exam_cat_id);
                                                            		$stm4->execute();
                                                            		$stm4->store_result();
                                                            		$stm4->bind_result($exam_exercise_id, $exam_exercise_name, $exam_exercise_description);
                                                            		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                                                            		while($stm4->fetch()>0){
                                                            		  echo '$exam_exercise='.$exam_exercise_id;
                                                                    ?>
                                                                    <div class="panel panel-default">
                                                                        <div class="panel-heading" role="tab" id="headingTwo">
                                                                            <h4 class="panel-title">
                                                                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#Four<?php echo $exam_exercise_id.$d;?>" aria-expanded="false" aria-controls="collapseTwo">
                                                                                    <i class="more-less glyphicon glyphicon-plus"></i>
                                                                                    <?php echo $exam_exercise_name;?>
                                                                                </a>
                                                                            </h4>
                                                                        </div>
                                                                        <div id="Four<?php echo $exam_exercise_id.$d;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                                            <div class="panel-body">
                                                                                <?php
                                                                                	$exam_status=1;
                                                                                	$stm5="SELECT exam_id, exam_name, description FROM exam WHERE status=? AND exam_exercise_id=? ORDER by exam_id asc limit 100";
                                                                                	if ($stm5 = $myconn->prepare($stm5)) 
                                                                                	{
                                                                                		$stm5->bind_param('ii', $exam_status, $exam_exercise_id);
                                                                                		$stm5->execute();
                                                                                		$stm5->store_result();
                                                                                		$stm5->bind_result($exam_id, $exam_name, $description);
                                                                                		$arr=array('bg-yellow','bg-aqua','bg-green','bg-purple','bg-yellow','bg-aqua','bg-green','bg-purple');
                                                                                		while($stm5->fetch()>0){
                                                                                		  echo '$exam_exercise='.$exam_id;
                                                                                        ?>
                                                                                        <div class="panel panel-default">
                                                                                            <div class="panel-heading" role="tab" id="headingTwo">
                                                                                                <h4 class="panel-title">
                                                                                                    <a role="button" href="<?php echo BASE_URL;?>start-exam/<?php echo $exam_id?>" onclick="return startExam(this,<?php echo $_SESSION['profile-percent'];?>)">
                                                                                                        <i class="more-less glyphicon glyphicon-file"></i>
                                                                                                        <?php echo $exam_name;?>
                                                                                                    </a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <?php
                                                                                            $e++;
                                                                                        }
                                                                                    }
                                                                                ?>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                        $d++;
                                                                    }
                                                                }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                                    $c++;
                                                }
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                                $b++;
                            }
                        }
                    ?>
                </div>
            </div>
        </div>
        <?php
            $a++;
        }
    }
?>



        </div>
        </div>
        </div>
        </div>
	<?php //require_once(__ROOT__.'/includes/footer.php');?>
	<!-- *************************** Redirect page to Start-Exam in new tab  ****************************-->
	<script>
		localStorage.clear();
		function startExam(hrefLink,profPerc){
		    var sendLink = hrefLink;
		    var prfValue = profPerc;
			if(prfValue < 100){
				window.open(sendLink,'Start-exam');
				return false;				
			}
			else{
				$('#divErrorProfile').show();
				$('#ErrorMessage').html('Your Profile is less than 100%, firstly complete your profile then you can take exam...');
				return false;
			}
		}
	</script>
	<!-- *************************** Search Exam On keypress ********************************************-->
	<script type="text/javascript">
		$(document).ready(function(){
			$("#filter").keyup(function(){
				// Retrieve the input field text and reset the count to zero
				var filter = $(this).val(), count = 0;
				// Loop through the comment list
				$(".panel-body div").each(function(){
					// If the list item does not contain the text phrase fade it out
					if ($(this).text().search(new RegExp(filter, "i")) < 0) {
						$(this).fadeOut();
					// Show the list item if the phrase matches and increase the count by 1
					} else {
						$(this).show();
						count++;
					}
				});
				// Update the count
				var numberItems = count;
				//$("#filter-count").text("Number of Comments = "+count);
			});
		});
	</script>	