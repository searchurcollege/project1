<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
    .scrollbar
    {
    	float: le0t;
    	height: 400px;
    	width: 100%;
    	background: #ffffff;
    	overflow-y: scroll;
    	margin-bottom: 25px;
    }
    .force-overflow
    {
    	min-height: 450px;
    }
    .style-4::-webkit-scrollbar-track
    {
    	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    	background-color: #F5F5F5;
    }
    .style-4::-webkit-scrollbar
    {
    	width: 10px;
    	background-color: #F5F5F5;
    }
    .style-4::-webkit-scrollbar-thumb
    {
    	background-color: #000000;
    	border: 2px solid #555555;
    }
    .but1 {
        position: relative;
        padding-left: 25px;
        margin-bottom: 12px;
        margin-right: 15px;
        cursor: pointer;
        font-size: 16px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    .but1 input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
    }
    .checkmark1 {
        position: absolute;
        top: 0;
        left: 0;
        height: 20px;
        width: 20px;
        background-color: white;
        border-radius: 50%;
    }
    .but1:hover input ~ .checkmark1 {
        background-color: #ccc;
    }
    .but1 input:checked ~ .checkmark1 {
        background-color: #2196F3;
    }
    .checkmark1:after {
        content: "";
        position: absolute;
        display: none;
    }
    .but1 input:checked ~ .checkmark1:after {
        display: block;
    }
    .but1 .checkmark1:after {
     	top: 6px;
    	left: 6px;
    	width: 8px;
    	height: 8px;
    	border-radius: 50%;
    	background: white;
    }
    .but2 {
        position: relative;
        padding-left: 25px;
        margin-bottom: 12px;
        margin-right: 15px;
        cursor: pointer;
        font-size: 16px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    .but2 input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
    }
    .checkmark2 {
        position: absolute;
        top: 0;
        left: 0;
        height: 20px;
        width: 20px;
        background-color: white;
    }
    .but2:hover input ~ .checkmark2 {
        background-color: #ccc;
    }
    .but2 input:checked ~ .checkmark2 {
        background-color: #2196F3;
    }
    .checkmark2:after {
        content: "";
        position: absolute;
        display: none;
    }
    .but2 input:checked ~ .checkmark2:after {
        display: block;
    }
    .but2 .checkmark2:after {
     	top: 3px;
    	left: 7px;
    	width: 5px;
    	height: 10px;
        border: solid white;
        border-width: 0 3px 3px 0;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
    }
    #mySidenav
    {
        position: absolute;
        top: 0px;
    }
    .sidenav {
        height: 100%;
        width: 0;
        position: fixed;
        z-index: 1;
        top: 0;
        right: 0;
        background-color: #111;
        overflow-x: hidden;
        transition: 0.5s;
        padding-top: 60px;
    }
    .sidenav a {
        padding: 8px 8px 8px 32px;
        text-decoration: none;
        font-size: 25px;
        color: #818181;
        display: block;
        transition: 0.3s;
    }
    .sidenav a:hover {
        color: #f1f1f1;
    }
    .sidenav .closebtn {
        position: absolute;
        top: 0;
        right: 25px;
        font-size: 36px;
        margin-left: 50px;
    }
    @media screen and (max-height: 450px) {
      .sidenav { ppadding-top: 15px;}
      .sidenav a {font-size: 18px;}
    }
    @media screen and (min-width: 200px) and (max-width: 499px){
        #rslide {display: block;}
        #rslide {display: none;}
    }
</style>
<body style="margin: 0px; background: #EAE8E7;">
<?php
    include('../../demo/connection/dbconnect.php');
    $eid=$_REQUEST['eid'];
    $sql="SELECT question_id FROM questions WHERE exam_id=$eid ORDER BY question_id";
    $result=$conn->query($sql);
    $qarray=array();
    if($result->num_rows>0)
    {
        $tq=0;
        foreach($result as $var)
        {
            $qarray[]=$var['question_id'];
            $tq++;
        }
    }
    $sql="SELECT question_id, question, question_type, option_count FROM questions WHERE exam_id=$eid ORDER BY question_id LIMIT 1";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        foreach($result as $var)
        {
            $qid=$var['question_id'];
            $question=$var['question'];
            $qt=$var['question_type'];
            $oc=$var['option_count'];
        }

        //LAST Question ID
        $sql="SELECT question_id FROM questions WHERE exam_id=$eid ORDER BY question_id DESC LIMIT 1";
        $result=$conn->query($sql);
        foreach($result as $var)
            $lqid=$var['question_id'];
        echo '<div class="content">';
        echo '<div class="col-md-12" style="margin-top: -20px; background: orange; color: white;">';
        echo '<h3>Test Title</h3>';
        echo '</div>';
        echo '<span style="font-size: 20px; cursor: pointer; position: absolute; top: 0px; right: 10px;" onclick="openNav()">&#9776;</span>';
        echo '<div id="mySidenav" class="sidenav">
              <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>';
        for($i=1;$i<=sizeof($qarray);$i++)
        {
            echo '<div class="text-center" style="float: left; margin-right: 5px;">';
            echo '<button type="button" class="btn btn-sm" onclick="getQ('.$qarray[$i-1].');">'.$i.'</button>';
            echo '</div>';
        }
        echo '</div>';

        echo '<input type="hidden" id="fq" value="'.$qid.'" />';
        echo '<input type="hidden" id="lq" value="'.$lqid.'" />';
        echo '<input type="hidden" id="tq" value="'.$tq.'" />';
        echo '<input type="hidden" id="qt" value="'.$qt.'" />';
        echo '<input type="hidden" id="oc" value="'.$oc.'" />';
        echo '<input type="hidden" id="count" value="1" />';
        echo '<input type="hidden" id="btn" />';
        echo '<input type="hidden" id="eid" value="'.$eid.'" />';
        echo '<input type="hidden" id="qid" value="'.$qid.'" />';
        echo '<input type="hhidden" id="answer" />';
        echo '<input type="hhidden" id="color" value="red" />';
        echo '<input type="hhidden" id="time_left" value="01:12:30" />';

        echo '<div class="row"></div>';
        echo '<div class="col-md-12">';
        echo '<div class="question scrollbar style-4" style="padding: 5px; min-height:70%; mmax-height:330px; overflow-y: scroll;">';
        echo '<span id="qno"><span>'.$question.'</div>';
        echo '<div class="row"></div>';
        echo '<div class="col-md-12">';
        echo '<center><div id="fourR" style="display: none;">
            <label class="but1">A <input type="radio" name="uanswer" id="o1" value="1" onclick=collect(1,"r")><span class="checkmark1"></span></label>
            <label class="but1">B <input type="radio" name="uanswer" id="o2" value="2" onclick=collect(2,"r")><span class="checkmark1"></span></label>
            <label class="but1">C <input type="radio" name="uanswer" id="o3" value="3" onclick=collect(3,"r")><span class="checkmark1"></span></label>
            <label class="but1">D <input type="radio" name="uanswer" id="o4" value="4" onclick=collect(4,"r")><span class="checkmark1"></span></label></div></center>';
        echo '<center><div id="fiveR" style="display: none;">
            <label class="but1">A <input type="radio" name="uanswer" id="o5" value="1" onclick=collect(1,"r")><span class="checkmark1"></span></label>
            <label class="but1">B <input type="radio" name="uanswer" id="o6" value="2" onclick=collect(2,"r")><span class="checkmark1"></span></label>
            <label class="but1">C <input type="radio" name="uanswer" id="o7" value="3" onclick=collect(3,"r")><span class="checkmark1"></span></label>
            <label class="but1">D <input type="radio" name="uanswer" id="o8" value="4" onclick=collect(4,"r")><span class="checkmark1"></span></label>
            <label class="but1">E <input type="radio" name="uanswer" id="o9" value="5" onclick=collect(5,"r")><span class="checkmark1"></span></label></div></center>';
        echo '<center><div id="fourC" style="display: none;">
            <label class="but2">A <input type="checkbox" name="uanswer[]" id="o10" value="1" onchange=collect(1,"c")><span class="checkmark2"></span></label>
            <label class="but2">B <input type="checkbox" name="uanswer[]" id="o11" value="2" onchange=collect(2,"c")><span class="checkmark2"></span></label>
            <label class="but2">C <input type="checkbox" name="uanswer[]" id="o12" value="3" onchange=collect(3,"c")><span class="checkmark2"></span></label>
            <label class="but2">D <input type="checkbox" name="uanswer[]" id="o13" value="4" onchange=collect(4,"c")><span class="checkmark2"></span></label></div></center>';
        echo '<center><div id="fiveC" style="display: none;">
            <label class="but2">A <input type="checkbox" name="uanswer[]" id="o14" value="1" onchange=collect(1,"c")><span class="checkmark2"></span></label>
            <label class="but2">B <input type="checkbox" name="uanswer[]" id="o15" value="2" onchange=collect(2,"c")><span class="checkmark2"></span></label>
            <label class="but2">C <input type="checkbox" name="uanswer[]" id="o16" value="3" onchange=collect(3,"c")><span class="checkmark2"></span></label>
            <label class="but2">D <input type="checkbox" name="uanswer[]" id="o17" value="4" onchange=collect(4,"c")><span class="checkmark2"></span></label>
            <label class="but2">E <input type="checkbox" name="uanswer[]" id="o18" value="5" onchange=collect(5,"c")><span class="checkmark2"></span></label></div></center></div>';
        echo '<div class="col-md-12"><ul class="pager">
            <li id="prev" style="display: none;"><a href="#">Previous</a></li>
            <li id="next"><a href="#">Next</a></li>
            </ul></div>';
        echo '<div class="row"></div>';



        echo '</div>';
    }
    else
        echo "No questions available for this Test";
    echo '</div>';
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        if($('#qt').val()=='Single' && $('#oc').val()==4)
            $('#fourR').css("display", "block");
        else
        if($('#qt').val()=='Single' && $('#oc').val()==5)
            $('#fiveR').css("display", "block");
        else
        if($('#qt').val()=='Multiple' && $('#oc').val()==4)
            $('#fourC').css("display", "block");
        else
        if($('#qt').val()=='Multiple' && $('#oc').val()==5)
            $('#fiveC').css("display", "block");
    });
    $('#next').click(function(event) {
        event.preventDefault();
        $('#btn').val('next'); 
        $('#prev').show();
        $('#count').val(parseInt($('#count').val())+1);
        c=$('#count').val();
        //$(".question").attr("id","page"+$("#count").val());
        btn=$('#btn').val();
        eid=$('#eid').val();
        qid=$('#qid').val();
        ans=$('#ans').val();
        color=$('#color').val();
        time_left=$('#time_left').val();
        $.ajax({
            type: "POST",
            url: "https://www.searchurcollege.com/exam/exam/getNext.php",
            data: "btn="+btn+"&eid="+eid+"&qid="+qid+"&color="+color+"&time_left="+time_left,
            success: function(e){
                //alert(e);
                if(e==0)
                {
                    fq=$('#fq').val();
                    $('#qid').val(fq);
                }
                else
                {
                    pos=e.indexOf("-X-");
                    len=e.length;
                    qid=e.substring(0, pos);
                    ques=e.substring(pos+3,len);


                    pos=ques.indexOf("-A-");
                    len=ques.length;
                    ans=ques.substring(0, pos);
                    ques=ques.substring(pos+3,len);
                    

                    pos=ques.indexOf("-OC-");
                    len=ques.length;
                    qt=ques.substring(4, pos);
                    ques=ques.substring(pos+4,len);

                    pos=ques.indexOf("-Q-");
                    len=ques.length;
                    oc=ques.substring(pos-3,1);
                    ques=ques.substring(pos+3,len);

                    $('#qid').val(qid);
                    $('.question').html(ques);
                    if(qt=='Single')
                        o='R';
                    else
                        o='C';

                    $('#fourR').hide();
                    $('#fiveR').hide();
                    $('#fourC').hide();
                    $('#fiveC').hide();
                    if(oc==4)
                        $('#four'+o).show();
                    else
                        $('#five'+o).show();
                    collect(oc,qt);
                }
                if($('#qid').val()==$('#lq').val())
                {
                    $('#qid').val($('#lq').val());
                    $('#next').hide();
                }
            }
        });
    });
    $('#prev').click(function(event) {
        event.preventDefault();
        $('#btn').val('prev');
        $('#next').show();
        $('#count').val(parseInt($('#count').val())-1);
        //$(".question").attr("id","page"+$("#count").val());
        btn=$('#btn').val();
        eid=$('#eid').val();
        qid=$('#qid').val();
        $.ajax({
            type: "POST",
            url: "https://www.searchurcollege.com/exam/exam/getNext.php",
            data: "btn="+btn+"&eid="+eid+"&qid="+qid,
            success: function(e){
                if(e==0)
                {
                    fq=$('#fq').val();
                    $('#qid').val(fq);
                }
                else
                {
                    pos=e.indexOf("-X-");
                    len=e.length;
                    qid=e.substring(0, pos);
                    ques=e.substring(pos+3,len);

                    pos=ques.indexOf("-OC-");
                    len=ques.length;
                    qt=ques.substring(4, pos);
                    ques=ques.substring(pos+4,len);
                    pos=ques.indexOf("-Q-");
                    len=ques.length;
                    oc=ques.substring(pos-3,1);
                    ques=ques.substring(pos+3,len);

                    $('#qid').val(qid);
                    $('.question').html(ques);
                    if(qt=='Single')
                        o='R';
                    else
                        o='C';
                    $('#fourR').hide();
                    $('#fiveR').hide();
                    $('#fourC').hide();
                    $('#fiveC').hide();
                    if(oc==4)
                        $('#four'+o).show();
                    else
                        $('#five'+o).show();
                }
                if($('#qid').val()==$('#fq').val())
                {
                    $('#qid').val($('#fq').val());
                    $('#prev').hide();
                }
            }
        });
    });
    function getQ(qid)
    {
        eid=$('#eid').val();
        btn='pallet';
        $.ajax({
            type: "POST",
            url: "https://www.searchurcollege.com/exam/exam/getNext.php",
            data: "btn="+btn+"&eid="+eid+"&qid="+qid,
            success: function(e){
                if(e==0)
                {
                    fq=$('#fq').val();
                    $('#qid').val(fq);
                }
                else
                {
                    pos=e.indexOf("-X-");
                    len=e.length;
                    qid=e.substring(0, pos);
                    ques=e.substring(pos+3,len);

                    pos=ques.indexOf("-OC-");
                    len=ques.length;
                    qt=ques.substring(4, pos);
                    ques=ques.substring(pos+4,len);
                    pos=ques.indexOf("-Q-");
                    len=ques.length;
                    oc=ques.substring(pos-3,1);
                    ques=ques.substring(pos+3,len);

                    $('#qid').val(qid);
                    $('.question').html(ques);
                    if(qt=='Single')
                        o='R';
                    else
                        o='C';
                    $('#fourR').hide();
                    $('#fiveR').hide();
                    $('#fourC').hide();
                    $('#fiveC').hide();
                    if(oc==4)
                        $('#four'+o).show();
                    else
                        $('#five'+o).show();
                }
                if($('#qid').val()==$('#fq').val())
                {
                    $('#qid').val($('#fq').val());
                    $('#prev').hide();
                }
            }
        });
    }
    function collect(v,qt)
    {
        //option=$("input[name=uanswer").val();
        if(qt=='c')
        {
        }
        //$('#answer').val(v);
        //alert(v+' '+qt);
    }
    function openNav() {
        document.getElementById("mySidenav").style.width = "250px";
    }
    
    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }
</script>

