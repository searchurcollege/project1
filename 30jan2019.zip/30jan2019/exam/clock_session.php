<?php

session_start();
$_SESSION['xt']='333';

?>