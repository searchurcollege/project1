<?php
   include("../connection/dbconnect.php");
    $cname=$_REQUEST["query"];
    if(isset($cname))
    {
    	$output="";
    	$query="SELECT search_tag_value  from suc_search_tag where search_tag_id LIKE '%$cname%'   GROUP BY search_tag_id order by search_tag_type limit 10";
    	$result=$conn->query($query);
        $result->num_rows;
    	$output='<ul class="list-unstyled">';
    	if($result->num_rows>0)
        {
            while ($row=$result->fetch_assoc()) {
                $output.='<li >'.$row["search_tag_value"].'</li>';
            }
        }
        else{
            $output.='<l1>Record not found</li>';
        }
        $output.="</ul>";
        echo $output;
    }
?>
