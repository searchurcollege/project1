<!DOCTYPE html>
<html>

<style type="text/css">
   ul{
    bbackground-color: lightgray;
    cursor: pointer;
    bborder: 1px solid black;
    
   } 
   #countryList1 ul
   {
    cursor: pointer;
    border: 1px solid lightgray;
   }
   #countryList1 li{
    padding:5px; 

   }
.search {
    width: 100px;
    height: 100px;
    background-color: orange    ;

    position: absolute;
    top:0;
    bottom: 0;
    left: 0;
    right: 0;

    margin: auto;
    margin-top: 0px;
}    
</style>
<head>
   <script>
    $(document).ready(function(){
      
    
    $("#country1").keyup(function(){
        var a=$("#country1").val();
        if(a<1)
        {
          $('#countryList1').fadeOut(); 
        }
          var query= $(this).val();
          //alert(query.length);
            if(query.length >= 2){
                $.ajax({
                    url:"https://www.searchurcollege.com/search2/search.php",
                    method:"POST",
                    data:{query:query},
                    success:function(data)
                    {

                        $('#countryList1').fadeIn(); 
                        $('#countryList1').html(data);
                    }
                });
            }
    });

    $(document).on('click','li',function(){
        $('#country1').val($(this).text());
        $('#countryList1').fadeOut();
    });

});
</script>
</head>
      <?php
        $c=$l='';
        if(isset($_REQUEST["country1"]))
            $c=$_REQUEST["country1"];
        if(isset($_REQUEST["country1"]))
            $l=$_REQUEST["location_id"];
      ?>

      <form action="https://www.searchurcollege.com/search/" method="POST">
       <div class="col-md-10 col-sm-12 col-xs-12"> <input type="text" name="country1"style="height: 40px; font-size: 16px; font-family:  Helvetica" autocomplete="off" id="country1" class="form-control" placeholder="College/Course Name " value="<?php echo $c;?>"> </div>
       <div class="col-md-2 col-sm-12 col-xs-12"> <center><button type="submit" class="" style="border-radius: 50px; color: white; wwidth=:100%; padding: 8px 32px; margin-left: -10px; background-color:#0F5C88;; font-size: 16px; font-family:  Helvetica"; >Search</button></center></div>
      </form>

