<!DOCTYPE HTML>
<!--[if IE 8 ]><html lang="en" class="ie8"><![endif]-->
<!--[if IE 9 ]><html lang="en" class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en">

<!--<![endif]-->
<head>
	
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
  <?
  include ('../connection/dbconnect.php');
  if(isset($_REQUEST["resultColName"]))
    echo '<title>'.$_REQUEST["resultColName"].'</title>  ';
  $meta_name=$_REQUEST["resultColName"];
  $keywords='Courses, Reviews, Facilities, Gallery, Documents, Contact ';
   $sql="select college_desc from suc_college where college_name='$meta_name'";
  $result=$conn->query($sql);
  while($row=$result->fetch_assoc())
    $meta_desc=$row['college_desc'];
  if($meta_desc=='')
    $meta_desc=$meta_name;
  echo '<meta name="Description" content="'.substr($meta_desc, 0,295).'"/> ';
  echo '<meta name="Keywords" content="'.$keywords.'"/>';
  ?>
  <style>
  bbody
  {
    font-family:Courier!important;
  }
        a:active, a:focus {
          outline: 0;
          border: none;
          -moz-outline-style: none;
        }

    .navEg {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #cceeff;
}

.navli {
    float: left;
}

.navli a {
    display: block;
    color: black;
    font-size: 16px;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

/* Change the link color to #111 (black) on hover */
.navli a:hover {
    background-color: #99ddff;
}
  .example1 {
    /*border: .5px solid lightgray;
    
    box-shadow: 2px 2px blue;
    height: 120px;*/
}
.boxx
{
 border: 1px solid #f2f2f2;
 border-radius: 2px;
  
}
.example2 {
    border: .5px solid lightgray;
    
    box-shadow: 1px 1px gray;
    height: 120px;
    width:100%;
}
.example1:hover
{
  background: #DCF2F3;
}
.gallery1{
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    
    
}

.gallery1:hover {
    border: 1px solid #777;
}

.gallery1 img {
    wwidth: 100%;
    hheight: auto;
    min-width:200px; 
    max-width:200px;
    height:150px;
}

.desc {
    padding: 15px;
    text-align: center;
}

.liS ul{
	margin-left: 20px;
  list-style-type: circle;
}
.liS ul li{
  color: #4d4d4d;
  font-size: 16px;
}
.liS ul li ul{
  list-style-type: square;
}
.liS ul li ul li{
  color: #4d4d4d;
  font-size: 16px;
  margin-left: 10px;
}

.liS ul li ul li p{
  color: #4d4d4d;
  font-size: 16px;
}

.CC p
{
  color: #4d4d4d;
}
.img-thumbnail
{
	box-shadow: 0px 2px #cccccc;
}
.tip {
    text-decoration: none
}
.tip:hover {
    
    position: relative
}
.tip span {
    display: none
}

.tip:hover span {
    
    padding: 5px 10px 5px 10px;
    display: block;
    z-index: 100;
    background:  #f0f0f0 ;
    left: 0px;
    mmargin: 10px;
    margin-top:20px; 
    text-align: left;
    mmargin-left: -10px;
    width: auto;
    height: auto;
    position: absolute;
    top: 25px;
    border-radius: 6px;
    font-size:14px; 
    box-shadow: 0px 3px lightgray;

    
}

.tip_info {
    text-decoration: none
}
.tip_info:hover {
    
    position: relative
}
.tip_info span {
    display: none
}

.tip_info:hover span {
    
    padding: 5px 10px 5px 10px;
    display: block;
    z-index: 100;
    background:  #f0f0f0 ;
    left: 0px;
    mmargin: 10px;
    margin-top:20px; 
    text-align: left;
    margin-left: -50px;
    width: 300px;
    height: auto;
    position: absolute;
    top: 10px;
    border-radius: 6px;
    font-size:16px; 
    box-shadow: 0px 3px lightgray;

    
}

#shotL:hover i
{

	color: #ff8533!important;
}

@media only screen and (max-width: 600px) {
  #navigation-menu {
    display: none;
  }
  .ss
  {
  	border-right: 0px solid gray!important;
  	width: 100%!important;
  	ddisplay: none;
  	margin: 10px!important;
  }
  .liS{
  	margin-left: 10px!important;
  }

  .liS ul{
	margin-left: 10px!important;
  list-style-type: circle;
}
.liS ul li{
  color: #4d4d4d;
  font-size: 16px;
}
.liS ul li ul{
  list-style-type: square;
}
.liS ul li ul li{
  color: #4d4d4d;
  font-size: 16px;
  margin-left: 10px;
}

.liS ul li ul li p{
  color: #4d4d4d;
  font-size: 16px;
}
.sn
{
	width: 100%!important;
	bbackground: red!important;
}
body
{
  font-family:Helvetica!important;
	color: black!important;

}
#comparePC
{
	display: none;
}
#brochurePC
{
	display: none;
}
#compareMob
{

	display: block!important;
}
#brochureMob
{ 
	margin-left: -10px;
	display: block!important;
}
#basic
{
	padding-top: 40px!important;
}
.heading 
{
	margin: 10px!important;
	margin-left: 0px!important;
}
.ssSub
{
	margin-top: 0px!important;
}
  .gallery1 img {
    min-width:80px; 
    max-width:80px;
    height:80px;
}

.desc {
  display: none;
    padding: 15px;
    text-align: center;
}
.boxx
{
  min-height:120px!important;
  max-height:120px!important;
  border: 0px!important;
  border-bottom: 1px solid #f2f2f2!important;
  
}
}


  </style>
</head>

	<?php
    include('../connection/dbconnect.php');
    $useragent=$_SERVER['HTTP_USER_AGENT'];
    if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
        include('../connection/header3.php');
    else
        include('../connection/header1.php');
 ?>
<?php
$cs="coming soon";
if(isset($_REQUEST["resultCol"]))
{ 
  $resultCol=$_REQUEST["resultCol"];
        //echo "&nbsp;";
       //$sql="SELECT uni_id,college_id ,college_name, college_image_path , college_desc FROM suc_college where college_id=$resultCol" ;
        $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_approval_flag1, college_highlights FROM suc_college where college_id=$resultCol" ;
}
if(isset($_REQUEST['cloud']))
{
    $title=$_REQUEST['cloud'];
    $title=str_replace('-', ' ', $title);
    $title=str_replace('~', '-', $title);
    $title=str_replace('__', "'", $title);
    $search_college_keyword=$title;
    $sql="SELECT uni_id,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_approval_flag1, college_highlights FROM suc_college where college_name like '%$search_college_keyword%'" ;
}
//echo 'D='.$sql;
        $result=$conn->query($sql);
        $i=0;
        while($row=$result->fetch_assoc())
        {
            $i++;
            $uni_id=$row['uni_id'];
            $unisql="SELECT uni_name from suc_university where uni_id=$uni_id";
            $result1=$conn->query($unisql);
          while($row1=$result1->fetch_assoc())
            $uni_name=$row1["uni_name"];
           // $d=strip_tags($des);
           $c_name=$row["college_name"];
            $c_id=$row['college_id'];
            $c_highlights=$row['college_highlights'];
            $c_desc=$row['college_desc'];
            $c_type=$row['college_type'];
            $c_location=$row['college_location_id'];
            $c_e_dt=$row['college_establishment_dt'];
            if($c_e_dt!="")
              $c_e_dt="| &nbsp Established ".substr($uni_establishment_dt, 0,4) ."&nbsp ";
            $c_aicte=$row['college_approval_flag1'];
            $c_img=$row['college_image_path'];
          $sql="SELECT location_name from location where id=".$c_location;
          $result=$conn->query($sql);
          if($result->num_rows>0){
              while ($row=$result->fetch_assoc())
                $location_name=$row["location_name"];
                $location_name='| &nbsp <i class="fa fa-map-marker" aria-hidden="true"></i> '.$location_name;
            }
          else
            $location_name="";
          if($c_type=="1")
            $type="Goverment";
          else
            $type="Private";
          $type=$type."&nbsp ";

        }

      $sql="SELECT course_uni_id FROM suc_college_courses WHERE college_id='$c_id' and course_uni_id>0 GROUP BY course_uni_id";
      $result=$conn->query($sql);
      while($row=$result->fetch_assoc())
        $course_uni_id=$row["course_uni_id"];
      if($course_uni_id>0){
      $sql="SELECT uni_name FROM suc_university WHERE uni_id='$course_uni_id'";
      $result=$conn->query($sql);
      while($row=$result->fetch_assoc())
        $course_uni_name=$row["uni_name"]." ,";
      }
      else
        $course_uni_name=" ,";
      //echo $course_uni_name;
       $course_uni_name=rtrim($course_uni_name," ,");
       $sql="select count(college_review_id) as review_count from suc_college_reviews where college_id=".$c_id." limit 1";
       $result=$conn->query($sql);
       while($row=$result->fetch_assoc())
         $review_count=$row["review_count"];

       $sql="select count(facility_id) as facility_count from suc_college_facilities where college_id=".$c_id." limit 1";
       $result=$conn->query($sql);
       while($row=$result->fetch_assoc())
         $facility_count=$row["facility_count"];

       $sql="select count(college_gallery_id) as gallery_count from suc_college_gallery where college_id=".$c_id." limit 1";
       $result=$conn->query($sql);
       while($row=$result->fetch_assoc())
         $gallery_count=$row["gallery_count"];

       $sql="select count(college_doc_id) as doc_count from suc_college_documents where college_id=".$c_id." limit 1";
       $result=$conn->query($sql);
       while($row=$result->fetch_assoc())
         $doc_count=$row["doc_count"];


        
      
// if($i>0)
// {// if $_request["uni_id"] ----- end here
?>
<body>
  <div class="ccol-md-12" style="background: #F4F4F4;">   
  <nav id="navigation-menu" style="position:fixed; width: 100%; z-index: 1000;">
    <ul class="navEg">
      <li class="navli"><a href="#basic">Overview</a></li>
      <li class="navli"><a href="#course">Courses</a></li>
      <?if($c_highlights!="")
        echo '<li class="navli"><a href="#highlight">Highlights</a></li>';?>
      <!-- <li class="navli"><a href="#place">Placements</a></li> -->
      <?
      if($review_count>0)
        echo '<li class="navli"><a href="#review">Reviews</a></li>';
      if($facility_count>0)
        echo '<li class="navli"><a href="#facility">Facilities</a></li>';
      if($gallery_count>0)
        echo '<li class="navli"><a href="#gal">Gallery</a></li>';
      if($doc_count>0)
        echo '<li class="navli"><a href="#doc">Documents</a></li>';
       ?>
      <li class="navli"><a href="#contact">Contact</a></li>
    </ul>
  </nav>
  
  <div class="col-md-12 col-sm-12 col-xs-12" style="background: #FaFaFa;">
    
    <div class="col-md-12 col-sm-12 col-xs-12">	
    <section id="basic" style="padding-top: 120px; margin:0px;">
      <div class="content img-thumbnail col-md-12 col-xs-12 col-sm-12" style="margin-bottom:30px; hheight: 200px; mmargin: 20px; background:white;">
        <div class="col-md-2 col-xs-12 col-sm-12">
          <img class="img-thumbnail" style=" min-width: 170px; max-width: 170px; min-height: 150px; max-height: 150px; margin: 10px; " src="https://www.searchurcollege.com/exam/admin/search/gallery/college/<? echo $c_img; ?>">
        </div>
        <div class="col-md-10 col-xs-12 col-sm-12">
       
        <div class="col-md-10 col-xs-12 col-sm-12"><h3 style="margin-left: 10px; font-size: 27px;"><b><? echo $c_name; ?></b></h3></div>
        <div class="col-md-2 col-xs-12 col-sm-12" style=" bbackground: lightgray; font-size: 18px;">
          <div id="shotL" class="pull-right" >Shortlist <i class="fa fa-star-o" style="color: gray;" aria-hidden="true"></i>
          </div>
        </div>
        <div class="col-md-12 col-xs-12 col-sm-12"><h4 style="margin-left: 10px; color:#a6a6a6;"><? echo $type,$c_e_dt,$location_name;  ?></h4></div>
        <br><br>
        <div class="col-md-12" >
        <?php

        
        echo'<div class="col-md-4 col-xs-12 col-sm-12 ss">
         <h4> Affilated to: <a href="uni_info.php?uni_id='.$uni_id.'&uni_name='.$uni_name.'">'.$uni_name.' </a> </h4>
        </div>';
      
        if($c_aicte!="")
        {
          echo '<div class="col-md-4 col-xs-12 col-sm-12 ss">
         <h4 sstyle="font-size: 20px; font-family:Helvetica" >AICTE Approved <i class="fa fa-info-circle tip_info" aria-hidden="true"><span>The All India Council for Technical Education is the statutory body and a national-level council for technical education, under Department of Higher Education, Ministry of Human Resource Development</span></i></h4>
        </div>';
        }
        
      

        ?>
        </div>
        <div id="brochurePC" class="pull-right " >
        	<a class="btn btn-info tip"  style="margin:20px;height: 100%; font-size: 18px;" >
        	<span><p>Download course information </p><p style="margin-top:-10px; ">in detail</p></span>Download Brochure</a>
        </div>
        <div id="comparePC" class="pull-right" >
        	<a class="btn btn-blank tip example1"  style="margin:20px;height: 100%; font-size: 18px; border: 1px solid #1ab2ff;color: #1ab2ff" >
        	<span><p>Compare colleges on ranking, </p><p style="margin-top:-10px; ">Placement, fee etc</p></span>Add to Compare</a>
        </div>

        <div id="brochureMob" style="display: none;">
        	<center>
        	<a class="btn btn-info tip"  style="margin:20px;height: 100%; font-size: 18px;" >
        	<span><p>Download course information </p><p style="margin-top:-10px; ">in detail</p></span>Download Brochure</a></center>
        </div>
        <div id="compareMob" style="display: none;" ><center>
        	<a class="btn btn-blank tip example1"  style="margin:20px;height: 100%; font-size: 18px; border: 1px solid #1ab2ff;color: #1ab2ff" >
        	<span><p>Compare colleges on ranking, </p><p style="margin-top:-10px; ">Placement, fee etc</p></span>Add to Compare</a></center>
        </div>
        

        <br>
       </div>
      </div>
    </section>


  <section id="course" style="padding-top: 120px; nbackground-color: yellow">
      <div class="content  col-md-12 col-xs-12 col-sm-12 img-thumbnail" style="background: white;  margin-bottom: 30px; mmargin: 20px;">
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Course</b></h3>
        </div>
        <?php
        $sql1="SELECT master_course_id from suc_college_courses where college_id=$c_id and college_course_status=1 group by master_course_id";
        $result1=$conn->query($sql1);
        while($row1=$result1->fetch_assoc())
        {
          $master_id.=$row1["master_course_id"].", ";
        }
        $master_id=rtrim($master_id,", ");
        //echo $master_id;
        echo '<div class="col-md-12" style="bbackground:red; margin-top:10px;  margin-bottom:20px; padding:0px;"> ';
          echo '<div class="col-md-2 col-sm-12 col-xs-12" style="margin-left:0px;"><i class="align-center">Search By Course</i></div>
          <div class="col-md-9" style="bbackground:yellow;">
          ';
        $sql1="SELECT a.course_cat_id, a.course_cat_name from suc_master_course_category a , suc_master_course b where a.course_cat_id=b.course_cat_id and  course_id IN ($master_id)group by course_cat_id";
        $result1=$conn->query($sql1);
        while($row1=$result1->fetch_assoc())
        {
          $course_cat_id=$row1["course_cat_id"];
          $course_cat_name=$row1["course_cat_name"];
          echo '<button class="btn btn-dange" style="background:white; margin-bottom:10px; margin-right:15px; border:1px solid lightgrey">'.$course_cat_name.'</button>';  
        }
        echo '</div></div>';

        echo '<div class="col-md-12" style="margin-top:10px;  margin-bottom:20px; padding:0px;"> ';
          echo '<div class="col-md-2 col-sm-12 col-xs-12" style="margin-left:0px;"><i class="align-center">Search By Stream</i></div>
          <div class="col-md-9" style="bbackground:yellow;">
          ';
        $sql1="SELECT a.course_stream_id, a.course_stream_name from suc_master_course_stream a , suc_master_course b where a.course_stream_id=b.course_stream_id and  course_id IN ($master_id)group by course_stream_id";
        $result1=$conn->query($sql1);
        while($row1=$result1->fetch_assoc())
        {
          $course_stream_id=$row1["course_stream_id"];
          $course_stream_name=$row1["course_stream_name"];
          echo '<button class="btn btn-dange" style="background:white; margin-bottom:10px; margin-right:15px; border:1px solid lightgrey">'.$course_stream_name.'</button>';  
        }
        echo '</div></div>';

         $sql1="SELECT college_course_id,college_course_name, college_course_full_part, college_course_duration, college_course_seats from suc_college_courses where college_id=$c_id and college_course_status=1";
        $result1=$conn->query($sql1);
        if($result1->num_rows<=8)
        {
        while($row1=$result1->fetch_assoc())
        {
         $course_id=$row1["college_course_id"];
         $course_name=$row1["college_course_name"];
         $course_type=$row1["college_course_full_part"];
         $course_duration=$row1["college_course_duration"];
         $course_seats=$row1["college_course_seats"];
         echo '<div class="sswell col-md-3 col-sm-12 col-xs-12  example1 boxx" style="bbackground:red; min-height:150px;
               max-height:150px; mmargin-bottom:30px;  bborder:1px solid lightgray;">
         <div  style=""> <br>
         <h4 class="memdia-heading" >
         <form target="_blank" method="POST" action="course_info.php">
         <input type="hidden" name="course_id" value="'.$course_id.'">
         <input type="hidden" name="course_name" value="'.$course_name.'">
          <button type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left;outline: 0;border: none;-moz-outline-style: none;"><strong>'.$course_name.'</strong></button> </form>
          </h4><div style="align-left"><p style="font-size :14px; color:gray;"> '.$course_type.' &nbsp  | &nbsp    Course Duration:&nbsp'.$course_duration.'</p></div>
        
          </div>
    
    
           </div>'; 
        }
      }
      else
        {
        $i=1;
          
          
            while($row1=$result1->fetch_assoc())
        {
          if($i<=7)
          {
         $course_id=$row1["college_course_id"];
         $course_name=$row1["college_course_name"];
         $course_type=$row1["college_course_full_part"];
         $course_duration=$row1["college_course_duration"];
         $course_seats=$row1["college_course_seats"];
         echo '<div class="sswell col-md-3 col-sm-12 col-xs-12 boxx  example1" style="bbackground:red; min-height:150px;
               max-height:150px; mmargin-bottom:30px;  bborder:1px solid lightgray;">
         <div  style=""> <br>
         <h4 class="memdia-heading" >
         <form target="_blank" method="POST" action="course_info.php">
         <input type="hidden" name="course_id" value="'.$course_id.'">
         <input type="hidden" name="course_name" value="'.$course_name.'">
          <button type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left;outline: 0;border: none;-moz-outline-style: none;"><strong>'.$course_name.'</strong></button> </form>
          </h4><div style="align-left"><p style="font-size :14px; color:gray;"> '.$course_type.' &nbsp  | &nbsp    Course Duration:&nbsp'.$course_duration.'</p></div>
        
          </div>
    
    
           </div>'; 
           $i++;
         }

        }
         echo '<div  class="sswell col-md-3 col-sm-12 col-xs-12 boxx  example1" style="bbackground:red; min-height:150px;
               max-height:150px; mmargin-bottom:30px;  bborder:1px solid lightgray; padding:50px">
               <div class="col-md-12 col-sm-12 col-xs-12"> 
               <form target="_blank" action="courseList.php" method="POST">
               <input type="hidden" value="'.$c_name.'" name="college_name" >
               <input type="hidden" value="'.$c_id.'" name="college_id" >
               <button class="btn btn-default" style="border:0px;">
               view More
               </button>
               </form>
               </div>

               </div>';
        }
           
        ?>
      </div>
    </section>

     <? if ($c_highlights!="")
    {?>
    <section id="highlight" style="padding-top: 120px; nbackground-color: yellow">
      <div class="content  col-md-12 col-xs-12 col-sm-12 img-thumbnail" style="background: white;  margin-bottom: 30px; mmargin: 20px;">
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Highlights</b></h3>
        </div>
        <br><br>
        <div class="liS" style="margin-left:40px; ">
        <ul><li><?php echo $c_highlights;?></li></ul>
        
        </div>
        <br>
      </div>
    </section>
  <? }?>
<? if($review_count>0) { ?>
<section id="review" style="padding-top: 120px; nbackground-color: yellow">
      <div class="content  col-md-12 col-xs-12 col-sm-12 img-thumbnail" style="background: white;  margin-bottom: 30px; mmargin: 20px; ">
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Reviews</b></h3>
        </div>
        <br>
        <?php
                    $queryReviews="SELECT college_review_date, college_review_user,college_review_comment,college_review_likes from suc_college_reviews where college_id=$c_id";  
                       $resultReview=$conn->query($queryReviews);
                        while($rowReview=$resultReview->fetch_assoc())
                        {
                           $college_review_user=$rowReview["college_review_user"];
                           $college_review_date=$rowReview["college_review_date"];
                           $college_review_comment=$rowReview["college_review_comment"];
                           $college_review_likes=$rowReview["college_review_likes"];
                           echo '<div style="padding:20px;">
                           <div>
                           <blockquote><q style="font-size:15px;">'.$college_review_comment.'</q></blockquote>
                           <strong><p style="font-size:20px; color:blue; margin-top:-15px;">'.$college_review_user.' </p></strong> <small><i class="fa fa-thumbs-up" style="color:skyblue;" aria-hidden="true"></i> ('.$college_review_likes.')</small> &nbsp  &nbsp
                           '.$college_review_date.'
                           
                            </div>
                           </div>';
                         }
                    ?>
        <br>
      </div>
    </section>
<? } 
if($facility_count>0)
{
?>
    <section id="facility" style="padding-top: 120px; nbackground-color: yellow">
      <div class="content  col-md-12 col-xs-12 col-sm-12 img-thumbnail" style="background: white;  margin-bottom: 30px; mmargin: 20px; ">
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Facilities</b></h3>
        </div>
        <br>
        <?php
                     //$cc="https://www.searchurcollege/exam/admin/search/gallery/college/gallery/college/facility/facility_".$c_id.'*.*';
       $sqlfacilities="SELECT m.facility_name , m.facility_icon_path FROM suc_college_facilities a , suc_facilities_master m WHERE a.facility_code=m.facility_code and a.college_id=$c_id order by m.facility_name ";
       $resultfacilities=$conn->query($sqlfacilities);
       while($rowfacilities=$resultfacilities->fetch_assoc()){
         $facility_name=$rowfacilities["facility_name"];
        $facility_icon_path=$rowfacilities["facility_icon_path"];
        echo '<div class="col-md-1 col-xs-4 col-xs-4 " style="max-height:110px; min-height:110px; margin-bottom:30px;"><center><img  style ="max-width: 70px; max-height:50px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/facility_master/'.$facility_icon_path.'" alt="'.$facility_name.'"> &nbsp';
        echo '<p style="margin-top:10px">'.$facility_name.'</center></p> </div>';
        }
            
      ?> 
        <br>
      </div>
    </section>
<?
} 
if($gallery_count>0)
{
?>
     <section id="gal" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="background: white;  margin-bottom:30px; mmargin: 20px;" >
         <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Gallery</b></h3>
        </div>
        <br><br>
        <div  style=" padding: 0px;">
        <?php
                    $sqlgallery="SELECT college_gallery_desc, college_gallery_content_path from suc_college_gallery where college_id=$c_id";
                    $resultgallery=$conn->query($sqlgallery);
                    while($rowgallery=$resultgallery->fetch_assoc())
                    {
                      $college_gallery_desc=$rowgallery["college_gallery_desc"];
                       $college_gallery_content_path=$rowgallery["college_gallery_content_path"];
                      echo '<div class="gallery1" ><img src="https://www.searchurcollege.com/exam/admin/search/gallery/'.$college_gallery_content_path.'" sstyle="min-width:200px; max-width:200px; height:150px;"><div class="desc">'.$college_gallery_desc.'</div></div>';
                    }
                     //$cc="https://www.searchurcollege/exam/admin/search/gallery/college/gallery/college/facility/facility_".$c_id.'*.*';
                    
                    ?>
        </div>
        <br><br>
      </div>
    </section>
<?
}
if($doc_count>0)
{
?>
    <section id="doc" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="background: white;  margin-bottom:30px; mmargin: 20px;" >
         <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Important Documents</b></h3>
        </div>
        <br><br>
        <div ">
        <?php
                    $sqlDoc="SELECT   college_doc_id, college_doc_name, college_doc_desc, college_doc from suc_college_documents where college_id=$c_id";
                    $resultDoc=$conn->query($sqlDoc);
                    //echo '<div class="col-md-12">';
                    while($rowDoc=$resultDoc->fetch_assoc())
                    {
                      $college_doc_id=$rowDoc["college_doc_id"];
                      $college_doc_name=$rowDoc["college_doc_name"];
                      $college_doc_desc=$rowDoc["college_doc_desc"];
                      $college_doc=$rowDoc["college_doc"];
                      $s= substr($college_doc, strpos($college_doc, ".")+1);
                      if($s=="pdf" or $s=="doc")
                        $college_doc="pdficon.png";
                      $c_download=$rowDoc["college_doc"];

                      echo '<div class="col-md-3 img-thumbnail example1" style="margin:20px;"><center><a href="https://www.searchurcollege.com/exam/admin/search/college-documents/documents/'.$c_download.'"  download ><img class="mmmedia-object col-xs-12"  title="Click to download" src="https://www.searchurcollege.com/exam/admin/search/college-documents/documents/'.$college_doc.'" style=" width: 100px  ;"/> &nbsp';
                  echo '<p>'.$college_doc_name.'</center></p> </a>  </div>';
                }?>
        </div>
        <br><br>
      </div>
    </section>
    
    <?}?>
    
    <section id="contact" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="mmargin-top: 50px; background:white; margin-bottom: 30px; mmargin: 20px;" >
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Contact</b></h3>
        </div>
        <br><br>
        <div class="sswell col-md-10">
         <?php

         $sqlContact="SELECT college_address, college_website, college_phone_1,college_phone_2,college_email from suc_college_contacts where college_id=$c_id";
                    $resultContact=$conn->query($sqlContact);
                     while($rowContact=$resultContact->fetch_assoc())
                     {
                      $college_address=$rowContact["college_address"];
                      $college_website=$rowContact["college_website"];
                      $college_phone_1=$rowContact["college_phone_1"];
                      $college_phone_2=$rowContact["college_phone_2"];
                      $college_email=$rowContact["college_email"];
                      if(substr($college_website, 0, 3)=="www")
                        $college_website= "http://".$college_website;

                     }
         if($college_address!="")
         {
          echo '<div class="mmedia-body col-md-4" style="bbackground: yellow; mmargin-left:-20px;">
                 <p style="color:gray; font-size: 18px;">Address<p>
                  '.$college_address.'
              </div>';
         }
        
                 
              if($college_website!="")
              {
                echo '<div class="mmedia-body col-md-4" style="bbackground: red; mmargin-left:-20px;">
              <p style="color:gray; font-size: 18px;">Website<p>
              <p><a target="_blank" href='.$college_website.'> Click here</a></p>
              </div>';
              }

                
              //echo '<!--<div class="mmedia-body col-md-4" style="bbackground: blue; mmargin-left:-20px;"><p style="color:gray; font-size: 18px;">Email Address<p><p>'.$college_email.'</p></div> -->
              
         ?>
       </div> 
       
         <br><br>
     
      </div>
    </section>

   <!--  <section id="contact" style="padding-top: 120px;">
      <div class="col-md-12 img-thumbnail" style="background: white; mmargin: 20px; margin-bottom: 150px;">
     <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 ><b>Contact</b></h3>
        </div>
        <br><br>
         <?php // echo $cc_eligibility_qual.":".$cc_eligibility_qual_criteria;?>
         <br><br>
      </div>
    </section> -->
  </div>
  <div class="col-md-1"></div>
  </div>
  <!-- Google CDN jQuery -->
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  
  <!-- Page Scroll to id plugin -->
  <script src="jquery.malihu.PageScroll2id.js"></script>
  
  <script>
    (function($){
      $(window).on("load",function(){
        
        /* Page Scroll to id fn call */
        $("#navigation-menu a,a[href='#top'],a[rel='m_PageScroll2id']").mPageScroll2id({
          highlightSelector:"#navigation-menu a"
        });
        
        /* demo functions */
        $("a[rel='next']").click(function(e){
          e.preventDefault();
          var to=$(this).parent().parent("section").next().attr("id");
          $.mPageScroll2id("scrollTo",to);
        });
        
      });
    })(jQuery);
  </script>
  <div><?php include("../footer.php");?>

</div></div>
</body>

</html>