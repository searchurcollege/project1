<?
include('../connection/dbconnect.php');
$i=0;
$sql="select question_id , question_id_OLD from questions where question_id_OLD!=0";
$result=$conn->query($sql);
while ($row=$result->fetch_assoc()) {
	  $row["question_id_OLD"].'--->'.$row["question_id"].'<br>';
	 $old_q=$row["question_id_OLD"];
	 $sql1="select question_id  from answer where question_id='$old_q' group by question_id ";
$result1=$conn->query($sql1);
while ($row1=$result1->fetch_assoc()) {
	 $row1["question_id"].'<br>';
	$i++;
}
}
echo $i.'<br>';

// $i=0;
// echo $sql="select question_id  from answer where exam_id in(96,97,98,99,100,101,104,105,106,107,108,109,110,111,112,113,114,115,116,118,119,120,122,124,126)";
// $result=$conn->query($sql);
// while ($row=$result->fetch_assoc()) {
// 	echo $row["question_id"].'<br>';
// 	$i++;
// }
// echo $i;
?>