<?php

//fetch_data.php

include("../connection/dbconnect.php");

 if(isset($_POST["c_id"]))
 {
   $c_id_f= $_POST["c_id"];
  $c_id_f=rtrim($c_id_f,', ');
 }

 if(isset($_REQUEST["loc_name"]))
{
 $loc=$_REQUEST["loc_name"];

}

$query="SELECT uni_id,uni_name,college_id ,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_approval_flag1 FROM suc_search_results where college_id IN (".$c_id_f.")";
 if(isset($_POST["brand"]))
 {
  $brand_filter = implode("','", $_POST["brand"]);
   $query.=" and college_location_id IN( '".$brand_filter."')";
 }

 if(isset($_POST["fee"]))
 {
  $storage_filter = implode(", ", $_POST["fee"]);
   $storage_filter;
  $k1 = explode(", ",$storage_filter);
   $min=$k1[0];
   $max=$k1[1];

   $query.=" and cc_total_fee BETWEEN '$min' and '$max'";

 }

if(isset($_POST["course"]))
 {
  $course_filter = implode("','", $_POST["course"]);
    $query.=" and course_cat_id IN ('$course_filter')";
 }
 if(isset($_REQUEST["state"]))
 { 
 // echo "statte................".$_REQUEST["state"];
   $state_filter = implode("','", $_REQUEST["state"]);
     $query.=" and state ='$state_filter'";
 }

 $query.=" group by college_id";
 
 if(!isset($_POST["fee"]) && !isset($_POST["course"]) && !isset($_POST["brand"]) && !isset($_POST["state"]))
 {
  $query="SELECT  DISTINCT(college_id) ,uni_id,uni_name,college_name , college_image_path , college_desc, college_location_id ,college_type ,college_establishment_dt ,college_approval_flag1 FROM    suc_search_results";
  if(isset($_REQUEST["college_like"]))
  {

      $s=$_REQUEST["college_like"];
     $sql="select search_tag_type from suc_search_tag where search_tag_value like '%$s%'";
     $result=$conn->query($sql);
     while($row=$result->fetch_assoc())
      {
        $name=$row["search_tag_type"];
      }
      $query.=" WHERE";
      if($name==1)
        $query.=" course_cat_name like'%".$s."%'";
      if($name==2)
        $query.=" college_name like '%$s%'";
      if(isset($_REQUEST["loc_name"]))
        $query.=" and college_location_id IN (".$loc.")";
    }
    elseif(isset($_REQUEST["loc_name"]))
    {
      $query.=" where college_location_id IN (".$loc.")";
    }
}
 

 $result = $conn->query($query);
  
 
 $output = '';
 if($result->num_rows>0)
 {
  foreach($result as $row)
  {
    $uni_id=$row['uni_id'];
          //   $unisql="SELECT uni_name from suc_university where uni_id=$uni_id";
          //   $result1=$conn->query($unisql);
          // while($row1=$result1->fetch_assoc())
            $uni_name=$row["uni_name"];
           // $d=strip_tags($des);
           $c_name=$row["college_name"];
            $c_id=$row['college_id'];
            $c_desc=$row['college_desc'];
            $c_type=$row['college_type'];
            $c_location=$row['college_location_id'];
            $c_e_dt=$row['college_establishment_dt'];
            $c_e_dt=substr($c_e_dt, 0,4);
            if(substr($c_e_dt, 0,1)!="0")
            {
              $c_e_dt='|  &nbsp Established &nbsp'.$c_e_dt;
            }
            else
              $c_e_dt=""; 
            $c_aicte=$row['college_approval_flag1'];
            $c_img=$row['college_image_path'];
            $sql2="SELECT college_rating from suc_college_rating where college_id=$c_id";
            $result2=$conn->query($sql2);
          while($row2=$result2->fetch_assoc())
             $rating=$row2["college_rating"];
          $sqlLocation="SELECT location_name,state from location where id=$c_location";
          $resultLocation=$conn->query($sqlLocation);
          while($rowLocation=$resultLocation->fetch_assoc()){
            $l_name=$rowLocation["location_name"];
            $l_state=$rowLocation["state"];
          }
          if($c_type=="1")
            $type="Government";
          else
            $type="Private";
          if($c_aicte!="")
             $aprroval='|  &nbsp '.$c_aicte.'  <i class="fa fa-info-circle" aria-hidden="true"></i>';
           else
             $aprroval='';
   // $output .= '
   // <div class="col-sm-4 col-lg-3 col-md-3">
   //  <div style="border:1px solid #ccc; border-radius:5px; padding:16px; margin-bottom:16px; height:450px;">
   //   <img src="image/'. $row['product_image'] .'" alt="" class="img-responsive" >
   //   <p align="center"><strong><a href="#">'. $row['product_name'] .'</a></strong></p>
   //   <h4 style="text-align:center;" class="text-danger" >'. $row['product_price'] .'</h4>
   //   <p>Camera : '. $row['product_camera'].' MP<br />
   //   Brand : '. $row['college_name'] .' <br />
   //   RAM : '. $row['product_ram'] .' GB<br />
   //   Storage : '. $row['product_storage'] .' GB </p>
   //  </div>

   // </div>
   // ';
           $output.= '<div class="well col-md-12 col-xs-12 col-sm-12 " style="background: white;height: auto; margin-bottom: 20px; padding: 10px;   border:1px solid #D3D3D3; ">
              <form class="listC" target="_blank" action="college_info.php" method="post">  
              
                  <input type="hidden" name="resultCol" value="'.$c_id.'" />
                  <input type="hidden" name="resultColName" value="'.$c_name.'" />
                  <div class="mmedia col-md-2" style="bbackground: red;">
                    <button type="submit" style="background: transparent; border: 0px;"><img class="img1"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/'.$c_img.'" sstyle="min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px; border:1px solid #D3D3D3;" sstyle="position:absolute; top:10px; left: 0px; height:125px; width: 150px; border:2px solid #d9d9d9;"/></button>
                  </div>
                <div class="mmedia-h col-md-10 col-sm-10 col-xs-10" style="margin-top: 10px;  ">
                 <h4 class="memdia-heading col-sm-12 col-xs-12 col-md-12" style="font-family: system-ui; "><button class="bsubmit" type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left; color:#0F5C88; mmargin-left: -15px; ">'.$c_name.'</button>';
                 // $output .='<span class="pull-right"><small>';
                 //    if($rating>=1)
                 //    {
                 //        $output.= "Rating";
                 //        for($i=0;$i<$rating;$i++)
                 //            $output.=' <i class="fa fa-star" style="color:#ffa31a;text-shadow:1px 1px black;" aria-hidden="true"></i>';
                 //    }
                 //    $output.='</small></span>';
                 $output.=' <h5 class="col-md-12 col-xs-12 col-sm-12 bsubmit-a" style="font-size :14px; color:#696969; font-weight: normal!important; margin-left:0px;text-transform:none; "><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp '.$l_name.','.$l_state.'
                   &nbsp| &nbsp&nbsp<i class="fa fa-university" aria-hidden="true"></i>&nbsp '.$uni_name.'
                   
                    &nbsp';
                 $output.=' </h5> <h5  class="bsubmit-h" style="color:#696969; font-size:14px; font-weight: normal!important;mmargin-left:0px;text-transform:none;">Ownership :&nbsp  '.$type;
                 $output.= '  &nbsp'.$c_e_dt.'&nbsp'.$aprroval.'</h5>';

                 $sqlfacilities="SELECT m.facility_name, m.facility_icon_path FROM suc_college_facilities a , suc_facilities_master m WHERE a.facility_code=m.facility_code and a.college_id=$c_id";
                 $resultfacilities=$conn->query($sqlfacilities);
                 while($rowfacilities=$resultfacilities->fetch_assoc()){
                   $facility_name=$rowfacilities["facility_name"];
                  $facility_image_path=$rowfacilities["facility_icon_path"];
                  $output.='<img cclass="img-thumbnail" style ="width: 20px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/facility_master/'.$facility_image_path.'" title="'.$facility_name.'"> &nbsp &nbsp';
                  }

                 // $sqlfacilities="SELECT facility_name, facility_image_path from suc_college_facilities where college_id=$c_id";
                 // $resultfacilities=$conn->query($sqlfacilities);
                 // while($rowfacilities=$resultfacilities->fetch_assoc()){
                 //   $facility_name=$rowfacilities["facility_name"];
                 //  $facility_image_path=$rowfacilities["facility_image_path"];
                 //  $output.= '<img cclass="img-thumbnail" style ="width: 25px; margin-left:5px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/'.$facility_image_path.'" title="'.$facility_name.'"> &nbsp';
                 //  }
                 $output.=' 
            </div>
            </form>
          </div>';
  }
 }
 else
 {
  //$output = '<h3>No Data Found</h3>';
 }
 echo $output;


?>