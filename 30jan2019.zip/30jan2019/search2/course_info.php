<!DOCTYPE HTML>
<!--[if IE 8 ]><html lang="en" class="ie8"><![endif]-->
<!--[if IE 9 ]><html lang="en" class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en">

<!--<![endif]-->
<head>
	<?php
	if(isset($_REQUEST["course_name"])){
    $course_name=$_REQUEST["course_name"];
		echo '<title>'.$course_name.'</title>  ';
  }
  else
    echo 'Searchurcollege';
	?>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
  .s_title
  {
    font-size: 18px;
    color:gray;
  }
        a:active, a:focus {
          outline: 0;
          border: none;
          -moz-outline-style: none;
        }

    .navEg {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

.navli {
    float: left;
}

.navli a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

/* Change the link color to #111 (black) on hover */
.navli a:hover {
    background-color: #111;
}
  .example1 {
    /*border: .5px solid lightgray;
    
    box-shadow: 2px 2px blue;
    height: 120px;*/
}
.example2 {
    border: .5px solid lightgray;
    
    box-shadow: 1px 1px gray;
    height: 120px;
    width:100%;
}
.example1:hover
{
  background: #DCF2F3;
}
.gallery1{
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    wwidth: 180px;
}

.gallery1:hover {
    border: 1px solid #777;
}

.gallery1 img {
    wwidth: 100%;
    hheight: auto;
}

.desc {
    padding: 15px;
    text-align: center;
}
.liX ul li{
  color: #4d4d4d;
  font-size: 16px;
}
.liS p
{
  font-size: 17px;
  color: #262626;
}
.liS ul{
	margin-left: 20px;
  list-style-type: circle;
}
.liS ul li{
  color: #4d4d4d;
  font-size: 16px;
}
.liS ul li ul{
  list-style-type: square;
}
.liS ul li ul li{
  color: #4d4d4d;
  font-size: 16px;
  margin-left: 10px;
}

.liS ul li ul li p{
  color: #4d4d4d;
  font-size: 16px;
}


.CC p
{
  color: #4d4d4d;
  font-size: 16px!important;
}
.img-thumbnail
{
	box-shadow: 0px 2px #cccccc;
}
.tip {
    text-decoration: none
}
.tip:hover {
    
    position: relative
}
.tip span {
    display: none
}

.tip:hover span {
    
    padding: 5px 10px 5px 10px;
    display: block;
    z-index: 100;
    background:  #f0f0f0 ;
    left: 0px;
    mmargin: 10px;
    margin-top:20px; 
    text-align: left;
    mmargin-left: -10px;
    width: auto;
    height: auto;
    position: absolute;
    top: 25px;
    border-radius: 6px;
    font-size:14px; 
    box-shadow: 0px 3px lightgray;

    
}
#shotL:hover i
{

	color: #ff8533!important;
}
@media only screen and (max-width: 600px) {
  #navigation-menu {
    display: none;
  }
  .liX ul li{
  color: #4d4d4d;
  font-size: 14px;
}
  .ss
  {
  	border-right: 0px solid gray!important;
  	width: 100%!important;
  	ddisplay: none;
  	margin: 10px!important;
  }
  .CC p
{
  color: #4d4d4d;
  font-size: 16px!important;
}
  .liS{
  	margin-left: 10px!important;
  }

  .liS ul{
	margin-left: 10px!important;
  list-style-type: circle;
}
.liS ul li{
  color: #4d4d4d;
  font-size: 16px;
}
.liS ul li ul{
  list-style-type: square;
}
.liS ul li ul li{
  color: #4d4d4d;
  font-size: 16px;
  margin-left: 10px;
}

.liS ul li ul li p{
  color: #4d4d4d;
  font-size: 16px;
}
.sn
{
	width: 100%!important;
	bbackground: red!important;
}
body
{
	color: black!important;

}
#comparePC
{
	display: none;
}
#brochurePC
{
	display: none;
}
#compareMob
{

	display: block!important;
}
#brochureMob
{ 
	margin-left: -10px;
	display: block!important;
}
#basic
{
	padding-top: 40px!important;
}
.heading 
{
	margin: 10px!important;
	margin-left: 0px!important;
}
.ssSub
{
	margin-top: 0px!important;
}
  
}


  </style>
</head>
<hheader>
	<?php
    include('../connection/dbconnect.php');
    $useragent=$_SERVER['HTTP_USER_AGENT'];
    if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
        include('../connection/header3.php');
    else
        include('../connection/header1.php');
 ?>
</header>
<?php
$cs="coming soon";
$college_name=$_REQUEST["college_name"];
if(isset($_REQUEST["course_id"]))
{ 
  $course_id=$_REQUEST["course_id"];
//echo "&nbsp;";
$sql="SELECT college_course_full_part,course_aicte_flag, college_course_highlights ,college_course_type,college_course_duration,college_course_language,college_course_seats,course_uni_id FROM suc_college_courses where college_course_id=$course_id" ;
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
  $college_course_full_part=$row['college_course_full_part'];
  if($college_course_full_part!="")
    $college_course_full_part=" &nbsp".$college_course_full_part."&nbsp |";
  else
    $college_course_full_part="";
  $course_aicte_flag=$row['course_aicte_flag'];
  $college_course_highlights=$row['college_course_highlights'];
  if($college_course_highlights=="")
     $college_course_highlights=$cs;
  $college_course_type=$row['college_course_type'];
  if($college_course_type!="")
     $college_course_type=ucfirst($college_course_type)."&nbsp |";
  else
    $college_course_type="";
  $college_course_duration=$row['college_course_duration'];
  if($college_course_duration!="")
    $college_course_duration="&nbsp Duration - ".$college_course_duration;
  else
    $college_course_duration="";
  $college_course_language=$row['college_course_language'];
  $college_course_seats=$row['college_course_seats'];
  
  $course_uni_id=$row['course_uni_id'];
}
$sql="SELECT cc_total_fee , cc_fee_currency, cc_fee_notes from suc_college_course_fee_structure where college_course_id=".$course_id;
$result=$conn->query($sql);
if($result->num_rows>0){
    while ($row=$result->fetch_assoc()) {
      $cc_total_fee=$row["cc_total_fee"];
      $cc_fee_notes=$row["cc_fee_notes"];
      if($cc_fee_notes!="")
        break;
      $cc_fee_currency=$row["cc_fee_currency"];
    }
  }
else{
  $cc_total_fee="";
  $cc_fee_currency="";
}





}

$sql="SELECT uni_name from suc_university where uni_id=".$course_uni_id;
$result=$conn->query($sql);
while ($row=$result->fetch_assoc())
  $uni_name=$row["uni_name"];

$sql="SELECT course_top_recruiters , course_highest_placementmet, course_average_placement, course_lowest_placement from suc_course_other_details where course_id=".$course_id;
         $result=$conn->query($sql);
         while($row=$result->fetch_assoc()){
          $top_recruiters=$row["course_top_recruiters"];
          $highest_placement=$row["course_highest_placementmet"];
          $average_placement=$row["course_average_placement"];
          $lowest_placement=$row["course_lowest_placement"];
         }

?>
<body>
  <div class="ccol-md-12" style="background: #fafafa;">   
  <nav id="navigation-menu" style="position:fixed; width: 100%; z-index: 1000;">
    <ul class="navEg">
      <li class="navli"><a href="#basic">Overview</a></li>
      <li class="navli"><a href="#highlight">Highlights</a></li>
      <li class="navli"><a href="#eligibility">Eligibility</a></li>
    <!--   <li class="navli"><a href="#review">Reviews</a></li> -->
      <li class="navli"><a href="#admission">Admission</a></li>
      <li class="navli"><a href="#fee">Fee</a></li>
      <li class="navli"><a href="#structure">Structure</a></li>
      <li class="navli"><a href="#seatI">Seat Info</a></li>
    <? if($top_recruiters!="") echo '<li class="navli"><a href="#place">Placement</a></li>'; ?>
      <!-- <li class="navli"><a href="#contact">Contact</a></li> -->
    </ul>
  </nav>
  
  <div class="col-md-12 ">
    
    <div class="col-md-12 col-sm-12 col-xs-12">	
    <section id="basic" style="padding-top: 120px; margin:0px;">
      <div class="content img-thumbnail col-md-12 col-xs-12 col-sm-12" style="margin-bottom:30px; hheight: 200px; mmargin: 20px; background:white;">
      	<div class="col-md-10 col-xs-12 col-sm-12"><span style="font-size: 18px; color:#a6a6a6; cursor: pointer;"><? echo $college_name; ?></span></div>
      	<div class="col-md-2 col-xs-12 col-sm-12" style=" bbackground: lightgray; font-size: 18px;">
      		<div id="shotL" class="pull-right" >Shortlist <i class="fa fa-star-o" style="color: gray;" aria-hidden="true"></i>
      		</div>
      	</div>
      	
       
        <div class="col-md-12 col-xs-12 col-sm-12"><h3 style="margin-left: 10px; font-size: 27px;"><b><? echo $course_name; ?></b></h3></div>
        <div class="col-md-12 col-xs-12 col-sm-12"><h4 style="margin-left: 10px; color:#a6a6a6;"><? echo $college_course_type,$college_course_full_part,$college_course_duration;  ?></h4></div>
        <br><br>
        <?php
        if($course_aicte_flag==1)
        {
          echo '<div class="col-md-1 col-xs-6 col-sm-6 ss" style=" border-right: 1px solid lightgray; width: 15%;">
         <center> <h4 style="font-size: 20px;" >AICTE</h4>
          <h4 class="ssSub" style="margin-top: -5px; color:#a6a6a6;">Approved
          </h4>
         </center>
        </div>';
        }
        if($cc_total_fee>0){
        echo'<div class="col-md-1 col-xs-12 col-sm-12 ss " style="border-right: 1px solid lightgray; width: 15%;">
         <center> <h4><b>'.$cc_fee_currency." ".$cc_total_fee.' </b></h4>
          <h4 class="ssSub" style="margin-top: -5px; color:#a6a6a6;">Total Fee
          </h4>
         </center>
        </div>';
      }
        ?>

        <div class="col-md-1 col-xs-12 col-sm-12 ss " style="width: 15%;">
         <center> <h4 style="font-size: 20px;" ><b><? echo $college_course_language;?></b></h4>
          <h4 class="ssSub" style="margin-top: -5px; color:#a6a6a6;">Medium
          </h4>
         </center>
        </div>
        <div id="brochurePC" class="pull-right " >
          <?php
          if(isset($_SESSION['email']))
            echo '<a class="btn btn-info tip"  style="margin:20px;height: 100%; font-size: 18px;" >
          <span><p>Download course information </p><p style="margin-top:-10px; ">in detail</p></span>Download Brochure</a>';
          else
            echo '<a class="btn btn-info tip" href="#" data-toggle="modal" data-target="#register"  style="margin:20px;height: 100%; font-size: 18px;" >
          <span><p>Download course information </p><p style="margin-top:-10px; ">in detail</p></span>Download Brochure</a>';
          ?>
        	
        </div>
        <div id="comparePC" class="pull-right" >
        	<a class="btn btn-blank tip example1"  style="margin:20px;height: 100%; font-size: 18px; border: 1px solid #1ab2ff;color: #1ab2ff" >
        	<span><p>Compare colleges on ranking, </p><p style="margin-top:-10px; ">Placement, fee etc</p></span>Add to Compare</a>
        </div>

        <div id="brochureMob" style="display: none;">
        	<center>
            <?php
          if(isset($_SESSION['email']))
            echo '<a class="btn btn-info tip"  style="margin:20px;height: 100%; font-size: 18px;" >
          <span><p>Download course information </p><p style="margin-top:-10px; ">in detail</p></span>Download Brochure</a>';
          else
            echo '<a class="btn btn-info tip" href="https://www.searchurcollege.com/connection/register1.php"  style="margin:20px;height: 100%; font-size: 18px;" >
          <span><p>Download course information </p><p style="margin-top:-10px; ">in detail</p></span>Download Brochure</a>';
          ?>
        	<!-- <a class="btn btn-info tip"  style="margin:20px;height: 100%; font-size: 18px;" >
        	<span><p>Download course information </p><p style="margin-top:-10px; ">in detail</p></span>Download Brochure</a> --></center>
        </div>
        <div id="compareMob" style="display: none;" ><center>
        	<a class="btn btn-blank tip example1"  style="margin:20px;height: 100%; font-size: 18px; border: 1px solid #1ab2ff;color: #1ab2ff" >
        	<span><p>Compare colleges on ranking, </p><p style="margin-top:-10px; ">Placement, fee etc</p></span>Add to Compare</a></center>
        </div>
        

        <br>
        <?
        if($uni_name!="")
        {
          echo '<div class="col-md-1" style="width: 100%; margin:10px;"> <h4 style="font-size: 18px; color:#4d4d4d">Affiliated to <span style="color:#999999">'.$uni_name.'</span></h4></div>';
        }
        ?>
        <br>
      </div>
    </section>

    <section id="highlight" style="padding-top: 120px; nbackground-color: yellow">
      <div class="content  col-md-12 col-xs-12 col-sm-12 img-thumbnail" style="background: white;  margin-bottom: 30px; mmargin: 20px;">
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Highlights</b></h3>
        </div>
        <br><br>
        <div class="CC liS" style="margin-left:40px; ">
        <?php echo $college_course_highlights;?>
        </div>
        <br>
      </div>
    </section>

    
    <section id="eligibility" style="padding-top: 120px; ">
      <div class="content col-md-12 img-thumbnail col-xs-12 col-sm-12 "  style="background:white; margin-bottom: 30px; mmargin: 20px;">
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Eligibility</b></h3>
        </div>
        <br>
        <span class="liS" style="font-size:16px;">
        <?php
		$sql="SELECT cc_eligibility_qual , cc_eligibility_qual_criteria from suc_college_course_eligibility where college_course_id=".$course_id;
		$result=$conn->query($sql);
		if($result->num_rows>0){
			echo '<ul style="margin-left:40px;">';
		    while ($row=$result->fetch_assoc()) {
		     echo $cc_eligibility_qual="<li>".$row["cc_eligibility_qual"].":";
		     echo $cc_eligibility_qual_criteria=$row["cc_eligibility_qual_criteria"]."</li>";
		    }
		    echo "</ul>";
		  }
		else{
		  $cc_eligibility_qual=$cs;
		  $cc_eligibility_qual_criteria="";
		}
        ?>
        </span>
         <br><br>
      </div>
    </section>
   
    <section id="admission" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="background: white;  margin-bottom:30px; mmargin: 20px;" >
         <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Admission</b></h3>
        </div>
        <br>
        <div class="liS" style="margin-left: 20px;">
        <?php
        $sql="SELECT cc_adm_step_desc  from suc_college_course_admission where college_course_id=".$course_id;
		$result=$conn->query($sql);
		if($result->num_rows>0){
		    while ($row=$result->fetch_assoc()) {
		      echo $cc_adm_step_desc=$row["cc_adm_step_desc"];
		      
		    }
		  }
		else{
		  $cc_adm_step_desc=$cs;
		  
		}
        ?>
        </div>
        <br><br>
      </div>
    </section>
    
    <section id="fee" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="background:white; margin-bottom: 30px!important; mmargin: 20px;">
         <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Fees</b></h3>
        </div>
        <br>
        <h4>Total Fee</h4>
        <h4><b><? echo $cc_fee_currency." ".$cc_total_fee ?></b></h4>
        <h5 class=" liS" style="margin-left: 20px;" sstyle="font-size: 16px; color: #4d4d4d!important;"><p><?php echo $cc_fee_notes; ?></p></h5>
        <br>
        <h4>Fee Structure(in INR)</h4>
        
        <div class="col-md-1 col-sm-12 col-xs-12 liX" style="width: 18%; font-size: 17!important;">
          <ul>
        <?php
        $sql="SELECT cc_fee_slab_desc , cc_fee_slab_amount from suc_college_course_fee_structure where college_course_id=".$course_id." order by cc_fee_slab_desc";
        $result=$conn->query($sql);
            while ($row=$result->fetch_assoc()) {
              $cc_fee_slab_desc=$row["cc_fee_slab_desc"];
              $cc_fee_slab_amount=$row["cc_fee_slab_amount"];
              if($cc_fee_slab_amount>0){
              	//echo '<li>'.$cc_fee_slab_desc.' : '.$cc_fee_slab_amount.'</li>';
              echo '<li>
              <div class="text-left" style="float: left;">'.$cc_fee_slab_desc .'</div>
              <div class="text-right"> '.$cc_fee_slab_amount.'</div>
            </li>';
              
            }
            else{
              //echo '<li ><div class="text-left" style="float: left;">--</div><div class="text-right"> --</div></li>';
              $cc_fee_slab_desc="";
              $cc_fee_slab_amount="";
              echo '<h4>'.$cs.'</h4>';
}
            }  
        ?>
      </ul>
    </div>
        <br><br>

      </div>
    </section>

    <section id="structure" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="margin-bottom: 30px; background: white; mmargin: 20px;">
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Structure</b></h3>
        </div>
        <br><br>
         <?php
         $sql="SELECT cc_semester_seq,cc_semester_subject from suc_college_course_structure where college_course_id=".$course_id;
         $result=$conn->query($sql);
         if($result->num_rows>0){
          while ($row=$result->fetch_assoc()) {
             $cc_semester_seq=$row["cc_semester_seq"];
            $cc_semester_subject=$row["cc_semester_subject"];
            if($cc_semester_seq!="")
            {
              echo '<h4><strong>'.$cc_semester_seq.'</strong></h4>';
              echo '<h4 style="font-size:16px;">'.$cc_semester_subject.'</h4>';
            }
            else
            {

              echo '<h4>'.$cs.'</h4>';
             // echo '<h5>'.$cs.'<h5>';
            }
          }}
          else
          {
            echo '<h4>'.$cs.'</h4>';
              //echo '<h5>'.$cs.'<h5>';
          }
         ?>
         <br><br>
      
        
      </div>

    </section>
    <section id="seatI" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="mmargin-top: 50px; background:white; margin-bottom: 30px; mmargin: 20px;" >
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Seat Info</b></h3>
        </div>
        
        <?php
        if($college_course_seats=="" || $college_course_seats=="0"){
        	echo '<br>';
   		 echo '<h4>'.$cs.'</h4>';
   		 echo '<br><br>';
        }
   		else
   		{
   			echo '<div class="col-md-2" style="width: 20%; height: 100px; border: 1px solid lightgray; margin: 20px;">
           <p style="position: absolute; top: 30%; left: 40%; font-size: 18px;"><b>'.$college_course_seats.'</b> </p>
           <p style="position: absolute; top: 50%; left: 30%; font-size: 16px;"> Total Seats</p>
         </div>';
   		}
        ?><!-- 
         <div class="col-md-2" style="width: 20%; height: 100px; border: 1px solid lightgray; margin: 20px;">
           <p style="position: absolute; top: 40%; left: 40%; font-size: 18px;"><b><?php //echo $college_course_seats; ?></b> </p>
           <p style="position: absolute; top: 60%; left: 30%; font-size: 16px;"> Total Seats</p>
         </div> -->
         
     
      </div>
    </section>
  <?php if($top_recruiters!=""){ ?>
    <section id="place" style="padding-top: 120px;">
      <div class="content col-md-12 img-thumbnail col-sm-12 col-xs-12" style="mmargin-top: 50px; background:white; margin-bottom: 30px; mmargin: 20px;" >
        <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 class="heading" ><b>Placement</b></h3>
        </div>
        <br>
       <!--  <p style="font-size: 15px; color:gray;">Placement in INR</p> -->
        
        
          <?
          if($highest_placement!="" || $average_placement!="" || $lowest_placement!="" )
          { 
          echo '<div>';
          if($lowest_placement!=""){
           echo '<div class="col-md-4 col-xs-12 col-sm-12 text-center" >
            <h4 style="font-size:22px;"><b>'. $lowest_placement.'</h4>
            <span class="s_title"> Lowest Salary(Annual) </b> </span>
          </div>';
        }
          if($average_placement!="")
          {
           echo '<div class="col-md-4 col-xs-12 col-sm-12 text-center">
           <h4 style="font-size:22px;"><b>'.$average_placement.'</h4>
           <span class="s_title"> Average Salary(Annual) </b></span>
           </div> ';
         }
         if($highest_placement!="")
         {
           echo '<div class="col-md-4 col-xs-12 col-sm-12 text-center">
           <h4 style="font-size:22px;"><b>'.$highest_placement.'</h4>
           <span class="s_title"> Highest Salary(Annual) </b></span>
          </div>';
        }
        echo '</div> <br>
         <br><br><br><br>';
      }
        
        
        if($top_recruiters!="")
        {
         echo '<div style="padding-bottom:60px;">
         <span class="s_title col-xs-12 col-sm-12 col-md-12"><b>Top Recruiters who visited the campus </b></span>
         <h4 class="col-xs-12 col-sm-12 col-md-12" style="font-size: 20px;">'.ucwords($top_recruiters).'</h4>
         </div>';
       }
         ?>
         <br><br>
     
      </div>
    </section>
<?php } ?>
   <!--  <section id="contact" style="padding-top: 120px;">
      <div class="col-md-12 img-thumbnail" style="background: white; mmargin: 20px; margin-bottom: 150px;">
     <div style="border-bottom:1px solid lightgray; width: 100%;" >
        <h3 ><b>Contact</b></h3>
        </div>
        <br><br>
         <?php // echo $cc_eligibility_qual.":".$cc_eligibility_qual_criteria;?>
         <br><br>
      </div>
    </section> -->
  </div>
  <div class="col-md-12" style="margin-bottom:120px;"></div>
  </div>
  <!-- Google CDN jQuery -->
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  
  <!-- Page Scroll to id plugin -->
  <script src="jquery.malihu.PageScroll2id.js"></script>
  
  <script>
    (function($){
      $(window).on("load",function(){
        
        /* Page Scroll to id fn call */
        $("#navigation-menu a,a[href='#top'],a[rel='m_PageScroll2id']").mPageScroll2id({
          highlightSelector:"#navigation-menu a"
        });
        
        /* demo functions */
        $("a[rel='next']").click(function(e){
          e.preventDefault();
          var to=$(this).parent().parent("section").next().attr("id");
          $.mPageScroll2id("scrollTo",to);
        });
        
      });
    })(jQuery);
  </script>
  <br><br><br><br><br><br><br>
  <div><?php include("../footer.php");?>

</div></div>
</body>

</html>