<?php include('../connection/dbconnect.php');
include '../connection/header1.php';
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href ="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->


<style>

 body 
   {
    position: relative; 
  }
  .affix 
  {
    top:0;
    width: 100%;
    z-index: 9999 !important;
  }
  .navbar 
  {
    margin-bottom: 0px;

  }

  .affix ~ .container-fluid 
  {
   possition: relative;
   top: 50px;
  }




div.scrollmenu {
  background-color:;
  overflow: auto;
  white-space: nowrap;

}

div.scrollmenu a {
  display: inline-block;
  color: blue;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}


      /* Scroll design*/
.scrollmenu::-webkit-scrollbar {
    width: 10px;
}
 
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
    border-radius: 10px;
}
 
::-webkit-scrollbar-thumb {
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.4); 
}

 /* End Scroll design*/


 #Highlights{padding-top:50px;}
  #courses    {padding-top:30px;}
  #reviews  {padding-top:0px;}
  #Facilites  {padding-top:0px;}
  #gallery{ padding-top:0px; }
  #important_document {padding-top:0px;}
  #Contact    {padding-top:0px;}

  @media only screen and (max-width: 600px)
  {
    #Highlights{padding-top:0px;}
  }
 
</style>
</head>
<body class="navbar navbar-default" data-spy="scroll" data-target=".navbar" data-offset="50">
<form method="POST" action="index.php">

<div class="container-content">
 <div id="Highlights" class="container-fluid">
      <div class="col-md-12 col-sm-12 col-xs-12 thumbnail"   style="height:auto;">

     

        <?php 
          if(isset($_GET['college_id']))
          {
            $college_id=$_GET['college_id'];
          }
          else
           {
           $college_id='44';
           }   
            
          $sql="select * from suc_college where college_id='$college_id'";
          $result=$conn->query($sql);
          while($row=$result->fetch_assoc())
              {  
            $college_name=$row["college_name"];
            $college_image_path=$row["college_image_path"];
            $college_location_id=$row['college_location_id'];
           $college_id=$row['college_id'];

            $college_establishment_dt = date("Y", strtotime($row['college_establishment_dt']));
             $college_aicte_approved=''; 
             $college_type=$row['college_type']; 
             $uni_id=$row['uni_id'];
              }
      
            echo'<div class="col-md-2 col-sm-12 col-xs-12"><img src="https://www.searchurcollege.com/exam/admin/search/gallery/college/'.$college_image_path.'" style="width:180px; height:140px;margin-left:0px; border-radius:5px;" class="img-thumbnail"></div>';
              echo "<h3 style='font-weight:bold;'>".$college_name."</h3>";



           $college_location="select * from location where id='$college_location_id'";
            $result=$conn->query($college_location);
            while($row=$result->fetch_assoc())
            {
                 $location_name=$row['location_name'];
                 echo '<i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;'.$location_name.'&nbsp;|&nbsp;Established &nbsp;';
                 echo $college_establishment_dt;
            }


              if($college_type==1)
              {
                echo "&nbsp;|&nbsp;Govt<br><br>";
              }

              else if($college_type==2)
              {
                echo "&nbsp;|&nbsp;Private<br><br>";
              } 


               $university_name="select * from suc_university where uni_id='$uni_id'";
               $result=$conn->query($university_name);
               while($row=$result->fetch_assoc())
               {
                $uni_name=$row['uni_name'];
                $uni_id=$row['uni_id'];
                echo "<div class='col-md-3 col-sm-12 col-xs-12' style='font-size:14px;'>Affiliated to:<a href='#' style='font-size:16px;'>".$uni_name."</a>
                </div>";
               


               if($college_aicte_approved==1)
               {
                echo "<div class='col-md-3 col-sm-12 col-xs-12' style='font-size:16px;'>AICTE Approval</div>";
               }
            } 
       ?>

       <div class="col-md-4" style="float:right;">
        <button class="btn btn-default">Add to Compare</button>&nbsp;&nbsp;
        <button class="btn btn-warning">Download Brochure</button></div>
</div>
</div>

	<nav class="navbar navbar-default" data-spy="affix" data-offset-top="240">
	<div class="container-fluid">
		<div class="scrollmenu">
        <span style="background-color:white;"><a href="#courses"  style="color:#008489;">Courses</a></span>
        <span style="background-color:white;"><a href="#reviews"  style="color:#008489;">Reviews</a></span>
        <span style="background-color:white;"><a href="#Facilites"  style="color:#008489;">Facilites</a></span>
        <span style="background-color:white;"><a href="#gallery"  style="color:#008489;" >Gallery</a></span>
        <span style="background-color:white;"><a href="#important_document "  style="color:#008489;">Important_doc</a></span>
        <span style="background-color:white;"><a href="#Contact"  style="color:#008489;">Contact</a></span>
</div>
</div>
</nav>





 <div class="container-content">
    <div id="courses" class="container-fluid">
      <div class=" col-md-12 col-md-sm-12 col-xs-12 thumbnail" style="height:auto;">
    <h3>Courses</h3>
    <hr>
    <div class="college-block lt-col">
    <?php 
           $master_course_id="";
         $sql1="SELECT master_course_id from suc_college_courses  where college_id=$college_id group by master_course_id";
            $result1=$conn->query($sql1);
          while($row1=$result1->fetch_assoc())
           {
          $master_course_id.=$row1["master_course_id"].", ";
            }
           $master_course_id=rtrim($master_course_id,", ");
        
           echo'<div class="col-md-12" style="margin-top:10px;margin-bottom:20px;">';
          echo '<div class="col-md-3" style="width:11%;"><i class="align-center">Search By Course</i></div>
            <div class="col-md-10">';
                 
          
          $sql2="SELECT a.course_cat_id, a.course_cat_name from suc_master_course_category a , suc_master_course b where a.course_cat_id=b.course_cat_id and course_id IN ($master_course_id)group by course_cat_id";
           $result1=$conn->query($sql2);
           while($row1=$result1->fetch_assoc())
          {
          $course_cat_id=$row1["course_cat_id"];
          $course_cat_name=$row1["course_cat_name"];
          echo '<button class="btn btn-dange" style="background:white; margin-bottom:10px; margin-right:15px; border:1px solid lightgrey">'.$course_cat_name.'</button>';  
            }
           echo '</div></div>';
          echo '<div class="col-md-12" style="margin-top:10px;  margin-bottom:20px;"> ';
          echo '<div class="col-md-3" style="width:11%;"><i class="align-center">Search By Stream</i></div>
           <div class="col-md-10">';
           
           $sql3="SELECT a.course_stream_id, a.course_stream_name from suc_master_course_stream a , suc_master_course b where a.course_stream_id=b.course_stream_id and  course_id IN ($master_course_id)group by course_stream_id";
           $result=$conn->query($sql3);
           while($row=$result->fetch_assoc())
           {
          $course_stream_id=$row["course_stream_id"];
          $course_stream_name=$row["course_stream_name"];
          echo '<button class="btn btn-dange" style="background:white; margin-bottom:10px; margin-right:15px; border:1px solid lightgrey">'.$course_stream_name.'</button>';  
            }
        echo '</div></div>';
         ?>

<br>
  </div>
      <hr>     
           <?php
                $sql2="select * from suc_college_courses where college_id='$college_id'";
                $result=$conn->query($sql2);
                while($row=$result->fetch_assoc())
               {   

                 $college_course_id=$row['college_course_id'];
                 $college_course_full_part=$row['college_course_full_part'];
                 $college_course_duration=$row['college_course_duration'];
                 $college_course_name=$row['college_course_name']; 
                 
                 echo '<a href="#" style="color:;"><div class="col-md-4 col-sm-12 col-xs-12">';
                 echo  '<div class="thumbnail" style="height:100px;">';
                 echo '<h4>'.$college_course_name.'</h4>'; 
                 echo        $college_course_full_part.'&nbsp;|&nbsp;';
                 echo        $college_course_duration.'</div></div></a>';
                 }  
                                     
 ?>
  </div>
</div>




 <div id="reviews" class="container-fluid">
   <div class="thumbnail" style="height:auto;">
  <h3>Reviews</h3>
  <hr>
 <?php

 ?>
</div>
</div>


 <div id="Facilites" class="container-fluid">
   <div class=" col-md-12 col-sm-12 col-xs-12 thumbnail" style="height:auto;">
  <h3>Facilites</h3>
  <hr>
 <?php      
          $facility="select facility_image_path  from suc_college_facilities where college_id='$college_id'";
           $result=$conn->query($facility);
           while($row=$result->fetch_assoc())
            {

        $facility_image_path=$row['facility_image_path'];
         echo'<div class="col-md-1 col-sm-2 col-xs-2 text-center"><img src="https://www.searchurcollege.com/exam/admin/search/gallery/college/facility/'.$facility_image_path.'" style="width:60px; height:50px;margin-left:0px; border-radius:5px;" class="img-thumbnail">
         </div>';
       }  
     ?>
</div>
</div>


<div id="events" class="container-fluid">
   <div class="col-md-12 col-sm-12 col-xs-12 thumbnail" style="height:auto;">
  <h3>Events</h3>
  <hr>
 <?php
$events="select college_event_name,college_event_gallery_id  from suc_college_events where college_id='$college_id'";
           $result=$conn->query($events);
           while($row=$result->fetch_assoc())
           {
          $college_event_gallery_id=$row['college_event_gallery_id'];
          $college_event_name=$row['college_event_name'];

          $sql2="select college_gallery_content_path  from suc_college_gallery where college_gallery_id='$college_event_gallery_id'";
           $result=$conn->query($sql2);
           while($row=$result->fetch_assoc())
           {
          $college_gallery_content_path=$row['college_gallery_content_path'];
            echo'<div class="col-md-3 col-sm-12 col-xs-12 thumbnail"><img src="../SHIKSHA/gallery/'.$college_gallery_content_path.'" style="width:300px; height:160px;margin-left:0px; border-radius:5px;">'.$college_event_name.'</div>'; 
        }
      }
 ?>
</div>
</div>


<div id="fauclty" class="container-fluid">
   <div class="col-md-12 col-sm-12 col-xs-12 thumbnail" style="height:auto;">
  <h3>Faculty</h3>
  <hr>
<?php
$faculty="select * from suc_college_faculty where college_id='$college_id'";
           $result=$conn->query($faculty);
           while($row=$result->fetch_assoc())
           {
          $college_faculty_strength=$row['college_faculty_strength'];
          $college_faculty_phd=$row['college_faculty_phd'];
          $college_faculty_full_time=$row['college_faculty_full_time'];
          $college_faculty_visiting=$row['college_faculty_visiting'];
          $college_faculty_profile=$row['college_faculty_profile'];

          echo '<div class="col-md-2 col-sm-12 col-xs-12 text-center"> <p style="color:gray; font-size:14px;">College Faculty Profile</p><br><img src="#" style="height:90px; width:80px; background:orange; border-radius:5px;">'.$college_faculty_profile.'</div>';

          echo '<div class="col-md-2 col-sm-12 col-xs-12 text-center"> <p style="color:gray; font-size:14px;">College Faculty Strngth<br></p>'.$college_faculty_strength.'</div>';

          echo '<div class="col-md-2 col-sm-12 col-xs-12 text-center"> <p style="color:gray; font-size:14px;">College Faculty PHD<br></p>'.$college_faculty_phd.'</div>';

          echo '<div class="col-md-2 col-sm-12 col-xs-12 text-center"> <p style="color:gray; font-size:14px;">College Faculty Full Time<br></p>'.$college_faculty_full_time.'</div>';

          echo '<div class="col-md-2 col-sm-12 col-xs-12 text-center"> <p style="color:gray; font-size:14px;">College Faculty Strngth<br></p>'.$college_faculty_visiting.'</div>';
          
     }
 ?>
</div>
</div>



<div id="college_other_details" class="container-fluid">
   <div class="thumbnail" style="height:auto;">
  <h3>College Other Details</h3>
  <hr>
 <?php
 ?>
</div>
</div>


<div id="rating" class="container-fluid">
   <div class="thumbnail" style="height:auto;">
  <h3>Rating</h3>
  <hr>
 <?php
 ?>
</div>
</div>

<div id="scholarship" class="container-fluid">
   <div class="col-md-12 col-sm-12 col-xs-12 thumbnail" style="height:auto;">
  <h3>Scholarship</h3>
  <hr>
 <?php
 $scholarship="select * from suc_college_scholarship where college_id='$college_id'";
           $result=$conn->query($scholarship);
           while($row=$result->fetch_assoc())
           {
          $college_scholarship_desc=$row['college_scholarship_desc'];
          echo '<div class="col-md-12 col-sm-12 col-xs-12"> <p style="color:gray; font-size:15px;">College Scholarship Description<br></p>'.'<p style="text-align:justify;">'.$college_scholarship_desc.'</p></div>';
        }
 ?>
</div>
</div>


<div id="countries" class="container-fluid">
   <div class="thumbnail" style="height:auto;">
  <h3>Countries</h3>
  <hr>
 <?php
 ?>
</div>
</div>
 <div id="gallery" class="container-fluid">
   <div class="thumbnail col-md-12 col-sm-12 col-xs-12">
       <h3>Gallery</h3>
 
      <?php       
              $sql2="select college_gallery_content_path,college_gallery_content_desc from suc_college_gallery where college_id='$college_id'";
              $result=$conn->query($sql2);
              while($row=$result->fetch_assoc())
               { 
               $college_gallery_content_path=$row['college_gallery_content_path'];
               $college_gallery_content_desc=$row['college_gallery_content_desc'];
                echo '<div class="center">';
              echo'<div class="col-md-3 col-sm-12 col-xs-12 thumbnail"><img src="../SHIKSHA/gallery/'.$college_gallery_content_path.'" style="width:100%; height:180px; margin-left:0px; border-radius:5px;" class="img-thumbnail center">'.$college_gallery_content_desc.'</div>';
              echo '</div>';
             }
      ?> 

    
</div>
</div>
 <div id="important_document" class="container-fluid">
   <div class="col-md-12 col-sm-12 col-xs-12 thumbnail" style="height:auto;">
  <h3>Important Documents</h3>
    <?php       
            $college_doc="";
            $college_doc_name="";

             $sql2="select * from suc_college_documents  where college_id='$college_id'";
              $result=$conn->query($sql2);
              while($row=$result->fetch_assoc())
               { 
                  $college_doc=$row['college_doc'];
                  $college_doc_name=$row['college_doc_name'];
                }   
                 
               echo'<div class="col-md-4 col-sm-12 col-xs-12"><p style="color:gray; font-size: 18px;">College Doc Name<p>'.$college_doc_name.'</div>';

               echo'<div class="col-md-3 col-sm-12 col-xs-12"><p style="color:gray; font-size: 18px;">PDF file</p>'.
                '<a href="'.$college_doc.'" Download><img src="../SHIKSHA/pdf_icon.png" style="width:60px; height:40px; float:left;"></a></div>'; 
                          
      ?>
</div>
</div>





 <div id="Contact" class="container-fluid">
   <div class="col-md-12 col-sm-12 col-xs-12 thumbnail" style="height:auto;">
  <h3>Contact</h3>


         <?php          
          $sql2="select * from suc_college_contacts  where college_id='$college_id'";
              $result=$conn->query($sql2);
              while($row=$result->fetch_assoc())
               { 
               $college_address=$row['college_address'];
               $college_email=$row['college_email'];

              echo'<div class="col-md-3 col-sm-12 col-xs-12"><p style="color:gray; font-size: 18px;">Collage Address<p>'.$college_address.'</div>';
               echo'<div class="col-md-3 col-sm-12 col-xs-12"><p style="color:gray; font-size: 18px;">Email Address<p>'.$college_email.'</div>';

             }
           
      ?> 
</div>
</div>
</div>
</div>
<script type="text/javascript">
    $("a[href^='#']").click(function(e) {
  e.preventDefault();
  
  var position = $($(this).attr("href")).offset().top;

  $("body, html").animate({
    scrollTop: position
  }/* speed */ );
});
</script>
</form>
<? include '../footer.php'; ?>
</body>
</html>

