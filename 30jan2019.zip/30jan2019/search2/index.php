<?
include('../connection/dbconnect.php');
$s=$loc=$c_id_A="";
if(isset($_REQUEST["country1"]) && ($_REQUEST["country1"])!="")
{
   $cs=$_REQUEST["country1"];
 $query="select search_tag_type , search_tag_value from suc_search_tag where search_tag_value = '$cs'";

$result=$conn->query($query);
while($row=$result->fetch_assoc())
{
   $tag_type=$row["search_tag_type"];
   $tag_value=$row["search_tag_value"];
}

include('historySave.php');
 if($tag_type!='')
{
 $query="select college_id , college_name from suc_college where college_name like '%".$tag_value."%'";

$result=$conn->query($query);
if($result->num_rows==1){
while($row=$result->fetch_assoc())
{
 $col_name=$row["college_name"];
$col_id=$row["college_id"];
}
 echo '<script>window.location.replace("college_info.php?resultColName='.$col_name.'&resultCol='.$col_id.'");</script>';
}

 $query="select uni_id , uni_name from suc_university where uni_name = '".$cs."'";

$result=$conn->query($query);
if($result->num_rows==1){
while($row=$result->fetch_assoc())
{
 $col_name=$row["uni_name"];
$col_id=$row["uni_id"];
}
 echo '<script>window.location.replace("uni_info.php?uni_name='.$col_name.'&uni_id='.$col_id.'");</script>';
}

}
 // echo "S";
  
}
?>
<head>
    <title>SearchurCollege - Results</title>  
    <META NAME="Description" CONTENT="Colleges and their Courses at SearchUrCollege.com"/>
    <META NAME="Keywords" CONTENT="Searchurcollege.com, Colleges, Colleges in India, MBA, Enginerring, Law, Medical, Courses, Reviews, Fee, Facility, Placement"/>
<link rel="stylesheet" type="text/css" href="https:////cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"/>

</head>
<style>
    .lbl:hover
    {
        color: #00b3b3;
    }

    .img1
  {
  	max-height: 130px;
  	max-width: 160px;
  	min-height:130px;
  	min-width: 160px;
  	
  	border: 2px solid #d9d9d9;
  	
  }
    
    .scrollbar
    {
      mmargin-left: 30px;
      float: le0t;
      height: 400px;
      width: 100%;
      background: #F5F5F5;
      overflow-y: scroll;
      margin-bottom: 25px;
    }
    .style-4::-webkit-scrollbar-track
    {
      -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
      background-color: #F5F5F5;
    }
    .style-4::-webkit-scrollbar
    {
      width: 10px;
      background-color: #F5F5F5;
    }
    .style-4::-webkit-scrollbar-thumb
    {
      background-color: #000000;
      border: 2px solid #555555;
    }
    @media only screen and (max-width: 600px) {
  #filter
  {
    width: 100%!important;
    margin-bottom: 20px;
    display: none!important;
  }
  #post-data
  {
    width: 100%!important;
  }
  .wwell
  {
    height: 60%!important;
  }
  .mmedia
  {
    ewidth: 100%!important;
    padding: 0px;

    
  }
  .mmedia-h
  {
  	margin-left: 0px;
  }
  .img1
  {
  	max-height: 55px!important;
  	max-width: 65px!important;
  	min-height:55px!important;
  	min-width: 65px!important;
  	margin-left: 0px;
  	margin-top: 10px;
  	border: 0px!important;
  }
  .bsubmit
  {
    ttext-align: center!important;
    font-size: 14px!important;
    margin-top: -10px!important;
  }
  .bsubmit-a
  {
    ttext-align: center!important;
    font-size: 12px!important;
    margin-top: -5px!important;
  }
  .bsubmit-h
  {
  	display: none;
  }
  .well
  {
  	border: 0px!important;
  	padding: 0px!important;
  }
  #search_panel
  {
    width:100%!important;
  }
  #title
  {
  	font-size: 14px!important;
  }
  .facility
  {
  	display: none;
  }
  #post-data
  {
  	padding: 0px!important;
  }
}
</style>
<?php
    
    $useragent=$_SERVER['HTTP_USER_AGENT'];
    if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
        include('../connection/header3.php');
    else
        include('../connection/header1.php');

    $title_name="";
 ?>
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
        a:active, a:focus {
          outline: 0;
          border: none;
          -moz-outline-style: none;
        }
        .locFil
        {
          height: 200px;
          overflow: auto;
        }
    </style>
    <!-- <sscript src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->
<div class="col-md-12" style="background: #fafafa; bbackground: url('https://www.searchurcollege.com/connection/images/books.jpg'); background-attachment: fixed; bbackground:#F4F4F4; padding-right: 0px; padding: 0px;">
  <div class="col-xs-12 col-sm-12 col-md-2" sstyle="width: 100%"></div>
  <div class="col-md-2 pull-right" sstyle="background: red ;height:120px;"></div>
<div id="search_panel" class="col-md-8 pull-right" style="margin-top: 10px; width: 60%;">
  

<!-- <h4 style="margin-left: 20px;">Search results for </h4> -->
<!-- <h4 style="margin-left: 20px;">Search results for Top Colleges in India </h4> -->

  <?php include("search_panel.php");?>
</div>
<?

?>
<?php
if(isset($_REQUEST["country1"]) && ($_REQUEST["country1"])!="")
{
   $title_name="Search results for <span style='color:#0F5C88;'><b>'".$_REQUEST["country1"]."'</b></span>";
}
elseif(isset($_REQUEST["cloud"]))
{
   $title=$_REQUEST['cloud'];
   $title=str_replace('-', ' ', $title);
   $title=str_replace('~', '-', $title);
   $title=str_replace('__', "'", $title);
   $title_name="<b style='color:#0F5C88;'>'".$title."'</b>";
}
elseif(isset($_REQUEST["location_id"]))
{
include('historySave.php');
 $loc=$_REQUEST["location_id"];
 if($loc>=5000)
 {
  $loc=$loc-5000;
  $sqL='SELECT state from location where id='.$loc;
  $resulT=$conn->query($sqL);
  while($roW=$resulT->fetch_assoc())
   $state=$roW['state'];
 $title_name="Search results for <span style='color:#0F5C88;'><b>' Top Colleges in ".$state."'</b></span>";
 }
 else
 {
$sqL='SELECT location_name from location where id='.$loc;
$resulT=$conn->query($sqL);
while($roW=$resulT->fetch_assoc())
  $city_name=$roW['location_name'];
$title_name="Search results for <span style='color:#0F5C88;'><b>' Top Colleges in ".$city_name."'</b></span>";
 }
  


}
else{
  $title_name="Search results for <span style='color:#0F5C88;'><b>' Top Colleges in India'</b></span>";
}

if(isset($_REQUEST['title']))
    $title_name="Search results for <span style='color:#0F5C88;'><b>'".$_REQUEST['title']."'";
?>
<div  class="col-md-12 col-sm-12 col-xs-12 " style="wwidth: 20%; margin-bottom: 10px;"><h3 id="title" style="color: black;"><?php echo $title_name; ?></h3></div>

<div class="ccol-md-9 col-sm-12 col-xs-12" style="width: 80%;"></div>
    
</div>

<div class="col-md-12" style="width: 100% ;background:#fafafa">

<div id="filter" class="filter col-sm-12 col-xs-12 col-md-2" style="background: white; width: 20%; wwidth: 20%; border: 1px solid lightgray; padding:0px;">
  
  <h5 style="background: #e6f9ff; font-size: 18px; border-bottom: 1px solid lightgray; padding: 15px; margin-top: 0px; width: auto; wwidth: 276px;"><b>Refine Results</b></h5>

  <!-- <div>
    <h5 style="padding:10px;"><b>State</b></h5>
    <center>
    <input id="stateInput" type="text" placeholder="Search State" style="padding: 8px;  width: 90%;"></center>
    <div  class="style-4 locFil" style="overflow-x: hidden; margin-top: 10px;"> 
  
<br>
    <?php
  // $filterLoc="SELECT state,id from location group by state";
  // $resultLoc=$conn->query($filterLoc);
  // while($rowLoc=$resultLoc->fetch_assoc())
  //   {
  //     echo '<div class="checkbox " style="margin-left: 10px;">
  //     <p><label class="lbl ">
  //     <input  type="checkbox" class="common_selector state" value="'.$rowLoc["id"].'">'.$rowLoc["state"].'</label>
  //     </p></div>';
  //   }
  ?>

  </div>
  </div>
<hr> -->
    <div>
    <h5 style="padding:10px;"><b>City</b></h5>
    <center>
    <input id="myInput" type="text" placeholder="Search Ciy" style="padding: 8px;  width: 90%;"></center>
    <div  id="locFil"class="style-4 locFil" style="overflow-x: hidden; margin-top: 14px; margin-right: 15px;"> 
  <!--FIlter Location -->
<br>
    <?php
  $filterLoc="SELECT location_name,id from location";
  $resultLoc=$conn->query($filterLoc);
  while($rowLoc=$resultLoc->fetch_assoc())
    {
      echo '<div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl ">
      <input  type="checkbox" class="common_selector brand" value="'.$rowLoc["id"].'">'.$rowLoc["location_name"].'</label>
      </p></div>';
    }
  ?>

  </div>
  </div>
  <hr>
  <div>
    <h5 style="padding:10px;"><b>State</b></h5>
    <center>
    <input id="myInput2" type="text" placeholder="Search State" style="padding: 8px;  width: 90%;"></center>
    <div  id="locFil2"class="style-4 locFil" style="overflow-x: hidden; margin-top: 14px; margin-right: 15px;"> 
  <!--FIlter Location -->
<br>
    <?php
  $filterLoc="SELECT state from location group by state";
  $resultLoc=$conn->query($filterLoc);
  while($rowLoc=$resultLoc->fetch_assoc())
    {
      echo '<div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl ">
      <input  type="checkbox" class="common_selector state" value="'.$rowLoc["state"].'">'.$rowLoc["state"].'</label>
      </p></div>';
    }
  ?>

  </div>
  </div>
  <hr>
  <div>
    <h5 style="padding:10px;"><b>Course</b></h5>
    <center>
    <input id="myInput3" type="text" placeholder="Search Course" style="padding: 8px;  width: 90%;"></center>
    <div  id="locFil3"class="style-4 locFil" style="overflow-x: hidden; margin-top: 14px; margin-right: 15px;"> 
  <!--FIlter Location -->
<br>
    <?php
  $filterLoc="SELECT course_cat_id, course_cat_name from suc_master_course_category";
  $resultLoc=$conn->query($filterLoc);
  while($rowLoc=$resultLoc->fetch_assoc())
    {
      echo '<div class="checkbox " style="margin-left: 10px;">
      <p><label class="lbl ">
      <input  type="checkbox" class="common_selector course" value="'.$rowLoc["course_cat_id"].'">'.$rowLoc["course_cat_name"].'</label>
      </p></div>';
    }
  ?>

  </div>
  </div>
      <hr>
        <div class="list-group">
     <h5 style="padding:10px; "><b>Fees</b></h5>
     <div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="0.0, 100000.00"> Less than Rs 1 Lakh </label>
      </p></div>
      <div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="100000, 200000"> Rs 1-2 Lacs </label>
      </p></div>
      <div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" value="200000, 300000" name="fee"> Rs 2-3 Lacs </label>
      </p></div><div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" value="300000, 400000" name="fee"> Rs 3-4 Lacs </label>
      </p></div><div class="checkbox " style="mmargin-left: 10px;">
      <p><label class="lbl ">
      <input  type="radio" class="common_selector fee" name="fee" value="400000, 500000"> Rs 5 Lacs and above </label>
      </p></div>      

     <!-- <input type="hidden" id="hidden_minimum_price" value="0" />
                    <input type="hidden" id="hidden_maximum_price" value="65000" />
                    <p id="price_show">1000 - 65000</p>
                    <div id="price_range"></div> -->
                </div>  


    
</div>
<div id="post-data" class="col-sm-12 col-xs-12  filter_data" style=" hheight: auto; width: 80%; padding-right: 0px; ppadding: 0px;">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.1.0/css/font-awesome.min.css"/>
<?php
if(isset($_REQUEST["location_id"]))
{
 $loc=$_REQUEST["location_id"];
 if($loc>=5000)
 {
  $loc=$loc-5000;
    $sqL='SELECT state from location where id='.$loc;
 $resulT=$conn->query($sqL);
  while($roW=$resulT->fetch_assoc())
     $state=$roW['state'];
   $sqL1="SELECT id from location where state='".$state."'";
  $resulT1=$conn->query($sqL1);
   while($roW1=$resulT1->fetch_assoc()){
       $loc1.="'".$roW1['id']."', ";
   }
    
    $loc1=rtrim($loc1,", ");
 }
 else
 {
  $loc1=$loc;
 }
  


}
$sql="SELECT  DISTINCT(college_id) ,uni_name,college_name , college_image_path , college_desc, college_location_id ,location_name,state,college_type ,college_establishment_dt ,college_approval_flag1 FROM    suc_search_results";
if(isset($_REQUEST["country1"]) && ($_REQUEST["country1"])!="")
{
 $s=$_REQUEST["country1"];
  $query="select search_tag_type , search_tag_value from suc_search_tag where search_tag_value = '$s'";
 $result=$conn->query($query);
  while($row=$result->fetch_assoc())
        {
          $name=$row["search_tag_type"];
           $s=$row["search_tag_value"];
        }
        $st=$s;
        $st;
        $sql.=" WHERE ";
        if($name==1)
          $sql.="course_cat_name like'%".$s."%' or course_stream_name like '%$s%'";
        else
          $sql.="college_name like '%$s%'";
        if(isset($_REQUEST["location_id"]))
          $sql.=" and college_location_id IN ( ".$loc1.")";
}
elseif(isset($_REQUEST["location_id"]))
{
   $sql.="  where college_location_id IN (".$loc1.")" ;
}

elseif(isset($_REQUEST['cloud']))
{
    $title=$_REQUEST['cloud'];
    $title=str_replace('-', ' ', $title);
    $title=str_replace('~', '-', $title);
    $title=str_replace('__', "'", $title);
    $search_college_keyword=$title;
    $sql="SELECT search_sql FROM suc_popular_searches WHERE search_college_keyword='$search_college_keyword'";
    $result=$conn->query($sql);
    while($row=$result->fetch_assoc())
        $sql=$row['search_sql'];
}
//echo $sql;
        $i=1;
        $result=$conn->query($sql);
       // echo '<table id="example1">';
        if($result->num_rows==0)
        {
          echo '<center><h2 style="color:#0F5C88">Sorry, No Colleges Found! </h2></center>';
        }
        while($row=$result->fetch_assoc())
        {
          $uni_id=$uni_name=$c_name=$c_id=$c_desc=$c_desc=$c_type=$c_location=$l_name=$l_state=$c_e_dt=$c_aicte=$c_img="";
            //$uni_id=$row['uni_id'];
            $uni_name=$row["uni_name"];
           // $d=strip_tags($des);
           $c_name=$row["college_name"];
           echo '<div class="post-id" id="'.$row['college_id'].'"></div>';
            $c_id=$row['college_id'];
            $c_id_A.=$c_id.", ";
            $c_desc=$row['college_desc'];
            $c_type=$row['college_type'];
            $c_location=$row['college_location_id'];
            $l_name=$row["location_name"];
            $l_state=$row["state"];
            $c_e_dt=$row['college_establishment_dt'];
            $c_e_dt=substr($c_e_dt, 0,4);
            if(substr($c_e_dt, 0,1)!="0")
            {
              $c_e_dt='|  &nbsp Established &nbsp'.$c_e_dt;
            }
            else
              $c_e_dt=""; 
            $c_aicte=$row['college_approval_flag1'];
            $c_img=$row['college_image_path'];
           //  $sql2="SELECT college_rating from suc_college_rating where college_id=$c_id";
           //  $result2=$conn->query($sql2);
           // while($row2=$result2->fetch_assoc())
           //    $rating=$row2["college_rating"];
          if($c_type=="1")
            $type="Government";
          else
            $type="Private";
            if($c_aicte!="")
              $aprroval='|  &nbsp '.$c_aicte.'  <i class="fa fa-info-circle" aria-hidden="true"></i>';
            else
              $aprroval="";
           
           
           ?>
           <tr>
            <td>
            <div class="well col-md-12 col-xs-12 col-sm-12 " style="background: white;height: auto; margin-bottom: 20px; padding: 10px;   border:1px solid #D3D3D3; ">
              <form class="listC" target="_blank" action="college_info.php" method="post"> 
              <!--<label style="position:absolute; right:0px; color:black;">Compare
             <input type="checkbox" name="Compare" class="largerCheckbox"  style="hheight:20px; margin-right:10px;">
             </label>-->
                  <input type="hidden" name="resultCol" value="<?php echo $c_id;?>" />
                  <input type="hidden" name="resultColName" value="<?php echo $c_name;?>" />
                  <div class="mmedia col-md-2 col-sm-2 col-xs-2 " style="bbackground: red; ">
                    <button type="submit" style="background: transparent; border: 0px;"><img class=" img1 " src="https://www.searchurcollege.com/exam/admin/search/gallery/college/<?php echo $c_img ?>" dstyle="border: 1px solid #d9d9d9;min-width: 150px; max-width:150px; max-height: 100px; min-height: 100px;" sstyle="position:absolute; top:10px; left: -5px; height:125px; width: 150px;"/></button>
                  </div>
                <div class="mmedia-h col-md-10 col-sm-10 col-xs-10" style="margin-top: 10px;  ">
                 <h4 class="memdia-heading col-sm-12 col-xs-12 col-md-12" style="font-family: system-ui; "> <button class="bsubmit" type="submit" style="background: transparent; border: 0px; margin-top: -10px; text-align: left; color:#0F5C88; mmargin-left: -15px; "><?php echo $c_name;?>
                 </button>      
                 </h4>
                 
                 
                 <h5 class="col-md-12 col-xs-12 col-sm-12 bsubmit-a" style="font-size :14px; color:#696969; font-weight: normal!important; margin-left:0px;text-transform:none; "><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp <?php echo $l_name.','.$l_state;?>
                   &nbsp| &nbsp&nbsp<i class="fa fa-university" aria-hidden="true"></i>&nbsp <?php echo $uni_name; ?>
                   
                    &nbsp
                   </h5> <h5  class="bsubmit-h" style="color:#696969; font-size:14px; font-weight: normal!important;mmargin-left:0px;text-transform:none;">Ownership :&nbsp  <?php echo $type; ?>
                  &nbsp <?php echo $c_e_dt.'&nbsp'.$aprroval.'</h5>';?> <?
                 $sqlfacilities="SELECT m.facility_name, m.facility_icon_path FROM suc_college_facilities a , suc_facilities_master m WHERE a.facility_code=m.facility_code and a.college_id=$c_id order by m.facility_name ";
                 $resultfacilities=$conn->query($sqlfacilities);
                 while($rowfacilities=$resultfacilities->fetch_assoc()){
                   $facility_name=$rowfacilities["facility_name"];
                  $facility_image_path=$rowfacilities["facility_icon_path"];
                  echo '<img class="facility" cclass="img-thumbnail" style ="width: 20px;"src="https://www.searchurcollege.com/exam/admin/search/gallery/facility_master/'.$facility_image_path.'" title="'.$facility_name.'"> &nbsp &nbsp';
                  }
                  ?>
                  
             </div>
            </form>
            
          </div>
        </td>
        </tr>
       <? $i++ ;
     }
?>
<!-- </table> -->
</div>




<?php 
if($s!="")
  echo '<input type="hidden" name="" class="college_like" value="'.$st.'">';
if($loc!="")
  echo '<input type="hidden" name="" class="location_name" value="'.$loc1.'">';
?>

<input type="hidden" name="" class="c_id" value="<? echo $c_id_A;?>">
<div style="margin-top: ">
<?php
    include('../footer.php');
?>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">

 

<script type="text/javascript" src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>

<!-- <script type="text/javascript">
    $(document).ready(function() {
        $('#example1').DataTable();
    });
</script>  
 -->
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#locFil div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
  $("#myInput2").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#locFil2 div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
  $("#myInput3").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#locFil3 div").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


</script>


<script>
$(document).ready(function(){

    //filter_data();

    function filter_data()
    {
      //alert(x);
     // alert($(".brand").val());
        // $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var brand = get_filter('brand');
        //alert(brand);
        var state = get_filter('state');
         //alert(state);
         var c_id = $('.c_id').val();
         var loc_name=$('.location_name').val();
         
         var college_like = $('.college_like').val();
         //alert(college_like)
         //alert(college_like);
        var fee=get_filter('fee');
        //alert(fee);
        var course=get_filter('course');
        //alert(course);
        var ram = get_filter('ram');
        var storage = get_filter('storage');
        $.ajax({
            url:"fetch_data_final.php",
            method:"POST",
            data:{action:action,fee:fee, brand:brand, state : state, loc_name:loc_name ,college_like:college_like, c_id:c_id, course:course,storage:storage},
            success:function(data){
                    //alert(data);
                if(data!="")
                  $('.filter_data').html(data);
                //$('#myInput').val("");
            }
        });
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            //alert($(this))
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function(){
        filter_data();
    });

    // $('#price_range').slider({
    //     range:true,
    //     min:1000,
    //     max:65000,
    //     values:[1000, 65000],
    //     step:500,
    //     stop:function(event, ui)
    //     {
    //         $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
    //         $('#hidden_minimum_price').val(ui.values[0]);
    //         $('#hidden_maximum_price').val(ui.values[1]);
    //         filter_data();
    //     }
    // });

});
</script>

<script type="text/javascript">
history.pushState(null, null, '<?php echo $_SERVER["REQUEST_URI"]; ?>');
window.addEventListener('popstate', function(event) {
    window.location.assign("https://www.searchurcollege.com/");
});
</script>
<!-- <script type="text/javascript">
  $(window).on("scroll", function() {
  var scrollHeight = $(document).height();
 // alert(scrollHeight);
  var scrollPosition = $(window).height() + $(window).scrollTop();
  //alert(scrollPosition);
  alert((scrollHeight - scrollPosition) / scrollHeight);
  if ((scrollHeight - scrollPosition) / scrollHeight === 0) {
      alert("end");
      // when scroll to bottom of the page
  }
});
</script> -->

<script type="text/javascript">
     $(document).ready(function(){
         $('input[type="checkbox"]').click(function(){
             if($(this).prop("checked") == true){
                // alert($(this).val());
             }
             else if($(this).prop("checked") == false){
               //  alert("Checkbox is unchecked.");
             }
         });
     });

</script>
