<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<?php
$master_id=$a=$uid=$user_name=$contact=$email='';
?>
<style>
    #otp
    { 
        position:fixed;
        top: 50%;
        left: 52%;
        width: 300px;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: -15em; /*set to a negative number 1/2 of your width*/
        border: 5px double #5d9bd0;
        background-color: #f3f3f3;
        padding: 30px;
    }
    ul, span { list-style-type: none;  color: black;}
    .div-mobile {
        display: none;
    }
    .div-no-mobile {
        display: block;
    }
    @media screen and (min-width: 200px) and (max-width: 999px)
    {
        .div-no-mobile
        {
            display:none
        }
        .div-mobile
        {
            display: block;
        }
        .modal-body
        {
            padding: 20px!important;
        }
        #col1
        {
            margin-top: -20px;
            padding-bottom: 0px;
        }
        #col2
        {
            margin-top: 0px;
            padding-top: 1px!important;
        }
        #regButton
        {
            margin-top: -80px;
        }
    }
    #col1, #col2
    {
        padding-top: 20px!important;
    }
    .modal-body
    {
        background: #DAEBFA;
        padding: 0px;
    }
    .input-group
    {
        margin-bottom: 10px;
        width: 100%;
    }
    input[type=text]
    {
        border: 1px solid lightgrey!important;
        color: black!important;
    }
    #msg
    {
        margin-top: -10px;
        position: relative;
    }
    #msg2
    {
        position:fixed!important;
        top: 50%;
        left: 50%;
        max-width: 200px;
        hheight:18em;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: 0%; /*set to a negative number 1/2 of your width*/
        border: 1px solid #ccc;
        background-color: #f3f3f3;
        z-index: 1000;
    }
    /**
 * th,td {text-align: center; vertical-align: middle; padding: 2px;}
 *     .first{text-align: left;}
 *     .second{background: #DAD8D8;}
 *     .third{background: #B2F068; border: 0px!important;}
 */
</style>
<style>
    * {
      box-sizing: border-box;
    }
    .fform-group {
  display: block;
  margin-bottom:0px;
}

.fform-group input {
  padding: 10;
height: 1px; width: 1px;  
  margin-bottom: 0;
  display: none;
  cursor: pointer;
}

.fform-group label {
  position: relative;
  cursor: pointer;
  font-weight:normal;
}


.fform-group label:before {
  content:'';
  -webkit-appearance: none;
  background-color: transparent;
  border: 2px solid #0079bf;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), inset 0px -15px 10px -12px rgba(0, 0, 0, 0.05);
  padding: 6px;
  display: inline-block;
  position: relative;
  vertical-align: middle;
  cursor: pointer;
  margin-right: 5px;
}

.fform-group input:checked + label:after {
  content: '';
  display: block;
  position: absolute;
  top: 3px;
  left: 5px;
  width: 5px;
  height: 10px;
  border: solid #0079bf;
  border-width: 0 2px 2px 0;
  transform: rotate(45deg);

}
    .autocomplete {
      /*the container must be positioned relative:*/
      position: relative;
      display: inline-block;
    }
    
    .autocomplete-items {
      position: absolute;
      border: 1px solid #d4d4d4;
      border-bottom: none;
      border-top: none;
      z-index: 99;
      /*position the autocomplete items to be the same width as the container:*/
      top: 100%;
      left: 0;
      right: 0;
    }
    
    .autocomplete-items div {
      padding: 10px;
      cursor: pointer;
      background-color: #fff; 
      border-bottom: 1px solid #d4d4d4; 
    }
    
    .autocomplete-items div:hover {
      /*when hovering an item:*/
      background-color: #e9e9e9; 
    }
    
    .autocomplete-active {
      /*when navigating through the items using the arrow keys:*/
      background-color: DodgerBlue !important; 
      color: #ffffff; 
    }
</style>

	<!--<link href="css/style.css" rel='stylesheet' type='text/css'/>-->
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
			<script>$(document).ready(function(c) {
			$('.alert-close').on('click', function(c){
				$('.main-agile').fadeOut('slow', function(c){
					$('.main-agile').remove();
				});
			});	  
		});
		</script>

<!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#register">Open Modal</button>-->

<div id="register" class="modal fade" role="dialog">
  <div id="d" class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-body">
            <div class="row row-eq-height">
        		<div id="col1" class="col-md-6" style=" padding: 0px 40px 20px 40px;">
                    <h3 class="div-no-mobile" style="color: #ff9934;"><b>Why Register ?</b></h3>
                    <h3 id="why_head" class="div-mobile" style="color: #5D9BD0; cursor: pointer;"><b>Why Register ? <small style="position: absolute; margin-top: 5px; right: 15px;"><i class="fa fa-plus pull-right"></i></small></b></h3> </br>
                    <span><!--<i class="pull-right fa fa-info"></i>-->
                    <span id="msg1" class="div-no-mobile"><b><h3>General Benifits</h3></b><br />
                        <lh><strong> Information About:</strong></lh>
                    <ul>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp   Exams </li>
                       
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp  Courses</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspTop Colleges & Universities</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspEligibility Criteria For Admission</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspRanking of Universities & Colleges</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspEducation Loans</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspScholarship</li>
                    </ul>
                    <lh><strong>Additionals</strong></lh>
                    <ul>
                        
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbspAsk Your Doubt</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspGet Advice From Experience Experts</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspAlumni Review</li>
                       <!-- <li>Top Colleges & Universities</li>
                        <li>Popular Courses</li>
                        <li>Eligibility & Admission</li>
                        <li>College Rankings</li>
                        <li>Previous Year Question Papers</li>
                        <li>Subject Library</li>
                        <li>Online Tests & Exam Prepration</li>
                        <li>Tests History</li>
                        <li>Progress Tracking</li>
                        <li>News & Updates</li>
                        <li>Important Dates Alerts</li>
                        <li>365 Days Support</li>
                        <li>Career Guidance</li> -->
                    </ul></span>
                </div>
                
        		<div id="col2" class="col-md-6" style="background: white; padding: 0px 40px 20px 40px;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 style="color: #ff9934; text-align: left;"><i class="fa fa-user fa-sm"></i> <b>Register</b></h3>
                    <b style="color: black;">Tell us something about youself to offer better assistance  .</b><br /><br />
                    <form id="frmRegister" action="user_register.php">
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <select id="L1" name="last_qualification" class="form-control" rrequired>
                                <option disabled selected>Last Qualification</option>
                                <?php
                                    include_once('functions.php');
                                    include_once('dbconnect.php');
                                    $result=selectCourse();
                                    while($row=$result->fetch_assoc())
                                    {
                                        $id=$row['id'];
                                        echo '<option value="'.$id.'">'.$row["course_master_name"].'</option>';
                                    }
                                ?>
                            </select>
                        </span>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <select id="course_interested" name="course_interested" class="form-control" rrequired>
                            <option disabled selected>Course Looking for</option>
                            
                            
                            </select>
                        </span>
                        <!-- <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-book"></i></span>
                            <input list="course_interested" id="L2" name="course_interested" class="form-control" placeholder="Course Looking for" rrequired />
                            <datalist id="course_interested">
                            </datalist>
                        </span> -->
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control iinput-md" id="first_name" name="first_name" placeholder="First Name" rrequired />
                          <span class="input-group-btn" style="width: 0px;"></span>
                          <input type="text" class="form-control input-md" id="last_name" name="last_name" placeholder="Last Name" rrequired />
                        </div>
                        <span class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input id="email2" type="email" class="form-control" name="email" placeholder="Email" rrequired />
                        </span>
                        <span class="input-group">
                            <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input type="password" onkeyup="repeat()" id="password1" class="form-control" data-toggle="password" name="password1" placeholder="Password" rrequired />
                            <input type="hidden" class="form-control" id="password2" name="password2" />
                            </div>
                        </span>
                        <span class="input-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="Contact No." rrequired />
                            </div>
                        </span>
                        <span class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                            <select id="cl" name="current_location" class="form-control" rrequired>
                                <option disabled selected>Current Location</option>
                                <?php
                                   include('dbconnect.php');
                                   $sql="SELECT * FROM location";
                                   $result=$conn->query($sql);
                                   while($row=$result->fetch_assoc())
                                   {
                                        $id=$row['id'];
                                        echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
                                   }
                                ?> 
                            </select>
                            <!-- <input list="current_location" id="cl" name="current_location" class="form-control" placeholder="Current Location" required /> -->
                           <!--  <datalist id="current_location">
                                
                            </datalist> -->
                            </span>
                        </span>

                        <span class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                            <select id="c2" name="preferred_location" class="form-control" rrequired>
                            <!-- <input list="preferred_location" id="c2" name="preferred_location" class="form-control" placeholder="Preferred Location" required /> -->
                            <option disabled selected>Preferred Location</option>
                                <?php
                                   $sql="SELECT * FROM location";
                                   $result=$conn->query($sql);
                                   while($row=$result->fetch_assoc())
                                   {
                                        $id=$row['id'];
                                        echo '<option value="'.$row["location_name"].'">'.$row["location_name"].'</option>';
                                   }
                                ?> 
                            </select>
                            </span>
                        </span>
                        <span class="input-group" style="margin-top: -10px;">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <select name="reference" id="r1" class="form-control">
                                <option selected disabled>Select Reference</option>
                                <option value="Facebook">Facebook</option>
                                <option value="Whatsapp">Whatsapp</option>
                                <option value="SMS">SMS</option>
                                <option value="Email">Email</option>
                                <option value="Internet">Internet</option>
                                <option value="Friend">Friend</option>
                                <option value="Coaching/Tuition">Coaching/Tuition</option>
                                <option value="School/College">School/College</option>
                                <option value="Others">Others</option>
                            </select>
                            <input type="text" class="col-md-6 form-control" id="reference_name" name="reference_name" placeholder="Name Source" style="display: none;" />
                            </span>
                        </span>
                        <!--<center><div style="ppadding: 0px;" class="g-recaptcha pull-right" data-sitekey="6LdkqGsUAAAAAHaGJsKsrkrvewL8eWH2U_xGOttR"></div></center>-->
                        
                        <div class="fform-group">
                    <input type="checkbox"  class="field_terms2" id="field_terms" checked style="text-align:justify;">&nbsp;&nbsp;&nbsp;<label for="field_terms">Yes,I have read and provide my consent for my data to be processed for the purposes as mentioned in the <a href="#"> Privacy Policy</a> and the <a href="https://www.searchurcollege.com/terms_conditions" target="_blank" id="btnShowPopup">Term & Condition</a></label>
                     </div>

                     <div class="fform-group" style="margin-top: -15px;">
                   <input type="checkbox"  class="field_terms2" id="field_terms2" value="" checked/ style="text-align:justify;">&nbsp;&nbsp;&nbsp;<label for="field_terms2">I agree to be contacted for service related information and promotional purposes.<i class="fa fa-info-circle"></i></label>  
                  </div>

                        <div class="col-md-12" style="padding: 0px;">
                        <div class="col-md-5">
                            Already Registered?</b>
                            <br /><a href="#" data-toggle="modal" data-target="#login" data-dismiss="modal"><b>Login Here</b></a>
                        </div>
                        <div class="col-md-7">
                            <div id="msg">
                                <span id="rsuccess" class="pull-right" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> <span id="m1"></span></span>
                                <span id="rerror" class="pull-right" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <span id="m2"></span></span>
                            </div>
                            <button id="sub" type="submit" class="btn btn-primary pull-right">Register</button>
                        </div>
                        <div id="regButton" class="col-md-4" style="display: none; background: #DE4313;">
                        </div>
                        </div>
                        <br /><br />
                    </form>
        		</div>
        		<div id="col3" class="col-md-12" style="display: none; color: black; background: transparent; z-index: 1000; padding: 0px 40px 20px 40px;">
                    <div class=".why" style="ddisplay: none; background: #DAEBFA; padding: 10px; text-align: left; color: black!important;">
                <h3 style="color: #5D9BD0;"><i class="fas fa-info-circle fa-lg"></i>
                <b>Premium Membership Offer</h3>
                <span title="Close" style="position: absolute; top: 10px; right: 30px; cursor: pointer;" onclick="window.history.back();"><i class="fa fa-times" aria-hidden="true"></i></span> </b>
                <br /><h4>Get the <b style="color: green;">Premium</b> benifits <strong>only @ <i class="fa fa-inr"></i> 199/- </strong></h4>
                <br />
                
                    
                    <span><!--<i class="pull-right fa fa-info"></i>-->
                    <span id="msg1" class="div-no-mobile"><br />
                        <lh><h4><strong> What will you get: </strong></h4></lh></br>
                    <ul>
                        <?php 
                            $sql="SELECT exam_exercise_name from cat03_exam_exercise where super_cat_id='$master_id'    order by sort_order LIMIT 5" ;
                            $result=$conn->query($sql);
                            if($result->num_rows>0){
                                foreach ($result as $var) {
                                    $exams_name=$var['exam_exercise_name'];  
                                   
                                    ?> 
                                  <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Last 10 years question banks for <strong> <?php echo $exams_name ?>.</strong></li> <?php
                                }
                              //  echo $master_id
                            }
                        ?>
                        
                       
                        
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp There will be more 40,000 questions</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Minimum 10 sets of chapter wise practice test for each subject in MBA syllabus</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp Unlimited full length practice test & Colleges</li>
                    </br>
                   
                        <lh><h4><strong> Information About:</strong></h4></lh></br>
                    <ul>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp   Exams </li>
                       
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbsp  Courses</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspTop Colleges & Universities</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspEligibility Criteria For Admission</li>
                        <li>&nbsp <i class="fa fa-check" style="color: green"></i>  &nbsp &nbspRanking of Universities & Colleges</li>
                       
                    </ul>
                </br>
                   </span>
             <!--   <table class="table stable-striped" border=1>
                    <tr style="background: gray; color: white;"><td width="45%"><b>Benifits</b></td><td><b>Standard</b></td><td style="background: green"><b>Premium</b></td></tr>
                    <tr><td class="first">10 Years Questions Bank</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Tests History & Progress Tracking</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Important Dates - Mobile Alerts</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>

                    
                    <?php
                        $c='Relevant Subjects';
                        for($i=0;$i<sizeof($a);$i++)
                        {
                            //  echo '<tr><td class="first">'.$a[$i].'</td><td></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>';
                        }
                       // echo '<tr><td colspan="2" class="first">Covering '.$c.' and many more...</td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>';
                    ?>

                    <tr><td class="first">Top Colleges & Universities</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">Eligibility & Admission</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">College Rankings</td><td><img src="../img/tick.png" height="20" /></td><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    <tr><td class="first">College Brochures</td><td><img src="../img/tick.png" height="20" /><td class="third"><img src="../img/tick2.png" height="20" /></td></tr>
                    
                   <tr><td class="first">365 Days Support</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>
                    <tr><td class="first">Career Guidance</td><td></td><td><img src="../img/tick.png" height="20" /></td></tr>
                </table> -->
                <center>
                	   <form method="POST" name="customerData" action="https://www.searchurcollege.com/cca/ccavRequestHandler.php">
                            <!--<input type="hhidden" id="na" name="na" />
                            <input type="hhidden" id="ct" name="ct" />
                            <input type="hhidden" id="ph" name="ph" />
                            <input type="hhidden" id="em" name="em" />-->
                            <?php
                                $dateTimeObject = new DateTime('now');
                                $uid=$user_name=$contact=$email='';
                                if(isset($_SESSION['uid']))
                                    $uid=$_SESSION['uid'];
                                if(isset($_SESSION['user_name']))
                                    $user_name=$_SESSION['user_name'];
                                if(isset($_SESSION['contact']))
                                    $contact=$_SESSION['contact'];
                                if(isset($_SESSION['email']))
                                    $email=$_SESSION['email'];
                                $tn=$dateTimeObject->format('Ymdhis');
                                $oid=$uid.'-'.$dateTimeObject->format('Ymdhis');
                            ?>
                            <input type="hidden" name="tid" id="tid" value="<?php echo $tn;?>" rreadonly />
                            <input type="hidden" name="merchant_id" value="188437"/>
                            <input type="hidden" name="order_id" value="<?php echo $oid;?>"/>
                            <input type="hidden" name="amount" value="199"/>
                            <input type="hidden" name="currency" value="INR"/>
                            <input type="hidden" name="redirect_url" value="https://www.searchurcollege.com/cca/success.php" />
                            <input type="hidden" name="cancel_url" value="https://www.searchurcollege.com/cca/failure.php" />
                            <input type="hidden" name="language" value="EN"/>
                            <input type="hidden" id="na" name="billing_name" value="<?php echo $user_name;?>" />
                            <input type="hidden" id="ct" name="billing_city" />
                            <input type="hidden" id="ph" name="billing_tel" value="<?php echo $contact;?>" />
        		        	<input type="hidden" id="em" name="billing_email" value="<?php echo $email;?>" />
                        <button type="submit" class="btn btn-primary">Complete your Payment</button>
                    </form>
                </center>
            </div>
                </div>
            </div>
        </div>
      </div>
    </div>
</div>

<!-- #modal 2 -->



<div id="otp" style="display: none; z-index: 10000; color: black;">
    <center>
    <form id="frmOTP">
        <h4>Enter OTP sent to your mobile</h4>
        <br />
        <div class="input-group">
            <input type="text" class="form-control" id="otp_box" name="otp" placeholder="OTP" sstyle="width: 150px;" required />
            <span class="input-group-btn">
                <button type="submit" class="btn btn-success">Go</button>
            </span>
        </div>
        <div id="v5" style="display: block;">Not received? <a class="resendOTP" href="">Resend OTP</a></div>
        <div id="v4" style="display: none;"><span style="font-weight: bold;">OTP sent</span><i class="fa fa-send" style="margin-left: 5px; margin-top: 20px;"></i></div>
        <div id="v1" style="display: none;"><span style="font-size: 20px; font-weight: bold;">Verifying</span><i class="fa fa-circle-o-notch fa-spin" style="font-size: 24px; margin-left: 5px; margin-top: 20px;"></i></div>
        <div id="v2" style="display: none;"><span style="color: green; font-weight: bold;">Number Verified</span><i class="fa fa-check" style="font-size: 24px; margin-left: 5px; margin-top: 20px; color: green;"></i></div>
        <div id="v3" style="display: none;"><span style="color: red; font-weight: bold;">Incorrect OTP</span><!--<i class="fa fa-close" style="margin-left: 5px; margin-top: 20px; color: red; margin-right: 10px; font-weight: bold;"></i><a class="resendOTP" href="">Resend OTP?</a></div>-->
    </form>
    </center>
</div>

<sscript src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    $('#why_head').click(function(){
        $(this).find('i').toggleClass('fa-plus fa-minus')
        $('#msg1').toggle().fade();
    });
    function repeat()
    {
        $('#password2').val($('#password1').val());
    }
</script>

<script type="text/javascript">
    $(document).ready(function(){
        $('#L1').change(function(event) {
           // alert('ss');
          $('#L2').val('');
          id=$('#L1').val();
          $.post(
           'https://www.searchurcollege.com/connection/info.php?id='+id,
            $(this).serialize(),
            function(data){
              $("#course_interested").html(data);
            }
          );
          return false;
        });   

        //Register User
        $('#frmRegister').submit(function(event) {
          $.post(
           'https://www.searchurcollege.com/connection/user_register.php',
            $(this).serialize(),
            function(data){
                //$('#v3').fadeIn().delay(2000).fadeOut();
                if(data==1 || data.substring(0,3)=="Log")
                {
                    $('#m1').text(data);
                    $("#frmRegister input").prop("disabled", true);
                    $("#frmRegister select").prop("disabled", true);
                    $('#sub').prop('disabled', true);
                    $('#rsuccess').css('display','block');
                    $('#rsuccess').fadeIn().delay(2000).fadeOut();
                    $('#otp').css('display', 'block');
                    $('#otp_box').focus();
                }
                else
                {
                    $('#m2').text(data);
                    $('#rerror').css('display','block');
                    $('#rerror').fadeIn().delay(2000).fadeOut();
                }
          });
          return false;   
        });

        //Verify OTP
        $('#frmOTP').submit(function(event) {
          phone=$('#phone').val();
          $('#v1').show();
          $.post(
           'https://www.searchurcollege.com/connection/verify_otp.php?phone='+phone,
            $(this).serialize(),
            function(data){
              $('#v1').hide();
                if(data=='found' || data.substring(0,3)=="Log")
              {
                $('#v2').show();
                $('#v3').hide();
                $('#v4').hide();
                $('#v5').hide();
                $('#na').val($('#first_name').val()+' '+$('#last_name').val());
                $('#ct').val($('#city').val());
                $('#ph').val($('#phone').val());
                $('#em').val($('#email2').val());

                $("#d").removeClass("modal-lg"); 
                $('#otp').css('display','none');
                $('#col1').css('display','none');
                $('#col2').css('display','none');
                location.reload();
                //$('#register .close').click();

                //$('#col3').css('display','block');  //PAYMENT POPUP
                // window.setTimeout(function(){
                //     window.location.href = "https://www.searchurcollege.com/connection/pay_now.php";
                // }, 1000);
                //$('#register .close').click();
                /*setTimeout(function() {
                    $('#otp').hide();
                    //$('#col3').css('display','block');
                    location.reload();
                    $("#d").removeClass("modal-lg"); 
                    $("#register").removeClass("modal-lg");
                    //alert("11");
                    $('#col1').css('display','none');
                    $('#col2').css('display','none');
                }, 2000);*/
              }
              else
              {
                $('#v2').hide();
                $('#v3').show();
                $('#v4').hide();
              }
            }
          );
          return false;   
        });   

        //Resend OTP
        $('.resendOTP').click(function(event) {
          $('#v1').hide();
          $('#v2').hide();
          $('#v3').hide();
          $('#v4').fadeIn().delay(2000).fadeOut();
          $('#v5').fadeOut().delay(2000).fadeIn();
          phone=$('#phone').val();
          $.post(
           'https://www.searchurcollege.com/connection/resend_otp.php?phone='+phone,
            $(this).serialize(),
            function(data){

            }
          );
          return false;   
        });   
    });
    $('#pclose').on('click', function () {
        location.reload();
    });
    $("#r1").on('input', function () {
        var val = this.value;
        if(val=='Others' || val=='Coaching/Tuition' || val=='School/College')
        {

            $("#r1").removeClass("col-md-12");
            $("#r1").addClass("col-md-6");

            $('#reference_name').show();
            $('#reference_name').focus();
             $('#reference_name').prop('required',true);
        }
        else
        {
            $("#r1").removeClass("col-md-6");
            $("#r1").addClass("col-md-12");
            $('#reference_name').hide();
            $('#reference_name').removeAttr('required',true);
        }
    });
</script>

<script>
  $('.field_terms2').click(function () {
    //check if checkbox is checked
    if ($("#field_terms").is(':checked') && $("#field_terms2").is(':checked')) {
        
        $('#sub').removeAttr('disabled'); //enable input
        
    } else {
        $('#sub').attr('disabled', true); //disable input
    }
});

</script>