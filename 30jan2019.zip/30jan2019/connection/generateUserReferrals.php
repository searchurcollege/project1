<?php
    $i=1;
    include('dbconnect.php');
    $sql="SELECT user_name,user_id FROM users WHERE balance_amt=0";
    $result=$conn->query($sql);
    foreach($result as $var)
    {
        $user_id=$var['user_id'];
        $user_name=$var['user_name'];
        $a=genrate_ref();
        $sql2="INSERT INTO suc_user_referrals (user_id, user_referral_code, user_status) VALUES('$user_id', '$a', 1)";
        $result2=$conn->query($sql2);
        $i++;
    }
    echo "Generated";
    function genrate_ref()
    {
        include("dbconnect.php");
        $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXY";
        $res = "";
        for ($i = 0; $i < 8; $i++) {
            $res .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        //$res="12345678";
        $sql1="SELECT user_referral_code from suc_user_referrals where user_referral_code=".$res;
        $result1=$conn->query($sql1);
        if($result1->num_rows>0){
            genrate_ref();
        }
        else
            return(strtoupper($res));    
        
    }
?>