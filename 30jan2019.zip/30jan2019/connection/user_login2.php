<?php
    include('dbconnect.php');
    $email=$_REQUEST['email'];
    $password=$_REQUEST['password'];
    $sql="SELECT id, first_name, email, contact, super_cat_id, course_interested, balance_amt, photo FROM users WHERE email='$email' AND password='$password' AND status=1";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        while($row=$result->fetch_assoc())
        {
            $id=$row["id"];
            $first_name=$row["first_name"];
            $email=$row["email"];
            $contact=$row["contact"];
            $sid=$row["super_cat_id"];
            $stream=$row["course_interested"];
            $ba=$row["balance_amt"];
            $photo=$row["photo"];
            if($photo=="")
                $photo="user1.png";
        }
        session_start();
        $_SESSION['uid']=$id;
        $_SESSION['user_name']=$first_name;
        $_SESSION['email']=$email;
        $_SESSION['contact']=$contact;
		$_SESSION['regUsrId']=$email;
		$_SESSION['stream']=$stream;
		$_SESSION['ba']=$ba;
        $_SESSION['photo']=$photo;
        $_SESSION['sid']=$sid;

        $sql="SELECT balance_amt FROM users WHERE email='$email'";
        $result=$conn->query($sql);
 
        if($result->num_rows>0)
        {
            foreach($result as $var)
                $balance_amt=$var['balance_amt'];
        }
        if($balance_amt>0)
            echo '2';   //Not Paid
        else
            echo '1';   //Paid
    }
    else
        echo '0';       //Not Registered

?>