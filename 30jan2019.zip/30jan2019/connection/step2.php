<?php
    include('header.php');
    $ph=$_SESSION['contact'];
    $stream=$_SESSION['stream'];
    include('dbconnect.php');

    $sql1="SELECT super_cat_id FROM `tbl_course_category` WHERE category='$stream'";
        $result1=$conn->query($sql1);
        foreach ($result1 as $var1)
            $master_id=$var1['super_cat_id'];
?>
    <title>SearchUrCollege.com - Payment Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <style type="text/css">
        li{
            font-size: 15px;
        }
        .b {font-weight: bold; color: #D9534F;}
    </style>
<style>
    .strip1 {
        /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ff9934+0,fffdfc+66 */
        background: #005B87; /* Old browsers */
        background: -moz-linear-gradient(left, #005B87 0%, transparent 66%); /* FF3.6-15 */
        background: -webkit-linear-gradient(left, #005B87 0%, transparent 66%); /* Chrome10-25,Safari5.1-6 */
        background: linear-gradient(to right, #005B87 0%, transparent 66%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#005B87', endColorstr='transparent',GradientType=1 ); /* IE6-9 */
    }
    .shadow1 { text-shadow: 1px 1px 1px white;}
</style>

    <body style="background: url('images/payment_background.jpg'); background-size: cover;">
    <div class="container" style="margin-top: 30px; opacity: .9;">
        <div class="col-md-2"></div>
        <div class="col-md-8">
    		<div class=".wwhy" style="ddisplay: nvone; background: white; padding: 20px; text-align: left; color: black!important; font-size: 40px;">
                <h3 style="color: #015A86; margin-top: -5px;"><i class="fa fa-info-circle fa-lg"></i>
                <!--<b>The Never Before Membership Offer</h3>-->
                <b></b>Go for PREMIUM MEMBERSHIP at &nbsp;<span class="b"><i class="fa fa-inr" aria-hidden="true"></i> <b>199/-</b></span> only.</h3>
                <span style="position: absolute; top: 10px; right: 30px;" onclick="location.href = 'https://www.searchurcollege.com'"><button class="btn btn-default btn-sm pull-left"><i class="fa fa-times"  aria-hidden="true"></i></button></span> </b>
                <h4><b>Comprehensive Program</b> for Aspirants.</h4>
    	   <form method="POST" name="customerData" action="https://www.searchurcollege.com/cca/ccavRequestHandler.php">
                <!--<h3><b>Go PREMIUM at &nbsp;<span class="b"><i class="fa fa-inr" aria-hidden="true"></i> <b>199/-</b></span> only.</b></h3>-->
                <!--<img src='../img/premium2.png' /> -->
                <!--<img src='../img/premium.png ' style="position: absolute; right: 50px; margin-top: -50px; height: 150px;" />-->
                    <span id="msg1">
                        <h3 style="margin-top: 20px; color: #015A86;">Benefits of <span style="color: black; font-weight: bold;">Premium Membership</span></h3>
                        <ul style="padding-left: 30px;">
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;<font color="red"><span class="b">Over</span> <span style="font-size: 20px;">45000</span><span class="b"> Questions to Practice with</span></font></li>
                        <?php 
                            $sql="SELECT exam_exercise_name from cat03_exam_exercise WHERE super_cat_id='$master_id' AND pay_now_sort_order!=0 order by pay_now_sort_order LIMIT 4";
                            $result=$conn->query($sql);
                            echo '<li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;Last <span class="b">10 Years Question Banks</span> for ';
                            while($row=$result->fetch_assoc())
                            {
                               $exam_name=$row['exam_exercise_name'];
                               echo '<span class="b">'.$exam_name.', </span>';
                            }
                            echo ' and more...</li>';
                        ?>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;Questions with Solutions - <span class="b">Model Question Papers, Chapterwise Tests & Pactice Sets</span></li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;Simplified Practice Test process</li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;<span class="b">Test Results</span> & <span class="b">Progress Tracking</span></li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;All modules included for extensive preparation</li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;Improves chance to <span class="b">CRACK</span> Competitive Entrance Exams</li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;<span class="b">Maximizes Score in Minimum Time</span></li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp;&nbsp;&nbsp;True value to money</li>
                        <h4 style="margin-top: 20px;"><strong> Also get Information about:</strong></h4>
                    <ul>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp &nbspCompetitive Exams </li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp &nbspDesired Courses</li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp &nbspTop Colleges & Universities</li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp &nbspAdmission FEE & Eligibility</li>
                        <li><i class="fa fa-check" style="color: green"></i>  &nbsp &nbspRanking of Universities & Colleges and many more...<br /><br /></li>
                    </ul>
                            <!--<input type="hhidden" id="na" name="na" />
                            <input type="hhidden" id="ct" name="ct" />
                            <input type="hhidden" id="ph" name="ph" />
                            <input type="hhidden" id="em" name="em" />-->
                            <?php
                                $dateTimeObject = new DateTime('now');
                                $tn=$dateTimeObject->format('Ymdhis');
                                $uid=$_SESSION['uid'];
                                $oid=$uid.'-'.$dateTimeObject->format('Ymdhis');
                            ?>
                            <input type="hidden" name="tid" id="tid" value="<?php echo $tn;?>" rreadonly />
                            <input type="hidden" name="merchant_id" value="188437"/>
                            <input type="hidden" name="order_id" value="<?php echo $oid;?>"/>
                            <input type="hidden" name="amount" value="199"/>
                            <input type="hidden" name="currency" value="INR"/>
                            <input type="hidden" name="redirect_url" value="https://www.searchurcollege.com/cca/success.php" />
                            <input type="hidden" name="cancel_url" value="https://www.searchurcollege.com/cca/failure.php" />
                            <input type="hidden" name="language" value="EN"/>
                            <input type="hidden" id="na" name="billing_name" value="<?php echo $_SESSION['user_name']?>" />
                            <input type="hidden" id="ct" name="billing_city" />
                            <input type="hidden" id="ph" name="billing_tel" value="<?php echo $_SESSION['contact']?>" />
        		        	<input type="hidden" id="em" name="billing_email" value="<?php echo $_SESSION['email']?>" />

                            <?php
                                if(!preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
                                    echo '<img class="div-no-mobile" src="../img/premium3.png" style="position: absolute; right: 55px; margin-top: -200px; height: 150px;" />';
                            ?>
                            <center><button id="make" type="submit" sstyle="position: absolute; right: 50px; margin-top: -40px;" class="btn btn-success btn-lg"><b><i class="fa fa-inr"></i> Make Payment</b></button>
                            <span id="ref" class="pull-right" style="margin-top: 20px; font-size: 14px; cursor: pointer;"><b>Having Referral Code?</b></span></center>
                            <span id="ref" class="pull-right" style="margin-top: -20px; font-size: 14px; cursor: pointer; color:gray;"><b><small title="Referral Code is a....">What is that?</small></b></span></center>
                    </form>
    		</div>
		</div>
    </div>
    
<style>
    #referral
    { 
        position:fixed;
        top: 50%;
        left: 52%;
        width: 300px;
        margin-top: -9em; /*set to a negative number 1/2 of your height*/
        margin-left: -15em; /*set to a negative number 1/2 of your width*/
        bborder: 1px double orange;
        bborder-radius: 10px;
        background: orange;
        padding: 30px;
    }
</style>
<div id="referral" style="display: none; z-index: 10000; color: black; bbox-shadow: 5px 5px lightgrey;">
    <center>
    <span id="close" class="pull-right" style="margin-top: -20px; margin-right: -20px; cursor: pointer; color: white;">Close</span>
    <br />
    <form id="frmReferral">
        <div class="input-group" id="ref2">
            <input list="browsers" name="browser" class="form-control"  />
              <datalist id="browsers">
                <option value="PT Raipur">
                <option value="Sharma Coaching Center, Agra">
                <option value="Sharma Coaching Center, Delhi">
                <option value="Prushottam Classes, Patna">
                <option value="RS Coaching, Patna">
                <option value="Gupta Sir Maths Coaching, Kanpur">
            </datalist>
            <!--<input type="text" class="form-control" style="width: 100%;" id="ref_code" name="ref2" placeholder="Your Referral Code" required />-->
            <br />
            <span id="rcsuccess" style="display: none; color: green; margin-left: 10px; margin-top: 5px;"><i class="fa fa-smile-o" style="font-size:20px"></i> Referral Code Applied</span></span>
            <span id="rcerror" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Invalid Referral Code</span></span>
            <span id="rcerror2" style="display: none; color: red; margin-left: 10px; margin-top: 7px;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Code Limit Exceeded</span></span>
            <br />
            <button type="submit" class="btn btn-block btn-primary">G O</button>
        </div>
    </form>
    </center>
</div>


<script>
    $('#ref').click(function(event) {
      $('#referral').css('display', 'block');
      $("#make").attr("disabled", true);
      return false;
    });
    $('#close').click(function(event) {
      $('#referral').css('display', 'none');
      $("#make").removeAttr("disabled");
      return false;
    });

    //Referral Choice
    $('#ref1').click(function(event) {
      $('#ref1').hide();
      $('#ref2').show();
      return false;
    });

    //Has Referral
    $('#frmReferral').submit(function(event) {
      referral=$('#ref_code').val();
      $.post(
       'https://www.searchurcollege.com/connection/referral_check.php?referral='+referral,
        $(this).serialize(),
        function(data){
            if(data==0)
            {
                $('#rcsuccess').css('display','block');
                $('#rcsuccess').fadeIn().delay(2000).fadeOut();
            }
            window.setTimeout(function(){
                window.location.href = "https://www.searchurcollege.com/connection/step3.php";
            }, 3000);
        }
      );
      return false;   
    });   
</script>

