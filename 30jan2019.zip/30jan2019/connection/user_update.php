<?php

include('dbconnect.php');
    session_start();    
    $email=$_SESSION['email'];
    
    if(isset($_REQUEST['email'])){
        $email=$_REQUEST['email'];
        $first_name=$_REQUEST['first_name2'];
        $last_name=$_REQUEST['last_name2'];
        $current_location=$_REQUEST['current_location'];
        $preferred_location=$_REQUEST['preferred_location'];
        $address=$_REQUEST['address'];
        $city=$_REQUEST['city'];
        $state=$_REQUEST['state'];
        $pincode=$_REQUEST['pincode'];
        $dob=$_REQUEST['dob'];
        $gender=$_REQUEST['gender'];
    
    $sql="UPDATE users SET first_name='$first_name', last_name='$last_name', current_location='$current_location', preferred_location='$preferred_location',address='$address', city='$city', state='$state', pincode='$pincode', dob='$dob', gender='$gender',  course_interested='$course_interested'  WHERE email='$email'";
    $result=$conn->query($sql);

}
    else{
         session_start();    
    $email=$_SESSION['email'];
    $password=$_REQUEST['newPassword'];
    
    echo $currentDir = getcwd();
    
    $uploadDirectory = "/";
    $errors = []; // Store all foreseen and unforseen errors here

    $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions

    $fileName = $_FILES['myfile']['name'];
    $fileSize = $_FILES['myfile']['size'];
    $fileTmpName  = $_FILES['myfile']['tmp_name'];
    $fileType = $_FILES['myfile']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    $uploadPath = $uploadDirectory . basename($fileName); 

    if (isset($_POST['submit'])) {

        if (! in_array($fileExtension,$fileExtensions)) {
            $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
        }

        if ($fileSize > 2000000) {
            $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
        }

        if (empty($errors)) {
            $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

            if ($didUpload) {
                echo "The file " . basename($fileName) . " has been uploaded";
            } else {
                echo "An error occurred somewhere. Try again or contact the admin";
            }
        } else {
            foreach ($errors as $error) {
                echo $error . "These are the errors" . "\n";
            }
        }
    }

}
?>