<?php
    $id=$_REQUEST['id'];
    $eid=$_REQUEST['eid'];
    session_start();
    $_SESSION['eid']=$eid;
    include('dbconnect.php');
    $sql1="SELECT main_cat_id FROM exam WHERE exam_id='$eid'";
    $result1=$conn->query($sql1);
    while($row1=$result1->fetch_assoc())
        $main_cat_id=$row1["main_cat_id"];
    if(isset($_SESSION['email']))
    {
        $email=$_SESSION['email'];
        
        if($id==$_SESSION['sid'])
        {
            
            if($main_cat_id==23)
            {
                $url='1';
            }
            else
            {
            $sql="SELECT balance_amt FROM users WHERE email='$email'";
            $result=$conn->query($sql);
            while($row=$result->fetch_assoc())
                $balance_amt=$row['balance_amt'];
            if($balance_amt==0)
            {
                $dt=date('Y-m-d');
                $sql="SELECT COUNT(id) AS count FROM user_exam WHERE user_id='$email' AND SUBSTR(created_at,1,10)='$dt'";
                $result=$conn->query($sql);
                while($row=$result->fetch_assoc())
                    $count=$row['count'];
                if($count>15)
                    $url='4';
                else
                    $url='1';//https://www.searchurcollege.com/exam/start-exam/'.$eid;
            }
            else
                $url='2';//"https://www.searchurcollege.com/connection/pay_now.php";
            }
        }
        else
            $url='3';
    }
    // elseif ($main_cat_id==23) {
    //     $url='1';
    // }
    else
        $url='0';///https://www.searchurcollege.com/connection/login.php?eid='.$eid;
    echo $url;
?>
