<?php
include('dbconnect.php');
$sql="SELECT exam_id, exam_name FROM exam";
$result=$conn->query($sql); 
$i=1;      
while($row=$result->fetch_assoc())
{
    $part2='';
    $exam_id=$row["exam_id"];
    $exam_name=strtoupper($row["exam_name"]);
    $part1=substr($exam_name,0,3);
    if($part1=='SET')
    {
        $part2=substr($exam_name,4,20);
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }        

    $part1=substr($exam_name,0,7);
    if($part1=='SRMJEEE')
    {
        $part2=substr($exam_name,8,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,7);
    if($part1=='MHT-CET')
    {
        $part2=substr($exam_name,8,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,8);
    if($part1=='JEE MAIN')
    {
        $part2=substr($exam_name,9,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='KCET')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='JCECE')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='VITEEE')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,8);
    if($part1=='JEE ADV.')
    {
        $part2=substr($exam_name,9,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='BITSAT')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='UPSEE')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='CUCET')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,3);
    if($part1=='IPU')
    {
        $part2=substr($exam_name,4,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='AMUEEE')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='KIITEE')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='CLAT')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='AILET')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='LSAT')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='ACLAT')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='CUCET')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='DU LLB')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }


    $part1=substr($exam_name,0,4);
    if($part1=='NEET')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='JIPMER')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='AIPMT')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='AIIMS')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='NIPER')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='AFMC')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='GPAT')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,7);
    if($part1=='BHU PMT')
    {
        $part2=substr($exam_name,8,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,8);
    if($part1=='AMU MBBS')
    {
        $part2=substr($exam_name,9,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='MH CET')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,11);
    if($part1=='CMC Vellore')
    {
        $part2=substr($exam_name,12,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,6);
    if($part1=='COMEDK')
    {
        $part2=substr($exam_name,7,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='DPMT')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,3);
    if($part1=='XAT')
    {
        $part2=substr($exam_name,4,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,3);
    if($part1=='MAT')
    {
        $part2=substr($exam_name,4,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='CMAT')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='NMAT')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='SNAP')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,3);
    if($part1=='CAT')
    {
        $part2=substr($exam_name,4,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='JAMIA')
    {
        $part2=substr($exam_name,6,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,4);
    if($part1=='IIFT')
    {
        $part2=substr($exam_name,5,20);
        ////echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,5);
    if($part1=='WBJEE')
    {
        $part2=substr($exam_name,6,20);
        //echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $part1=substr($exam_name,0,11);
    if($part1=='JEE ADV. 20')
    {
        $part2=substr($exam_name,12,20);
        echo '<br>P='.$part1;
        $sql2="UPDATE exam SET exam_sort_order=$part2 WHERE exam_id=$exam_id";
        $result2=$conn->query($sql2); 
    }

    $i++;
}
echo "All exams names are re-sorted.<br /><br />Thanks<br />Admin";
?>