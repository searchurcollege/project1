<script type="text/javascript">
function reload()
{
img = document.getElementById("capt");
img.src="captcha-image-adv.php?rand_number=" + Math.random();
}
</script>

<div class="input-group">
<img src="captcha-image-adv.php" id="capt" style="padding-left: 10px;">
<input type="text" name="t1" class="form-control" placeholder="Captcha" style="margin-left: 15px; padding-right:80px; width: 20px;">
<i class="fa fa-refresh" onClick=reload(); style="padding-left: 10px;" ></i>

</div>






