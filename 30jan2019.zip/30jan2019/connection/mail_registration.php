<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<style>
body {font-family: tahoma;}
table {border:1px solid black;}
td,th {border:1px solid black;}
</style>
<?php
ob_start();
$to1=$email;
$to2='contact@searchurcollege.com';
$from="contact@searchurcollege.com";
$from_name="SearchUrCollege";
$cc="searchurcollege@gmail.com";
$subject1="Welcome ".ucwords($user_name);
$subject2="New Registration - ".$user_name;
$img='<img src="https://www.searchurcollege.com/img/logo2.png" width="100px">';
$signature='Administrator<br />
    <b>SearchUrCollege</b><br />'.$img.'<br />
    B-41, 2nd Floor, Sector-2<br />
    Noida, Uttar Pradesh <small>(INDIA)</small><br />
    <small><i class="fa fa-envelope"></i> <a href="mailto:'.$from.'">'.$from.'</a>
    <i class="fa fa-phone"></i> <a href="tel:+911204750214">+91-120-475 0214</a>
    <i class="fa fa-globe"></i> <a target="_blank" href="https://www.searchurcollege.com">www.searchurcollege.com</a></small><br />';
$message1='Dear '.$user_name.',<br /><br />Thanks for Joining <b>SearchUrCollege - <i>One Stop Solution for Students</i></b>.<br /><br />We wish you Good Luck for your Test-Prepration & Competitive Exams.<br /><br /><br />'.$signature;
$message2='Dear Admin,<br /><br />A new Registration is made at our www.searchurcollege.com portal. Details are as under: <br />
    <table width="50%">
    <tr><td width="50%">Name</td><td>'.$user_name.'</td></tr>
    <tr><td>Email</td><td>'.$email.'</td></tr>
    <tr><td>Phone</td><td>'.$phone.'</td></tr>
    <tr><td>Current Location</td><td>'.$current_location.'</td></tr>
    <tr><td>Preferred Location</td><td>'.$preferred_location.'</td></tr>
    <tr><td>Course Interested</td><td>'.$course_interested.'</td></tr>
    <tr><td>Reference Source</td><td>'.$reference.'</td></tr>
    <tr><td>Reference Name</td><td>'.$reference_name.'</td></tr>
    </table><br /><br />'.$signature;

$message1=file_get_contents("mail_registration.txt");
//echo $message1;
//echo '<br /><br /><br />';
//echo $message2;

//Sanitize Message
//$message1=preg_replace('/<[^>]*>/', '', $message1);
//$message2=preg_replace('/<[^>]*>/', '', $message2);
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'To: '.$to.' <'.$to.'>' . "\r\n";
$headers .= 'From: '.$from_name.' <'.$from.'>' . "\r\n";
$headers .= 'Cc: '.$cc . "\r\n";

// Mail to User
if(mail($to1, $subject1, $message1.$signature, $headers))
    ;
// Mail to Admin
if(mail($to2, $subject2, $message2, $headers))
    ;
?>